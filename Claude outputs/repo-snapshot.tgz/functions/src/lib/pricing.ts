import { HttpsError } from "firebase-functions/v2/https";

/**
 * The single gate between a cached game document and a bet. Both wallets
 * (placeBet and placeLeagueBet) price through here, so "is this game
 * bettable, and at what price?" has one answer.
 */

export type Side = "home" | "away";

export interface PricedTeam {
  name: string;
  abbreviation: string;
  color: string;
  odds: number;
}

export const NO_LINE_MESSAGE = "No line yet for this game. Check back closer to kickoff.";

/** Drift against the bettor larger than this fails loudly instead of shrinking the payout. */
export const MAX_ADVERSE_DRIFT = 0.05;

interface GameDoc {
  get(field: string): unknown;
}

function validOdds(x: unknown): x is number {
  return typeof x === "number" && Number.isFinite(x) && x > 1;
}

/**
 * The picked side and its opponent, or a `failed-precondition` when the feed
 * had no moneyline. `priced` must be explicitly true: documents written by the
 * old sync (hash-priced) have no flag and are refused until the next sync
 * rewrites them.
 */
export function requirePricedSide(game: GameDoc, side: Side): { team: PricedTeam; opponent: { abbreviation: string; name: string } } {
  const team = game.get(side === "home" ? "homeTeam" : "awayTeam") as Partial<PricedTeam> | undefined;
  const opponent = game.get(side === "home" ? "awayTeam" : "homeTeam") as { abbreviation?: string; name?: string } | undefined;
  if (game.get("priced") !== true || !team || !validOdds(team.odds)) {
    throw new HttpsError("failed-precondition", NO_LINE_MESSAGE);
  }
  return {
    team: {
      name: team.name ?? side,
      abbreviation: team.abbreviation ?? side.toUpperCase(),
      color: team.color ?? "#4A90D9",
      odds: team.odds,
    },
    opponent: { abbreviation: opponent?.abbreviation ?? "TBD", name: opponent?.name ?? "Opponent" },
  };
}

/**
 * Prices track a real moneyline, so they move between syncs. Drift in the
 * user's favour applies silently; drift against them past MAX_ADVERSE_DRIFT
 * is an `aborted` the client can retry at the new price.
 */
export function assertNoAdverseDrift(odds: number, expectedOdds: number | undefined): void {
  if (expectedOdds && odds < expectedOdds * (1 - MAX_ADVERSE_DRIFT)) {
    throw new HttpsError("aborted", `The price moved to ${odds.toFixed(2)}x before this went through. Tap again to take it.`);
  }
}
