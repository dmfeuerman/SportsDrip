import { setGlobalOptions } from "firebase-functions/v2";

setGlobalOptions({ region: "us-central1", maxInstances: 20 });

// Profile / identity
export { createProfile, checkUsername, updateAvatar, searchUsers } from "./callable/profile";
export { saveAppearance } from "./callable/avatar";
export { getPlayerProfile, updateFavoriteTeams } from "./callable/players";
export { getGameInsights } from "./callable/insights";
export { registerPushToken } from "./callable/push";

// Social graph
export {
  sendFriendRequest,
  respondFriendRequest,
  removeFriend,
  listFriends,
} from "./callable/friends";

// Economy
export { placeBet, cancelBet } from "./callable/bets";
export { createChallenge, respondChallenge, cancelChallenge } from "./callable/challenges";
export { purchaseItem, equipItem } from "./callable/shop";
export { purchaseMove, setMoveLoadout } from "./callable/moves";
export { openPrizeBox, claimPrizeBox, resetPrizeBox } from "./callable/prizes";
export { admobReward, claimAdReward } from "./http/adReward";

// Leagues — every league mutation goes through one of these.
export {
  createLeague,
  joinLeague,
  leaveLeague,
  updateLeagueSettings,
  inviteToLeague,
  endLeague,
  placeLeagueBet,
  takeBankLoan,
  repayLoan,
  requestPeerLoan,
  peerLoanAction,
} from "./callable/leagues";

// Background jobs
export { syncGames, pruneGames } from "./scheduled/syncGames";
export { onGameFinal, settleBetsSweep, refundStaleBets } from "./scheduled/settleBets";
export { leagueSweep } from "./scheduled/leagues";

// Side effects of committed writes (never inside a money transaction)
export { pushOnNotification } from "./triggers/push";
