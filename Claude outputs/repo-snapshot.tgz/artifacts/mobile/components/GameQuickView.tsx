import { MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Platform, StyleSheet, Text, View } from "react-native";
import BetModal, { type BetWallet } from "@/components/BetModal";
import GameDetailSheet, { type DetailBet } from "@/components/GameDetailSheet";
import KeyboardSheet from "@/components/KeyboardSheet";
import { useApp } from "@/context/AppContext";
import { useLeague } from "@/context/LeagueContext";
import { useToast } from "@/context/ToastContext";
import { useColors } from "@/hooks/useColors";
import { useGame } from "@/hooks/useGame";
import { prefetchGameInsights } from "@/hooks/useGameInsights";
import * as api from "@/lib/api";
import { newIdempotencyKey } from "@/lib/api";
import { openGameCenter } from "@/lib/gameCenter";
import { sideOdds, type Game, type Side } from "@/types/game";

/**
 * Tail (same side) or fade (other side) another member's league bet. Opens the
 * slip straight away with that league and their stake preselected.
 */
export interface FollowIntent {
  betId: string;
  kind: "tail" | "fade";
  leagueId: string;
  /** The member being followed. */
  name: string;
  /** Side this bet backs: theirs for a tail, the other one for a fade. */
  side: Side;
  stake: number;
  sourceTeamAbbr: string;
}

/**
 * The games-board detail sheet, openable from any bet by id.
 *
 * Loads games/{id} directly so bets on games that have left the board still
 * open. Upcoming games get the same bet slip as the board.
 *
 * Render it inside whatever sheet lists the bets: iOS only stacks a Modal on
 * one that is already presented when it is a descendant of it.
 */
export default function GameQuickView({
  gameId,
  onClose,
  defaultWallet,
  onLeave,
  follow,
}: {
  gameId: string | null;
  onClose: () => void;
  /** Preselected wallet in the bet slip (a league id). */
  defaultWallet?: string;
  /** Called before navigating to the game center, so a host sheet can close. */
  onLeave?: () => void;
  /** Skip the detail sheet and open a tail / fade slip directly. */
  follow?: FollowIntent | null;
}) {
  const c = useColors();
  const { game: loaded, loading, missing } = useGame(gameId);
  const game = loaded && loaded.id === gameId ? loaded : null;
  const { balance, bets } = useApp();
  const { leagues, activeLeagues, uid, placeLeagueBet, myLeagueBets } = useLeague();
  const { betLocked, show } = useToast();

  const [showDetail, setShowDetail] = useState(true);
  const [pending, setPending] = useState<{ game: Game; side: Side; key: string; friend?: boolean; follow?: FollowIntent } | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [slipError, setSlipError] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const followKey = follow ? `${follow.betId}:${follow.kind}` : null;
  useEffect(() => {
    setShowDetail(!followKey);
    setPending(null);
    setSlipError(null);
    if (gameId) prefetchGameInsights(gameId);
  }, [gameId, followKey]);

  // Tail / fade: once the game has loaded, go straight to the slip — unless it
  // has started, in which case the detail sheet explains betting is closed.
  const followOpened = useRef<string | null>(null);
  useEffect(() => {
    if (!follow || !game || !followKey) return;
    const key = `${game.id}:${followKey}`;
    if (followOpened.current === key) return;
    followOpened.current = key;
    if (game.status !== "upcoming" || game.startsAt <= Date.now()) {
      setShowDetail(true);
      return;
    }
    setPending({ game, side: follow.side, key: newIdempotencyKey(), follow });
  }, [follow, followKey, game]);
  useEffect(() => {
    if (!gameId) followOpened.current = null;
  }, [gameId]);
  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
  }, []);

  const detailBets: DetailBet[] = useMemo(() => {
    if (!gameId) return [];
    const out: DetailBet[] = bets.filter((b) => b.gameId === gameId);
    for (const lg of leagues) {
      for (const b of myLeagueBets[lg.id] ?? []) {
        if (b.gameId === gameId) out.push({ ...b, id: `${lg.id}:${b.id}`, wallet: lg.name });
      }
    }
    return out;
  }, [gameId, bets, leagues, myLeagueBets]);

  const wallets: BetWallet[] = useMemo(() => {
    const out: BetWallet[] = [{ id: "credits", label: "Credits", balance, kind: "credits" }];
    if (!pending || !uid) return out;
    for (const lg of activeLeagues) {
      if (!lg.allowedSports.includes(pending.game.sport)) continue;
      if (pending.game.startsAt >= lg.endsAt) continue;
      const me = lg.members[uid];
      if (!me) continue;
      out.push({ id: lg.id, label: lg.name, balance: me.leagueTokens, kind: "league" });
    }
    return out;
  }, [pending, activeLeagues, uid, balance]);

  // Same iOS constraint as the board: let the detail sheet finish dismissing
  // before the slip presents.
  const startBet = useCallback((g: Game, side: Side, friend?: boolean) => {
    setShowDetail(false);
    setSlipError(null);
    const open = () => setPending({ game: g, side, key: newIdempotencyKey(), friend });
    if (Platform.OS === "ios") timer.current = setTimeout(open, 350);
    else open();
  }, []);

  const confirmBet = useCallback(
    async (stake: number, walletId: string) => {
      if (!pending) return;
      const expectedOdds = sideOdds(pending.game, pending.side);
      if (expectedOdds === null) {
        setSlipError("No line yet for this game. Check back closer to kickoff.");
        return;
      }
      setSubmitting(true);
      setSlipError(null);
      let failure: string | null = null;
      if (walletId === "credits") {
        try {
          await api.placeBet({ gameId: pending.game.id, side: pending.side, stake, idempotencyKey: pending.key, expectedOdds });
        } catch (err) {
          failure = api.friendlyError(err);
        }
      } else {
        // The tail / fade reference only means something in the league it came from.
        const f = pending.follow && pending.follow.leagueId === walletId ? pending.follow : null;
        failure = await placeLeagueBet({
          leagueId: walletId,
          gameId: pending.game.id,
          side: pending.side,
          stake,
          idempotencyKey: `${pending.key}${walletId.slice(-4)}`,
          expectedOdds,
          ...(f ? (f.kind === "tail" ? { tailOf: f.betId } : { fadeOf: f.betId }) : {}),
        });
      }
      setSubmitting(false);
      if (failure) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error).catch(() => {});
        setSlipError(failure);
        return;
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
      {
        const t = pending.side === "home" ? pending.game.homeTeam : pending.game.awayTeam;
        const w = wallets.find((x) => x.id === walletId);
        betLocked({
          teamName: t.name,
          teamAbbr: t.abbreviation,
          teamColor: t.color,
          odds: expectedOdds,
          stake,
          payout: Math.round(stake * expectedOdds),
          currency: walletId === "credits" ? "credits" : "league",
          walletLabel: w?.label,
        });
      }
      setPending(null);
      onClose();
    },
    [pending, placeLeagueBet, onClose, wallets, betLocked]
  );

  if (!gameId) return null;

  if (!game) {
    if (loading || !missing) return null;
    return (
      <KeyboardSheet visible onClose={onClose} maxHeight="40%">
        <View style={styles.missing}>
          <MaterialCommunityIcons name="calendar-remove" size={28} color={c.mutedForeground} />
          <Text style={[styles.missingTitle, { color: c.foreground }]}>This game has been archived</Text>
          <Text style={[styles.missingBody, { color: c.mutedForeground }]}>
            Finished games drop off the board after two days. The bet keeps its result.
          </Text>
        </View>
      </KeyboardSheet>
    );
  }

  const team = pending ? (pending.side === "home" ? pending.game.homeTeam : pending.game.awayTeam) : null;

  return (
    <>
      <GameDetailSheet
        game={showDetail ? game : null}
        onClose={onClose}
        onBet={startBet}
        onChallenge={(g, side) => startBet(g, side, true)}
        bets={detailBets}
        onOpenCenter={(g) => {
          onClose();
          onLeave?.();
          openGameCenter(g.id, g.status === "upcoming" ? "matchup" : "live");
        }}
      />
      {pending && team && (
        <BetModal
          visible
          onClose={onClose}
          onConfirm={confirmBet}
          teamName={team.name}
          teamAbbr={team.abbreviation}
          teamColor={team.color}
          odds={sideOdds(pending.game, pending.side)}
          game={pending.game}
          side={pending.side}
          wallets={wallets}
          defaultWallet={pending.follow?.leagueId ?? defaultWallet}
          defaultStake={pending.follow?.stake}
          context={
            pending.follow
              ? {
                  icon: pending.follow.kind === "tail" ? "account-multiple-plus" : "account-switch",
                  text:
                    pending.follow.kind === "tail"
                      ? `Tailing ${pending.follow.name} on ${pending.follow.sourceTeamAbbr}`
                      : `Fading ${pending.follow.name}'s ${pending.follow.sourceTeamAbbr} pick`,
                  leagueId: pending.follow.leagueId,
                }
              : undefined
          }
          error={slipError}
          submitting={submitting}
          challenge={pending.follow ? undefined : {
            initial: pending.friend,
            onSent: (sent) => {
              setPending(null);
              onClose();
              show({
                id: `chsent_${Date.now()}`,
                kind: "social",
                icon: "sword-cross",
                color: sent.teamColor,
                title: `Challenge sent to ${sent.friendName}`,
                body: `${sent.stake.toLocaleString()} on ${sent.teamAbbr} is in the pot. Winner takes ${sent.pot.toLocaleString()} once they accept.`,
                cta: "View",
                href: "/challenges",
              });
            },
            onFindFriends: () => {
              setPending(null);
              onClose();
              onLeave?.();
              router.navigate("/(tabs)/friends");
            },
          }}
          gameSummary={`${pending.game.awayTeam.abbreviation} @ ${pending.game.homeTeam.abbreviation} · ${pending.game.sport}`}
        />
      )}
    </>
  );
}

const styles = StyleSheet.create({
  missing: { alignItems: "center", gap: 8, paddingHorizontal: 20, paddingVertical: 16 },
  missingTitle: { fontSize: 16, fontFamily: "Inter_700Bold", textAlign: "center" },
  missingBody: { fontSize: 13, lineHeight: 18, fontFamily: "Inter_400Regular", textAlign: "center" },
});
