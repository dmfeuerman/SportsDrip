import { trackEvent } from "@/lib/analytics";
import { callable } from "@/lib/firebase";

import type { AvatarConfig, Slot } from "@/types/avatar";
import type { GameInsights } from "@/types/insights";
import type { LeagueDuration } from "@/constants/leagueTypes";
export type { AvatarConfig, Slot } from "@/types/avatar";

export interface PublicUser {
  uid: string;
  username: string;
  displayName: string;
  avatar: AvatarConfig;
  equipped: Partial<Record<Slot, string>>;
  /** Dance-move loadout (constants/moves.ts). Absent on older profiles. */
  moves?: string[];
  balance?: number;
  stats?: UserStats;
  favoriteTeams?: FavoriteTeam[];
}

/** A team someone follows. Stored on users/{uid}.favoriteTeams (max 5). */
export interface FavoriteTeam {
  sport: "NFL" | "NBA" | "MLB" | "NHL" | "NCAAF" | "NCAAB" | "Soccer";
  abbr: string;
  name: string;
  color: string;
}

export interface UserStats {
  betsPlaced: number;
  betsWon: number;
  betsLost: number;
  betsPush: number;
  creditsWon: number;
  creditsStaked: number;
}

// ── profile ────────────────────────────────────────────────────────────────
export const createProfile = callable<
  { username: string; displayName: string; avatar?: AvatarConfig },
  { ok: true; username: string }
>("createProfile");

export const checkUsername = callable<
  { username: string },
  { available: boolean; reason: "invalid" | "taken" | null }
>("checkUsername");

export const updateAvatar = callable<{ avatar: AvatarConfig }, { ok: true }>("updateAvatar");

export const searchUsers = callable<{ q: string }, { results: PublicUser[] }>("searchUsers");

export const updateFavoriteTeams = callable<{ teams: FavoriteTeam[] }, { ok: true; teams: FavoriteTeam[] }>(
  "updateFavoriteTeams"
);

// ── player profiles ────────────────────────────────────────────────────────
export interface ProfileBet {
  id: string;
  gameId: string;
  sport: string | null;
  side: "home" | "away";
  teamName: string;
  teamAbbr: string;
  teamColor: string;
  opponentAbbr: string;
  stake: number;
  odds: number;
  potentialPayout: number;
  status: "pending" | "won" | "lost" | "push" | "cancelled" | string;
  placedAt: number | null;
  settledAt: number | null;
  finalHomeScore: number | null;
  finalAwayScore: number | null;
}

export interface PlayerProfile {
  /** What the server let the viewer see. */
  relation: "self" | "friend" | "league" | "none";
  profile: {
    uid: string;
    username: string;
    displayName: string;
    avatar: AvatarConfig | null;
    equipped: Partial<Record<Slot, string>>;
    /** Their dance-move loadout (the default if they never set one). */
    moves?: string[];
    favoriteTeams: FavoriteTeam[];
    stats: UserStats | null;
    memberSince: number | null;
    balance: number | null;
  };
  /** Global bets — self and friends only. */
  bets: ProfileBet[] | null;
  /** That league's line and bets, when both are members. */
  league: {
    leagueId: string;
    leagueName: string;
    leagueTokens: number;
    betsWon: number;
    betsLost: number;
    betsPush: number;
    joinedAt: number | null;
    bets: ProfileBet[];
  } | null;
}

export const getPlayerProfile = callable<{ uid: string; leagueId?: string }, PlayerProfile>("getPlayerProfile");

// ── push ───────────────────────────────────────────────────────────────────
export const registerPushToken = callable<
  { token: string; enabled?: boolean; platform?: "ios" },
  { ok: true; registered: boolean }
>("registerPushToken");

// ── game insights ──────────────────────────────────────────────────────────
export const getGameInsights = callable<{ gameId: string }, { insights: GameInsights }>("getGameInsights");

// ── friends ────────────────────────────────────────────────────────────────
export const sendFriendRequest = callable<
  { toUid: string },
  { ok: true; status: "sent" | "already_sent" | "accepted" }
>("sendFriendRequest");

export const respondFriendRequest = callable<
  { fromUid: string; accept: boolean },
  { ok: true; status: string }
>("respondFriendRequest");

export const removeFriend = callable<{ otherUid: string }, { ok: true }>("removeFriend");

export const listFriends = callable<Record<string, never>, { friends: PublicUser[] }>(
  "listFriends"
);

// ── betting ────────────────────────────────────────────────────────────────
export interface PlaceBetArgs {
  gameId: string;
  side: "home" | "away";
  stake: number;
  idempotencyKey: string;
  /** Decimal odds the user was shown, so a moved price fails loudly. */
  expectedOdds?: number;
  opponentUid?: string;
}
export interface PlaceBetResult {
  ok: true;
  betId: string;
  duplicate: boolean;
  balance: number | null;
}
const placeBetCall = callable<PlaceBetArgs, PlaceBetResult>("placeBet");

/** Every credits bet goes through here, so `bet_placed` is tracked exactly once per new bet. */
export async function placeBet(args: PlaceBetArgs): Promise<PlaceBetResult> {
  const res = await placeBetCall(args);
  if (!res.duplicate) {
    trackEvent("bet_placed", {
      wallet: "credits",
      game_id: args.gameId,
      side: args.side,
      stake: args.stake,
      odds: args.expectedOdds ?? null,
    });
  }
  return res;
}

export const cancelBet = callable<{ betId: string }, { ok: true; balance: number | null }>(
  "cancelBet"
);

// ── friend challenges ──────────────────────────────────────────────────────
export type ChallengeMode = "pot" | "odds";
export type ChallengeStatus = "pending" | "accepted" | "declined" | "cancelled" | "expired" | "settled" | "void";

export interface ChallengeTeam {
  name: string;
  abbreviation: string;
  color: string;
}

/** challenges/{id}. Written only by the server; both players can read it. */
export interface Challenge {
  id: string;
  gameId: string;
  sport: string | null;
  startsAt: number;
  home: ChallengeTeam;
  away: ChallengeTeam;
  mode: ChallengeMode;
  /** The challenger's price on their own pick (2.00 for a pot). */
  odds: number;
  creatorUid: string;
  opponentUid: string;
  participants: string[];
  creatorName: string;
  opponentName: string;
  creatorSide: "home" | "away";
  creatorStake: number;
  opponentStake: number;
  pot: number;
  message: string | null;
  status: ChallengeStatus;
  outcome: "creator" | "opponent" | "push" | null;
  winnerUid: string | null;
  finalHomeScore: number | null;
  finalAwayScore: number | null;
  createdAtMs: number;
  respondedAtMs: number | null;
  closedAtMs: number | null;
  settledAtMs: number | null;
}

export const createChallenge = callable<
  {
    gameId: string;
    opponentUid: string;
    side: "home" | "away";
    mode: ChallengeMode;
    stake: number;
    odds?: number;
    message?: string;
    idempotencyKey: string;
  },
  { ok: true; challengeId: string; duplicate: boolean; balance: number | null }
>("createChallenge");

export const respondChallenge = callable<
  { challengeId: string; accept: boolean },
  { ok: true; status: "accepted" | "declined" | "expired"; balance: number | null }
>("respondChallenge");

export const cancelChallenge = callable<
  { challengeId: string },
  { ok: true; status: string; balance: number | null }
>("cancelChallenge");

// ── shop ───────────────────────────────────────────────────────────────────
export const purchaseItem = callable<
  { itemId: string; idempotencyKey: string },
  { ok: true; balance: number | null; itemId: string }
>("purchaseItem");

export const saveAppearance = callable<
  { avatar: AvatarConfig; equipped: Partial<Record<Slot, string | null>> },
  { ok: true; avatar: AvatarConfig; equipped: Partial<Record<Slot, string>> }
>("saveAppearance");

export const equipItem = callable<{ slot: Slot; itemId: string | null }, { ok: true; removed: Slot[] }>(
  "equipItem"
);

// ── moves ──────────────────────────────────────────────────────────────────
export const purchaseMove = callable<
  { moveId: string; idempotencyKey: string },
  { ok: true; balance: number | null; moveId: string; equipped: boolean }
>("purchaseMove");

export const setMoveLoadout = callable<{ moves: string[] }, { ok: true; moves: string[] }>("setMoveLoadout");

// ── prize boxes ────────────────────────────────────────────────────────────
export type BoxTier = "bronze" | "silver" | "gold";

export const openPrizeBox = callable<
  { tier: BoxTier },
  { ok: true; state: "waiting" | "ready"; readyAt: number }
>("openPrizeBox");

export const claimPrizeBox = callable<
  { tier: BoxTier },
  { ok: true; duplicate: boolean; rewardCredits: number; balance: number | null }
>("claimPrizeBox");

export const resetPrizeBox = callable<{ tier: BoxTier }, { ok: true }>("resetPrizeBox");

export const claimAdReward = callable<
  { nonce: string },
  { result: "granted" | "duplicate" | "capped" | "too_soon" | "no_user" | "pending" }
>("claimAdReward");

// ── leagues ────────────────────────────────────────────────────────────────
// Every league mutation is a callable. The client reads leagues/{id} and its
// subcollections; it never writes them (firestore.rules denies it).
export const createLeague = callable<
  {
    idempotencyKey: string;
    name: string;
    startingLeagueTokens: number;
    duration: LeagueDuration;
    sports: string[];
    buyIn: number;
    prizePreset: "winner-all" | "top-2" | "top-3";
    bankLoanEnabled: boolean;
    bankInterestRate: number;
    bankInterestIntervalHours: number;
  },
  { ok: true; leagueId: string; code: string; duplicate: boolean }
>("createLeague");

export const joinLeague = callable<{ code: string }, { ok: true; leagueId: string; duplicate: boolean }>(
  "joinLeague"
);

export const leaveLeague = callable<{ leagueId: string }, { ok: true }>("leaveLeague");

export const updateLeagueSettings = callable<
  { leagueId: string; bankLoanEnabled: boolean; bankInterestRate: number; bankInterestIntervalHours: number },
  { ok: true }
>("updateLeagueSettings");

export const inviteToLeague = callable<
  { leagueId: string; friendUid: string },
  { ok: true; status: "sent" | "already_member" }
>("inviteToLeague");

export const endLeague = callable<{ leagueId: string }, { ok: true }>("endLeague");

export interface PlaceLeagueBetArgs {
  leagueId: string;
  gameId: string;
  side: "home" | "away";
  stake: number;
  idempotencyKey: string;
  expectedOdds?: number;
  /** Id of another member's pending league bet this one copies (same side). */
  tailOf?: string;
  /** Id of another member's pending league bet this one opposes (other side). */
  fadeOf?: string;
}
export interface PlaceLeagueBetResult {
  ok: true;
  betId: string;
  duplicate: boolean;
  leagueTokens: number | null;
}
const placeLeagueBetCall = callable<PlaceLeagueBetArgs, PlaceLeagueBetResult>("placeLeagueBet");

/** Every league bet goes through here; tails and fades are tracked on top of `bet_placed`. */
export async function placeLeagueBet(args: PlaceLeagueBetArgs): Promise<PlaceLeagueBetResult> {
  const res = await placeLeagueBetCall(args);
  if (!res.duplicate) {
    const params = {
      wallet: "league",
      league_id: args.leagueId,
      game_id: args.gameId,
      side: args.side,
      stake: args.stake,
      odds: args.expectedOdds ?? null,
    };
    trackEvent("bet_placed", { ...params, follow: args.tailOf ? "tail" : args.fadeOf ? "fade" : "none" });
    if (args.tailOf) trackEvent("bet_tailed", { ...params, source_bet_id: args.tailOf });
    if (args.fadeOf) trackEvent("bet_faded", { ...params, source_bet_id: args.fadeOf });
  }
  return res;
}

export const takeBankLoan = callable<
  { leagueId: string; amount: number; idempotencyKey: string },
  { ok: true; loanId: string; duplicate: boolean }
>("takeBankLoan");

export const repayLoan = callable<
  { leagueId: string; loanId: string; amount: number; idempotencyKey: string },
  { ok: true; duplicate: boolean; applied: number; toInterest?: number; toPrincipal?: number; settled?: boolean; remaining?: number }
>("repayLoan");

export const requestPeerLoan = callable<
  { leagueId: string; amount: number; rate: number; message?: string; idempotencyKey: string },
  { ok: true; loanId: string; duplicate: boolean }
>("requestPeerLoan");

export type PeerLoanActionName = "fund" | "counter" | "decline" | "cancel" | "accept_counter" | "reject_counter";

export const peerLoanAction = callable<
  { leagueId: string; loanId: string; action: PeerLoanActionName; rate?: number },
  { ok: true }
>("peerLoanAction");

// ── helpers ────────────────────────────────────────────────────────────────

/**
 * Idempotency keys for every mutating call. A double-tap, a lost response, or a
 * retry after a dropped connection all reuse the same key, so the server treats
 * them as one operation (AUDIT B10).
 */
export function newIdempotencyKey(): string {
  const rand = Math.random().toString(36).slice(2, 12);
  return `${Date.now().toString(36)}${rand}`;
}

/** Turns a Functions error into something worth showing a user. */
export function friendlyError(err: unknown): string {
  const e = err as { code?: string; message?: string } | undefined;
  const code = e?.code ?? "";
  if (code.includes("unauthenticated")) return "You've been signed out. Sign in again.";
  if (code.includes("failed-precondition")) return e?.message ?? "That isn't available right now.";
  if (code.includes("already-exists")) return e?.message ?? "You've already done that.";
  if (code.includes("aborted")) return e?.message ?? "The price changed. Try again.";
  if (code.includes("permission-denied")) return e?.message ?? "You can't do that.";
  if (code.includes("not-found")) return e?.message ?? "Not found.";
  if (code.includes("resource-exhausted")) return e?.message ?? "Limit reached.";
  if (code.includes("invalid-argument")) return e?.message ?? "Check the details and try again.";
  if (code.includes("unavailable") || code.includes("deadline-exceeded"))
    return "Network problem — check your connection and try again.";
  // A callable that isn't deployed (or crashed before answering) surfaces as a bare "internal".
  if (code.includes("internal") && (!e?.message || e.message === "internal"))
    return "The server couldn't do that right now. Try again in a moment.";
  return e?.message ?? "Something went wrong. Try again.";
}
