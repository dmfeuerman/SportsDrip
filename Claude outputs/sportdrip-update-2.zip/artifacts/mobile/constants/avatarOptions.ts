import {
  DEFAULT_AVATAR,
  DEFAULT_BASE,
  EYE_COLORS,
  HAIR_COLORS,
  sanitizeAppearance,
  SKIN_TONES,
} from "@/lib/avatar3d/avatarRules";
import type { AvatarConfig } from "@/types/avatar";

/**
 * Labels for the character creator. The allowed values themselves live in
 * lib/avatar3d/avatarRules.ts (shared with the server); a test checks every
 * id here exists there and vice versa.
 */
export { DEFAULT_AVATAR, EYE_COLORS, HAIR_COLORS, SKIN_TONES };

export interface HairStyle {
  id: string;
  label: string;
}

export const HAIR_STYLES: HairStyle[] = [
  { id: "buzz", label: "Buzz" },
  { id: "short_crop", label: "Short crop" },
  { id: "fade", label: "Fade" },
  { id: "curls", label: "Curls" },
  { id: "afro", label: "Afro" },
  { id: "braids", label: "Braids" },
  { id: "long", label: "Long" },
  { id: "ponytail", label: "Ponytail" },
  { id: "bald", label: "Bald" },
];

export const FACE_SHAPES = [
  { id: "oval", label: "Oval" },
  { id: "round", label: "Round" },
  { id: "square", label: "Square" },
  { id: "heart", label: "Heart" },
];

export const EYEBROWS = [
  { id: "soft", label: "Soft" },
  { id: "arched", label: "Arched" },
  { id: "bold", label: "Bold" },
  { id: "none", label: "None" },
];

export const EYE_SHAPES = [
  { id: "round", label: "Round" },
  { id: "almond", label: "Almond" },
  { id: "sleepy", label: "Sleepy" },
];

export const NOSE_SHAPES = [
  { id: "button", label: "Button" },
  { id: "straight", label: "Straight" },
  { id: "broad", label: "Broad" },
];

export const MOUTH_SHAPES = [
  { id: "neutral", label: "Neutral" },
  { id: "full", label: "Full" },
  { id: "wide", label: "Wide" },
];

export const FACIAL_HAIR = [
  { id: "none", label: "None" },
  { id: "stubble", label: "Stubble" },
  { id: "goatee", label: "Goatee" },
  { id: "beard", label: "Beard" },
];

export const BASE_MODEL = DEFAULT_BASE;

/** Any stored avatar (older clients, partial docs) as a complete, valid one. */
export function normalizeAvatar(a: Partial<AvatarConfig> | null | undefined): AvatarConfig {
  return sanitizeAppearance(a);
}

/** Randomiser for the "surprise me" button — keeps onboarding fast (§8). */
export function randomAvatar(): AvatarConfig {
  const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)]!;
  return {
    height: Math.random(),
    bodyType: Math.random(),
    skinTone: pick(SKIN_TONES),
    hairStyle: pick(HAIR_STYLES).id,
    hairColor: pick(HAIR_COLORS),
    faceShape: pick(FACE_SHAPES).id,
    eyeColor: pick(EYE_COLORS),
    eyebrows: pick(EYEBROWS).id,
    eyeShape: pick(EYE_SHAPES).id,
    noseShape: pick(NOSE_SHAPES).id,
    mouthShape: pick(MOUTH_SHAPES).id,
    // Mostly clean-shaven: a random look shouldn't usually come with a beard.
    facialHair: Math.random() < 0.7 ? "none" : pick(FACIAL_HAIR.slice(1)).id,
    faceStyle: "features",
    base: BASE_MODEL,
  };
}

/**
 * Starting points for the signup avatar picker ("Pick an avatar, customise it
 * after"). A spread of skin tones, hair and faces; every value comes from the
 * shared rules lists, so each one is a valid saved look as-is.
 */
const look = (p: Partial<AvatarConfig>): AvatarConfig => normalizeAvatar({ ...DEFAULT_AVATAR, ...p });
export const STARTER_LOOKS: Array<{ id: string; avatar: AvatarConfig }> = [
  { id: "a", avatar: look({ skinTone: SKIN_TONES[2], hairStyle: "short_crop", hairColor: HAIR_COLORS[3], facialHair: "goatee", faceShape: "oval" }) },
  { id: "b", avatar: look({ skinTone: SKIN_TONES[6], hairStyle: "fade", hairColor: HAIR_COLORS[0], faceShape: "square", noseShape: "broad" }) },
  { id: "c", avatar: look({ skinTone: SKIN_TONES[1], hairStyle: "long", hairColor: HAIR_COLORS[5], faceShape: "heart", eyeColor: EYE_COLORS[3], eyeShape: "almond" }) },
  { id: "d", avatar: look({ skinTone: SKIN_TONES[4], hairStyle: "buzz", hairColor: HAIR_COLORS[1], facialHair: "beard", faceShape: "square" }) },
  { id: "e", avatar: look({ skinTone: SKIN_TONES[8], hairStyle: "afro", hairColor: HAIR_COLORS[0], faceShape: "round", mouthShape: "full" }) },
  { id: "f", avatar: look({ skinTone: SKIN_TONES[0], hairStyle: "ponytail", hairColor: HAIR_COLORS[4], faceShape: "oval", eyeColor: EYE_COLORS[2], noseShape: "straight" }) },
  { id: "g", avatar: look({ skinTone: SKIN_TONES[5], hairStyle: "curls", hairColor: HAIR_COLORS[2], facialHair: "stubble", faceShape: "oval" }) },
  { id: "h", avatar: look({ skinTone: SKIN_TONES[7], hairStyle: "braids", hairColor: HAIR_COLORS[0], faceShape: "heart", eyeShape: "almond" }) },
  { id: "i", avatar: look({ skinTone: SKIN_TONES[3], hairStyle: "short_crop", hairColor: HAIR_COLORS[6], faceShape: "round", eyeColor: EYE_COLORS[4], eyebrows: "bold" }) },
];
