import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  Inter_800ExtraBold,
  Inter_900Black,
  useFonts,
} from "@expo-google-fonts/inter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Redirect, router, Stack, useGlobalSearchParams, useSegments } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { ActivityIndicator, View } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { SafeAreaProvider } from "react-native-safe-area-context";

import AppWalkthroughModal from "@/components/AppWalkthroughModal";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AdsProvider } from "@/context/AdsContext";
import { AppProvider, useApp } from "@/context/AppContext";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { CartProvider } from "@/context/CartContext";
import { ChallengeProvider } from "@/context/ChallengeContext";
import { ChatProvider } from "@/context/ChatContext";
import DevFlagsRunner from "@/components/DevFlagsRunner";
import { hasDevFlags } from "@/lib/devFlags";
import { flushAnalytics } from "@/lib/analytics";
import { normalizeInviteCode, savePendingInvite, takePendingInvite } from "@/lib/invites";
import { normalizeReferralCode, savePendingReferral } from "@/lib/referrals";
import { startStallWatch, trace } from "@/lib/devtrace";
import ResultPopupHost from "@/components/ResultPopup";
import { PresenceBeat } from "@/lib/presence";
import EngagementWatchers from "@/components/EngagementWatchers";
import InviteToastHost from "@/components/InviteToastHost";
import LevelUpHost from "@/components/LevelUpHost";
import ToastHost from "@/components/ToastHost";
import { ToastProvider } from "@/context/ToastContext";
import AvatarPortraitStudio from "@/components/avatar/AvatarPortraitStudio";
import { LeagueProvider } from "@/context/LeagueContext";
import { NotificationProvider } from "@/context/NotificationContext";
import { useColors } from "@/hooks/useColors";
import { firebaseConfigured } from "@/lib/firebase";

SplashScreen.preventAutoHideAsync();
startStallWatch();
trace("boot", "bundle loaded");

const queryClient = new QueryClient();

function useInviteLinkCode(): string | null {
  const segments = useSegments();
  const params = useGlobalSearchParams<{ code?: string }>();
  return (segments[0] as string | undefined) === "join" ? normalizeInviteCode(params.code) : null;
}

/** sportdrip://ref/{CODE}: a friend's invite code, parked for the signup form. */
function useReferralLinkCode(): string | null {
  const segments = useSegments();
  const params = useGlobalSearchParams<{ code?: string }>();
  return (segments[0] as string | undefined) === "ref" ? normalizeReferralCode(params.code) : null;
}

function AppShell() {
  const { profile, ready, needsOnboarding } = useApp();
  const segments = useSegments();
  const colors = useColors();
  const linkCode = useInviteLinkCode();
  const refCode = useReferralLinkCode();
  const top = segments[0] as string | undefined;

  useEffect(() => {
    if (ready && needsOnboarding && linkCode) void savePendingInvite(linkCode, { signedIn: true });
  }, [ready, needsOnboarding, linkCode]);

  useEffect(() => {
    if (ready && needsOnboarding && refCode) void savePendingReferral(refCode);
  }, [ready, needsOnboarding, refCode]);

  useEffect(() => {
    if (!ready || needsOnboarding || !profile?.uid || top === "onboarding" || top === "join") return;
    let cancelled = false;
    void takePendingInvite().then((code) => {
      if (cancelled || !code) return;
      router.navigate({ pathname: "/(tabs)/leagues", params: { join: "1", code, via: "link", t: String(Date.now()) } });
    });
    return () => {
      cancelled = true;
    };
  }, [ready, needsOnboarding, profile?.uid, top]);

  useEffect(() => {
    if (ready) trace("boot", needsOnboarding ? "shell ready (onboarding)" : "shell ready");
  }, [ready, needsOnboarding]);

  const signedInUid = profile?.uid ?? null;
  useEffect(() => {
    if (signedInUid) void flushAnalytics();
  }, [signedInUid]);

  if (!ready) return <Splash />;

  if (needsOnboarding && segments[0] !== "onboarding") {
    return <Redirect href="/onboarding" />;
  }

  const uid = profile?.uid ?? null;
  const inMainApp = !needsOnboarding && top !== "onboarding" && top !== "login";

  return (
    <LeagueProvider uid={uid}>
      <NotificationProvider uid={uid} promptForPush={false}>
        <ChallengeProvider uid={uid}>
          <AdsProvider uid={uid} active={!!uid && !needsOnboarding}>
            <CartProvider>
              <ToastProvider>
                <ChatProvider>
                  <AvatarPortraitStudio />
                  <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background } }}>
                    <Stack.Screen name="login" options={{ headerShown: false, animation: "fade" }} />
                    <Stack.Screen name="onboarding" options={{ headerShown: false, animation: "fade" }} />
                    <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
                    <Stack.Screen name="messages" options={{ animation: "slide_from_right" }} />
                    <Stack.Screen name="bets" />
                    <Stack.Screen name="shop" />
                    <Stack.Screen name="moves" options={{ animation: "slide_from_right" }} />
                    <Stack.Screen name="levels" options={{ animation: "slide_from_right" }} />
                    <Stack.Screen name="trophies" options={{ animation: "slide_from_right" }} />
                    <Stack.Screen name="settings" options={{ animation: "slide_from_right" }} />
                    <Stack.Screen name="customize" options={{ animation: "slide_from_bottom" }} />
                    <Stack.Screen name="checkout" options={{ animation: "slide_from_right" }} />
                    <Stack.Screen name="activity" />
                    <Stack.Screen name="feed" options={{ animation: "slide_from_right" }} />
                    <Stack.Screen name="challenges" options={{ animation: "slide_from_right" }} />
                    <Stack.Screen name="league/[id]" />
                    <Stack.Screen name="game/[id]" options={{ animation: "slide_from_right" }} />
                  </Stack>
                  <AppWalkthroughModal autoTrigger={inMainApp} />
                  {uid ? <ResultPopupHost /> : null}
                  {uid ? <PresenceBeat uid={uid} /> : null}
                  {uid ? <InviteToastHost /> : null}
                  {uid ? <EngagementWatchers /> : null}
                  {uid && inMainApp ? <LevelUpHost /> : null}
                  {__DEV__ && hasDevFlags && uid && inMainApp ? <DevFlagsRunner uid={uid} /> : null}
                  <ToastHost />
                </ChatProvider>
              </ToastProvider>
            </CartProvider>
          </AdsProvider>
        </ChallengeProvider>
      </NotificationProvider>
    </LeagueProvider>
  );
}

function Splash() {
  const colors = useColors();
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.background }}>
      <ActivityIndicator color={colors.primary} />
    </View>
  );
}

function RootLayoutNav() {
  const { currentUser, loading } = useAuth();
  const segments = useSegments();
  const linkCode = useInviteLinkCode();
  const refCode = useReferralLinkCode();

  useEffect(() => {
    if (!loading && firebaseConfigured && !currentUser && linkCode) void savePendingInvite(linkCode, { signedIn: false });
  }, [loading, currentUser, linkCode]);

  useEffect(() => {
    if (!loading && firebaseConfigured && !currentUser && refCode) void savePendingReferral(refCode);
  }, [loading, currentUser, refCode]);

  if (loading) return <Splash />;

  if (firebaseConfigured && !currentUser) {
    if (segments[0] !== "login") return <Redirect href="/login" />;
  }

  const uid = currentUser?.uid ?? "local";

  return (
    <AppProvider key={uid} uid={uid}>
      <AppShell />
    </AppProvider>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
    Inter_800ExtraBold,
    Inter_900Black,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) SplashScreen.hideAsync();
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <AuthProvider>
            <GestureHandlerRootView>
              <KeyboardProvider>
                <RootLayoutNav />
              </KeyboardProvider>
            </GestureHandlerRootView>
          </AuthProvider>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
