import { MaterialCommunityIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { doc, onSnapshot } from "firebase/firestore";
import React, { useEffect, useMemo, useState } from "react";
import { Modal, ScrollView, StyleSheet, Text, View } from "react-native";
import Animated, { FadeIn, FadeInDown, FadeOut, ZoomIn } from "react-native-reanimated";
import Svg, { Circle, Defs, LinearGradient as SvgGradient, Path, Rect, Stop } from "react-native-svg";
import { Pressable } from "@/components/fx/Tap";
import { Button, ScreenHeader, useBottomPad } from "@/components/ui";
import { ACHIEVEMENTS, METALS, type TrophyMetal } from "@/constants/achievements";
import type { TrophyItem } from "@/constants/leagueTypes";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { haptic } from "@/lib/motion";
import * as api from "@/lib/api";
import { DEMO } from "@/lib/demo";
import { getDb } from "@/lib/firebase";

type Shape = "cup" | "medal" | "spoon";
interface Piece {
  key: string;
  title: string;
  icon: string;
  metal: TrophyMetal;
  shape: Shape;
  earned: boolean;
  sub: string;
  detail: string;
  awardedAt?: number;
  /** users/{uid}/trophies doc id, when earned. */
  trophyId?: string;
  /** Achievements: players who hold it / all players. */
  rarity?: number | null;
}

const PER_SHELF = 3;
const WOOD = { hi: "#7A4B28", mid: "#5A3418", lo: "#2E1A0B" };

function leaguePiece(t: TrophyItem, i: number): Piece {
  const kind = t.kind;
  const metal: TrophyMetal = kind === "champion" ? "gold" : kind === "h2h_champion" ? "platinum" : kind === "lock_of_week" ? "silver" : "bronze";
  const shape: Shape = kind === "last_place" ? "spoon" : "cup";
  const name = t.title || t.leagueName || "League Trophy";
  const what =
    kind === "champion" ? "League Champion" : kind === "h2h_champion" ? "Head-to-Head Champion" : kind === "lock_of_week" ? "Lock of the Week" : kind === "last_place" ? "Last Place" : "League Trophy";
  return {
    key: `${t.id ?? t.leagueId}_${i}`,
    trophyId: t.id,
    title: name,
    icon: kind === "last_place" ? "emoticon-sad-outline" : kind === "lock_of_week" ? "lock" : "trophy",
    metal,
    shape,
    earned: true,
    sub: t.leagueName && t.leagueName !== name ? t.leagueName : what,
    detail: [what, t.leagueName, t.rank ? `Finished #${t.rank}` : null].filter(Boolean).join(" · "),
    awardedAt: t.awardedAt,
  };
}

/**
 * Trophy Case: every trophy and achievement on lit glass shelves. League
 * hardware sits on the top shelf; achievements fill the rest, with locked
 * ones shown as dark silhouettes that say how to earn them.
 */
export default function TrophiesScreen() {
  const c = useColors();
  const bottom = useBottomPad(false);
  const { trophies, profile } = useApp();
  const [open, setOpen] = useState<Piece | null>(null);
  const [stats, setStats] = useState<{ players: number; counts: Record<string, number> } | null>(null);
  const [pinned, setPinned] = useState<string | null | undefined>(undefined);
  const featured = pinned !== undefined ? pinned : profile?.featuredTrophy ?? null;
  useEffect(() => {
    if (DEMO) return;
    const db = getDb();
    if (!db) return;
    return onSnapshot(doc(db, "meta", "achievementStats"), (s) => setStats(s.exists() ? (s.data() as typeof stats) : null), () => {});
  }, []);
  const pin = async (id: string | null) => {
    haptic.medium();
    const before = featured;
    setPinned(id);
    try {
      await api.setFeaturedTrophy({ trophyId: id });
    } catch {
      setPinned(before);
    }
  };

  const { league, achievements, earnedCount } = useMemo(() => {
    const got = new Map(trophies.filter((t) => t.kind === "achievement").map((t) => [t.achievementId ?? t.id.replace(/^ach_/, ""), t]));
    const achievements: Piece[] = ACHIEVEMENTS.map((a) => {
      const t = got.get(a.id);
      return {
        key: a.id,
        title: a.title,
        icon: a.icon,
        metal: a.metal,
        shape: "medal" as const,
        earned: !!t,
        sub: t ? new Date(t.awardedAt).toLocaleDateString() : a.how,
        detail: a.how,
        awardedAt: t?.awardedAt,
        trophyId: t?.id,
        rarity: stats && stats.players > 0 ? (stats.counts[a.id] ?? 0) / stats.players : null,
      };
    }).sort((x, y) => Number(y.earned) - Number(x.earned));
    const league = trophies
      .filter((t) => t.kind !== "achievement")
      .sort((a, b) => (b.awardedAt ?? 0) - (a.awardedAt ?? 0))
      .map(leaguePiece);
    return { league, achievements, earnedCount: achievements.filter((a) => a.earned).length };
  }, [trophies, stats]);

  const shelves = (items: Piece[]) => {
    const rows: Piece[][] = [];
    for (let i = 0; i < items.length; i += PER_SHELF) rows.push(items.slice(i, i + PER_SHELF));
    return rows;
  };

  const tap = (p: Piece) => {
    haptic.light();
    setOpen(p);
  };

  return (
    <View style={[styles.fill, { backgroundColor: c.background }]}>
      <ScreenHeader
        back
        title="Trophy Case"
        subtitle={`${earnedCount}/${ACHIEVEMENTS.length} achievements · ${league.length} league trophi${league.length === 1 ? "y" : "es"}`}
      />
      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: bottom }]} showsVerticalScrollIndicator={false}>
        <LinearGradient colors={[WOOD.hi, WOOD.mid, WOOD.lo]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.cabinet}>
          <View style={styles.crown}>
            <LinearGradient colors={[METALS.gold.hi, METALS.gold.mid]} style={styles.nameplate}>
              <Text style={styles.nameplateText}>HALL OF DRIP</Text>
            </LinearGradient>
          </View>
          <View style={styles.glass}>
            {/* Back panel + spotlight from the top */}
            <LinearGradient colors={["#1B2230", "#0D1118", "#080A0F"]} style={StyleSheet.absoluteFill} />
            <LinearGradient colors={["rgba(255,236,190,0.22)", "rgba(255,236,190,0)"]} style={styles.spot} />

            <Text style={styles.shelfLabel}>LEAGUE HARDWARE</Text>
            {league.length ? (
              shelves(league).map((row, r) => <Shelf key={`l${r}`} row={row} base={r * PER_SHELF} onPress={tap} pinnedId={featured} />)
            ) : (
              <>
                <View style={styles.emptyShelf}>
                  <MaterialCommunityIcons name="trophy-outline" size={22} color="rgba(255,255,255,0.28)" />
                  <Text style={styles.emptyText}>Win a league to put a cup here</Text>
                </View>
                <Plank />
              </>
            )}

            <Text style={[styles.shelfLabel, { marginTop: 18 }]}>ACHIEVEMENTS</Text>
            {shelves(achievements).map((row, r) => (
              <Shelf key={`a${r}`} row={row} base={(league.length + r) * PER_SHELF} onPress={tap} pinnedId={featured} />
            ))}

            {/* Glass reflection */}
            <LinearGradient
              pointerEvents="none"
              colors={["rgba(255,255,255,0)", "rgba(255,255,255,0.07)", "rgba(255,255,255,0)"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0.6 }}
              locations={[0.25, 0.4, 0.55]}
              style={StyleSheet.absoluteFill}
            />
          </View>
        </LinearGradient>
      </ScrollView>

      <Modal visible={!!open} transparent animationType="none" onRequestClose={() => setOpen(null)} statusBarTranslucent>
        {open ? (
          <Animated.View entering={FadeIn.duration(140)} exiting={FadeOut.duration(140)} style={[styles.scrim, { backgroundColor: c.overlay }]}>
            <Pressable style={StyleSheet.absoluteFill} onPress={() => setOpen(null)} accessibilityRole="button" accessibilityLabel="Close" />
            <Animated.View entering={ZoomIn.springify().damping(14)} style={[styles.detail, { backgroundColor: c.elevated, borderColor: open.earned ? METALS[open.metal].mid : c.border }]}>
              <Trophy piece={open} size={140} />
              <Text style={[styles.detailTitle, { color: c.foreground }]}>{open.title}</Text>
              <Text style={[styles.detailSub, { color: open.earned ? METALS[open.metal].mid : c.mutedForeground }]}>
                {open.earned ? `${open.metal.toUpperCase()} · EARNED` : "LOCKED"}
              </Text>
              {open.rarity != null ? (
                <Text style={[styles.rarity, { color: c.accent }]}>
                  {open.rarity < 0.005 ? "<0.5%" : `${Math.round(open.rarity * 1000) / 10}%`} of players have this
                </Text>
              ) : null}
              <Text style={[styles.detailBody, { color: c.mutedForeground }]}>
                {open.earned
                  ? `${open.detail}${open.awardedAt ? `\nAwarded ${new Date(open.awardedAt).toLocaleDateString()}` : ""}`
                  : `How to earn: ${open.detail}`}
              </Text>
              {open.earned && open.trophyId ? (
                <Button
                  label={featured === open.trophyId ? "Unpin From Profile" : "Pin to Profile"}
                  icon={featured === open.trophyId ? "pin-off-outline" : "pin-outline"}
                  onPress={() => void pin(featured === open.trophyId ? null : open.trophyId!)}
                  style={{ alignSelf: "stretch" }}
                />
              ) : null}
              <Button label="Close" variant="secondary" onPress={() => setOpen(null)} style={{ alignSelf: "stretch" }} />
            </Animated.View>
          </Animated.View>
        ) : null}
      </Modal>
    </View>
  );
}

function Shelf({ row, base, onPress, pinnedId }: { row: Piece[]; base: number; onPress: (p: Piece) => void; pinnedId?: string | null }) {
  return (
    <>
      <View style={styles.row}>
        {row.map((p, i) => (
          <Animated.View key={p.key} entering={FadeInDown.delay(Math.min(base + i, 14) * 45).springify().damping(16)} style={styles.slot}>
            <Pressable onPress={() => onPress(p)} accessibilityRole="button" accessibilityLabel={`${p.title}${p.earned ? "" : ", locked"}`} style={styles.slotPress}>
              <Trophy piece={p} size={66} />
              {p.trophyId && p.trophyId === pinnedId ? (
                <View style={styles.pinBadge}>
                  <MaterialCommunityIcons name="pin" size={12} color="#4A2C05" />
                </View>
              ) : null}
              <Text style={[styles.slotTitle, { color: p.earned ? "#F4F1EA" : "rgba(255,255,255,0.4)" }]} numberOfLines={1}>
                {p.title}
              </Text>
              <Text style={styles.slotSub} numberOfLines={1}>
                {p.sub}
              </Text>
            </Pressable>
          </Animated.View>
        ))}
        {Array.from({ length: PER_SHELF - row.length }, (_, i) => (
          <View key={`gap${i}`} style={styles.slot} />
        ))}
      </View>
      <Plank />
    </>
  );
}

function Plank() {
  return (
    <View style={styles.plankWrap}>
      <LinearGradient colors={[WOOD.hi, WOOD.mid]} style={styles.plankTop} />
      <LinearGradient colors={[WOOD.mid, WOOD.lo]} style={styles.plankFront} />
      <LinearGradient colors={["rgba(0,0,0,0.55)", "rgba(0,0,0,0)"]} style={styles.plankShadow} />
    </View>
  );
}

const LOCKED = { hi: "#3A414B", mid: "#262B33", lo: "#171A20" };

/** A trophy drawn in SVG: a cup (league), a medal on a stand (achievement) or the wooden spoon. */
function Trophy({ piece, size }: { piece: Piece; size: number }) {
  const m = piece.earned ? METALS[piece.metal] : LOCKED;
  const h = size * (84 / 64);
  const id = `${piece.key}_${size}`;
  const iconColor = piece.earned ? (piece.metal === "silver" || piece.metal === "platinum" ? "#24313A" : "#4A2C05") : "rgba(255,255,255,0.35)";
  const iconTop = piece.shape === "medal" ? 34 : piece.shape === "spoon" ? 20 : 22;
  return (
    <View style={{ width: size, height: h }}>
      {piece.earned ? <View style={[styles.glow, { width: size * 0.9, height: size * 0.9, borderRadius: size, left: size * 0.05, top: h * 0.05, backgroundColor: m.mid }]} /> : null}
      <Svg width={size} height={h} viewBox="0 0 64 84">
        <Defs>
          <SvgGradient id={`${id}_m`} x1="0" y1="0" x2="1" y2="0">
            <Stop offset="0" stopColor={m.lo} />
            <Stop offset="0.35" stopColor={m.hi} />
            <Stop offset="0.6" stopColor={m.mid} />
            <Stop offset="1" stopColor={m.lo} />
          </SvgGradient>
          <SvgGradient id={`${id}_w`} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor={piece.earned ? "#4A2D16" : "#20242A"} />
            <Stop offset="1" stopColor={piece.earned ? "#22130A" : "#121418"} />
          </SvgGradient>
        </Defs>
        {piece.shape === "cup" ? (
          <>
            <Path d="M16 13 C3 13 4 34 21 36" stroke={m.mid} strokeWidth={3.5} fill="none" />
            <Path d="M48 13 C61 13 60 34 43 36" stroke={m.mid} strokeWidth={3.5} fill="none" />
            <Path d="M14 8 H50 V16 C50 32 42 40 32 41 C22 40 14 32 14 16 Z" fill={`url(#${id}_m)`} />
            <Rect x={12} y={5.5} width={40} height={4.5} rx={2} fill={m.hi} />
            <Path d="M29 41 H35 L36.5 52 H27.5 Z" fill={`url(#${id}_m)`} />
            <Rect x={24} y={51} width={16} height={4} rx={2} fill={m.mid} />
          </>
        ) : piece.shape === "spoon" ? (
          <>
            <Path d="M32 4 C22 4 20 14 20 20 C20 28 26 32 30 33 L29 55 H35 L34 33 C38 32 44 28 44 20 C44 14 42 4 32 4 Z" fill={piece.earned ? "#9A6A3C" : m.mid} />
            <Path d="M26 12 C27 8 30 7 32 7" stroke="rgba(255,255,255,0.35)" strokeWidth={1.5} fill="none" />
          </>
        ) : (
          <>
            <Path d="M20 2 H29 L35 22 H26 Z" fill={piece.earned ? "#C62F3B" : "#2A2F36"} />
            <Path d="M44 2 H35 L29 22 H38 Z" fill={piece.earned ? "#2850B8" : "#30363F"} />
            <Circle cx={32} cy={34} r={17} fill={`url(#${id}_m)`} />
            <Circle cx={32} cy={34} r={13} fill="none" stroke={m.hi} strokeWidth={1.2} opacity={0.8} />
            <Rect x={29} y={50} width={6} height={5} fill={m.mid} />
          </>
        )}
        <Path d="M20 55 H44 L46.5 72 H17.5 Z" fill={`url(#${id}_w)`} />
        <Rect x={17} y={71} width={30} height={4} rx={1} fill={piece.earned ? "#1A0E06" : "#0E1013"} />
        <Rect x={24} y={60} width={16} height={6} rx={1} fill={m.mid} opacity={piece.earned ? 1 : 0.6} />
      </Svg>
      <View pointerEvents="none" style={[styles.iconWrap, { top: (iconTop / 84) * h - size * 0.13, width: size, height: size * 0.26 }]}>
        <MaterialCommunityIcons name={(piece.earned ? piece.icon : "lock") as never} size={size * 0.24} color={iconColor} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  content: { padding: 16 },
  cabinet: { borderRadius: 18, padding: 10, paddingTop: 0, shadowColor: "#000", shadowOpacity: 0.5, shadowRadius: 16, shadowOffset: { width: 0, height: 8 }, elevation: 8 },
  crown: { alignItems: "center", paddingVertical: 10 },
  nameplate: { paddingHorizontal: 16, paddingVertical: 4, borderRadius: 4 },
  nameplateText: { color: "#4A2C05", fontSize: 11, letterSpacing: 2.5, fontFamily: "Inter_900Black" },
  glass: { borderRadius: 10, overflow: "hidden", paddingHorizontal: 8, paddingTop: 14, paddingBottom: 6, borderWidth: 2, borderColor: "rgba(0,0,0,0.5)" },
  spot: { position: "absolute", top: 0, left: "15%", right: "15%", height: 220, borderBottomLeftRadius: 200, borderBottomRightRadius: 200 },
  shelfLabel: { color: "rgba(255,236,190,0.55)", fontSize: 10, letterSpacing: 2, fontFamily: "Inter_800ExtraBold", textAlign: "center", marginBottom: 6 },
  row: { flexDirection: "row", alignItems: "flex-end", paddingHorizontal: 4 },
  slot: { flex: 1, alignItems: "center" },
  slotPress: { alignItems: "center", paddingTop: 6, paddingHorizontal: 2, width: "100%" },
  slotTitle: { fontSize: 11, fontFamily: "Inter_700Bold", marginTop: 2, maxWidth: "100%" },
  slotSub: { fontSize: 9, fontFamily: "Inter_500Medium", color: "rgba(255,255,255,0.4)", marginBottom: 4, maxWidth: "100%" },
  plankWrap: { marginHorizontal: -8, marginBottom: 16 },
  plankTop: { height: 6 },
  plankFront: { height: 10, borderBottomWidth: 1, borderBottomColor: "rgba(0,0,0,0.6)" },
  plankShadow: { height: 12, marginBottom: -12 },
  emptyShelf: { alignItems: "center", gap: 6, paddingVertical: 26 },
  emptyText: { color: "rgba(255,255,255,0.4)", fontSize: 12, fontFamily: "Inter_600SemiBold" },
  glow: { position: "absolute", opacity: 0.16 },
  pinBadge: { position: "absolute", top: 4, right: "22%", width: 20, height: 20, borderRadius: 10, backgroundColor: "#F2B925", alignItems: "center", justifyContent: "center" },
  iconWrap: { position: "absolute", left: 0, alignItems: "center", justifyContent: "center" },
  scrim: { flex: 1, alignItems: "center", justifyContent: "center", padding: 24 },
  detail: { width: "100%", maxWidth: 360, borderRadius: 22, borderWidth: 1.5, padding: 20, alignItems: "center", gap: 6 },
  detailTitle: { fontSize: 22, fontFamily: "Inter_900Black", textAlign: "center", marginTop: 6 },
  detailSub: { fontSize: 11, letterSpacing: 1.5, fontFamily: "Inter_800ExtraBold" },
  rarity: { fontSize: 13, fontFamily: "Inter_800ExtraBold" },
  detailBody: { fontSize: 13, fontFamily: "Inter_500Medium", textAlign: "center", lineHeight: 19, marginBottom: 10 },
});
