import BackToLevels from "@/components/BackToLevels";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { haptic as buzz } from "@/lib/motion";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Pressable } from "@/components/fx/Tap";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import BetModal, { type BetWallet, type SlipExtras } from "@/components/BetModal";
import GameCard, { type MyPosition } from "@/components/GameCard";
import FeaturedGameCard, { pickFeatured } from "@/components/FeaturedGameCard";
import GameQuickView, { type FollowIntent } from "@/components/GameQuickView";
import TailSheet from "@/components/TailSheet";
import GameDetailSheet, { type DetailBet } from "@/components/GameDetailSheet";
import SponsoredCard from "@/components/ads/SponsoredCard";
import TokenBalance from "@/components/TokenBalance";
import { FilterPills, IconButton } from "@/components/ui";
import { SPORT_COLORS } from "@/constants/colors";
import { SPORT_ICONS } from "@/constants/leagueTypes";
import { AD_POLICY } from "@/constants/ads";
import { useAds } from "@/context/AdsContext";
import { useApp } from "@/context/AppContext";
import { holdsMyStake, useChallenges, viewOf } from "@/context/ChallengeContext";
import { useBoardLeagueSides, useLeague } from "@/context/LeagueContext";
import { useNow } from "@/hooks/useNow";
import { useToast } from "@/context/ToastContext";
import { useNotifications } from "@/context/NotificationContext";
import { useColors } from "@/hooks/useColors";
import { useGames } from "@/hooks/useGames";
import { prefetchGameInsights } from "@/hooks/useGameInsights";
import { openGameCenter } from "@/lib/gameCenter";
import * as api from "@/lib/api";
import { newIdempotencyKey } from "@/lib/api";
import { quoteMarket, weekKey, type Market, type Selection } from "@/lib/markets";
import { SPORTS, sideOdds, type Game, type Side } from "@/types/game";

const ALL = "ALL";

type Row =
  | { kind: "section"; id: string; title: string; live?: boolean }
  | { kind: "game"; id: string; game: Game }
  | { kind: "ad"; id: string };

export default function GamesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const { balance, bets, error, clearError, profile } = useApp();
  const { leagues, activeLeagues, uid, placeLeagueBet, myLeagueBets } = useLeague();
  const { betLocked } = useToast();
  const { unreadCount } = useNotifications();
  const { live, upcoming, loading, error: gamesError, syncedAt } = useGames();
  const boardSides = useBoardLeagueSides(uid);
  const clock = useNow(15_000);
  const { enabled: adsOn } = useAds();
  const params = useLocalSearchParams<{ wallet?: string; challenge?: string; challengeName?: string }>();
  const challenges = useChallenges();
  const { show } = useToast();
  const [target, setTarget] = useState<{ uid: string; name: string } | null>(null);
  useEffect(() => {
    if (params.challenge) {
      setTarget({ uid: params.challenge, name: params.challengeName || "your friend" });
      router.setParams({ challenge: undefined, challengeName: undefined });
    }
  }, [params.challenge, params.challengeName]);
  const [slipError, setSlipError] = useState<string | null>(null);

  const [sport, setSport] = useState<string>(ALL);
  const [pending, setPending] = useState<{
    game: Game;
    side: Side;
    market?: Market;
    selection?: Selection;
    key: string;
    friend?: boolean;
  } | null>(null);
  const [detail, setDetail] = useState<Game | null>(null);
  const [tailGame, setTailGame] = useState<Game | null>(null);
  const [quickGame, setQuickGame] = useState<string | null>(null);
  const [follow, setFollow] = useState<FollowIntent | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const topPad = Platform.OS === "web" ? 24 : insets.top;
  const bottomPad = Platform.OS === "web" ? 100 : insets.bottom + 84;

  const openBets =
    bets.filter((b) => b.status === "pending").length +
    Object.values(myLeagueBets).reduce((n, list) => n + list.filter((b) => b.status === "pending").length, 0);

  const positions = useMemo(() => {
    const map = new Map<string, MyPosition>();
    for (const b of bets) {
      if (b.status !== "pending" || map.has(b.gameId)) continue;
      map.set(b.gameId, {
        side: b.side,
        label: b.label,
        stake: b.stake,
        potentialPayout: b.potentialPayout,
      });
    }
    for (const lg of leagues) {
      for (const b of myLeagueBets[lg.id] ?? []) {
        if (b.status !== "pending" || map.has(b.gameId)) continue;
        map.set(b.gameId, {
          side: b.side,
          label: b.label,
          stake: b.stake,
          potentialPayout: b.potentialPayout,
        });
      }
    }
    const me = challenges.uid;
    if (me) {
      for (const [gameId, list] of challenges.byGame) {
        if (map.has(gameId)) continue;
        const ch = list.find((x) => holdsMyStake(x, me));
        if (!ch) continue;
        const v = viewOf(ch, me);
        map.set(gameId, { side: v.mySide, stake: v.myStake, potentialPayout: ch.pot });
      }
    }
    return map;
  }, [bets, leagues, myLeagueBets, challenges.byGame, challenges.uid]);

  const rows: Row[] = useMemo(() => {
    const match = (g: Game) => sport === ALL || g.sport === sport;
    const l = live.filter(match);
    const u = upcoming.filter(match);
    const out: Row[] = [];
    let seen = 0;
    let ads = 0;
    const pushGame = (g: Game) => {
      out.push({ kind: "game", id: g.id, game: g });
      seen += 1;
      const slot = seen - AD_POLICY.boardFirstAfter;
      if (adsOn && ads < AD_POLICY.boardMax && slot >= 0 && slot % AD_POLICY.boardEvery === 0) {
        out.push({ kind: "ad", id: `ad-${ads}` });
        ads += 1;
      }
    };
    if (l.length) {
      out.push({ kind: "section", id: "sec-live", title: "Live Now", live: true });
      l.forEach(pushGame);
    }
    let lastDay = "";
    for (const g of u) {
      const day = dayKey(g.startsAt);
      if (day !== lastDay) {
        lastDay = day;
        out.push({ kind: "section", id: `sec-${day}`, title: dayTitle(g.startsAt) });
      }
      pushGame(g);
    }
    return out;
  }, [live, upcoming, sport, adsOn]);

  const featured = useMemo(() => {
    const favs = new Set((profile?.favoriteTeams ?? []).map((t) => `${t.sport}:${t.abbr}`));
    const pool = upcoming.filter((g) => sport === ALL || g.sport === sport);
    return pickFeatured(pool, boardSides, favs, Date.now());
  }, [upcoming, sport, boardSides, profile?.favoriteTeams]);

  const openBetSheet = useCallback(
    (game: Game, side: Side, friend?: boolean, market?: Market, selection?: Selection) => {
      prefetchGameInsights(game.id);
      setSlipError(null);
      setPending({ game, side, market, selection, key: newIdempotencyKey(), friend: friend || !!target });
    },
    [target]
  );

  const onChallengeSent = useCallback(
    (sent: { friendName: string; teamAbbr: string; teamColor: string; stake: number; pot: number }) => {
      setPending(null);
      setTarget(null);
      show({
        id: `chsent_${Date.now()}`,
        kind: "social",
        icon: "sword-cross",
        color: sent.teamColor,
        title: `Challenge sent to ${sent.friendName}`,
        body: `${sent.stake.toLocaleString()} on ${sent.teamAbbr} is in the pot. Winner takes ${sent.pot.toLocaleString()} once they accept.`,
        cta: "View",
        href: "/challenges",
      });
    },
    [show]
  );

  const wallets: BetWallet[] = useMemo(() => {
    const out: BetWallet[] = [{ id: "credits", label: "Credits", balance, kind: "credits" }];
    if (!pending || !uid) return out;
    for (const lg of activeLeagues) {
      if (!lg.allowedSports.includes(pending.game.sport)) continue;
      if (pending.game.startsAt >= lg.endsAt) continue;
      const me = lg.members[uid];
      if (!me) continue;
      out.push({ id: lg.id, label: lg.name, balance: me.leagueTokens, kind: "league" });
    }
    return out;
  }, [pending, activeLeagues, uid, balance]);

  const lockUsedMap: Record<string, boolean> = useMemo(() => {
    const wk = weekKey();
    const out: Record<string, boolean> = {};
    for (const lg of activeLeagues) {
      const me = uid ? lg.members[uid] : undefined;
      out[lg.id] =
        me?.lastLockWeek === wk ||
        (myLeagueBets[lg.id] ?? []).some((b) => b.lockWeek === wk && b.status !== "cancelled");
    }
    return out;
  }, [activeLeagues, uid, myLeagueBets]);

  const confirmBet = useCallback(
    async (stake: number, walletId: string, extras?: SlipExtras) => {
      if (!pending) return;
      const m: Market = pending.market ?? "ml";
      const sel: Selection = pending.selection ?? pending.side;
      const q = quoteMarket(pending.game, m, sel);
      if (!q || !q.odds) {
        setSlipError("No line yet for this game. Check back closer to kickoff.");
        return;
      }
      const oddsVal = q.odds;
      setSubmitting(true);
      setSlipError(null);
      let failure: string | null = null;
      if (walletId === "credits") {
        try {
          await api.placeBet({
            gameId: pending.game.id,
            side: q.side ?? undefined,
            market: m,
            selection: sel,
            expectedLine: q.line ?? undefined,
            stake,
            idempotencyKey: pending.key,
            expectedOdds: oddsVal,
          });
        } catch (err) {
          failure = api.friendlyError(err);
        }
      } else {
        failure = await placeLeagueBet({
          leagueId: walletId,
          gameId: pending.game.id,
          side: q.side ?? undefined,
          market: m,
          selection: sel,
          expectedLine: q.line ?? undefined,
          lock: extras?.lock,
          hidden: extras?.hidden,
          stake,
          idempotencyKey: `${pending.key}${walletId.slice(-4)}`,
          expectedOdds: oddsVal,
        });
      }
      setSubmitting(false);
      if (failure) {
        buzz.error();
        setSlipError(failure);
        return;
      }
      buzz.success();
      {
        const t = (q.side ?? pending.side) === "home" ? pending.game.homeTeam : pending.game.awayTeam;
        const w = wallets.find((x) => x.id === walletId);
        betLocked({
          teamName: q.label || t.name,
          teamAbbr: t.abbreviation,
          teamColor: t.color,
          odds: oddsVal,
          stake,
          payout: Math.round(stake * oddsVal),
          currency: walletId === "credits" ? "credits" : "league",
          walletLabel: w?.label,
          leagueId: walletId === "credits" ? undefined : walletId,
          gameId: pending.game.id,
          hidden: !!extras?.hidden,
        });
      }
      setPending(null);
    },
    [pending, placeLeagueBet, wallets, betLocked]
  );


  const detailBets: DetailBet[] = useMemo(() => {
    if (!detail) return [];
    const out: DetailBet[] = bets.filter((b) => b.gameId === detail.id);
    for (const lg of leagues) {
      for (const b of myLeagueBets[lg.id] ?? []) {
        if (b.gameId === detail.id) out.push({ ...b, id: `${lg.id}:${b.id}`, wallet: lg.name });
      }
    }
    return out;
  }, [detail, bets, leagues, myLeagueBets]);

  const betFromDetail = useCallback(
    (game: Game, side: Side, friend?: boolean, market?: Market, selection?: Selection) => {
      setDetail(null);
      if (Platform.OS === "ios") setTimeout(() => openBetSheet(game, side, friend, market, selection), 350);
      else openBetSheet(game, side, friend, market, selection);
    },
    [openBetSheet]
  );

  const team = pending
    ? pending.side === "home"
      ? pending.game.homeTeam
      : pending.game.awayTeam
    : null;
  const pendingQuote = pending
    ? quoteMarket(pending.game, pending.market ?? "ml", pending.selection ?? pending.side)
    : null;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          { backgroundColor: colors.background, borderBottomColor: colors.border, paddingTop: topPad + 12 },
        ]}
      >
        <View style={styles.headerRow}>
          <BackToLevels />
          <Text accessibilityRole="header" style={[styles.title, { color: colors.foreground }]}>Games</Text>
          <View style={styles.headerRight}>
            {openBets > 0 && (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`${openBets} open bets. Open My bets`}
                onPress={() => router.push("/bets")}
                style={[styles.pendingBadge, { backgroundColor: colors.alpha(colors.accent, 0.16), borderColor: colors.alpha(colors.accent, 0.5) }]}
              >
                <Text style={[styles.pendingText, { color: colors.accent }]}>{openBets} open</Text>
              </Pressable>
            )}
            <TokenBalance tokens={balance} />
            <IconButton icon="bell-outline" label="Activity" badge={unreadCount} onPress={() => router.push("/activity")} />
          </View>
        </View>

        <FilterPills
          value={sport}
          onChange={setSport}
          options={[
            { value: ALL, label: "All", icon: "trophy-outline" as const },
            ...SPORTS.map((sp) => ({ value: sp, label: sp, icon: SPORT_ICONS[sp] as never, color: SPORT_COLORS[sp] })),
          ]}
        />
        {syncedAt ? (
          <Text style={{ color: colors.subtleForeground, fontSize: 12, fontFamily: "Inter_500Medium", textAlign: "center", marginTop: 8, marginBottom: -4 }}>
            Scores live · updated {ago(syncedAt, clock)}
          </Text>
        ) : null}
      </View>

      {target && (
        <View style={[styles.banner, { backgroundColor: colors.alpha(colors.accent, 0.12), borderColor: colors.alpha(colors.accent, 0.6) }]}>
          <MaterialCommunityIcons name="sword-cross" size={16} color={colors.accent} />
          <Text style={[styles.bannerText, { color: colors.foreground }]} numberOfLines={2}>
            Tap a team on any upcoming game to challenge {target.name}.
          </Text>
          <Pressable accessibilityRole="button" accessibilityLabel="Cancel challenge" hitSlop={10} onPress={() => setTarget(null)}>
            <MaterialCommunityIcons name="close" size={16} color={colors.mutedForeground} />
          </Pressable>
        </View>
      )}

      {error && (
        <Pressable
          style={[styles.banner, { backgroundColor: colors.destructive + "22", borderColor: colors.destructive }]}
          onPress={clearError}
        >
          <MaterialCommunityIcons name="alert-circle-outline" size={15} color={colors.destructive} />
          <Text style={[styles.bannerText, { color: colors.destructive }]}>{error}</Text>
          <MaterialCommunityIcons name="close" size={15} color={colors.destructive} />
        </Pressable>
      )}

      {loading ? (
        <SkeletonList colors={colors} />
      ) : (
        <FlatList
          data={rows}
          keyExtractor={(r) => r.id}
          // Child 0 is the featured header when there is one, so section rows sit one further down.
          stickyHeaderIndices={rows
            .map((r, i) => (r.kind === "section" ? i + (featured ? 1 : 0) : -1))
            .filter((i) => i >= 0)}
          ListHeaderComponent={
            featured ? (
              <FeaturedGameCard game={featured} sides={boardSides.get(featured.id) ?? []} onOpen={setDetail} />
            ) : undefined
          }
          renderItem={({ item }) =>
            item.kind === "ad" ? (
              <SponsoredCard compact style={styles.adRow} />
            ) : item.kind === "section" ? (
              <View style={[styles.sectionHeader, { backgroundColor: colors.background }]}>
                {item.live ? (
                  <View style={[styles.liveDot, { backgroundColor: colors.live }]} />
                ) : (
                  <MaterialCommunityIcons name="calendar-clock" size={15} color={colors.mutedForeground} />
                )}
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{item.title}</Text>
              </View>
            ) : (
              <GameCard
                game={item.game}
                onBet={(g, s, m, sel) => openBetSheet(g, s, false, m, sel)}
                onChallenge={(g, s) => openBetSheet(g, s, true)}
                onOpenDetail={setDetail}
                position={positions.get(item.game.id) ?? null}
                leagueMembers={boardSides.get(item.game.id)}
                onLeaguePress={setTailGame}
              />
            )
          }
          contentContainerStyle={[styles.listContent, { paddingBottom: bottomPad }]}
          showsVerticalScrollIndicator={false}
          initialNumToRender={8}
          maxToRenderPerBatch={8}
          windowSize={7}
          ListEmptyComponent={
            <EmptyState
              colors={colors}
              error={gamesError}
              sport={sport}
              onClearFilter={() => setSport(ALL)}
            />
          }
        />
      )}

      <GameDetailSheet
        game={detail}
        onClose={() => setDetail(null)}
        onBet={(g, side, market, selection) => betFromDetail(g, side, false, market, selection)}
        onChallenge={(g, side) => betFromDetail(g, side, true)}
        bets={detailBets}
        onOpenCenter={(game) => {
          setDetail(null);
          openGameCenter(game.id, game.status === "upcoming" ? "matchup" : "live");
        }}
      />

      {pending && team && (
        <BetModal
          visible
          onClose={() => setPending(null)}
          onConfirm={confirmBet}
          teamName={team.name}
          teamAbbr={team.abbreviation}
          teamColor={team.color}
          pickTitle={pendingQuote?.label}
          lockUsed={lockUsedMap}
          odds={pendingQuote ? pendingQuote.odds : sideOdds(pending.game, pending.side)}
          game={pending.game}
          side={pending.side}
          wallets={wallets}
          defaultWallet={params.wallet}
          error={slipError}
          submitting={submitting}
          challenge={{
            initial: pending.friend,
            friendUid: target?.uid,
            onSent: onChallengeSent,
            onFindFriends: () => {
              setPending(null);
              router.navigate("/(tabs)/friends");
            },
          }}
          gameSummary={`${pending.game.awayTeam.abbreviation} @ ${pending.game.homeTeam.abbreviation} · ${pending.game.sport}`}
        />
      )}

      <TailSheet
        game={tailGame}
        members={tailGame ? boardSides.get(tailGame.id) ?? [] : []}
        onClose={() => setTailGame(null)}
        onFollow={(gameId, intent) => {
          setTailGame(null);
          setFollow(intent);
          setQuickGame(gameId);
        }}
      />
      <GameQuickView
        gameId={quickGame}
        onClose={() => {
          setQuickGame(null);
          setFollow(null);
        }}
        defaultWallet={follow?.leagueId}
        follow={follow}
      />
    </View>
  );
}

function dayKey(ms: number): string {
  const d = new Date(ms);
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

function dayTitle(ms: number): string {
  const d = new Date(ms);
  const start = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((start(d) - start(new Date())) / 86_400_000);
  if (diff <= 0) return "Today";
  if (diff === 1) return "Tomorrow";
  return d.toLocaleDateString([], { weekday: "long", month: "short", day: "numeric" });
}

function SkeletonList({ colors }: { colors: ReturnType<typeof useColors> }) {
  return (
    <View style={styles.listContent}>
      {[0, 1, 2, 3].map((i) => (
        <View
          key={i}
          style={[styles.skeleton, { backgroundColor: colors.card, borderColor: colors.border }]}
        >
          <View style={[styles.skelBar, { backgroundColor: colors.secondary, width: "35%" }]} />
          <View style={styles.skelRow}>
            <View style={[styles.skelBar, { backgroundColor: colors.secondary, flex: 1, height: 46 }]} />
            <View style={[styles.skelBar, { backgroundColor: colors.secondary, flex: 1, height: 46 }]} />
          </View>
        </View>
      ))}
      <ActivityIndicator color={colors.mutedForeground} style={{ marginTop: 12 }} />
    </View>
  );
}

function EmptyState({
  colors,
  error,
  sport,
  onClearFilter,
}: {
  colors: ReturnType<typeof useColors>;
  error: string | null;
  sport: string;
  onClearFilter: () => void;
}) {
  const filtered = sport !== ALL;
  return (
    <View style={[styles.empty, { borderColor: colors.border, backgroundColor: colors.card }]}>
      <MaterialCommunityIcons
        name={error ? "wifi-off" : "calendar-blank-outline"}
        size={34}
        color={colors.mutedForeground}
      />
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
        {error ? "Can't reach the board" : filtered ? `No ${sport} games right now` : "No games on the board"}
      </Text>
      <Text style={[styles.emptyBody, { color: colors.mutedForeground }]}>
        {error
          ? "You're offline, or the scores service is down. The board will fill in on its own once you're back."
          : "Fixtures land here as soon as they're scheduled. Check back closer to game day."}
      </Text>
      {filtered && !error && (
        <Pressable
          style={[styles.emptyBtn, { borderColor: colors.alpha(colors.primary, 0.6), backgroundColor: colors.alpha(colors.primary, 0.12) }]}
          onPress={onClearFilter}
        >
          <Text style={[styles.emptyBtnText, { color: colors.primary }]}>Show All Sports</Text>
        </Pressable>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { borderBottomWidth: 1, paddingBottom: 12 },
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  title: { fontSize: 24, fontFamily: "Inter_900Black" },
  headerRight: { flexDirection: "row", alignItems: "center", gap: 8 },
  pendingBadge: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, borderWidth: 1 },
  pendingText: { fontSize: 12, fontFamily: "Inter_700Bold" },
  filterList: { paddingHorizontal: 16, gap: 8 },
  chip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, borderWidth: 1 },
  chipText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  banner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginHorizontal: 16,
    marginTop: 10,
    padding: 10,
    borderRadius: 10,
    borderWidth: 1,
  },
  bannerText: { flex: 1, fontSize: 12, fontFamily: "Inter_500Medium" },
  listContent: { padding: 16 },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingVertical: 10,
  },
  liveDot: { width: 8, height: 8, borderRadius: 4 },
  adRow: { marginBottom: 10 },
  sectionTitle: { fontSize: 16, fontFamily: "Inter_700Bold" },
  skeleton: { borderRadius: 16, borderWidth: 1, padding: 14, marginBottom: 10, gap: 12 },
  skelBar: { height: 12, borderRadius: 6 },
  skelRow: { flexDirection: "row", gap: 10 },
  empty: {
    alignItems: "center",
    gap: 10,
    padding: 32,
    borderRadius: 16,
    borderWidth: 1,
    marginTop: 24,
  },
  emptyTitle: { fontSize: 16, fontFamily: "Inter_600SemiBold", textAlign: "center" },
  emptyBody: { fontSize: 13, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 19 },
  emptyBtn: { borderWidth: 1.5, borderRadius: 999, paddingHorizontal: 16, paddingVertical: 9, minHeight: 38, justifyContent: "center", marginTop: 4 },
  emptyBtnText: { fontSize: 14, fontFamily: "Inter_800ExtraBold" },
});

function ago(t: number, now: number): string {
  const s = Math.max(0, Math.round((now - t) / 1000));
  if (s < 60) return s < 10 ? "just now" : `${s}s ago`;
  const m = Math.round(s / 60);
  return m < 60 ? `${m}m ago` : `${Math.round(m / 60)}h ago`;
}
