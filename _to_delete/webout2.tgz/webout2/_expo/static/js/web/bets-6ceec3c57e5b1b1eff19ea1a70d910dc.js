__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return MyBetsScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoRouter = require(_dependencyMap[1]);
  var _libSettings = require(_dependencyMap[2]);
  var _react = require(_dependencyMap[3]);
  var _reactNativeWebDistExportsFlatList = require(_dependencyMap[4]);
  var FlatList = _interopDefault(_reactNativeWebDistExportsFlatList);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[5]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsBetBreakdownModal = require(_dependencyMap[7]);
  var BetBreakdownModal = _interopDefault(_componentsBetBreakdownModal);
  var _componentsBetTicket = require(_dependencyMap[8]);
  var BetTicket = _interopDefault(_componentsBetTicket);
  var _componentsGameQuickView = require(_dependencyMap[9]);
  var GameQuickView = _interopDefault(_componentsGameQuickView);
  var _componentsUi = require(_dependencyMap[10]);
  var _contextAppContext = require(_dependencyMap[11]);
  var _contextChallengeContext = require(_dependencyMap[12]);
  var _contextLeagueContext = require(_dependencyMap[13]);
  var _hooksUseColors = require(_dependencyMap[14]);
  var _hooksUseGames = require(_dependencyMap[15]);
  var _reactJsxRuntime = require(_dependencyMap[16]);
  /**
   * Every bet you have, in both wallets.
   */
  function MyBetsScreen() {
    const $ = (0, _reactCompilerRuntime.c)(80);
    const c = (0, _hooksUseColors.useColors)();
    const bottomPad = (0, _componentsUi.useBottomPad)(false);
    const params = (0, _expoRouter.useLocalSearchParams)();
    const {
      bets,
      balance,
      totalWon,
      totalStaked,
      cancelBet
    } = (0, _contextAppContext.useApp)();
    const {
      leagues,
      myLeagueBets
    } = (0, _contextLeagueContext.useLeague)();
    const {
      games
    } = (0, _hooksUseGames.useGames)();
    let t0;
    if ($[0] !== games) {
      t0 = new Map(games.map(_temp));
      $[0] = games;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    const gameById = t0;
    const [tab, setTab] = (0, _react.useState)("open");
    const [wallet, setWallet] = (0, _react.useState)(params.wallet ?? "all");
    const [busy, setBusy] = (0, _react.useState)(null);
    const [quickGame, setQuickGame] = (0, _react.useState)(null);
    const [breakdown, setBreakdown] = (0, _react.useState)(null);
    const {
      incoming: chIn,
      outgoing: chOut,
      live: chLive,
      escrowed
    } = (0, _contextChallengeContext.useChallenges)();
    const openChallenges = chIn.length + chOut.length + chLive.length;
    let t1;
    if ($[2] !== bets || $[3] !== leagues || $[4] !== myLeagueBets || $[5] !== wallet) {
      const out = [];
      if (wallet === "all" || wallet === "credits") {
        for (const b of bets) {
          out.push({
            bet: b,
            key: b.id,
            placed: (b.placedAt?.seconds ?? 0) * 1000,
            wallet: null,
            cancellable: true
          });
        }
      }
      for (const lg of leagues) {
        if (wallet !== "all" && wallet !== lg.id) {
          continue;
        }
        for (const b_0 of myLeagueBets[lg.id] ?? []) {
          out.push({
            bet: b_0,
            key: `${lg.id}:${b_0.id}`,
            placed: b_0.placedAt,
            wallet: lg.name,
            leagueId: lg.id,
            cancellable: false
          });
        }
      }
      t1 = out.sort(_temp2);
      $[2] = bets;
      $[3] = leagues;
      $[4] = myLeagueBets;
      $[5] = wallet;
      $[6] = t1;
    } else {
      t1 = $[6];
    }
    const rows = t1;
    const open = rows.filter(_temp3);
    const settled = rows.filter(_temp4);
    const list = tab === "open" ? open : settled;
    const openNew = (0, _libSettings.useUnseenCount)("bets.open", open.map(_temp5), tab === "open");
    const settledNew = (0, _libSettings.useUnseenCount)("bets.settled", settled.map(_temp6), tab === "settled");
    const won = settled.filter(_temp7).length;
    const lost = settled.filter(_temp8).length;
    const pushes = settled.filter(_temp9).length;
    let t2;
    if ($[7] !== lost || $[8] !== won) {
      t2 = won + lost > 0 ? Math.round(won / (won + lost) * 100) : null;
      $[7] = lost;
      $[8] = won;
      $[9] = t2;
    } else {
      t2 = $[9];
    }
    const winRate = t2;
    let t3;
    let t4;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
      t3 = {
        id: "all",
        label: "All"
      };
      t4 = {
        id: "credits",
        label: "Credits"
      };
      $[10] = t3;
      $[11] = t4;
    } else {
      t3 = $[10];
      t4 = $[11];
    }
    let t5;
    if ($[12] !== leagues) {
      t5 = [t3, t4, ...leagues.map(_temp0)];
      $[12] = leagues;
      $[13] = t5;
    } else {
      t5 = $[13];
    }
    const wallets = t5;
    let t6;
    if ($[14] !== c.background) {
      t6 = [styles.container, {
        backgroundColor: c.background
      }];
      $[14] = c.background;
      $[15] = t6;
    } else {
      t6 = $[15];
    }
    const t7 = `${won}W · ${lost}L${pushes ? ` · ${pushes}P` : ""}${winRate !== null ? ` · ${winRate}% hit rate` : ""}`;
    let t8;
    if ($[16] !== balance) {
      t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
        value: balance,
        animate: true
      });
      $[16] = balance;
      $[17] = t8;
    } else {
      t8 = $[17];
    }
    let t9;
    if ($[18] !== totalStaked) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.StatTile, {
        label: "Staked",
        hint: "credits, all time",
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
          value: totalStaked,
          size: "sm",
          tone: "neutral"
        })
      });
      $[18] = totalStaked;
      $[19] = t9;
    } else {
      t9 = $[19];
    }
    const t10 = totalWon > 0 ? "positive" : "neutral";
    let t11;
    if ($[20] !== t10 || $[21] !== totalWon) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.StatTile, {
        label: "Net From Wins",
        hint: "credits",
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
          value: totalWon,
          size: "sm",
          tone: t10,
          signed: true
        })
      });
      $[20] = t10;
      $[21] = totalWon;
      $[22] = t11;
    } else {
      t11 = $[22];
    }
    let t12;
    if ($[23] !== t11 || $[24] !== t9) {
      t12 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.stats,
        children: [t9, t11]
      });
      $[23] = t11;
      $[24] = t9;
      $[25] = t12;
    } else {
      t12 = $[25];
    }
    let t13;
    if ($[26] !== chIn || $[27] !== escrowed || $[28] !== openChallenges) {
      t13 = openChallenges > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
        icon: "sword-cross",
        label: `${openChallenges} friend challenge${openChallenges > 1 ? "s" : ""}${escrowed ? ` · ${escrowed.toLocaleString()} in pots` : ""}${chIn.length ? ` · ${chIn.length} need an answer` : ""}`,
        onPress: _temp1,
        style: {
          alignSelf: "flex-start"
        }
      });
      $[26] = chIn;
      $[27] = escrowed;
      $[28] = openChallenges;
      $[29] = t13;
    } else {
      t13 = $[29];
    }
    let t14;
    if ($[30] !== leagues.length || $[31] !== wallet || $[32] !== wallets) {
      t14 = leagues.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.FilterPills, {
        value: wallet,
        onChange: setWallet,
        inset: 0,
        options: wallets.map(_temp10)
      });
      $[30] = leagues.length;
      $[31] = wallet;
      $[32] = wallets;
      $[33] = t14;
    } else {
      t14 = $[33];
    }
    const t15 = openNew || undefined;
    let t16;
    if ($[34] !== t15) {
      t16 = {
        value: "open",
        label: "Open",
        badge: t15
      };
      $[34] = t15;
      $[35] = t16;
    } else {
      t16 = $[35];
    }
    const t17 = settledNew || undefined;
    let t18;
    if ($[36] !== t17) {
      t18 = {
        value: "settled",
        label: "Settled",
        badge: t17
      };
      $[36] = t17;
      $[37] = t18;
    } else {
      t18 = $[37];
    }
    let t19;
    if ($[38] !== t16 || $[39] !== t18) {
      t19 = [t16, t18];
      $[38] = t16;
      $[39] = t18;
      $[40] = t19;
    } else {
      t19 = $[40];
    }
    let t20;
    if ($[41] !== t19 || $[42] !== tab) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.TabStrip, {
        value: tab,
        onChange: setTab,
        options: t19
      });
      $[41] = t19;
      $[42] = tab;
      $[43] = t20;
    } else {
      t20 = $[43];
    }
    let t21;
    if ($[44] !== t12 || $[45] !== t13 || $[46] !== t14 || $[47] !== t20 || $[48] !== t7 || $[49] !== t8) {
      t21 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.ScreenHeader, {
        back: true,
        title: "My Bets",
        subtitle: t7,
        right: t8,
        children: [t12, t13, t14, t20]
      });
      $[44] = t12;
      $[45] = t13;
      $[46] = t14;
      $[47] = t20;
      $[48] = t7;
      $[49] = t8;
      $[50] = t21;
    } else {
      t21 = $[50];
    }
    let t22;
    if ($[51] !== bottomPad) {
      t22 = [styles.list, {
        paddingBottom: bottomPad
      }];
      $[51] = bottomPad;
      $[52] = t22;
    } else {
      t22 = $[52];
    }
    let t23;
    if ($[53] !== busy || $[54] !== cancelBet || $[55] !== gameById) {
      t23 = t24 => {
        const {
          item
        } = t24;
        return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BetTicket.default, {
          bet: item.bet,
          walletLabel: item.wallet ?? undefined,
          game: gameById.get(item.bet.gameId) ?? null,
          busy: busy === item.key,
          onOpen: () => {
            if (item.bet.status !== "pending") {
              setBreakdown({
                id: item.bet.id,
                gameId: item.bet.gameId,
                sport: item.bet.sport,
                teamName: item.bet.teamName,
                teamAbbr: item.bet.teamAbbr,
                teamColor: item.bet.teamColor,
                opponentAbbr: item.bet.opponentAbbr,
                side: item.bet.side,
                market: item.bet.market ?? "ml",
                selection: item.bet.selection ?? null,
                line: item.bet.line ?? null,
                label: item.bet.label ?? null,
                lock: Boolean(item.bet.lockWeek),
                odds: item.bet.odds,
                stake: item.bet.stake,
                payout: item.bet.potentialPayout,
                status: item.bet.status,
                finalHomeScore: item.bet.finalHomeScore ?? null,
                finalAwayScore: item.bet.finalAwayScore ?? null,
                wallet: item.wallet ? "league" : "credits",
                leagueId: item.leagueId ?? null,
                leagueName: item.wallet,
                placedAtMs: item.placed || null
              });
            } else {
              setQuickGame(item.bet.gameId);
            }
          },
          onCancel: item.cancellable ? async () => {
            setBusy(item.key);
            await cancelBet(item.bet.id);
            setBusy(null);
          } : undefined
        });
      };
      $[53] = busy;
      $[54] = cancelBet;
      $[55] = gameById;
      $[56] = t23;
    } else {
      t23 = $[56];
    }
    const t24 = tab === "open" ? "ticket-outline" : "history";
    const t25 = tab === "open" ? "No open bets" : "Nothing settled yet";
    const t26 = tab === "open" ? "Pick a game on the board and back a team." : "Results land here automatically when games finish \u2014 you don't need the app open.";
    const t27 = tab === "open" ? "Browse games" : undefined;
    let t28;
    if ($[57] !== t24 || $[58] !== t25 || $[59] !== t26 || $[60] !== t27) {
      t28 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
        icon: t24,
        title: t25,
        body: t26,
        action: t27,
        onAction: _temp12
      });
      $[57] = t24;
      $[58] = t25;
      $[59] = t26;
      $[60] = t27;
      $[61] = t28;
    } else {
      t28 = $[61];
    }
    let t29;
    if ($[62] !== list || $[63] !== t22 || $[64] !== t23 || $[65] !== t28) {
      t29 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FlatList.default, {
        data: list,
        keyExtractor: _temp11,
        contentContainerStyle: t22,
        showsVerticalScrollIndicator: false,
        initialNumToRender: 10,
        windowSize: 7,
        renderItem: t23,
        ListEmptyComponent: t28
      });
      $[62] = list;
      $[63] = t22;
      $[64] = t23;
      $[65] = t28;
      $[66] = t29;
    } else {
      t29 = $[66];
    }
    let t30;
    let t31;
    if ($[67] === Symbol.for("react.memo_cache_sentinel")) {
      t30 = () => setBreakdown(null);
      t31 = gId => setQuickGame(gId);
      $[67] = t30;
      $[68] = t31;
    } else {
      t30 = $[67];
      t31 = $[68];
    }
    let t32;
    if ($[69] !== breakdown) {
      t32 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BetBreakdownModal.default, {
        item: breakdown,
        onClose: t30,
        onOpenGame: t31
      });
      $[69] = breakdown;
      $[70] = t32;
    } else {
      t32 = $[70];
    }
    let t33;
    if ($[71] === Symbol.for("react.memo_cache_sentinel")) {
      t33 = () => setQuickGame(null);
      $[71] = t33;
    } else {
      t33 = $[71];
    }
    let t34;
    if ($[72] !== quickGame) {
      t34 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(GameQuickView.default, {
        gameId: quickGame,
        onClose: t33
      });
      $[72] = quickGame;
      $[73] = t34;
    } else {
      t34 = $[73];
    }
    let t35;
    if ($[74] !== t21 || $[75] !== t29 || $[76] !== t32 || $[77] !== t34 || $[78] !== t6) {
      t35 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t6,
        children: [t21, t29, t32, t34]
      });
      $[74] = t21;
      $[75] = t29;
      $[76] = t32;
      $[77] = t34;
      $[78] = t6;
      $[79] = t35;
    } else {
      t35 = $[79];
    }
    return t35;
  }
  function _temp12() {
    return _expoRouter.router.navigate("/(tabs)/games");
  }
  function _temp11(r_6) {
    return r_6.key;
  }
  function _temp10(w) {
    return {
      value: w.id,
      label: w.label,
      icon: w.id === "credits" ? "lightning-bolt" : "shield-star"
    };
  }
  function _temp1() {
    return _expoRouter.router.push("/challenges");
  }
  function _temp0(l) {
    return {
      id: l.id,
      label: l.name
    };
  }
  function _temp9(r_5) {
    return r_5.bet.status === "push";
  }
  function _temp8(r_4) {
    return r_4.bet.status === "lost";
  }
  function _temp7(r_3) {
    return r_3.bet.status === "won";
  }
  function _temp6(r_2) {
    return r_2.key;
  }
  function _temp5(r_1) {
    return r_1.key;
  }
  function _temp4(r_0) {
    return r_0.bet.status !== "pending";
  }
  function _temp3(r) {
    return r.bet.status === "pending";
  }
  function _temp2(a, b_1) {
    return b_1.placed - a.placed;
  }
  function _temp(g) {
    return [g.id, g];
  }
  const styles = StyleSheet.default.create({
    container: {
      flex: 1
    },
    stats: {
      flexDirection: "row",
      gap: 8
    },
    chips: {
      gap: 8
    },
    chip: {
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderRadius: 999,
      borderWidth: 1,
      maxWidth: 180
    },
    chipText: {
      fontSize: 12,
      fontFamily: "Inter_600SemiBold"
    },
    list: {
      padding: 16
    }
  });
},758,[815,817,816,12,107,28,109,890,891,851,836,837,821,858,819,860,6]);