__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      if (k === 'default') return;
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return OnboardingScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _libPromptGate = require(_dependencyMap[2]);
  var _libMotion = require(_dependencyMap[3]);
  var _expoRouter = require(_dependencyMap[4]);
  var _react = require(_dependencyMap[5]);
  var _reactNativeWebDistExportsActivityIndicator = require(_dependencyMap[6]);
  var ActivityIndicator = _interopDefault(_reactNativeWebDistExportsActivityIndicator);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[7]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[8]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[9]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsTextInput = require(_dependencyMap[10]);
  var TextInput = _interopDefault(_reactNativeWebDistExportsTextInput);
  var _reactNativeWebDistExportsView = require(_dependencyMap[11]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[12]);
  var _reactNativeSafeAreaContext = require(_dependencyMap[13]);
  var _componentsAvatarDisplay = require(_dependencyMap[14]);
  var AvatarDisplay = _interopDefault(_componentsAvatarDisplay);
  var _componentsFavoriteTeamsSheet = require(_dependencyMap[15]);
  var FavoriteTeamsSheet = _interopDefault(_componentsFavoriteTeamsSheet);
  var _componentsDailyPickCard = require(_dependencyMap[16]);
  var DailyPickCard = _interopDefault(_componentsDailyPickCard);
  var _componentsInviteFriendsCard = require(_dependencyMap[17]);
  var InviteFriendsCard = _interopDefault(_componentsInviteFriendsCard);
  var _componentsPushPrimer = require(_dependencyMap[18]);
  var PushPrimer = _interopDefault(_componentsPushPrimer);
  var _contextNotificationContext = require(_dependencyMap[19]);
  var _componentsAvatarEditorControls = require(_dependencyMap[20]);
  var _componentsUi = require(_dependencyMap[21]);
  var _hooksUseCatalog = require(_dependencyMap[22]);
  var _libDemo = require(_dependencyMap[23]);
  var _appLogin = require(_dependencyMap[24]);
  var _libSettings = require(_dependencyMap[25]);
  var _constantsAvatarOptions = require(_dependencyMap[26]);
  var _firebaseFirestore = require(_dependencyMap[27]);
  var _contextLeagueContext = require(_dependencyMap[28]);
  var _libAnalytics = require(_dependencyMap[29]);
  var _libApi = require(_dependencyMap[30]);
  var api = _interopNamespace(_libApi);
  var _libFirebase = require(_dependencyMap[31]);
  var _libInvites = require(_dependencyMap[32]);
  var _libReferrals = require(_dependencyMap[33]);
  var _constantsProgression = require(_dependencyMap[34]);
  var _hooksUseColors = require(_dependencyMap[35]);
  var _reactJsxRuntime = require(_dependencyMap[36]);
  /** Nothing is worn at signup (createProfile equips nothing; the starter kit goes to the inventory). */const NO_OUTFIT = {};

  /**
   * Order follows time-to-value: who you are → a quick character → your teams →
   * your crew → a first (free) pick → the push primer → done. Anything skipped
   * can be finished later (Locker, Friends tab).
   */

  const STEP_ORDER = ["identity", "appearance", "teams", "crew", "pick", "welcome"];
  function OnboardingScreen() {
    const colors = (0, _hooksUseColors.useColors)();
    const pendingMeta = (0, _libSettings.usePendingSignupMeta)();
    const [step, setStep] = (0, _react.useState)("identity");
    const [teamsOpen, setTeamsOpen] = (0, _react.useState)(false);
    const [teamsSet, setTeamsSet] = (0, _react.useState)(false);
    const [moreLooks, setMoreLooks] = (0, _react.useState)(false);
    const [primer, setPrimer] = (0, _react.useState)(false);
    const {
      pushStatus,
      enablePush
    } = (0, _contextNotificationContext.useNotifications)();
    // Email sign-up already collected birth date / age and phone: never ask twice.
    const ageFromSignup = !!pendingMeta?.age || !!pendingMeta?.birthDate;
    const phoneFromSignup = (0, _appLogin.extractPhoneDigits)(pendingMeta?.phoneNumber ?? "").length === 10;
    const [username, setUsername] = (0, _react.useState)("");
    const [displayName, setDisplayName] = (0, _react.useState)("");
    const [ageText, setAgeText] = (0, _react.useState)(pendingMeta?.age ? String(pendingMeta.age) : "");
    const [phone, setPhone] = (0, _react.useState)(pendingMeta?.phoneNumber ?? "");
    // Everyone starts from the same plain base (bald, nothing worn) and builds from there.
    const [avatar, setAvatar] = (0, _react.useState)(_constantsAvatarOptions.SIGNUP_AVATAR);
    const [tab, setTab] = (0, _react.useState)("body");
    const [cheer, setCheer] = (0, _react.useState)(0);

    // A friend's invite code: pre-filled from a sportdrip://ref link, checked as you type.
    const [refText, setRefText] = (0, _react.useState)("");
    const [refCheck, setRefCheck] = (0, _react.useState)({
      state: "idle"
    });
    const [referred, setReferred] = (0, _react.useState)(null);
    const refCode = (0, _libReferrals.normalizeReferralCode)(refText);
    (0, _react.useEffect)(() => {
      void (0, _libReferrals.peekPendingReferral)().then(code => {
        if (code) setRefText(t => t || code);
      });
    }, []);
    (0, _react.useEffect)(() => {
      if (!refText.trim()) {
        setRefCheck({
          state: "idle"
        });
        return;
      }
      if (!refCode) {
        setRefCheck({
          state: "invalid"
        });
        return;
      }
      let cancelled = false;
      setRefCheck({
        state: "checking"
      });
      const t = setTimeout(async () => {
        try {
          const res = _libDemo.DEMO ? {
            valid: true,
            displayName: "a friend",
            username: null
          } : await api.checkReferralCode({
            code: refCode
          });
          if (cancelled) return;
          setRefCheck(res.valid ? {
            state: "valid",
            name: res.displayName,
            username: res.username
          } : {
            state: "invalid"
          });
        } catch {
          if (!cancelled) setRefCheck({
            state: "idle"
          });
        }
      }, 400);
      return () => {
        cancelled = true;
        clearTimeout(t);
      };
    }, [refText, refCode]);
    const [checking, setChecking] = (0, _react.useState)(false);
    const [available, setAvailable] = (0, _react.useState)(null);
    const [submitting, setSubmitting] = (0, _react.useState)(false);
    const [error, setError] = (0, _react.useState)(null);
    (0, _react.useEffect)(() => {
      if (pendingMeta?.age && !ageText) setAgeText(String(pendingMeta.age));
      if (pendingMeta?.phoneNumber && !phone) setPhone(pendingMeta.phoneNumber);
    }, [pendingMeta, ageText, phone]);

    // An invite link opened before signup: joined automatically once the profile exists.
    const {
      joinLeague
    } = (0, _contextLeagueContext.useLeague)();
    const [invite, setInvite] = (0, _react.useState)(null);
    const normalized = username.trim().toLowerCase();
    const usernameValid = /^[a-z0-9_]{3,20}$/.test(normalized);
    const parsedAge = Number.parseInt(ageText, 10);
    const ageValid = ageFromSignup || Number.isFinite(parsedAge) && parsedAge >= 18 && parsedAge <= 120;
    const phoneDigits = (0, _appLogin.extractPhoneDigits)(phone);
    const phoneValid = phoneFromSignup || phoneDigits.length === 10;

    // Debounced availability check.
    (0, _react.useEffect)(() => {
      if (!usernameValid) {
        setAvailable(null);
        return;
      }
      let cancelled = false;
      setChecking(true);
      const t = setTimeout(async () => {
        try {
          const res = _libDemo.DEMO ? {
            available: true
          } : await api.checkUsername({
            username: normalized
          });
          if (!cancelled) setAvailable(res.available);
        } catch {
          if (!cancelled) setAvailable(null);
        } finally {
          if (!cancelled) setChecking(false);
        }
      }, 400);
      return () => {
        cancelled = true;
        clearTimeout(t);
      };
    }, [normalized, usernameValid]);
    const canContinue = usernameValid && available === true && displayName.trim().length > 0 && ageValid && phoneValid && refCheck.state !== "invalid" && refCheck.state !== "checking";
    const handleCreate = (0, _react.useCallback)(async () => {
      setError(null);
      setSubmitting(true);
      try {
        if (!_libDemo.DEMO) {
          await api.createProfile({
            username: normalized,
            displayName: displayName.trim(),
            avatar,
            ...(Number.isFinite(parsedAge) ? {
              age: parsedAge
            } : pendingMeta?.age ? {
              age: pendingMeta.age
            } : {}),
            birthDate: pendingMeta?.birthDate,
            phoneNumber: phone,
            ...(refCode && refCheck.state === "valid" ? {
              referralCode: refCode
            } : {})
          });
        }
        if (refCheck.state === "valid") setReferred(refCheck.name);
        void (0, _libReferrals.clearPendingReferral)();
        (0, _libSettings.setPendingSignupMeta)(null);
        const code = _libDemo.DEMO ? null : await (0, _libInvites.takePendingInvite)();
        (0, _libAnalytics.trackEvent)("onboarding_completed", {
          has_pending_invite: !!code
        });
        _libMotion.haptic.success();
        setCheer(n => n + 1);
        setStep("teams");
        if (code) void joinFromInvite(code);
      } catch (err) {
        setError(api.friendlyError(err));
      } finally {
        setSubmitting(false);
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [normalized, displayName, avatar, parsedAge, pendingMeta?.birthDate, phone, setStep, refCode, refCheck]);
    async function joinFromInvite(code) {
      setInvite({
        code,
        name: null,
        state: "joining"
      });
      const db = (0, _libFirebase.getDb)();
      const preview = db ? (0, _firebaseFirestore.getDoc)((0, _firebaseFirestore.doc)(db, "leagueInvites", code)).then(s => s.exists() ? s.get("leagueName") ?? null : null).catch(() => null) : Promise.resolve(null);
      const [res, name] = await Promise.all([joinLeague(code, "signup"), preview]);
      if ("error" in res) setInvite({
        code,
        name,
        state: "failed",
        error: res.error
      });else {
        _libMotion.haptic.success();
        setInvite({
          code,
          name,
          state: "joined",
          leagueId: res.leagueId
        });
      }
    }

    // After the first pick: soft push pre-prompt (never the system dialog cold), then done.
    function afterPick() {
      if (pushStatus === "undetermined" && (0, _libSettings.pushPrimerDue)()) {
        (0, _libSettings.markPushPrimerShown)();
        setPrimer(true);
        return;
      }
      setStep("welcome");
    }
    function finish() {
      // The walkthrough no longer auto-opens: onboarding already covered it (Help on Home replays it).
      (0, _libSettings.markWalkthroughSeen)();
      if (invite?.state === "joined") {
        _expoRouter.router.replace({
          pathname: "/league/[id]",
          params: {
            id: invite.leagueId
          }
        });
      } else if (invite?.state === "failed") {
        _expoRouter.router.replace({
          pathname: "/(tabs)/leagues",
          params: {
            join: "1",
            code: invite.code,
            via: "link",
            t: String(Date.now())
          }
        });
      } else {
        _expoRouter.router.replace("/(tabs)");
      }
    }
    const {
      byId: catalog
    } = (0, _hooksUseCatalog.useCatalog)();
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactNativeSafeAreaContext.SafeAreaView, {
      style: [s.safe, {
        backgroundColor: colors.background
      }],
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(ProgressDots, {
        step: step,
        colors: colors
      }), step === "identity" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        contentContainerStyle: s.body,
        keyboardShouldPersistTaps: "handled",
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [s.title, {
            color: colors.foreground
          }],
          children: "Pick Your Name"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [s.sub, {
            color: colors.mutedForeground
          }],
          children: "Your username is how friends find you. Complete your profile details below."
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Field, {
          label: "Username",
          colors: colors,
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: s.inputRow,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [s.at, {
                color: colors.mutedForeground
              }],
              children: "@"
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TextInput.default, {
              style: [s.input, {
                color: colors.foreground
              }],
              value: username,
              onChangeText: setUsername,
              placeholder: "courtvision",
              placeholderTextColor: colors.mutedForeground,
              autoCapitalize: "none",
              autoCorrect: false,
              maxLength: 20
            }), checking && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
              size: "small",
              color: colors.mutedForeground
            }), !checking && available === true && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "check-circle",
              size: 18,
              color: colors.primary
            }), !checking && available === false && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "close-circle",
              size: 18,
              color: colors.destructive
            })]
          })
        }), username.length > 0 && !usernameValid && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Hint, {
          colors: colors,
          tone: "muted",
          children: "3\u201320 characters: lowercase letters, numbers and underscores."
        }), available === false && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Hint, {
          colors: colors,
          tone: "error",
          children: "That username is taken."
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Field, {
          label: "Display Name",
          colors: colors,
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TextInput.default, {
            style: [s.input, {
              color: colors.foreground
            }],
            value: displayName,
            onChangeText: setDisplayName,
            placeholder: "Jordan",
            placeholderTextColor: colors.mutedForeground,
            maxLength: 30
          })
        }), !ageFromSignup && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Field, {
            label: "Age (18+)",
            colors: colors,
            children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: s.inputRow,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "calendar-account-outline",
                size: 18,
                color: colors.mutedForeground
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TextInput.default, {
                style: [s.input, {
                  color: colors.foreground
                }],
                value: ageText,
                onChangeText: v => setAgeText(v.replace(/\D/g, "").slice(0, 3)),
                placeholder: "21",
                placeholderTextColor: colors.mutedForeground,
                keyboardType: "number-pad",
                maxLength: 3
              }), ageValid && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "check-circle",
                size: 18,
                color: colors.primary
              })]
            })
          }), ageText.length > 0 && !ageValid && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Hint, {
            colors: colors,
            tone: "error",
            children: "You must be 18 or older to play."
          })]
        }), !phoneFromSignup && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Field, {
            label: "Phone Number",
            colors: colors,
            children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: s.inputRow,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "phone-outline",
                size: 18,
                color: colors.mutedForeground
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TextInput.default, {
                style: [s.input, {
                  color: colors.foreground
                }],
                value: phone,
                onChangeText: v => setPhone((0, _appLogin.formatPhoneMask)(v)),
                placeholder: "(555) 123-4567",
                placeholderTextColor: colors.mutedForeground,
                keyboardType: "phone-pad",
                maxLength: 14
              }), phoneValid && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "check-circle",
                size: 18,
                color: colors.primary
              })]
            })
          }), phone.length > 0 && !phoneValid && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Hint, {
            colors: colors,
            tone: "muted",
            children: "Enter a 10-digit US phone number."
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Field, {
          label: "Invite code (optional)",
          colors: colors,
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: s.inputRow,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "ticket-percent-outline",
              size: 18,
              color: colors.mutedForeground
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TextInput.default, {
              style: [s.input, {
                color: colors.foreground,
                letterSpacing: refText ? 2 : 0
              }],
              value: refText,
              onChangeText: v => setRefText(v.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10)),
              placeholder: "From a friend",
              placeholderTextColor: colors.mutedForeground,
              autoCapitalize: "characters",
              autoCorrect: false,
              maxLength: 10
            }), refCheck.state === "checking" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
              size: "small",
              color: colors.mutedForeground
            }), refCheck.state === "valid" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "check-circle",
              size: 18,
              color: colors.primary
            }), refCheck.state === "invalid" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "close-circle",
              size: 18,
              color: colors.destructive
            })]
          })
        }), refCheck.state === "valid" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Hint, {
          colors: colors,
          tone: "muted",
          children: ["Invited by ", refCheck.name, refCheck.username ? ` (@${refCheck.username})` : "", " \u2014 you'll start with +", _constantsProgression.REFERRAL.newUserCredits.toLocaleString(), " bonus credits."]
        }), refCheck.state === "invalid" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Hint, {
          colors: colors,
          tone: "error",
          children: "We couldn't find that code. Check it or leave it blank."
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PrimaryButton, {
          label: "Continue",
          disabled: !canContinue,
          onPress: () => setStep("appearance"),
          colors: colors
        })]
      }), step === "appearance" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        contentContainerStyle: s.body,
        showsVerticalScrollIndicator: false,
        stickyHeaderIndices: [1],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [s.title, {
            color: colors.foreground
          }],
          children: "Make It Yours"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: {
            backgroundColor: colors.background,
            paddingBottom: 12
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [s.preview, {
              backgroundColor: colors.secondary,
              borderColor: colors.border
            }],
            children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarDisplay.default, {
              avatar: avatar,
              equipped: NO_OUTFIT,
              catalog: catalog,
              size: "lg",
              focus: tab === "body" ? "full" : "head",
              cheerSignal: cheer
            })
          }), moreLooks ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SegmentedControl, {
            style: {
              marginTop: 12
            },
            options: [{
              value: "body",
              label: "Body"
            }, {
              value: "face",
              label: "Face"
            }, {
              value: "hair",
              label: "Hair"
            }],
            value: tab,
            onChange: setTab
          }) : null]
        }), !moreLooks && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Swatches, {
            label: "Skin Tone",
            options: _constantsAvatarOptions.SKIN_TONES,
            value: avatar.skinTone,
            onChange: skinTone => setAvatar(a => ({
              ...a,
              skinTone
            }))
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Hair",
            options: _constantsAvatarOptions.HAIR_STYLES,
            value: avatar.hairStyle,
            onChange: hairStyle => setAvatar(a => ({
              ...a,
              hairStyle
            }))
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Swatches, {
            label: "Hair Colour",
            options: _constantsAvatarOptions.HAIR_COLORS,
            value: avatar.hairColor,
            onChange: hairColor => setAvatar(a => ({
              ...a,
              hairColor
            }))
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: "More Options",
            icon: "tune-variant",
            variant: "ghost",
            onPress: () => setMoreLooks(true)
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Hint, {
            colors: colors,
            tone: "muted",
            children: "You can finish your look in the Locker anytime."
          })]
        }), moreLooks && tab === "body" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Swatches, {
            label: "Skin Tone",
            options: _constantsAvatarOptions.SKIN_TONES,
            value: avatar.skinTone,
            onChange: skinTone => setAvatar(a => ({
              ...a,
              skinTone
            }))
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Stops, {
            label: "Height",
            value: avatar.height,
            onChange: height => setAvatar(a => ({
              ...a,
              height
            })),
            ends: ["Shorter", "Taller"]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Stops, {
            label: "Build",
            value: avatar.bodyType,
            onChange: bodyType => setAvatar(a => ({
              ...a,
              bodyType
            })),
            ends: ["Slim", "Broad"]
          })]
        }), moreLooks && tab === "face" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Face Shape",
            options: _constantsAvatarOptions.FACE_SHAPES,
            value: avatar.faceShape ?? "oval",
            onChange: faceShape => setAvatar(a => ({
              ...a,
              faceShape
            }))
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Eye Shape",
            options: _constantsAvatarOptions.EYE_SHAPES,
            value: avatar.eyeShape ?? "round",
            onChange: eyeShape => setAvatar(a => ({
              ...a,
              eyeShape
            }))
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Swatches, {
            label: "Eyes",
            options: _constantsAvatarOptions.EYE_COLORS,
            value: avatar.eyeColor ?? _constantsAvatarOptions.EYE_COLORS[0],
            onChange: eyeColor => setAvatar(a => ({
              ...a,
              eyeColor
            }))
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Brows",
            options: _constantsAvatarOptions.EYEBROWS,
            value: avatar.eyebrows ?? "soft",
            onChange: eyebrows => setAvatar(a => ({
              ...a,
              eyebrows
            }))
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Nose",
            options: _constantsAvatarOptions.NOSE_SHAPES,
            value: avatar.noseShape ?? "button",
            onChange: noseShape => setAvatar(a => ({
              ...a,
              noseShape
            }))
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Mouth",
            options: _constantsAvatarOptions.MOUTH_SHAPES,
            value: avatar.mouthShape ?? "neutral",
            onChange: mouthShape => setAvatar(a => ({
              ...a,
              mouthShape
            }))
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Facial Hair",
            options: _constantsAvatarOptions.FACIAL_HAIR,
            value: avatar.facialHair ?? "none",
            onChange: facialHair => setAvatar(a => ({
              ...a,
              facialHair
            }))
          })]
        }), moreLooks && tab === "hair" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Style",
            options: _constantsAvatarOptions.HAIR_STYLES,
            value: avatar.hairStyle,
            onChange: hairStyle => setAvatar(a => ({
              ...a,
              hairStyle
            }))
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Swatches, {
            label: "Colour",
            options: _constantsAvatarOptions.HAIR_COLORS,
            value: avatar.hairColor,
            onChange: hairColor => setAvatar(a => ({
              ...a,
              hairColor
            }))
          })]
        }), error && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Hint, {
          colors: colors,
          tone: "error",
          children: error
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PrimaryButton, {
          label: submitting ? "" : "Looks good — next",
          loading: submitting,
          disabled: submitting,
          onPress: handleCreate,
          colors: colors
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: "Back",
          icon: "arrow-left",
          variant: "ghost",
          onPress: () => setStep("identity")
        })]
      }), step === "teams" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        contentContainerStyle: s.body,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [s.title, {
            color: colors.foreground
          }],
          children: "Who do you root for?"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [s.sub, {
            color: colors.mutedForeground
          }],
          children: "Pick up to five teams. We'll show them on your profile and can remind you before they play."
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PrimaryButton, {
          label: teamsSet ? "Teams saved — next" : "Pick my teams",
          onPress: () => teamsSet ? setStep("crew") : setTeamsOpen(true),
          colors: colors
        }), !teamsSet ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: "Skip for Now",
          variant: "ghost",
          onPress: () => setStep("crew")
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FavoriteTeamsSheet.default, {
          visible: teamsOpen,
          initial: [],
          initialReminders: true,
          saveLabel: "Save teams",
          onSaved: () => {
            setTeamsSet(true);
            setStep("crew");
          },
          onClose: () => setTeamsOpen(false)
        })]
      }), step === "crew" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        contentContainerStyle: s.body,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [s.title, {
            color: colors.foreground
          }],
          children: "Bring Your Crew"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [s.sub, {
            color: colors.mutedForeground
          }],
          children: "SportDrip is better with friends: leagues, head-to-heads and trash talk."
        }), invite ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Hint, {
          colors: colors,
          tone: invite.state === "failed" ? "error" : "muted",
          children: invite.state === "joining" ? `Joining ${invite.name ?? "your friend's league"}…` : invite.state === "joined" ? `You're in ${invite.name ?? "your friend's league"}.` : `Couldn't join ${invite.name ?? `league ${invite.code}`}: ${invite.error}`
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(InviteFriendsCard.default, {}), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PrimaryButton, {
          label: "Next: your first pick",
          onPress: () => setStep("pick"),
          colors: colors
        })]
      }), step === "pick" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        contentContainerStyle: s.body,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [s.title, {
            color: colors.foreground
          }],
          children: "Make Your First Call"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [s.sub, {
            color: colors.mutedForeground
          }],
          children: "Today's Daily Pick is free \u2014 no credits at risk. Call it and start your streak."
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(DailyPickCard.default, {}), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PrimaryButton, {
          label: "Next",
          onPress: afterPick,
          colors: colors
        })]
      }), primer ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PushPrimer.default, {
        onAccept: () => {
          setPrimer(false);
          void enablePush().then(st => {
            (0, _libPromptGate.markPromptResult)("push", st === "granted");
            if (st === "granted") api.setAlertPrefs({
              sweat: true
            }).catch(() => {});
          });
          setStep("welcome");
        },
        onDecline: () => {
          (0, _libPromptGate.markPromptResult)("push", false);
          setPrimer(false);
          setStep("welcome");
        }
      }) : null, step === "welcome" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [s.body, s.welcome],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [s.welcomeIcon, {
            backgroundColor: colors.primary + "22",
            borderColor: colors.primary + "55"
          }],
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "lightning-bolt",
            size: 44,
            color: colors.primary
          })
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [s.title, {
            color: colors.foreground,
            textAlign: "center"
          }],
          children: ["You're in, ", displayName.trim()]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [s.card, {
            backgroundColor: colors.card,
            borderColor: colors.border
          }],
          children: [referred ? {
            icon: "account-heart",
            text: `You start with ${(1000 + _constantsProgression.REFERRAL.newUserCredits).toLocaleString()} credits — ${_constantsProgression.REFERRAL.newUserCredits.toLocaleString()} of them from ${referred}'s invite — and you're already friends.`
          } : {
            icon: "lightning-bolt",
            text: "You start with 1,000 credits and a basic fit."
          }, {
            icon: "star-circle-outline",
            text: "Win, buy and invite friends to level up. Every level pays credits and unlocks gear."
          }, {
            icon: "sportscourt",
            text: "Call games right and your credits grow. Results settle automatically."
          }, {
            icon: "gift-outline",
            text: "Prize boxes hand out free credits on a timer."
          }, {
            icon: "hanger",
            text: "Spend credits in the shop and your character wears it."
          }, {
            icon: "account-group",
            text: "Add friends to see their fits, chat, and go head to head."
          }].map(({
            icon,
            text
          }, i) => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: s.bulletRow,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [s.bulletIcon, {
                backgroundColor: colors.secondary
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: icon,
                size: 16,
                color: colors.primary
              })
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [s.bulletText, {
                color: colors.mutedForeground
              }],
              children: text
            })]
          }, i))
        }), invite ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [s.card, {
            backgroundColor: colors.card,
            borderColor: invite.state === "failed" ? colors.negative : colors.league
          }],
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: s.bulletRow,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [s.bulletIcon, {
                backgroundColor: colors.secondary
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: invite.state === "failed" ? "alert-circle-outline" : "trophy-outline",
                size: 16,
                color: invite.state === "failed" ? colors.negative : colors.league
              })
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [s.bulletText, {
                color: colors.foreground
              }],
              children: invite.state === "joining" ? `Joining ${invite.name ?? "your friend's league"}…` : invite.state === "joined" ? `You're in ${invite.name ?? "your friend's league"}. Your league tokens are waiting.` : `Couldn't join ${invite.name ?? `league ${invite.code}`}: ${invite.error}`
            })]
          })
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PrimaryButton, {
          label: invite?.state === "joined" ? `Go to ${invite.name ?? "the league"}` : invite?.state === "failed" ? "Review the invite" : "Let's go",
          loading: invite?.state === "joining",
          disabled: invite?.state === "joining",
          onPress: finish,
          colors: colors
        }), invite?.state === "failed" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: "Skip for Now",
          variant: "ghost",
          onPress: () => _expoRouter.router.replace("/(tabs)")
        }) : null]
      })]
    });
  }

  /* ── small local building blocks ─────────────────────────────────────────── */

  function ProgressDots(t0) {
    const $ = (0, _reactCompilerRuntime.c)(5);
    const {
      step,
      colors
    } = t0;
    const idx = STEP_ORDER.indexOf(step);
    let t1;
    if ($[0] !== colors || $[1] !== idx) {
      t1 = STEP_ORDER.map((_, i) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [s.dot, {
          backgroundColor: i <= idx ? colors.primary : colors.border,
          width: i === idx ? 22 : 8
        }]
      }, i));
      $[0] = colors;
      $[1] = idx;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    let t2;
    if ($[3] !== t1) {
      t2 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: s.dots,
        children: t1
      });
      $[3] = t1;
      $[4] = t2;
    } else {
      t2 = $[4];
    }
    return t2;
  }
  function Field(t0) {
    const $ = (0, _reactCompilerRuntime.c)(16);
    const {
      label,
      colors,
      children
    } = t0;
    let t1;
    if ($[0] !== colors.mutedForeground) {
      t1 = [s.fieldLabel, {
        color: colors.mutedForeground
      }];
      $[0] = colors.mutedForeground;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    let t2;
    if ($[2] !== label) {
      t2 = label.toUpperCase();
      $[2] = label;
      $[3] = t2;
    } else {
      t2 = $[3];
    }
    let t3;
    if ($[4] !== t1 || $[5] !== t2) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t1,
        children: t2
      });
      $[4] = t1;
      $[5] = t2;
      $[6] = t3;
    } else {
      t3 = $[6];
    }
    let t4;
    if ($[7] !== colors.border || $[8] !== colors.secondary) {
      t4 = [s.fieldBox, {
        borderColor: colors.border,
        backgroundColor: colors.secondary
      }];
      $[7] = colors.border;
      $[8] = colors.secondary;
      $[9] = t4;
    } else {
      t4 = $[9];
    }
    let t5;
    if ($[10] !== children || $[11] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t4,
        children: children
      });
      $[10] = children;
      $[11] = t4;
      $[12] = t5;
    } else {
      t5 = $[12];
    }
    let t6;
    if ($[13] !== t3 || $[14] !== t5) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: s.field,
        children: [t3, t5]
      });
      $[13] = t3;
      $[14] = t5;
      $[15] = t6;
    } else {
      t6 = $[15];
    }
    return t6;
  }
  function Hint(t0) {
    const $ = (0, _reactCompilerRuntime.c)(5);
    const {
      colors,
      tone,
      children
    } = t0;
    const t1 = tone === "error" ? colors.destructive : colors.mutedForeground;
    let t2;
    if ($[0] !== t1) {
      t2 = [s.hint, {
        color: t1
      }];
      $[0] = t1;
      $[1] = t2;
    } else {
      t2 = $[1];
    }
    let t3;
    if ($[2] !== children || $[3] !== t2) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t2,
        children: children
      });
      $[2] = children;
      $[3] = t2;
      $[4] = t3;
    } else {
      t3 = $[4];
    }
    return t3;
  }
  function PrimaryButton(t0) {
    const $ = (0, _reactCompilerRuntime.c)(12);
    const {
      label,
      onPress,
      disabled,
      loading,
      colors
    } = t0;
    let t1;
    if ($[0] !== colors.primary || $[1] !== disabled) {
      t1 = t2 => {
        const {
          pressed
        } = t2;
        return [s.primaryBtn, {
          backgroundColor: colors.primary,
          opacity: disabled ? 0.45 : pressed ? 0.85 : 1
        }];
      };
      $[0] = colors.primary;
      $[1] = disabled;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    let t2;
    if ($[3] !== colors.primaryForeground || $[4] !== label || $[5] !== loading) {
      t2 = loading ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
        color: colors.primaryForeground,
        size: "small"
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [s.primaryBtnText, {
          color: colors.primaryForeground
        }],
        children: label
      });
      $[3] = colors.primaryForeground;
      $[4] = label;
      $[5] = loading;
      $[6] = t2;
    } else {
      t2 = $[6];
    }
    let t3;
    if ($[7] !== disabled || $[8] !== onPress || $[9] !== t1 || $[10] !== t2) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
        style: t1,
        onPress: onPress,
        disabled: disabled,
        children: t2
      });
      $[7] = disabled;
      $[8] = onPress;
      $[9] = t1;
      $[10] = t2;
      $[11] = t3;
    } else {
      t3 = $[11];
    }
    return t3;
  }
  const s = StyleSheet.default.create({
    safe: {
      flex: 1
    },
    dots: {
      flexDirection: "row",
      gap: 6,
      justifyContent: "center",
      paddingVertical: 16
    },
    dot: {
      height: 8,
      borderRadius: 4
    },
    body: {
      padding: 24,
      gap: 18,
      paddingBottom: 48
    },
    title: {
      fontSize: 30,
      fontFamily: "Inter_900Black",
      letterSpacing: -1
    },
    sub: {
      fontSize: 14,
      fontFamily: "Inter_400Regular",
      marginTop: -10
    },
    field: {
      gap: 8
    },
    fieldLabel: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.6
    },
    fieldBox: {
      borderWidth: 1,
      borderRadius: 12,
      paddingHorizontal: 14,
      paddingVertical: 12
    },
    inputRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    at: {
      fontSize: 15,
      fontFamily: "Inter_600SemiBold"
    },
    input: {
      flex: 1,
      fontSize: 15,
      fontFamily: "Inter_400Regular"
    },
    hint: {
      fontSize: 12,
      fontFamily: "Inter_400Regular",
      marginTop: -10
    },
    preview: {
      height: 290,
      borderRadius: 20,
      borderWidth: 1,
      overflow: "hidden"
    },
    primaryBtn: {
      paddingVertical: 15,
      borderRadius: 14,
      alignItems: "center",
      marginTop: 8
    },
    primaryBtnText: {
      fontSize: 16,
      fontFamily: "Inter_700Bold"
    },
    welcome: {
      flex: 1,
      justifyContent: "center",
      alignItems: "stretch",
      gap: 20
    },
    welcomeIcon: {
      width: 88,
      height: 88,
      borderRadius: 44,
      borderWidth: 2,
      alignItems: "center",
      justifyContent: "center",
      alignSelf: "center"
    },
    card: {
      borderRadius: 18,
      borderWidth: 1,
      padding: 18,
      gap: 14
    },
    bulletRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12
    },
    bulletIcon: {
      width: 32,
      height: 32,
      borderRadius: 10,
      alignItems: "center",
      justifyContent: "center"
    },
    bulletText: {
      flex: 1,
      fontSize: 13,
      fontFamily: "Inter_400Regular",
      lineHeight: 19
    }
  });
},772,[815,818,1199,820,817,12,228,133,28,188,255,109,827,271,828,831,892,845,1200,823,1217,836,838,902,769,816,894,905,858,897,863,906,1193,1194,1264,819,6]);