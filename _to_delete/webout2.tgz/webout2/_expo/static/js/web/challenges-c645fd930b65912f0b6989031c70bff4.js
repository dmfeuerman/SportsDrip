__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return ChallengesScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _libMotion = require(_dependencyMap[1]);
  var _libSettings = require(_dependencyMap[2]);
  var _expoRouter = require(_dependencyMap[3]);
  var _react = require(_dependencyMap[4]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[5]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[6]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[7]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[8]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsChallengeCard = require(_dependencyMap[9]);
  var ChallengeCard = _interopDefault(_componentsChallengeCard);
  var _componentsGameQuickView = require(_dependencyMap[10]);
  var GameQuickView = _interopDefault(_componentsGameQuickView);
  var _componentsUi = require(_dependencyMap[11]);
  var _contextAppContext = require(_dependencyMap[12]);
  var _contextChallengeContext = require(_dependencyMap[13]);
  var _contextToastContext = require(_dependencyMap[14]);
  var _hooksUseColors = require(_dependencyMap[15]);
  var _hooksUseGames = require(_dependencyMap[16]);
  var _hooksUseNow = require(_dependencyMap[17]);
  var _reactJsxRuntime = require(_dependencyMap[18]);
  /**
   * Every head-to-head with a friend: offers waiting on you (and on them),
   * accepted pots riding on a game, and what's been settled.
   */
  function ChallengesScreen() {
    const $ = (0, _reactCompilerRuntime.c)(93);
    const c = (0, _hooksUseColors.useColors)();
    const bottom = (0, _componentsUi.useBottomPad)(false);
    const now = (0, _hooksUseNow.useNow)(30000);
    const params = (0, _expoRouter.useLocalSearchParams)();
    const {
      balance
    } = (0, _contextAppContext.useApp)();
    const {
      uid,
      incoming,
      outgoing,
      live,
      history,
      escrowed,
      respond,
      cancel
    } = (0, _contextChallengeContext.useChallenges)();
    const {
      show
    } = (0, _contextToastContext.useToast)();
    const {
      games
    } = (0, _hooksUseGames.useGames)();
    let t0;
    if ($[0] !== games) {
      t0 = new Map(games.map(_temp));
      $[0] = games;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    const gameById = t0;
    const [tab, setTab] = (0, _react.useState)(params.tab === "live" || params.tab === "history" ? params.tab : incoming.length || outgoing.length || !live.length ? "inbox" : "live");
    const [busy, setBusy] = (0, _react.useState)(null);
    const [confirm, setConfirm] = (0, _react.useState)(null);
    const [error, setError] = (0, _react.useState)(null);
    const [quickGame, setQuickGame] = (0, _react.useState)(null);
    let t1;
    if ($[2] !== uid) {
      t1 = list => uid ? list.map(ch => (0, _contextChallengeContext.viewOf)(ch, uid)) : [];
      $[2] = uid;
      $[3] = t1;
    } else {
      t1 = $[3];
    }
    const views = t1;
    const inV = views(incoming);
    const outV = views(outgoing);
    const liveV = views(live);
    let t2;
    if ($[4] !== history || $[5] !== views) {
      t2 = views(history);
      $[4] = history;
      $[5] = views;
      $[6] = t2;
    } else {
      t2 = $[6];
    }
    const histV = t2;
    const inboxNew = (0, _libSettings.useUnseenCount)("challenges.inbox", inV.map(_temp2), tab === "inbox");
    const liveNew = (0, _libSettings.useUnseenCount)("challenges.live", liveV.map(_temp3), tab === "live");
    let r;
    if ($[7] !== histV) {
      r = {
        won: 0,
        lost: 0,
        net: 0
      };
      for (const v_1 of histV) {
        if (v_1.result === "won") {
          r.won = r.won + 1;
          r.net = r.net + v_1.theirStake;
        } else {
          if (v_1.result === "lost") {
            r.lost = r.lost + 1;
            r.net = r.net - v_1.myStake;
          }
        }
      }
      $[7] = histV;
      $[8] = r;
    } else {
      r = $[8];
    }
    const record = r;
    let t3;
    if ($[9] !== respond || $[10] !== show) {
      t3 = async function accept(v_2) {
        setBusy({
          id: v_2.ch.id,
          action: "accept"
        });
        setError(null);
        const res = await respond(v_2.ch.id, true);
        setBusy(null);
        setConfirm(null);
        if (res.error) {
          _libMotion.haptic.error();
          setError(res.error);
          return;
        }
        if (res.status === "expired") {
          show({
            kind: "warning",
            icon: "timer-sand",
            title: "Too Late",
            body: "That game has started, so the challenge expired. Nothing was taken."
          });
          return;
        }
        _libMotion.haptic.success();
        show({
          id: `chacc_${v_2.ch.id}`,
          kind: "social",
          icon: "sword-cross",
          color: v_2.myTeam.color,
          title: `You're on with ${v_2.friendName}`,
          body: `${v_2.ch.pot.toLocaleString()} locked in the pot. ${v_2.myTeam.abbreviation} wins it for you.`
        });
        setTab("live");
      };
      $[9] = respond;
      $[10] = show;
      $[11] = t3;
    } else {
      t3 = $[11];
    }
    const accept = t3;
    let t4;
    if ($[12] !== respond) {
      t4 = async function decline(v_3) {
        setBusy({
          id: v_3.ch.id,
          action: "decline"
        });
        setError(null);
        const res_0 = await respond(v_3.ch.id, false);
        setBusy(null);
        if (res_0.error) {
          setError(res_0.error);
        }
      };
      $[12] = respond;
      $[13] = t4;
    } else {
      t4 = $[13];
    }
    const decline = t4;
    let t5;
    if ($[14] !== cancel) {
      t5 = async function withdraw(v_4) {
        setBusy({
          id: v_4.ch.id,
          action: "cancel"
        });
        setError(null);
        const err = await cancel(v_4.ch.id);
        setBusy(null);
        if (err) {
          setError(err);
        }
      };
      $[14] = cancel;
      $[15] = t5;
    } else {
      t5 = $[15];
    }
    const withdraw = t5;
    let t6;
    if ($[16] !== busy || $[17] !== decline || $[18] !== gameById || $[19] !== now || $[20] !== withdraw) {
      t6 = v_5 => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ChallengeCard.default, {
        view: v_5,
        game: gameById.get(v_5.ch.gameId) ?? null,
        now: now,
        busy: busy?.id === v_5.ch.id ? busy.action : null,
        onOpen: () => setQuickGame(v_5.ch.gameId),
        onAccept: () => setConfirm(v_5),
        onDecline: () => void decline(v_5),
        onCancel: () => void withdraw(v_5)
      }, v_5.ch.id);
      $[16] = busy;
      $[17] = decline;
      $[18] = gameById;
      $[19] = now;
      $[20] = withdraw;
      $[21] = t6;
    } else {
      t6 = $[21];
    }
    const card = t6;
    const findFriends = _temp4;
    const browse = _temp5;
    const T0 = View.default;
    let t7;
    if ($[22] !== c.background) {
      t7 = [styles.container, {
        backgroundColor: c.background
      }];
      $[22] = c.background;
      $[23] = t7;
    } else {
      t7 = $[23];
    }
    const t8 = `${record.won}W · ${record.lost}L against friends`;
    let t9;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.IconButton, {
        icon: "account-multiple-plus-outline",
        label: "Challenge a Friend",
        onPress: findFriends
      });
      $[24] = t9;
    } else {
      t9 = $[24];
    }
    let t10;
    if ($[25] !== balance) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.StatTile, {
        label: "Credits",
        hint: "free to use",
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
          value: balance,
          size: "sm"
        })
      });
      $[25] = balance;
      $[26] = t10;
    } else {
      t10 = $[26];
    }
    const t11 = `${outV.length + liveV.length} open`;
    let t12;
    if ($[27] !== escrowed) {
      t12 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
        value: escrowed,
        size: "sm",
        tone: "neutral"
      });
      $[27] = escrowed;
      $[28] = t12;
    } else {
      t12 = $[28];
    }
    let t13;
    if ($[29] !== t11 || $[30] !== t12) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.StatTile, {
        label: "In Pots",
        hint: t11,
        children: t12
      });
      $[29] = t11;
      $[30] = t12;
      $[31] = t13;
    } else {
      t13 = $[31];
    }
    const t14 = record.net > 0 ? "positive" : record.net < 0 ? "negative" : "neutral";
    let t15;
    if ($[32] !== record.net || $[33] !== t14) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.StatTile, {
        label: "Net vs Friends",
        hint: "settled",
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
          value: record.net,
          size: "sm",
          signed: true,
          tone: t14
        })
      });
      $[32] = record.net;
      $[33] = t14;
      $[34] = t15;
    } else {
      t15 = $[34];
    }
    let t16;
    if ($[35] !== t10 || $[36] !== t13 || $[37] !== t15) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.stats,
        children: [t10, t13, t15]
      });
      $[35] = t10;
      $[36] = t13;
      $[37] = t15;
      $[38] = t16;
    } else {
      t16 = $[38];
    }
    const t17 = inboxNew || undefined;
    let t18;
    if ($[39] !== t17) {
      t18 = {
        value: "inbox",
        label: "Inbox",
        badge: t17
      };
      $[39] = t17;
      $[40] = t18;
    } else {
      t18 = $[40];
    }
    const t19 = liveNew || undefined;
    let t20;
    if ($[41] !== t19) {
      t20 = {
        value: "live",
        label: "Locked in",
        badge: t19
      };
      $[41] = t19;
      $[42] = t20;
    } else {
      t20 = $[42];
    }
    let t21;
    if ($[43] === Symbol.for("react.memo_cache_sentinel")) {
      t21 = {
        value: "history",
        label: "History"
      };
      $[43] = t21;
    } else {
      t21 = $[43];
    }
    let t22;
    if ($[44] !== t18 || $[45] !== t20) {
      t22 = [t18, t20, t21];
      $[44] = t18;
      $[45] = t20;
      $[46] = t22;
    } else {
      t22 = $[46];
    }
    let t23;
    if ($[47] !== t22 || $[48] !== tab) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.TabStrip, {
        value: tab,
        onChange: setTab,
        options: t22
      });
      $[47] = t22;
      $[48] = tab;
      $[49] = t23;
    } else {
      t23 = $[49];
    }
    let t24;
    if ($[50] !== t16 || $[51] !== t23 || $[52] !== t8) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.ScreenHeader, {
        back: true,
        title: "Challenges",
        subtitle: t8,
        right: t9,
        children: [t16, t23]
      });
      $[50] = t16;
      $[51] = t23;
      $[52] = t8;
      $[53] = t24;
    } else {
      t24 = $[53];
    }
    const T1 = ScrollView.default;
    let t25;
    if ($[54] !== bottom) {
      t25 = [styles.list, {
        paddingBottom: bottom
      }];
      $[54] = bottom;
      $[55] = t25;
    } else {
      t25 = $[55];
    }
    const t26 = false;
    let t27;
    if ($[56] === Symbol.for("react.memo_cache_sentinel")) {
      t27 = () => setError(null);
      $[56] = t27;
    } else {
      t27 = $[56];
    }
    let t28;
    if ($[57] !== error) {
      t28 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ErrorBanner, {
        message: error,
        onDismiss: t27
      });
      $[57] = error;
      $[58] = t28;
    } else {
      t28 = $[58];
    }
    const t29 = tab === "inbox" ? inV.length + outV.length === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
      icon: "sword-cross",
      title: "No Challenges Waiting",
      body: "Pick a game, tap a team, and switch the slip to \u201CChallenge a friend\u201D. Pot or your own odds \u2014 both stakes are locked in before kickoff.",
      action: "Browse Games",
      onAction: browse,
      secondary: "Pick a Friend",
      onSecondary: findFriends
    }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
      children: [inV.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.section, {
          color: c.foreground
        }],
        children: "Waiting on You"
      }), inV.map(card), outV.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.section, {
          color: c.foreground
        }],
        children: "Waiting on Them"
      }), outV.map(card)]
    }) : tab === "live" ? liveV.length === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
      icon: "lock-outline",
      title: "Nothing Locked in",
      body: "Accepted challenges sit here until the final whistle. The pot pays out on its own.",
      action: "Browse Games",
      onAction: browse
    }) : liveV.map(card) : histV.length === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
      icon: "history",
      title: "No History Yet",
      body: "Settled challenges, and any that were declined or expired, land here."
    }) : histV.map(card);
    let t30;
    if ($[59] !== T1 || $[60] !== t25 || $[61] !== t28 || $[62] !== t29) {
      t30 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T1, {
        contentContainerStyle: t25,
        showsVerticalScrollIndicator: t26,
        children: [t28, t29]
      });
      $[59] = T1;
      $[60] = t25;
      $[61] = t28;
      $[62] = t29;
      $[63] = t30;
    } else {
      t30 = $[63];
    }
    const t31 = !!confirm;
    const t32 = confirm ? `Accept ${confirm.friendName}'s challenge?` : "";
    let t33;
    if ($[64] !== confirm) {
      t33 = confirm ? `You put ${confirm.myStake.toLocaleString()} credits on ${confirm.myTeam.name} (${confirm.myOdds.toFixed(2)}x). ${confirm.friendName} already has ${confirm.theirStake.toLocaleString()} on ${confirm.theirTeam.abbreviation}. Once you accept, the ${confirm.ch.pot.toLocaleString()} pot is locked — neither of you can back out — and the winner is paid when the game is final.` : "";
      $[64] = confirm;
      $[65] = t33;
    } else {
      t33 = $[65];
    }
    let t34;
    if ($[66] !== confirm) {
      t34 = confirm ? `Lock in ${confirm.myStake.toLocaleString()}` : "Accept";
      $[66] = confirm;
      $[67] = t34;
    } else {
      t34 = $[67];
    }
    const t35 = busy?.action === "accept";
    let t36;
    if ($[68] !== balance || $[69] !== confirm) {
      t36 = confirm && confirm.myStake > balance ? `You have ${balance.toLocaleString()} credits — not enough to cover this.` : null;
      $[68] = balance;
      $[69] = confirm;
      $[70] = t36;
    } else {
      t36 = $[70];
    }
    let t37;
    if ($[71] === Symbol.for("react.memo_cache_sentinel")) {
      t37 = () => setConfirm(null);
      $[71] = t37;
    } else {
      t37 = $[71];
    }
    let t38;
    if ($[72] !== accept || $[73] !== confirm) {
      t38 = () => confirm && void accept(confirm);
      $[72] = accept;
      $[73] = confirm;
      $[74] = t38;
    } else {
      t38 = $[74];
    }
    let t39;
    if ($[75] !== t31 || $[76] !== t32 || $[77] !== t33 || $[78] !== t34 || $[79] !== t35 || $[80] !== t36 || $[81] !== t38) {
      t39 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ConfirmDialog, {
        visible: t31,
        title: t32,
        body: t33,
        confirmLabel: t34,
        busy: t35,
        error: t36,
        onCancel: t37,
        onConfirm: t38
      });
      $[75] = t31;
      $[76] = t32;
      $[77] = t33;
      $[78] = t34;
      $[79] = t35;
      $[80] = t36;
      $[81] = t38;
      $[82] = t39;
    } else {
      t39 = $[82];
    }
    let t40;
    if ($[83] === Symbol.for("react.memo_cache_sentinel")) {
      t40 = () => setQuickGame(null);
      $[83] = t40;
    } else {
      t40 = $[83];
    }
    let t41;
    if ($[84] !== quickGame) {
      t41 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(GameQuickView.default, {
        gameId: quickGame,
        onClose: t40
      });
      $[84] = quickGame;
      $[85] = t41;
    } else {
      t41 = $[85];
    }
    let t42;
    if ($[86] !== T0 || $[87] !== t24 || $[88] !== t30 || $[89] !== t39 || $[90] !== t41 || $[91] !== t7) {
      t42 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T0, {
        style: t7,
        children: [t24, t30, t39, t41]
      });
      $[86] = T0;
      $[87] = t24;
      $[88] = t30;
      $[89] = t39;
      $[90] = t41;
      $[91] = t7;
      $[92] = t42;
    } else {
      t42 = $[92];
    }
    return t42;
  }
  function _temp5() {
    return _expoRouter.router.navigate("/(tabs)/games");
  }
  function _temp4() {
    return _expoRouter.router.navigate("/(tabs)/friends");
  }
  function _temp3(v_0) {
    return v_0.ch.id;
  }
  function _temp2(v) {
    return v.ch.id;
  }
  function _temp(g) {
    return [g.id, g];
  }
  const styles = StyleSheet.default.create({
    container: {
      flex: 1
    },
    stats: {
      flexDirection: "row",
      gap: 8
    },
    list: {
      padding: 16
    },
    section: {
      fontSize: 15,
      fontFamily: "Inter_700Bold",
      marginBottom: 10,
      marginTop: 4
    }
  });
},759,[815,820,816,817,12,133,28,188,109,1213,851,836,837,821,859,819,860,844,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _componentsTeamCrest = require(_dependencyMap[2]);
  var TeamCrest = _interopDefault(_componentsTeamCrest);
  var _react = require(_dependencyMap[3]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxPressableScale = require(_dependencyMap[7]);
  var PressableScale = _interopDefault(_componentsFxPressableScale);
  var _componentsInsights = require(_dependencyMap[8]);
  var _componentsUi = require(_dependencyMap[9]);
  var _hooksUseColors = require(_dependencyMap[10]);
  var _libOdds = require(_dependencyMap[11]);
  var _reactJsxRuntime = require(_dependencyMap[12]);
  /**
   * One head-to-head, from the signed-in player's side: you and your team on
   * the left, your friend and theirs on the right, the pot in the middle, and
   * whatever needs doing (accept, decline, withdraw) underneath.
   */
  function ChallengeCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(128);
    const {
      view,
      game,
      now,
      busy,
      onOpen,
      onAccept,
      onDecline,
      onCancel
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const {
      ch
    } = view;
    const kicked = ch.startsAt <= now || !!game && game.status !== "upcoming";
    const live = ch.status === "accepted" && game?.status === "live";
    let t1;
    if ($[0] !== c || $[1] !== game || $[2] !== kicked || $[3] !== live || $[4] !== view) {
      const pos = live && game ? (0, _libOdds.livePosition)(game, view.mySide) : null;
      t1 = statusOf(view, kicked, pos, c);
      $[0] = c;
      $[1] = game;
      $[2] = kicked;
      $[3] = live;
      $[4] = view;
      $[5] = t1;
    } else {
      t1 = $[5];
    }
    const status = t1;
    let t2;
    if ($[6] !== ch.finalAwayScore || $[7] !== ch.finalHomeScore || $[8] !== game || $[9] !== view.mySide) {
      t2 = scoreFor(view.mySide, ch.finalHomeScore, ch.finalAwayScore, game);
      $[6] = ch.finalAwayScore;
      $[7] = ch.finalHomeScore;
      $[8] = game;
      $[9] = view.mySide;
      $[10] = t2;
    } else {
      t2 = $[10];
    }
    const myScore = t2;
    const t3 = view.mySide === "home" ? "away" : "home";
    let t4;
    if ($[11] !== ch.finalAwayScore || $[12] !== ch.finalHomeScore || $[13] !== game || $[14] !== t3) {
      t4 = scoreFor(t3, ch.finalHomeScore, ch.finalAwayScore, game);
      $[11] = ch.finalAwayScore;
      $[12] = ch.finalHomeScore;
      $[13] = game;
      $[14] = t3;
      $[15] = t4;
    } else {
      t4 = $[15];
    }
    const theirScore = t4;
    const showScore = myScore !== null && theirScore !== null && (ch.status === "settled" || live);
    let t5;
    if ($[16] !== c || $[17] !== ch.status || $[18] !== status.tone || $[19] !== view.isCreator) {
      t5 = status.tone === "positive" ? c.alpha(c.positive, 0.5) : status.tone === "negative" ? c.alpha(c.negative, 0.45) : ch.status === "pending" && !view.isCreator ? c.alpha(c.accent, 0.6) : c.border;
      $[16] = c;
      $[17] = ch.status;
      $[18] = status.tone;
      $[19] = view.isCreator;
      $[20] = t5;
    } else {
      t5 = $[20];
    }
    const border = t5;
    const t6 = `${view.myTeam.abbreviation} against ${view.friendName} on ${view.theirTeam.abbreviation}, ${status.label}. Pot ${ch.pot}.`;
    let t7;
    if ($[21] !== border || $[22] !== c.card) {
      t7 = [styles.card, {
        backgroundColor: c.card,
        borderColor: border
      }];
      $[21] = border;
      $[22] = c.card;
      $[23] = t7;
    } else {
      t7 = $[23];
    }
    let t8;
    if ($[24] !== c.subtleForeground) {
      t8 = [styles.kicker, {
        color: c.subtleForeground
      }];
      $[24] = c.subtleForeground;
      $[25] = t8;
    } else {
      t8 = $[25];
    }
    const t9 = `${ch.away.abbreviation} @ ${ch.home.abbreviation}`;
    let t10;
    if ($[26] !== ch.startsAt || $[27] !== ch.status || $[28] !== kicked || $[29] !== now) {
      t10 = ch.status === "settled" ? "Final" : kicked ? null : (0, _libOdds.kickoffLabel)(ch.startsAt, now);
      $[26] = ch.startsAt;
      $[27] = ch.status;
      $[28] = kicked;
      $[29] = now;
      $[30] = t10;
    } else {
      t10 = $[30];
    }
    let t11;
    if ($[31] !== ch.sport || $[32] !== t10 || $[33] !== t9) {
      t11 = [ch.sport, t9, t10].filter(Boolean);
      $[31] = ch.sport;
      $[32] = t10;
      $[33] = t9;
      $[34] = t11;
    } else {
      t11 = $[34];
    }
    const t12 = t11.join(" \xB7 ");
    let t13;
    if ($[35] !== t12 || $[36] !== t8) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t8,
        numberOfLines: 1,
        children: t12
      });
      $[35] = t12;
      $[36] = t8;
      $[37] = t13;
    } else {
      t13 = $[37];
    }
    let t14;
    if ($[38] !== ch.mode || $[39] !== view.myOdds) {
      t14 = ch.mode === "pot" ? "POT" : `${view.myOdds.toFixed(2)}X`;
      $[38] = ch.mode;
      $[39] = view.myOdds;
      $[40] = t14;
    } else {
      t14 = $[40];
    }
    const t15 = ch.mode === "pot" ? "treasure-chest" : "scale-balance";
    let t16;
    if ($[41] !== t14 || $[42] !== t15) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
        label: t14,
        tone: "accent",
        icon: t15
      });
      $[41] = t14;
      $[42] = t15;
      $[43] = t16;
    } else {
      t16 = $[43];
    }
    let t17;
    if ($[44] !== status.icon || $[45] !== status.label || $[46] !== status.tone) {
      t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
        label: status.label,
        tone: status.tone,
        icon: status.icon
      });
      $[44] = status.icon;
      $[45] = status.label;
      $[46] = status.tone;
      $[47] = t17;
    } else {
      t17 = $[47];
    }
    let t18;
    if ($[48] !== t16 || $[49] !== t17) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.pills,
        children: [t16, t17]
      });
      $[48] = t16;
      $[49] = t17;
      $[50] = t18;
    } else {
      t18 = $[50];
    }
    let t19;
    if ($[51] !== t13 || $[52] !== t18) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.head,
        children: [t13, t18]
      });
      $[51] = t13;
      $[52] = t18;
      $[53] = t19;
    } else {
      t19 = $[53];
    }
    const t20 = showScore ? myScore : null;
    let t21;
    if ($[54] !== c || $[55] !== ch.sport || $[56] !== t20 || $[57] !== view.myStake || $[58] !== view.myTeam) {
      t21 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Fighter, {
        sport: ch.sport,
        who: "You",
        team: view.myTeam,
        stake: view.myStake,
        score: t20,
        align: "left",
        c: c
      });
      $[54] = c;
      $[55] = ch.sport;
      $[56] = t20;
      $[57] = view.myStake;
      $[58] = view.myTeam;
      $[59] = t21;
    } else {
      t21 = $[59];
    }
    let t22;
    if ($[60] !== c) {
      t22 = c.alpha(c.accent, 0.45);
      $[60] = c;
      $[61] = t22;
    } else {
      t22 = $[61];
    }
    let t23;
    if ($[62] !== c) {
      t23 = c.alpha(c.accent, 0.08);
      $[62] = c;
      $[63] = t23;
    } else {
      t23 = $[63];
    }
    let t24;
    if ($[64] !== t22 || $[65] !== t23) {
      t24 = [styles.pot, {
        borderColor: t22,
        backgroundColor: t23
      }];
      $[64] = t22;
      $[65] = t23;
      $[66] = t24;
    } else {
      t24 = $[66];
    }
    let t25;
    if ($[67] !== c.accent || $[68] !== live) {
      t25 = live ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsInsights.LiveDot, {
        size: 6
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "sword-cross",
        size: 14,
        color: c.accent
      });
      $[67] = c.accent;
      $[68] = live;
      $[69] = t25;
    } else {
      t25 = $[69];
    }
    let t26;
    if ($[70] !== c.foreground) {
      t26 = [styles.potValue, {
        color: c.foreground
      }];
      $[70] = c.foreground;
      $[71] = t26;
    } else {
      t26 = $[71];
    }
    let t27;
    if ($[72] !== ch.pot) {
      t27 = ch.pot.toLocaleString();
      $[72] = ch.pot;
      $[73] = t27;
    } else {
      t27 = $[73];
    }
    let t28;
    if ($[74] !== t26 || $[75] !== t27) {
      t28 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t26,
        children: t27
      });
      $[74] = t26;
      $[75] = t27;
      $[76] = t28;
    } else {
      t28 = $[76];
    }
    let t29;
    if ($[77] !== c.mutedForeground) {
      t29 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.potLabel, {
          color: c.mutedForeground
        }],
        children: "POT"
      });
      $[77] = c.mutedForeground;
      $[78] = t29;
    } else {
      t29 = $[78];
    }
    let t30;
    if ($[79] !== t24 || $[80] !== t25 || $[81] !== t28 || $[82] !== t29) {
      t30 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t24,
        children: [t25, t28, t29]
      });
      $[79] = t24;
      $[80] = t25;
      $[81] = t28;
      $[82] = t29;
      $[83] = t30;
    } else {
      t30 = $[83];
    }
    const t31 = showScore ? theirScore : null;
    let t32;
    if ($[84] !== c || $[85] !== ch.sport || $[86] !== t31 || $[87] !== view.friendName || $[88] !== view.theirStake || $[89] !== view.theirTeam) {
      t32 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Fighter, {
        sport: ch.sport,
        who: view.friendName,
        team: view.theirTeam,
        stake: view.theirStake,
        score: t31,
        align: "right",
        c: c
      });
      $[84] = c;
      $[85] = ch.sport;
      $[86] = t31;
      $[87] = view.friendName;
      $[88] = view.theirStake;
      $[89] = view.theirTeam;
      $[90] = t32;
    } else {
      t32 = $[90];
    }
    let t33;
    if ($[91] !== t21 || $[92] !== t30 || $[93] !== t32) {
      t33 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.versus,
        children: [t21, t30, t32]
      });
      $[91] = t21;
      $[92] = t30;
      $[93] = t32;
      $[94] = t33;
    } else {
      t33 = $[94];
    }
    let t34;
    if ($[95] !== c.cardForeground || $[96] !== c.secondary || $[97] !== ch.message) {
      t34 = ch.message ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.message, {
          color: c.cardForeground,
          backgroundColor: c.secondary
        }],
        numberOfLines: 2,
        children: ["\u201C", ch.message, "\u201D"]
      }) : null;
      $[95] = c.cardForeground;
      $[96] = c.secondary;
      $[97] = ch.message;
      $[98] = t34;
    } else {
      t34 = $[98];
    }
    const t35 = status.detailColor ?? c.mutedForeground;
    let t36;
    if ($[99] !== t35) {
      t36 = [styles.detail, {
        color: t35
      }];
      $[99] = t35;
      $[100] = t36;
    } else {
      t36 = $[100];
    }
    let t37;
    if ($[101] !== status.detail || $[102] !== t36) {
      t37 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t36,
        children: status.detail
      });
      $[101] = status.detail;
      $[102] = t36;
      $[103] = t37;
    } else {
      t37 = $[103];
    }
    let t38;
    if ($[104] !== busy || $[105] !== ch.status || $[106] !== kicked || $[107] !== onAccept || $[108] !== onDecline || $[109] !== view.isCreator || $[110] !== view.myStake) {
      t38 = ch.status === "pending" && !view.isCreator && !kicked ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.actions,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: "Decline",
          variant: "secondary",
          onPress: onDecline,
          loading: busy === "decline",
          disabled: !!busy,
          style: {
            flex: 1
          }
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: `Accept · ${view.myStake.toLocaleString()}`,
          icon: "sword-cross",
          onPress: onAccept,
          loading: busy === "accept",
          disabled: !!busy,
          shimmer: !busy,
          style: {
            flex: 1.6
          }
        })]
      }) : null;
      $[104] = busy;
      $[105] = ch.status;
      $[106] = kicked;
      $[107] = onAccept;
      $[108] = onDecline;
      $[109] = view.isCreator;
      $[110] = view.myStake;
      $[111] = t38;
    } else {
      t38 = $[111];
    }
    let t39;
    if ($[112] !== busy || $[113] !== ch.status || $[114] !== kicked || $[115] !== onCancel || $[116] !== view.isCreator) {
      t39 = ch.status === "pending" && view.isCreator && !kicked ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.actions,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: "Withdraw Challenge",
          variant: "ghost",
          size: "sm",
          onPress: onCancel,
          loading: busy === "cancel",
          disabled: !!busy
        })
      }) : null;
      $[112] = busy;
      $[113] = ch.status;
      $[114] = kicked;
      $[115] = onCancel;
      $[116] = view.isCreator;
      $[117] = t39;
    } else {
      t39 = $[117];
    }
    let t40;
    if ($[118] !== onOpen || $[119] !== t19 || $[120] !== t33 || $[121] !== t34 || $[122] !== t37 || $[123] !== t38 || $[124] !== t39 || $[125] !== t6 || $[126] !== t7) {
      t40 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(PressableScale.default, {
        accessibilityRole: "button",
        accessibilityLabel: t6,
        onPress: onOpen,
        scaleTo: 0.985,
        dimTo: 0.95,
        style: t7,
        children: [t19, t33, t34, t37, t38, t39]
      });
      $[118] = onOpen;
      $[119] = t19;
      $[120] = t33;
      $[121] = t34;
      $[122] = t37;
      $[123] = t38;
      $[124] = t39;
      $[125] = t6;
      $[126] = t7;
      $[127] = t40;
    } else {
      t40 = $[127];
    }
    return t40;
  }
  function Fighter(t0) {
    const $ = (0, _reactCompilerRuntime.c)(38);
    const {
      sport,
      who,
      team,
      stake,
      score,
      align,
      c
    } = t0;
    const right = align === "right";
    let t1;
    if ($[0] !== right) {
      t1 = right && {
        alignItems: "flex-end"
      };
      $[0] = right;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    let t2;
    if ($[2] !== t1) {
      t2 = [styles.fighter, t1];
      $[2] = t1;
      $[3] = t2;
    } else {
      t2 = $[3];
    }
    let t3;
    if ($[4] !== c.mutedForeground) {
      t3 = [styles.who, {
        color: c.mutedForeground
      }];
      $[4] = c.mutedForeground;
      $[5] = t3;
    } else {
      t3 = $[5];
    }
    let t4;
    if ($[6] !== who) {
      t4 = who.toUpperCase();
      $[6] = who;
      $[7] = t4;
    } else {
      t4 = $[7];
    }
    let t5;
    if ($[8] !== t3 || $[9] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t3,
        numberOfLines: 1,
        children: t4
      });
      $[8] = t3;
      $[9] = t4;
      $[10] = t5;
    } else {
      t5 = $[10];
    }
    let t6;
    if ($[11] !== right) {
      t6 = right && {
        flexDirection: "row-reverse"
      };
      $[11] = right;
      $[12] = t6;
    } else {
      t6 = $[12];
    }
    let t7;
    if ($[13] !== t6) {
      t7 = [styles.teamRow, t6];
      $[13] = t6;
      $[14] = t7;
    } else {
      t7 = $[14];
    }
    let t8;
    if ($[15] !== sport || $[16] !== team.abbreviation || $[17] !== team.color) {
      t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TeamCrest.default, {
        abbr: team.abbreviation,
        color: team.color,
        size: 40,
        sport: sport
      });
      $[15] = sport;
      $[16] = team.abbreviation;
      $[17] = team.color;
      $[18] = t8;
    } else {
      t8 = $[18];
    }
    let t9;
    if ($[19] !== c.foreground || $[20] !== score) {
      t9 = score !== null ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.score, {
          color: c.foreground
        }],
        children: score
      }) : null;
      $[19] = c.foreground;
      $[20] = score;
      $[21] = t9;
    } else {
      t9 = $[21];
    }
    let t10;
    if ($[22] !== t7 || $[23] !== t8 || $[24] !== t9) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t7,
        children: [t8, t9]
      });
      $[22] = t7;
      $[23] = t8;
      $[24] = t9;
      $[25] = t10;
    } else {
      t10 = $[25];
    }
    let t11;
    if ($[26] !== c.cardForeground) {
      t11 = [styles.stake, {
        color: c.cardForeground
      }];
      $[26] = c.cardForeground;
      $[27] = t11;
    } else {
      t11 = $[27];
    }
    let t12;
    if ($[28] !== stake) {
      t12 = stake.toLocaleString();
      $[28] = stake;
      $[29] = t12;
    } else {
      t12 = $[29];
    }
    let t13;
    if ($[30] !== t11 || $[31] !== t12) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: t11,
        children: [t12, " in"]
      });
      $[30] = t11;
      $[31] = t12;
      $[32] = t13;
    } else {
      t13 = $[32];
    }
    let t14;
    if ($[33] !== t10 || $[34] !== t13 || $[35] !== t2 || $[36] !== t5) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t2,
        children: [t5, t10, t13]
      });
      $[33] = t10;
      $[34] = t13;
      $[35] = t2;
      $[36] = t5;
      $[37] = t14;
    } else {
      t14 = $[37];
    }
    return t14;
  }
  function scoreFor(side, home, away, game) {
    if (home !== null && away !== null) return side === "home" ? home : away;
    if (!game) return null;
    return side === "home" ? game.homeScore : game.awayScore;
  }
  function statusOf(v, kicked, pos, c) {
    const {
      ch
    } = v;
    const now = Date.now();
    switch (ch.status) {
      case "pending":
        if (kicked) return {
          label: "Expiring",
          tone: "neutral",
          icon: "timer-sand",
          detail: "Kicked off before it was accepted — the stake goes back."
        };
        return v.isCreator ? {
          label: "Sent",
          tone: "accent",
          icon: "send",
          detail: `Waiting on ${v.friendName} · kicks off ${(0, _libOdds.untilKickoff)(ch.startsAt, now)}. Your ${v.myStake.toLocaleString()} is in escrow and comes back if they pass.`
        } : {
          label: "Your Call",
          tone: "warning",
          icon: "bell-ring-outline",
          detail: `Put in ${v.myStake.toLocaleString()} on ${v.myTeam.abbreviation} (${v.myOdds.toFixed(2)}x) to win the ${ch.pot.toLocaleString()} pot. Answer before kickoff, ${(0, _libOdds.untilKickoff)(ch.startsAt, now)}.`
        };
      case "accepted":
        if (pos === "ahead") return {
          label: "Winning",
          tone: "positive",
          icon: "arrow-up-bold",
          detail: `Takes the ${ch.pot.toLocaleString()} pot if it ends now.`,
          detailColor: c.positive
        };
        if (pos === "behind") return {
          label: "Losing",
          tone: "negative",
          icon: "arrow-down-bold",
          detail: `${v.friendName} takes the pot if it ends now.`,
          detailColor: c.negative
        };
        if (pos === "level") return {
          label: "Level",
          tone: "warning",
          detail: "Both stakes come back if it ends level."
        };
        return {
          label: "Locked",
          tone: "accent",
          icon: "lock",
          detail: kicked ? "Game's on — the pot pays out at the final whistle." : `Both stakes are in the pot. Kicks off ${(0, _libOdds.untilKickoff)(ch.startsAt, now)}.`
        };
      case "settled":
        if (v.result === "won") return {
          label: "Won",
          tone: "positive",
          icon: "trophy",
          detail: `+${v.theirStake.toLocaleString()} from ${v.friendName}. The ${ch.pot.toLocaleString()} pot was paid to you.`,
          detailColor: c.positive
        };
        if (v.result === "lost") return {
          label: "Lost",
          tone: "negative",
          icon: "close",
          detail: `${v.friendName} took the ${ch.pot.toLocaleString()} pot.`,
          detailColor: c.negative
        };
        return {
          label: "Push",
          tone: "neutral",
          detail: "Ended level — both stakes returned."
        };
      case "declined":
        return {
          label: "Declined",
          tone: "neutral",
          detail: v.isCreator ? `${v.friendName} passed. Your stake was returned.` : "You passed on this one."
        };
      case "cancelled":
        return {
          label: "Withdrawn",
          tone: "neutral",
          detail: v.isCreator ? "You withdrew it. Your stake was returned." : `${v.friendName} withdrew it.`
        };
      case "expired":
        return {
          label: "Expired",
          tone: "neutral",
          detail: v.isCreator ? "Not accepted before kickoff. Your stake was returned." : "You didn't answer before kickoff."
        };
      default:
        return {
          label: "Void",
          tone: "neutral",
          detail: "The game didn't go ahead. Both stakes were returned."
        };
    }
  }
  const styles = StyleSheet.default.create({
    card: {
      borderWidth: 1,
      borderRadius: 18,
      padding: 14,
      gap: 12,
      marginBottom: 10
    },
    head: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 8
    },
    kicker: {
      flex: 1,
      fontSize: 11,
      fontFamily: "Inter_600SemiBold"
    },
    pills: {
      flexDirection: "row",
      gap: 6
    },
    versus: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10
    },
    fighter: {
      flex: 1,
      gap: 4
    },
    who: {
      fontSize: 11,
      fontFamily: "Inter_800ExtraBold",
      letterSpacing: 0.8
    },
    teamRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    teamDot: {
      minWidth: 44,
      height: 44,
      borderRadius: 22,
      borderWidth: 1.5,
      alignItems: "center",
      justifyContent: "center",
      paddingHorizontal: 4
    },
    teamAbbr: {
      fontSize: 13,
      fontFamily: "Inter_800ExtraBold"
    },
    score: {
      fontSize: 26,
      fontFamily: "Inter_900Black",
      fontVariant: ["tabular-nums"]
    },
    stake: {
      fontSize: 12,
      fontFamily: "Inter_600SemiBold",
      fontVariant: ["tabular-nums"]
    },
    pot: {
      alignItems: "center",
      borderWidth: 1.5,
      borderRadius: 14,
      paddingHorizontal: 10,
      paddingVertical: 6,
      minWidth: 78,
      gap: 1
    },
    potValue: {
      fontSize: 18,
      fontFamily: "Inter_900Black",
      fontVariant: ["tabular-nums"]
    },
    potLabel: {
      fontSize: 11,
      fontFamily: "Inter_800ExtraBold",
      letterSpacing: 1
    },
    message: {
      fontSize: 13,
      fontFamily: "Inter_500Medium",
      fontStyle: "italic",
      borderRadius: 10,
      paddingHorizontal: 10,
      paddingVertical: 7
    },
    detail: {
      fontSize: 12,
      lineHeight: 17,
      fontFamily: "Inter_500Medium"
    },
    actions: {
      flexDirection: "row",
      gap: 10,
      justifyContent: "flex-end"
    }
  });
  var _default = /*#__PURE__*/(0, _react.memo)(ChallengeCard);
},1213,[815,818,866,12,28,188,109,868,1214,836,819,870,6]);