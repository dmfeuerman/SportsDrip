__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "AppleAuthenticationButton", {
    enumerable: true,
    get: function () {
      return _AppleAuthenticationButton2.default;
    }
  });
  var _AppleAuthentication = require(_dependencyMap[0]);
  Object.keys(_AppleAuthentication).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _AppleAuthentication[k];
        }
      });
    }
  });
  var _AppleAuthenticationTypes = require(_dependencyMap[1]);
  Object.keys(_AppleAuthenticationTypes).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _AppleAuthenticationTypes[k];
        }
      });
    }
  });
  var _AppleAuthenticationButton = require(_dependencyMap[2]);
  var _AppleAuthenticationButton2 = _interopDefault(_AppleAuthenticationButton);
},1273,[1274,1275,1277]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.isAvailableAsync = isAvailableAsync;
  exports.signInAsync = signInAsync;
  exports.refreshAsync = refreshAsync;
  exports.signOutAsync = signOutAsync;
  exports.getCredentialStateAsync = getCredentialStateAsync;
  exports.formatFullName = formatFullName;
  exports.addRevokeListener = addRevokeListener;
  var _expo = require(_dependencyMap[0]);
  var _AppleAuthenticationTypes = require(_dependencyMap[1]);
  var _ExpoAppleAuthentication = require(_dependencyMap[2]);
  var ExpoAppleAuthentication = _interopDefault(_ExpoAppleAuthentication);
  // @needsAudit
  /**
   * Determine if the current device's operating system supports Apple authentication.
   * @return A promise that fulfills with `true` if the system supports Apple authentication, and `false` otherwise.
   */
  async function isAvailableAsync() {
    if (!ExpoAppleAuthentication.default || !ExpoAppleAuthentication.default.isAvailableAsync) {
      return false;
    }
    return ExpoAppleAuthentication.default.isAvailableAsync();
  }
  // @needsAudit
  /**
   * Sends a request to the operating system to initiate the Apple authentication flow, which will
   * present a modal to the user over your app and allow them to sign in.
   *
   * You can request access to the user's full name and email address in this method, which allows you
   * to personalize your UI for signed in users. However, users can deny access to either or both
   * of these options at runtime.
   *
   * Additionally, you will only receive Apple Authentication Credentials the first time users sign
   * into your app, so you must store it for later use. It's best to store this information either
   * server-side, or using [`expo-secure-store`](./securestore), so that the data persists across app installs.
   * You can use [`AppleAuthenticationCredential.user`](#appleauthenticationcredential) to identify
   * the user, since this remains the same for apps released by the same developer.
   *
   * @param options An optional [`AppleAuthenticationSignInOptions`](#appleauthenticationsigninoptions) object
   * @return A promise that fulfills with an [`AppleAuthenticationCredential`](#appleauthenticationcredential)
   * object after a successful authentication, and rejects with `ERR_REQUEST_CANCELED` if the user cancels the
   * sign-in operation.
   */
  async function signInAsync(options) {
    if (!ExpoAppleAuthentication.default || !ExpoAppleAuthentication.default.requestAsync) {
      throw new _expo.UnavailabilityError('expo-apple-authentication', 'signInAsync');
    }
    const requestOptions = {
      ...options,
      requestedOperation: _AppleAuthenticationTypes.AppleAuthenticationOperation.LOGIN
    };
    const credential = await ExpoAppleAuthentication.default.requestAsync(requestOptions);
    if (!credential.authorizationCode || !credential.identityToken || !credential.user) {
      throw new _expo.CodedError('ERR_REQUEST_FAILED', 'The credential returned by `signInAsync` is missing one or more required fields.');
    }
    return credential;
  }
  // @needsAudit
  /**
   * An operation that refreshes the logged-in user’s credentials.
   * Calling this method will show the sign in modal before actually refreshing the user credentials.
   *
   * @param options An [`AppleAuthenticationRefreshOptions`](#appleauthenticationrefreshoptions) object
   * @returns A promise that fulfills with an [`AppleAuthenticationCredential`](#appleauthenticationcredential)
   * object after a successful authentication, and rejects with `ERR_REQUEST_CANCELED` if the user cancels the
   * refresh operation.
   */
  async function refreshAsync(options) {
    if (!ExpoAppleAuthentication.default || !ExpoAppleAuthentication.default.requestAsync) {
      throw new _expo.UnavailabilityError('expo-apple-authentication', 'refreshAsync');
    }
    const requestOptions = {
      ...options,
      requestedOperation: _AppleAuthenticationTypes.AppleAuthenticationOperation.REFRESH
    };
    const credential = await ExpoAppleAuthentication.default.requestAsync(requestOptions);
    if (!credential.authorizationCode || !credential.identityToken || !credential.user) {
      throw new _expo.CodedError('ERR_REQUEST_FAILED', 'The credential returned by `refreshAsync` is missing one or more required fields.');
    }
    return credential;
  }
  // @needsAudit
  /**
   * An operation that ends the authenticated session.
   * Calling this method will show the sign in modal before actually signing the user out.
   *
   * It is not recommended to use this method to sign out the user as it works counterintuitively.
   * Instead of using this method it is recommended to simply clear all the user's data collected
   * from using [`signInAsync`](#appleauthenticationsigninasyncoptions) or [`refreshAsync`](#appleauthenticationrefreshasyncoptions) methods.
   *
   * @param options An [`AppleAuthenticationSignOutOptions`](#appleauthenticationsignoutoptions) object
   * @returns A promise that fulfills with an [`AppleAuthenticationCredential`](#appleauthenticationcredential)
   * object after a successful authentication, and rejects with `ERR_REQUEST_CANCELED` if the user cancels the
   * sign-out operation.
   */
  async function signOutAsync(options) {
    if (!ExpoAppleAuthentication.default || !ExpoAppleAuthentication.default.requestAsync) {
      throw new _expo.UnavailabilityError('expo-apple-authentication', 'signOutAsync');
    }
    const requestOptions = {
      ...options,
      requestedOperation: _AppleAuthenticationTypes.AppleAuthenticationOperation.LOGOUT
    };
    return ExpoAppleAuthentication.default.requestAsync(requestOptions);
  }
  // @needsAudit
  /**
   * Queries the current state of a user credential, to determine if it is still valid or if it has been revoked.
   * > **Note:** This method must be tested on a real device. On the iOS simulator it always throws an error.
   *
   * @param user The unique identifier for the user whose credential state you'd like to check.
   * This should come from the user field of an [`AppleAuthenticationCredential`](#appleauthenticationcredentialstate) object.
   * @return A promise that fulfills with an [`AppleAuthenticationCredentialState`](#appleauthenticationcredentialstate)
   * value depending on the state of the credential.
   */
  async function getCredentialStateAsync(user) {
    if (!ExpoAppleAuthentication.default || !ExpoAppleAuthentication.default.getCredentialStateAsync) {
      throw new _expo.UnavailabilityError('expo-apple-authentication', 'getCredentialStateAsync');
    }
    return ExpoAppleAuthentication.default.getCredentialStateAsync(user);
  }
  // @needsAudit @docsMissing
  /**
   * Creates a locale-aware string representation of a person's name from an object representing the tokenized portions of a user's full name
   *
   * @param fullName The full name object with the tokenized portions
   * @param formatStyle The style in which the name should be formatted
   * @returns A locale-aware string representation of a person's name
   */
  function formatFullName(fullName, formatStyle) {
    if (!ExpoAppleAuthentication.default || !ExpoAppleAuthentication.default.formatFullName) {
      throw new _expo.UnavailabilityError('expo-apple-authentication', 'formatFullName');
    }
    return ExpoAppleAuthentication.default.formatFullName(fullName, formatStyle);
  }
  // @docsMissing
  function addRevokeListener(listener) {
    return ExpoAppleAuthentication.default.addListener('Expo.appleIdCredentialRevoked', listener);
  }
},1274,[620,1275,1276]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "AppleAuthenticationScope", {
    enumerable: true,
    get: function () {
      return AppleAuthenticationScope;
    }
  });
  Object.defineProperty(exports, "AppleAuthenticationOperation", {
    enumerable: true,
    get: function () {
      return AppleAuthenticationOperation;
    }
  });
  Object.defineProperty(exports, "AppleAuthenticationCredentialState", {
    enumerable: true,
    get: function () {
      return AppleAuthenticationCredentialState;
    }
  });
  Object.defineProperty(exports, "AppleAuthenticationUserDetectionStatus", {
    enumerable: true,
    get: function () {
      return AppleAuthenticationUserDetectionStatus;
    }
  });
  Object.defineProperty(exports, "AppleAuthenticationButtonType", {
    enumerable: true,
    get: function () {
      return AppleAuthenticationButtonType;
    }
  });
  Object.defineProperty(exports, "AppleAuthenticationButtonStyle", {
    enumerable: true,
    get: function () {
      return AppleAuthenticationButtonStyle;
    }
  });
  // @needsAudit @docsMissing
  /**
   * An enum whose values specify scopes you can request when calling [`AppleAuthentication.signInAsync()`](#appleauthenticationsigninasyncoptions).
   *
   * > Note that it is possible that you will not be granted all of the scopes which you request.
   * > You will still need to handle null values for any fields you request.
   *
   * @see [Apple
   * Documentation](https://developer.apple.com/documentation/authenticationservices/asauthorizationscope)
   * for more details.
   */
  var AppleAuthenticationScope = /*#__PURE__*/function (AppleAuthenticationScope) {
    AppleAuthenticationScope[AppleAuthenticationScope["FULL_NAME"] = 0] = "FULL_NAME";
    AppleAuthenticationScope[AppleAuthenticationScope["EMAIL"] = 1] = "EMAIL";
    return AppleAuthenticationScope;
  }({});
  // @needsAudit @docsMissing
  var AppleAuthenticationOperation = /*#__PURE__*/function (AppleAuthenticationOperation) {
    /**
    * An operation that depends on the particular kind of credential provider.
    */
    AppleAuthenticationOperation[AppleAuthenticationOperation["IMPLICIT"] = 0] = "IMPLICIT";
    AppleAuthenticationOperation[AppleAuthenticationOperation["LOGIN"] = 1] = "LOGIN";
    AppleAuthenticationOperation[AppleAuthenticationOperation["REFRESH"] = 2] = "REFRESH";
    AppleAuthenticationOperation[AppleAuthenticationOperation["LOGOUT"] = 3] = "LOGOUT";
    return AppleAuthenticationOperation;
  }({});
  // @needsAudit @docsMissing
  /**
   * An enum whose values specify state of the credential when checked with [`AppleAuthentication.getCredentialStateAsync()`](#appleauthenticationgetcredentialstateasyncuser).
   *
   * @see [Apple
   * Documentation](https://developer.apple.com/documentation/authenticationservices/asauthorizationappleidprovidercredentialstate)
   * for more details.
   */
  var AppleAuthenticationCredentialState = /*#__PURE__*/function (AppleAuthenticationCredentialState) {
    AppleAuthenticationCredentialState[AppleAuthenticationCredentialState["REVOKED"] = 0] = "REVOKED";
    AppleAuthenticationCredentialState[AppleAuthenticationCredentialState["AUTHORIZED"] = 1] = "AUTHORIZED";
    AppleAuthenticationCredentialState[AppleAuthenticationCredentialState["NOT_FOUND"] = 2] = "NOT_FOUND";
    AppleAuthenticationCredentialState[AppleAuthenticationCredentialState["TRANSFERRED"] = 3] = "TRANSFERRED";
    return AppleAuthenticationCredentialState;
  }({});
  // @needsAudit
  /**
   * An enum whose values specify the system's best guess for how likely the current user is a real person.
   *
   * @see [Apple
   * Documentation](https://developer.apple.com/documentation/authenticationservices/asuserdetectionstatus)
   * for more details.
   */
  var AppleAuthenticationUserDetectionStatus = /*#__PURE__*/function (AppleAuthenticationUserDetectionStatus) {
    /**
    * The system does not support this determination and there is no data.
    */
    AppleAuthenticationUserDetectionStatus[AppleAuthenticationUserDetectionStatus["UNSUPPORTED"] = 0] = "UNSUPPORTED";
    /**
    * The system has not determined whether the user might be a real person.
    */
    AppleAuthenticationUserDetectionStatus[AppleAuthenticationUserDetectionStatus["UNKNOWN"] = 1] = "UNKNOWN";
    /**
    * The user appears to be a real person.
    */
    AppleAuthenticationUserDetectionStatus[AppleAuthenticationUserDetectionStatus["LIKELY_REAL"] = 2] = "LIKELY_REAL";
    return AppleAuthenticationUserDetectionStatus;
  }({});
  // @needsAudit
  /**
   * An enum whose values control which pre-defined text to use when rendering an [`AppleAuthenticationButton`](#appleauthenticationbutton).
   */
  var AppleAuthenticationButtonType = /*#__PURE__*/function (AppleAuthenticationButtonType) {
    /**
    * "Sign in with Apple"
    */
    AppleAuthenticationButtonType[AppleAuthenticationButtonType["SIGN_IN"] = 0] = "SIGN_IN";
    /**
    * "Continue with Apple"
    */
    AppleAuthenticationButtonType[AppleAuthenticationButtonType["CONTINUE"] = 1] = "CONTINUE";
    /**
    * "Sign up with Apple"
    * @platform ios 13.2+
    */
    AppleAuthenticationButtonType[AppleAuthenticationButtonType["SIGN_UP"] = 2] = "SIGN_UP";
    return AppleAuthenticationButtonType;
  }({});
  // @needsAudit
  /**
   * An enum whose values control which pre-defined color scheme to use when rendering an [`AppleAuthenticationButton`](#appleauthenticationbutton).
   */
  var AppleAuthenticationButtonStyle = /*#__PURE__*/function (AppleAuthenticationButtonStyle) {
    /**
    * White button with black text.
    */
    AppleAuthenticationButtonStyle[AppleAuthenticationButtonStyle["WHITE"] = 0] = "WHITE";
    /**
    * White button with a black outline and black text.
    */
    AppleAuthenticationButtonStyle[AppleAuthenticationButtonStyle["WHITE_OUTLINE"] = 1] = "WHITE_OUTLINE";
    /**
    * Black button with white text.
    */
    AppleAuthenticationButtonStyle[AppleAuthenticationButtonStyle["BLACK"] = 2] = "BLACK";
    return AppleAuthenticationButtonStyle;
  }({});
},1275,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _expo = require(_dependencyMap[0]);
  // If the real native module doesn't exist, make a pretend one, instead of
  // `null`, so we can offer an `isAvailableAsync` (that will always give
  // `false`, because we're on an unsupported platform).
  var _default = (0, _expo.requireOptionalNativeModule)('ExpoAppleAuthentication') || {
    isAvailableAsync() {
      return Promise.resolve(false);
    },
    // RN v0.65 gives a console warning if this method is missing; see
    //   https://github.com/facebook/react-native/commit/114be1d21
    addListener() {
      // Nothing to do; unsupported platform.
    },
    // RN v0.65 gives a console warning if this method is missing; see
    //   https://github.com/facebook/react-native/commit/114be1d21
    removeListeners() {
      // Nothing to do; unsupported platform.
      return Promise.resolve();
    }
  };
},1276,[620]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return AppleAuthenticationButton;
    }
  });
  var _reactJsxRuntime = require(_dependencyMap[0]);
  var _ExpoAppleAuthenticationButton = require(_dependencyMap[1]);
  var ExpoAppleAuthenticationButton = _interopDefault(_ExpoAppleAuthenticationButton);
  // @needsAudit
  /**
   * This component displays Apple's proprietary "Sign In with Apple" / "Continue with Apple" button
   * using the native [`ASAuthorizationAppleIDButton`](https://developer.apple.com/documentation/authenticationservices/asauthorizationappleidbutton).
   * Apple's [Human Interface Guidelines](https://developer.apple.com/design/human-interface-guidelines/sign-in-with-apple)
   * allow custom buttons as long as they follow Apple's branding rules (approved title, official
   * logo asset, approved colors, proportions, and minimum size). Using this component is the easiest
   * way to meet those requirements, since the system button is automatically Apple-approved,
   * localized, and accessible.
   *
   * You should only attempt to render this if [`AppleAuthentication.isAvailableAsync()`](#appleauthenticationisavailableasync)
   * resolves to `true`. This component will render nothing if it is not available, and you will get
   * a warning in development mode (`__DEV__ === true`).
   *
   * The properties of this component extend from `View`; however, you should not attempt to set
   * `backgroundColor` or `borderRadius` with the `style` property. This will not work and is against
   * the App Store Guidelines. Instead, you should use the `buttonStyle` property to choose one of the
   * predefined color styles and the `cornerRadius` property to change the border radius of the
   * button.
   *
   * Make sure to attach height and width via the style props, since without them the button will
   * not appear on the screen.
   *
   * @see [Apple
   * Documentation](https://developer.apple.com/documentation/authenticationservices/asauthorizationappleidbutton)
   * for more details.
   */
  function AppleAuthenticationButton({
    onPress,
    ...restProps
  }) {
    if (!ExpoAppleAuthenticationButton.default) {
      return null;
    }
    return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ExpoAppleAuthenticationButton.default, {
      onButtonPress: onPress,
      ...restProps
    });
  }
},1277,[6,1278]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  require(_dependencyMap[0]);
  require(_dependencyMap[1]);
  let ExpoAppleAuthenticationButton;
  var _default = ExpoAppleAuthenticationButton;
},1278,[620,104]);