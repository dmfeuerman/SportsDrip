__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return LevelsScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _expoRouter = require(_dependencyMap[2]);
  var _expoRouterReactNavigation = require(_dependencyMap[3]);
  var _react = require(_dependencyMap[4]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[5]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[6]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[7]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[8]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsAvatarAvatarBackdrop = require(_dependencyMap[9]);
  var AvatarBackdrop = _interopDefault(_componentsAvatarAvatarBackdrop);
  var _componentsFxTap = require(_dependencyMap[10]);
  var _componentsLevelBar = require(_dependencyMap[11]);
  var LevelBar = _interopDefault(_componentsLevelBar);
  var _componentsLevelUpHost = require(_dependencyMap[12]);
  var _componentsUi = require(_dependencyMap[13]);
  var _constantsProgression = require(_dependencyMap[14]);
  var _contextAppContext = require(_dependencyMap[15]);
  var _hooksUseColors = require(_dependencyMap[16]);
  var _hooksUseLevelRewards = require(_dependencyMap[17]);
  var _libMotion = require(_dependencyMap[18]);
  var _reactJsxRuntime = require(_dependencyMap[19]);
  const EARN = [{
    icon: "trophy-outline",
    label: "Win a Bet",
    xp: `${_constantsProgression.XP.betWin}+ XP`,
    to: "/(tabs)/games"
  }, {
    icon: "sword-cross",
    label: "Win a Friend Challenge",
    xp: `${_constantsProgression.XP.challengeWin} XP`,
    to: "/challenges"
  }, {
    icon: "shield-star-outline",
    label: "Win a League Bet",
    xp: `${_constantsProgression.XP.leagueBetWin} XP`,
    to: "/(tabs)/leagues"
  }, {
    icon: "podium-gold",
    label: "Finish in the Money in a League",
    xp: `${_constantsProgression.XP.leaguePayout} XP`
  }, {
    icon: "shopping-outline",
    label: "Buy From the Drip Shop",
    xp: `1 XP / ${_constantsProgression.XP.purchasePer} credits`,
    to: "/shop"
  }, {
    icon: "gift-outline",
    label: "Open a Prize Box",
    xp: `${_constantsProgression.XP.prizeBox} XP`,
    to: "/(tabs)"
  }, {
    icon: "account-plus-outline",
    label: "Add a Friend",
    xp: `${_constantsProgression.XP.newFriend} XP`,
    to: "/(tabs)/friends"
  }, {
    icon: "account-heart-outline",
    label: "Invite a Friend With Your Code",
    xp: `${_constantsProgression.XP.referrer} XP`,
    to: "/(tabs)/friends"
  }];

  /**
   * Levels: where you are, how XP is earned, and the road ahead — what every
   * level pays and unlocks. Tap your medallion to replay the level-up.
   */
  function LevelsScreen() {
    const c = (0, _hooksUseColors.useColors)();
    const bottom = (0, _componentsUi.useBottomPad)(false);
    const {
      progress
    } = (0, _contextAppContext.useApp)();
    const {
      rows,
      nextAfter
    } = (0, _hooksUseLevelRewards.useLevelRewards)();
    const tier = (0, _componentsLevelBar.levelTier)(progress.level);
    const toNext = progress.maxed ? 0 : progress.needed - progress.into;
    const next = nextAfter(progress.level);

    // Leaving Levels (back button, swipe, Android back) always lands on Home,
    // wherever it was opened from.
    const navigation = (0, _expoRouter.useNavigation)();
    const [leaving, setLeaving] = (0, _react.useState)(false);
    const allowLeave = (0, _expoRouterReactNavigation.usePreventRemove)(!leaving, ({
      data
    }) => {
      setLeaving(true);
      allowLeave();
      const type = data.action.type;
      if (type === "GO_BACK" || type === "POP") {
        _expoRouter.router.dismissTo("/(tabs)");
        _expoRouter.router.navigate("/(tabs)");
      } else navigation.dispatch(data.action);
    });
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
      style: [styles.container, {
        backgroundColor: c.background
      }],
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
        back: true,
        title: "Levels",
        subtitle: `${progress.xp.toLocaleString()} XP lifetime`
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        contentContainerStyle: [styles.content, {
          paddingBottom: bottom
        }],
        showsVerticalScrollIndicator: false,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.hero, {
            borderColor: c.alpha(tier.glow, 0.4)
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarBackdrop.default, {
            id: "galaxy"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [StyleSheet.default.absoluteFill, {
              backgroundColor: "rgba(0,0,0,0.25)"
            }]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
            accessibilityRole: "button",
            accessibilityLabel: `Level ${progress.level}. Replay the level-up`,
            onPress: () => {
              _libMotion.haptic.light();
              (0, _componentsLevelUpHost.replayLevelUp)(progress.level);
            },
            disabled: progress.level < 2,
            children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsLevelBar.LevelBadge, {
              level: progress.level,
              size: 92,
              glow: true
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: styles.heroTitle,
            children: ["Level ", progress.level]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.heroRank, {
              color: tier.glow
            }],
            children: tier.name.toUpperCase()
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: styles.heroSub,
            children: progress.maxed ? "Max level. Legend." : `${toNext.toLocaleString()} XP to level ${progress.level + 1}`
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(LevelBar.default, {
            progress: progress,
            nextReward: next,
            style: {
              alignSelf: "stretch",
              marginTop: 6
            }
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
          title: "Earn XP"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Card, {
          style: {
            padding: 0,
            overflow: "hidden"
          },
          children: EARN.map((e, i) => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
            accessibilityRole: e.to ? "button" : undefined,
            disabled: !e.to,
            onPress: () => e.to && _expoRouter.router.push({
              pathname: e.to,
              params: {
                from: "levels"
              }
            }),
            style: ({
              pressed
            }) => [styles.earnRow, i < EARN.length - 1 && {
              borderBottomWidth: StyleSheet.default.hairlineWidth,
              borderBottomColor: c.border
            }, pressed && {
              backgroundColor: c.secondary
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.earnIcon, {
                backgroundColor: c.alpha(c.primary, 0.13)
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: e.icon,
                size: 18,
                color: c.primary
              })
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.earnLabel, {
                color: c.foreground
              }],
              children: e.label
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.earnXp, {
                color: c.primary
              }],
              children: e.xp
            }), e.to ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "chevron-right",
              size: 18,
              color: c.mutedForeground
            }) : null]
          }, e.label))
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.note, {
            color: c.subtleForeground
          }],
          children: ["Every level pays a credit bonus. Friends who join with your invite code get ", _constantsProgression.REFERRAL.newUserCredits.toLocaleString(), " credits, and you get", " ", _constantsProgression.REFERRAL.referrerCredits.toLocaleString(), "."]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
          title: "Level Road"
        }), rows.map(r => {
          const reached = progress.level >= r.level;
          const isNext = r.level === progress.level + 1;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.road, {
              backgroundColor: c.card,
              borderColor: isNext ? c.alpha(c.primary, 0.6) : c.border
            }, isNext && {
              borderWidth: 1.5
            }, !reached && !isNext && {
              opacity: 0.72
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: {
                opacity: reached || isNext ? 1 : 0.55
              },
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsLevelBar.LevelBadge, {
                level: r.level,
                size: 38
              })
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1,
                gap: 6
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: styles.roadHead,
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                  style: [styles.roadCredits, {
                    color: c.foreground
                  }],
                  children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                    name: "lightning-bolt",
                    size: 13,
                    color: c.primary
                  }), " +", r.credits.toLocaleString()]
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                  style: [styles.roadXp, {
                    color: c.subtleForeground
                  }],
                  children: [(0, _constantsProgression.totalXpForLevel)(r.level).toLocaleString(), " XP"]
                })]
              }), r.unlocks.length ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
                style: styles.chips,
                children: r.unlocks.map(u => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(UnlockChip, {
                  u: u
                }, `${u.kind}:${u.id}`))
              }) : null]
            }), reached ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "check-circle",
              size: 20,
              color: c.primary
            }) : isNext ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.nextTag, {
                color: c.primaryForeground,
                backgroundColor: c.primary
              }],
              children: "NEXT"
            }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "lock-outline",
              size: 18,
              color: c.subtleForeground
            })]
          }, r.level);
        })]
      })]
    });
  }
  function UnlockChip(t0) {
    const $ = (0, _reactCompilerRuntime.c)(32);
    const {
      u
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    let T0;
    let col;
    let t1;
    let t2;
    let t3;
    if ($[0] !== c || $[1] !== u.rarity) {
      col = c.rarity(u.rarity);
      T0 = View.default;
      t3 = styles.chip;
      t1 = c.alpha(col, 0.55);
      t2 = c.alpha(col, 0.1);
      $[0] = c;
      $[1] = u.rarity;
      $[2] = T0;
      $[3] = col;
      $[4] = t1;
      $[5] = t2;
      $[6] = t3;
    } else {
      T0 = $[2];
      col = $[3];
      t1 = $[4];
      t2 = $[5];
      t3 = $[6];
    }
    let t4;
    if ($[7] !== t1 || $[8] !== t2) {
      t4 = {
        borderColor: t1,
        backgroundColor: t2
      };
      $[7] = t1;
      $[8] = t2;
      $[9] = t4;
    } else {
      t4 = $[9];
    }
    let t5;
    if ($[10] !== t3 || $[11] !== t4) {
      t5 = [t3, t4];
      $[10] = t3;
      $[11] = t4;
      $[12] = t5;
    } else {
      t5 = $[12];
    }
    const t6 = u.kind === "background" ? "image-filter-hdr" : u.mode === "reward" ? "gift" : "lock-open-variant-outline";
    let t7;
    if ($[13] !== col || $[14] !== t6) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: t6,
        size: 12,
        color: col
      });
      $[13] = col;
      $[14] = t6;
      $[15] = t7;
    } else {
      t7 = $[15];
    }
    let t8;
    if ($[16] !== c.foreground) {
      t8 = [styles.chipText, {
        color: c.foreground
      }];
      $[16] = c.foreground;
      $[17] = t8;
    } else {
      t8 = $[17];
    }
    let t9;
    if ($[18] !== t8 || $[19] !== u.name) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t8,
        numberOfLines: 1,
        children: u.name
      });
      $[18] = t8;
      $[19] = u.name;
      $[20] = t9;
    } else {
      t9 = $[20];
    }
    let t10;
    if ($[21] !== col) {
      t10 = [styles.chipTag, {
        color: col
      }];
      $[21] = col;
      $[22] = t10;
    } else {
      t10 = $[22];
    }
    const t11 = u.mode === "reward" ? "FREE" : "SHOP";
    let t12;
    if ($[23] !== t10 || $[24] !== t11) {
      t12 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t10,
        children: t11
      });
      $[23] = t10;
      $[24] = t11;
      $[25] = t12;
    } else {
      t12 = $[25];
    }
    let t13;
    if ($[26] !== T0 || $[27] !== t12 || $[28] !== t5 || $[29] !== t7 || $[30] !== t9) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T0, {
        style: t5,
        children: [t7, t9, t12]
      });
      $[26] = T0;
      $[27] = t12;
      $[28] = t5;
      $[29] = t7;
      $[30] = t9;
      $[31] = t13;
    } else {
      t13 = $[31];
    }
    return t13;
  }
  const styles = StyleSheet.default.create({
    container: {
      flex: 1
    },
    content: {
      padding: 16,
      gap: 12
    },
    hero: {
      borderRadius: 24,
      borderWidth: 1,
      overflow: "hidden",
      alignItems: "center",
      padding: 18,
      paddingTop: 22,
      gap: 2
    },
    heroTitle: {
      color: "#FFFFFF",
      fontSize: 30,
      fontFamily: "Inter_900Black",
      letterSpacing: -1,
      marginTop: 8
    },
    heroRank: {
      fontSize: 12,
      fontFamily: "Inter_900Black",
      letterSpacing: 3
    },
    heroSub: {
      color: "rgba(255,255,255,0.75)",
      fontSize: 13,
      fontFamily: "Inter_600SemiBold",
      marginTop: 4
    },
    earnRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      paddingHorizontal: 14,
      paddingVertical: 11
    },
    earnIcon: {
      width: 32,
      height: 32,
      borderRadius: 10,
      alignItems: "center",
      justifyContent: "center"
    },
    earnLabel: {
      flex: 1,
      fontSize: 14,
      fontFamily: "Inter_600SemiBold"
    },
    earnXp: {
      fontSize: 13,
      fontFamily: "Inter_800ExtraBold"
    },
    note: {
      fontSize: 12,
      fontFamily: "Inter_500Medium",
      lineHeight: 17,
      marginTop: -4
    },
    road: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      padding: 12,
      borderRadius: 16,
      borderWidth: 1
    },
    roadHead: {
      flexDirection: "row",
      alignItems: "baseline",
      justifyContent: "space-between"
    },
    roadCredits: {
      fontSize: 15,
      fontFamily: "Inter_800ExtraBold"
    },
    roadXp: {
      fontSize: 11,
      fontFamily: "Inter_600SemiBold",
      fontVariant: ["tabular-nums"]
    },
    chips: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 6
    },
    chip: {
      flexDirection: "row",
      alignItems: "center",
      gap: 5,
      paddingHorizontal: 8,
      paddingVertical: 4,
      borderRadius: 10,
      borderWidth: 1,
      maxWidth: "100%"
    },
    chipText: {
      fontSize: 12,
      fontFamily: "Inter_600SemiBold",
      flexShrink: 1
    },
    chipTag: {
      fontSize: 11,
      fontFamily: "Inter_900Black",
      letterSpacing: 0.6
    },
    nextTag: {
      fontSize: 11,
      fontFamily: "Inter_900Black",
      letterSpacing: 0.8,
      paddingHorizontal: 8,
      paddingVertical: 4,
      borderRadius: 8,
      overflow: "hidden"
    }
  });
},768,[815,818,817,1216,12,133,28,188,109,829,827,889,1197,836,1264,837,819,895,820,6]);