__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "GoogleSignin", {
    enumerable: true,
    get: function () {
      return _signInGoogleSignin.GoogleSignin;
    }
  });
  Object.defineProperty(exports, "statusCodes", {
    enumerable: true,
    get: function () {
      return _errorsErrorCodes.statusCodes;
    }
  });
  Object.defineProperty(exports, "GoogleSigninButton", {
    enumerable: true,
    get: function () {
      return _buttonsGoogleSigninButton.GoogleSigninButton;
    }
  });
  var _signInGoogleSignin = require(_dependencyMap[0]);
  var _errorsErrorCodes = require(_dependencyMap[1]);
  var _buttonsGoogleSigninButton = require(_dependencyMap[2]);
  var _typesJs = require(_dependencyMap[3]);
  Object.keys(_typesJs).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _typesJs[k];
        }
      });
    }
  });
  var _functionsJs = require(_dependencyMap[4]);
  Object.keys(_functionsJs).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _functionsJs[k];
        }
      });
    }
  });
},1286,[1287,1288,1289,1291,1292]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "GoogleSignin", {
    enumerable: true,
    get: function () {
      return GoogleSignin;
    }
  });
  var _errorsErrorCodesWebJs = require(_dependencyMap[0]);
  const errorMessage = "RNGoogleSignIn: you are calling a not-implemented method on web platform. Web support is only available to sponsors. \nIf you are a sponsor, please follow the installation instructions carefully to obtain the implementation.";
  const logNotImplementedError = () => {
    console.warn(errorMessage);
  };
  function throwNotImplementedError() {
    const e = new Error(errorMessage);
    // the docs say that the errors produced by the module should have a code property
    Object.assign(e, {
      code: _errorsErrorCodesWebJs.statusCodes.PLAY_SERVICES_NOT_AVAILABLE
    });
    throw e;
  }
  async function signIn(_options = {}) {
    throwNotImplementedError();
  }
  async function hasPlayServices(_options = {
    showPlayServicesUpdateDialog: true
  }) {
    logNotImplementedError();
    return false;
  }
  function configure(_options) {
    logNotImplementedError();
  }
  async function addScopes(_options) {
    logNotImplementedError();
    return null;
  }
  async function signInSilently() {
    throwNotImplementedError();
  }
  async function signOut() {
    logNotImplementedError();
    return null;
  }
  async function revokeAccess() {
    logNotImplementedError();
    return null;
  }
  function hasPreviousSignIn() {
    logNotImplementedError();
    return false;
  }
  function getCurrentUser() {
    logNotImplementedError();
    return null;
  }
  async function clearCachedAccessToken(_tokenString) {
    logNotImplementedError();
    return null;
  }
  async function getTokens() {
    throwNotImplementedError();
  }
  const GoogleSignin = {
    hasPlayServices,
    configure,
    signIn,
    addScopes,
    signInSilently,
    signOut,
    revokeAccess,
    hasPreviousSignIn,
    getCurrentUser,
    clearCachedAccessToken,
    getTokens
  };
},1287,[1288]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "statusCodes", {
    enumerable: true,
    get: function () {
      return statusCodes;
    }
  });
  const statusCodesRaw = {
    SIGN_IN_CANCELLED: 'SIGN_IN_CANCELLED',
    IN_PROGRESS: 'IN_PROGRESS',
    PLAY_SERVICES_NOT_AVAILABLE: 'PLAY_SERVICES_NOT_AVAILABLE',
    SIGN_IN_REQUIRED: 'SIGN_IN_REQUIRED',
    NULL_PRESENTER: 'NULL_PRESENTER'
  };
  const statusCodes = Object.freeze(statusCodesRaw);
},1288,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "GoogleSigninButton", {
    enumerable: true,
    get: function () {
      return GoogleSigninButton;
    }
  });
  var _staticsJs = require(_dependencyMap[0]);
  const GoogleSigninButton = () => null;
  GoogleSigninButton.Color = _staticsJs.Color;
  GoogleSigninButton.Size = {
    Icon: 0,
    Standard: 1,
    Wide: 2
  };
},1289,[1290]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "Color", {
    enumerable: true,
    get: function () {
      return Color;
    }
  });
  const Color = {
    Dark: 'dark',
    Light: 'light'
  };
},1290,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},1291,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  /**
   * TypeScript helper to check if an object has the `code` property.
   * This is used to avoid `as` casting when you access the `code` property on errors returned by the module.
   */
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "isErrorWithCode", {
    enumerable: true,
    get: function () {
      return isErrorWithCode;
    }
  });
  exports.isCancelledResponse = isCancelledResponse;
  exports.isNoSavedCredentialFoundResponse = isNoSavedCredentialFoundResponse;
  exports.isSuccessResponse = isSuccessResponse;
  const isErrorWithCode = error => {
    // to account for https://github.com/facebook/react-native/issues/41950
    // fixed in https://github.com/facebook/react-native/commit/9525074a194b9cf2b7ef8ed270978e3f7f2c41f7 0.74
    const isNewArchErrorIOS = typeof error === 'object' && error != null;
    return (error instanceof Error || isNewArchErrorIOS) && 'code' in error;
  };

  /**
   * TypeScript helper to check if a response is a `cancelled` response. This is the same as checking if the `response.type === "cancelled"`.
   *
   * Use this if you prefer to use a function instead of comparing with a raw string.
   *
   * It supports both One Tap and Original Google Sign In responses.
   *
   * @example
   * ```ts
   * const response = await GoogleOneTapSignIn.createAccount();
   *
   * if (isCancelledResponse(response)) {
   *   // handle cancelled response
   * }
   * ```
   */
  function isCancelledResponse(response) {
    return response.type === 'cancelled';
  }

  /**
   * TypeScript helper to check if a response is a `noSavedCredentialFound` response. This is the same as checking if the `response.type === "noSavedCredentialFound"`.
   *
   * Use this if you prefer to use a function instead of comparing with a raw string.
   *
   * It supports both One Tap and Original Google Sign In responses.
   *
   * @example
   * ```ts
   * const response = await GoogleOneTapSignIn.signIn();
   *
   * if (isNoSavedCredentialFoundResponse(response)) {
   *   // the case when no user was previously signed in
   * }
   * ```
   */
  function isNoSavedCredentialFoundResponse(response) {
    return response.type === 'noSavedCredentialFound';
  }

  /**
   * TypeScript helper to check if a response is a `cancelled` response. This is the same as checking if the `response.type === "success"`.
   *
   * Use this if you prefer to use a function instead of comparing with a raw string.
   *
   * It supports both One Tap and Original Google Sign In responses.
   *
   * @example
   * ```ts
   * const response = await GoogleOneTapSignIn.createAccount();
   *
   * if (isSuccessResponse(response)) {
   *   // handle user signed in
   * }
   * ```
   */
  function isSuccessResponse(response) {
    return response.type === 'success';
  }
},1292,[]);