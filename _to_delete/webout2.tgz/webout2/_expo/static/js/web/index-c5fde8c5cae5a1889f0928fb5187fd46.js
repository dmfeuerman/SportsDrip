__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return HomeScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoLinearGradient = require(_dependencyMap[1]);
  var _expoVectorIcons = require(_dependencyMap[2]);
  var _libMotion = require(_dependencyMap[3]);
  var _expoRouter = require(_dependencyMap[4]);
  var _react = require(_dependencyMap[5]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[6]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[7]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[8]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[9]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[10]);
  var _componentsAvatarAvatarHero = require(_dependencyMap[11]);
  var AvatarHero = _interopDefault(_componentsAvatarAvatarHero);
  var _componentsAvatarAvatarBackdrop = require(_dependencyMap[12]);
  var _componentsLevelBar = require(_dependencyMap[13]);
  var LevelBar = _interopDefault(_componentsLevelBar);
  var _componentsBetBreakdownModal = require(_dependencyMap[14]);
  var BetBreakdownModal = _interopDefault(_componentsBetBreakdownModal);
  var _componentsBetTicket = require(_dependencyMap[15]);
  var BetTicket = _interopDefault(_componentsBetTicket);
  var _componentsDailyPickCard = require(_dependencyMap[16]);
  var DailyPickCard = _interopDefault(_componentsDailyPickCard);
  var _componentsFirstWeekChecklist = require(_dependencyMap[17]);
  var FirstWeekChecklist = _interopDefault(_componentsFirstWeekChecklist);
  var _componentsLadderPromotionHost = require(_dependencyMap[18]);
  var LadderPromotionHost = _interopDefault(_componentsLadderPromotionHost);
  var _componentsQuestsCard = require(_dependencyMap[19]);
  var QuestsCard = _interopDefault(_componentsQuestsCard);
  var _componentsRewardsCard = require(_dependencyMap[20]);
  var RewardsCard = _interopDefault(_componentsRewardsCard);
  var _componentsNextActionCard = require(_dependencyMap[21]);
  var NextActionCard = _interopDefault(_componentsNextActionCard);
  var _componentsLiveSweatCard = require(_dependencyMap[22]);
  var LiveSweatCard = _interopDefault(_componentsLiveSweatCard);
  var _componentsWeeklyRecapCard = require(_dependencyMap[23]);
  var WeeklyRecapCard = _interopDefault(_componentsWeeklyRecapCard);
  var _componentsCrewFeed = require(_dependencyMap[24]);
  var CrewFeedModule = _interopDefault(_componentsCrewFeed);
  var _componentsGameQuickView = require(_dependencyMap[25]);
  var GameQuickView = _interopDefault(_componentsGameQuickView);
  var _componentsAdsSponsoredCard = require(_dependencyMap[26]);
  var SponsoredCard = _interopDefault(_componentsAdsSponsoredCard);
  var _componentsUi = require(_dependencyMap[27]);
  var _constantsAvatarOptions = require(_dependencyMap[28]);
  var _contextAppContext = require(_dependencyMap[29]);
  var _contextChallengeContext = require(_dependencyMap[30]);
  var _contextLeagueContext = require(_dependencyMap[31]);
  var _contextChatContext = require(_dependencyMap[32]);
  var _contextNotificationContext = require(_dependencyMap[33]);
  var _hooksUseCatalog = require(_dependencyMap[34]);
  var _hooksUseColors = require(_dependencyMap[35]);
  var _hooksUseGames = require(_dependencyMap[36]);
  var _hooksUseLevelRewards = require(_dependencyMap[37]);
  var _hooksUseNow = require(_dependencyMap[38]);
  var _libOdds = require(_dependencyMap[39]);
  var _libSettings = require(_dependencyMap[40]);
  var _reactJsxRuntime = require(_dependencyMap[41]);
  /**
   * Home: "where do I stand?" answered in one screen. Order follows "now":
   * live stakes, challenges, your team today, leagues, then wallet and boxes.
   */
  function HomeScreen() {
    const c = (0, _hooksUseColors.useColors)();
    const top = (0, _componentsUi.useTopPad)();
    const bottom = (0, _componentsUi.useBottomPad)();
    const now = (0, _hooksUseNow.useNow)(30_000);
    const {
      profile,
      balance,
      bets,
      totalWon,
      progress,
      background
    } = (0, _contextAppContext.useApp)();
    const {
      nextAfter
    } = (0, _hooksUseLevelRewards.useLevelRewards)();
    const onScene = (0, _componentsAvatarAvatarBackdrop.isSceneBackdrop)(background);
    const {
      myLeagueBets,
      leagues
    } = (0, _contextLeagueContext.useLeague)();
    const {
      summaries,
      totalDebt
    } = (0, _contextLeagueContext.useLeagueSummaries)();
    const {
      notifications,
      unreadCount
    } = (0, _contextNotificationContext.useNotifications)();
    const {
      unreadChatCount
    } = (0, _contextChatContext.useChat)();
    const {
      byId
    } = (0, _hooksUseCatalog.useCatalog)();
    const {
      games
    } = (0, _hooksUseGames.useGames)();
    const gameById = (0, _react.useMemo)(() => new Map(games.map(g => [g.id, g])), [games]);
    const openCredit = bets.filter(b => b.status === "pending");
    const openLeague = leagues.flatMap(l => (myLeagueBets[l.id] ?? []).filter(b_0 => b_0.status === "pending").map(b_1 => ({
      b: b_1,
      league: l.name
    })));
    const openTotal = openCredit.length + openLeague.length;
    const {
      incoming: challengeInbox,
      live: challengesLive,
      outgoing: challengesSent,
      escrowed
    } = (0, _contextChallengeContext.useChallenges)();
    // Credits in friend pots are in play too.
    const atRisk = openCredit.reduce((s, b_2) => s + b_2.stake, 0) + escrowed;
    const couldReturn = openCredit.reduce((s_0, b_3) => s_0 + b_3.potentialPayout, 0);
    const results = notifications.filter(n => n.bet).slice(0, 4);
    const settled = bets.filter(b_4 => b_4.status === "won" || b_4.status === "lost");
    const wins = settled.filter(b_5 => b_5.status === "won").length;
    // Net, not just gross winnings: payouts back minus every settled stake.
    const net = settled.reduce((s_1, b_6) => s_1 + (b_6.status === "won" ? b_6.potentialPayout : 0) - b_6.stake, 0);
    const name = profile?.displayName?.trim() || profile?.username || "there";
    const focused = (0, _expoRouter.useIsFocused)();
    const [avatarGesture, setAvatarGesture] = (0, _react.useState)(false);
    const [quickGame, setQuickGame] = (0, _react.useState)(null);
    const [breakdown, setBreakdown] = (0, _react.useState)(null);
    // "Run It Back" from a result popup lands here with the game to open.
    const params = (0, _expoRouter.useLocalSearchParams)();
    (0, _react.useEffect)(() => {
      if (!params.game) return;
      setQuickGame(params.game);
      _expoRouter.router.setParams({
        game: undefined
      });
    }, [params.game]);

    // A favorite team on today's board (live first, then the next kickoff within 18h).
    const teamTonight = (0, _react.useMemo)(() => {
      const fav = new Set((profile?.favoriteTeams ?? []).map(t => `${t.sport}:${t.abbr}`));
      if (!fav.size) return null;
      const hit = g_0 => fav.has(`${g_0.sport}:${g_0.homeTeam.abbreviation}`) ? g_0.homeTeam.abbreviation : fav.has(`${g_0.sport}:${g_0.awayTeam.abbreviation}`) ? g_0.awayTeam.abbreviation : null;
      const pool = games.filter(g_1 => g_1.status === "live" || g_1.status === "upcoming" && g_1.startsAt - now < 64800000).sort((a, b_7) => (a.status === "live" ? -1 : 0) - (b_7.status === "live" ? -1 : 0) || a.startsAt - b_7.startsAt);
      for (const g_2 of pool) {
        const abbr = hit(g_2);
        if (abbr) return {
          game: g_2,
          abbr
        };
      }
      return null;
    }, [profile?.favoriteTeams, games, now]);
    const scrollRef = (0, _react.useRef)(null);
    const sectionY = (0, _react.useRef)({
      prizes: 0,
      daily: 0
    });
    const scrollTo = section => scrollRef.current?.scrollTo({
      y: Math.max(0, sectionY.current[section] - 12),
      animated: true
    });
    const openGameIds = (0, _react.useMemo)(() => new Set([...openCredit.map(b_8 => b_8.gameId), ...openLeague.map(({
      b: b_9
    }) => b_9.gameId)]), [openCredit, openLeague]);
    const sweat = [...openCredit.map(b_10 => ({
      ...b_10,
      key: b_10.id,
      wallet: null
    })), ...openLeague.map(({
      b: b_11,
      league
    }) => ({
      ...b_11,
      key: `lg_${b_11.id}`,
      wallet: league
    }))];
    const bestLeague = summaries.filter(s_2 => s_2.me?.rank).sort((a_0, b_12) => (a_0.me.rank ?? 99) - (b_12.me.rank ?? 99))[0];
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
      style: [styles.container, {
        backgroundColor: c.background
      }],
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        ref: scrollRef,
        scrollEnabled: !avatarGesture,
        contentContainerStyle: [styles.content, {
          paddingTop: top + 12,
          paddingBottom: bottom
        }],
        showsVerticalScrollIndicator: false,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarHero.default, {
          avatar: profile?.avatar ?? _constantsAvatarOptions.DEFAULT_AVATAR,
          equipped: profile?.equipped ?? {},
          catalog: byId,
          moves: profile?.moves,
          onEditMoves: () => _expoRouter.router.push("/moves"),
          active: focused,
          onGesture: setAvatarGesture,
          background: background,
          footer: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(LevelBar.default, {
            progress: progress,
            nextReward: nextAfter(progress.level),
            onPress: () => _expoRouter.router.push("/levels")
          }),
          header: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              accessibilityRole: "header",
              style: [styles.h1, {
                color: onScene ? "#FFFFFF" : c.foreground,
                flex: 1
              }, onScene && styles.onScene],
              numberOfLines: 1,
              children: ["Hello ", name]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.IconButton, {
              icon: "help-circle-outline",
              label: "How It Works",
              onPress: _libSettings.openWalkthrough
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.IconButton, {
              icon: "chat-processing-outline",
              label: "Chat",
              badge: unreadChatCount,
              onPress: () => _expoRouter.router.push("/messages")
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.IconButton, {
              icon: "bell-outline",
              label: "Activity",
              badge: unreadCount,
              onPress: () => _expoRouter.router.push("/activity")
            })]
          })
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(NextActionCard.default, {
          now: now,
          games: games,
          openGameIds: openGameIds,
          teamTonight: teamTonight,
          onOpenGame: setQuickGame,
          onScrollTo: scrollTo
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(WeeklyRecapCard.default, {
          bets: bets,
          now: now,
          leagueLine: bestLeague ? `#${bestLeague.me.rank} of ${bestLeague.memberCount} in ${bestLeague.league.name}` : null
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
          title: "Wallet",
          icon: "wallet-outline"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
          style: [styles.wallet, {
            backgroundColor: c.elevated,
            borderColor: c.alpha(c.primary, 0.28)
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoLinearGradient.LinearGradient, {
            pointerEvents: "none",
            colors: [c.alpha(c.primary, c.isDark ? 0.2 : 0.12), c.alpha(c.accent, 0.05), "transparent"],
            start: {
              x: 0,
              y: 0
            },
            end: {
              x: 0.9,
              y: 1
            },
            style: StyleSheet.default.absoluteFill
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.label, {
              color: c.mutedForeground
            }],
            children: "CREDITS"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
            value: balance,
            size: "xl",
            animate: true
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.walletStats,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(WalletStat, {
              label: "In Play",
              value: atRisk.toLocaleString(),
              hint: escrowed > 0 ? `${openCredit.length} bets · ${escrowed.toLocaleString()} in pots` : `${openCredit.length} open`
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(WalletStat, {
              label: "Could Return",
              value: couldReturn.toLocaleString(),
              color: c.positive
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(WalletStat, {
              label: "League Debt",
              value: totalDebt.toLocaleString(),
              color: totalDebt > 0 ? c.debt : undefined,
              hint: totalDebt > 0 ? "flat interest" : "none"
            })]
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(LiveSweatCard.default, {
          bets: sweat,
          gameById: gameById,
          onOpen: setQuickGame
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
          title: "My Bets",
          action: openTotal > 0 ? "See All" : undefined,
          onAction: () => _expoRouter.router.push("/bets")
        }), openTotal === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
          icon: "ticket-outline",
          title: "Nothing Riding",
          body: "Back a team on the board \u2014 results pop up here the moment the game's final.",
          action: "Browse Games",
          onAction: () => _expoRouter.router.navigate("/(tabs)/games")
        }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [openCredit.slice(0, 3).map(b_13 => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BetTicket.default, {
            bet: b_13,
            game: gameById.get(b_13.gameId) ?? null,
            onOpen: () => setQuickGame(b_13.gameId)
          }, b_13.id)), openLeague.slice(0, Math.max(0, 3 - openCredit.length)).map(({
            b: b_14,
            league: league_0
          }) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BetTicket.default, {
            bet: b_14,
            walletLabel: league_0,
            game: gameById.get(b_14.gameId) ?? null,
            onOpen: () => setQuickGame(b_14.gameId)
          }, b_14.id)), openTotal > 3 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: `See all ${openTotal} open bets`,
            icon: "ticket-confirmation-outline",
            variant: "secondary",
            onPress: () => _expoRouter.router.push("/bets"),
            style: {
              borderColor: c.primary,
              borderWidth: 1.5
            }
          }) : null]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          onLayout: e => sectionY.current.prizes = e.nativeEvent.layout.y,
          style: {
            gap: 12
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
            title: "Prizes",
            icon: "gift-outline"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(RewardsCard.default, {})]
        }), challengeInbox.length + challengesLive.length + challengesSent.length > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
            title: "Challenges",
            icon: "sword-cross",
            action: "See All",
            onAction: () => _expoRouter.router.push("/challenges")
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
            tone: challengeInbox.length ? "accent" : undefined,
            onPress: () => _expoRouter.router.push("/challenges"),
            style: styles.rowCard,
            accessibilityLabel: "Friend challenges",
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "sword-cross",
              size: 22,
              color: c.accent
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.rowTitle, {
                  color: c.foreground
                }],
                children: challengeInbox.length ? `${challengeInbox.length} challenge${challengeInbox.length > 1 ? "s" : ""} waiting on you` : challengesLive.length ? `${challengesLive.length} challenge${challengesLive.length > 1 ? "s" : ""} locked in` : `${challengesSent.length} challenge${challengesSent.length > 1 ? "s" : ""} sent`
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.rowSub, {
                  color: c.mutedForeground
                }],
                children: challengeInbox.length ? `${challengeInbox[0].creatorName} wants ${challengeInbox[0].away.abbreviation} @ ${challengeInbox[0].home.abbreviation}` : `${escrowed.toLocaleString()} credits in friend pots`
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "chevron-right",
              size: 20,
              color: c.mutedForeground
            })]
          })]
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
          title: "Today",
          icon: "calendar-today"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FirstWeekChecklist.default, {}), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(LadderPromotionHost.default, {}), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          onLayout: e_0 => sectionY.current.daily = e_0.nativeEvent.layout.y,
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(DailyPickCard.default, {})
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(QuestsCard.default, {}), teamTonight ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
          onPress: () => setQuickGame(teamTonight.game.id),
          style: styles.rowCard,
          accessibilityLabel: `${teamTonight.abbr} plays ${(0, _libOdds.untilKickoff)(teamTonight.game.startsAt, now)}`,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "calendar-star",
            size: 22,
            color: c.primary
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: {
              flex: 1
            },
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.rowTitle, {
                color: c.foreground
              }],
              children: [teamTonight.abbr, " ", teamTonight.game.status === "live" ? "is live now" : `plays ${(0, _libOdds.untilKickoff)(teamTonight.game.startsAt, now)}`]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.rowSub, {
                color: c.mutedForeground
              }],
              children: [teamTonight.game.awayTeam.abbreviation, " @ ", teamTonight.game.homeTeam.abbreviation, " \xB7 get your pick in"]
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "chevron-right",
            size: 20,
            color: c.mutedForeground
          })]
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
          title: "Your Leagues",
          action: leagues.length ? "See All" : undefined,
          onAction: () => _expoRouter.router.navigate("/(tabs)/leagues")
        }), summaries.length === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
          icon: "trophy-outline",
          title: "Compete With Friends",
          body: "A league gives everyone the same stack of tokens for a season. Best net worth at the end takes the pot.",
          action: "Start a League",
          onAction: () => _expoRouter.router.navigate({
            pathname: "/(tabs)/leagues",
            params: {
              create: "1"
            }
          }),
          secondary: "Join With a Code",
          onSecondary: () => _expoRouter.router.navigate({
            pathname: "/(tabs)/leagues",
            params: {
              join: "1"
            }
          })
        }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ScrollView.default, {
          horizontal: true,
          showsHorizontalScrollIndicator: false,
          contentContainerStyle: styles.leagueRow,
          children: summaries.slice(0, 6).map(s_3 => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
            onPress: () => _expoRouter.router.push({
              pathname: "/league/[id]",
              params: {
                id: s_3.league.id
              }
            }),
            accessibilityLabel: `${s_3.league.name}, rank ${s_3.me?.rank ?? "unranked"} of ${s_3.memberCount}`,
            style: styles.leagueCard,
            tone: s_3.me?.rank === 1 ? "money" : undefined,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.leagueName, {
                color: c.foreground
              }],
              numberOfLines: 1,
              children: s_3.league.name
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.rankLine,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.rank, {
                  color: s_3.me?.rank === 1 ? c.primary : c.foreground
                }],
                children: ["#", s_3.me?.rank ?? "–"]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.rankOf, {
                  color: c.mutedForeground
                }],
                children: ["of ", s_3.memberCount]
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
              value: s_3.me?.netWorth ?? 0,
              currency: "league",
              size: "sm"
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.rowSub, {
                color: c.subtleForeground
              }],
              children: [s_3.closed ? "Closed" : `${s_3.daysLeft}d left`, s_3.me && s_3.me.debt > 0 ? ` · owes ${s_3.me.debt.toLocaleString()}` : ""]
            })]
          }, s_3.league.id))
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(CrewFeedModule.default, {}), results.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
            title: "Recent Results",
            action: "See All",
            onAction: () => _expoRouter.router.push("/activity")
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Card, {
            style: {
              padding: 0,
              overflow: "hidden"
            },
            children: results.map((n_0, i) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ResultRow, {
              n: n_0,
              last: i === results.length - 1,
              onPress: () => {
                if (!n_0.bet) return;
                _libMotion.haptic.tick();
                const won = n_0.type === "bet_won" || n_0.type === "challenge_won";
                const lost = n_0.type === "bet_lost" || n_0.type === "challenge_lost";
                setBreakdown({
                  id: n_0.bet.betId,
                  gameId: n_0.bet.gameId,
                  sport: n_0.bet.sport,
                  teamName: n_0.bet.teamName,
                  teamAbbr: n_0.bet.teamAbbr,
                  teamColor: n_0.bet.teamColor,
                  opponentAbbr: n_0.bet.opponentAbbr,
                  side: n_0.bet.side,
                  market: n_0.type.startsWith("challenge_") ? "challenge" : "ml",
                  odds: n_0.bet.odds,
                  stake: n_0.bet.stake,
                  payout: n_0.bet.payout,
                  status: won ? "won" : lost ? "lost" : "push",
                  finalHomeScore: n_0.bet.finalHomeScore,
                  finalAwayScore: n_0.bet.finalAwayScore,
                  wallet: n_0.wallet,
                  leagueId: n_0.leagueId,
                  leagueName: n_0.leagueName,
                  friendName: n_0.data?.friendName ?? null,
                  settledAtMs: n_0.createdAtMs
                });
              }
            }, n_0.id))
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(SponsoredCard.default, {}), settled.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.record,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
            label: `${wins}–${settled.length - wins} record`,
            icon: "chart-line"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
            label: `${Math.round(wins / settled.length * 100)}% hit rate`,
            tone: "accent"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
            label: `${net >= 0 ? "+" : ""}${net.toLocaleString()} net`,
            tone: net > 0 ? "positive" : net < 0 ? "negative" : "neutral"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
            label: `${totalWon.toLocaleString()} won gross`,
            tone: "neutral"
          })]
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BetBreakdownModal.default, {
        item: breakdown,
        onClose: () => setBreakdown(null),
        onOpenGame: gId => setQuickGame(gId)
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(GameQuickView.default, {
        gameId: quickGame,
        onClose: () => setQuickGame(null)
      })]
    });
  }
  function WalletStat(t0) {
    const $ = (0, _reactCompilerRuntime.c)(20);
    const {
      label,
      value,
      hint,
      color
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    let t1;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = {
        flex: 1,
        gap: 2
      };
      $[0] = t1;
    } else {
      t1 = $[0];
    }
    let t2;
    if ($[1] !== c.subtleForeground) {
      t2 = [styles.label, {
        color: c.subtleForeground
      }];
      $[1] = c.subtleForeground;
      $[2] = t2;
    } else {
      t2 = $[2];
    }
    let t3;
    if ($[3] !== label) {
      t3 = label.toUpperCase();
      $[3] = label;
      $[4] = t3;
    } else {
      t3 = $[4];
    }
    let t4;
    if ($[5] !== t2 || $[6] !== t3) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t2,
        children: t3
      });
      $[5] = t2;
      $[6] = t3;
      $[7] = t4;
    } else {
      t4 = $[7];
    }
    const t5 = color ?? c.foreground;
    let t6;
    if ($[8] !== t5) {
      t6 = [styles.walletValue, {
        color: t5
      }];
      $[8] = t5;
      $[9] = t6;
    } else {
      t6 = $[9];
    }
    let t7;
    if ($[10] !== t6 || $[11] !== value) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t6,
        children: value
      });
      $[10] = t6;
      $[11] = value;
      $[12] = t7;
    } else {
      t7 = $[12];
    }
    let t8;
    if ($[13] !== c.subtleForeground || $[14] !== hint) {
      t8 = hint ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.rowSub, {
          color: c.subtleForeground
        }],
        children: hint
      }) : null;
      $[13] = c.subtleForeground;
      $[14] = hint;
      $[15] = t8;
    } else {
      t8 = $[15];
    }
    let t9;
    if ($[16] !== t4 || $[17] !== t7 || $[18] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t1,
        children: [t4, t7, t8]
      });
      $[16] = t4;
      $[17] = t7;
      $[18] = t8;
      $[19] = t9;
    } else {
      t9 = $[19];
    }
    return t9;
  }
  function ResultRow(t0) {
    const $ = (0, _reactCompilerRuntime.c)(58);
    const {
      n,
      last,
      onPress
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const won = n.type === "bet_won" || n.type === "challenge_won";
    const lost = n.type === "bet_lost" || n.type === "challenge_lost";
    const friend = n.type.startsWith("challenge_") ? n.data?.friendName : null;
    const tone = won ? c.positive : lost ? c.negative : c.mutedForeground;
    const t1 = `${n.bet?.teamAbbr} vs ${n.bet?.opponentAbbr}, ${won ? "Won" : lost ? "Lost" : "Push"}. Tap for bet breakdown`;
    let t2;
    if ($[0] !== c.border || $[1] !== c.secondary || $[2] !== last) {
      t2 = t3 => {
        const {
          pressed
        } = t3;
        return [styles.result, !last && {
          borderBottomWidth: StyleSheet.default.hairlineWidth,
          borderBottomColor: c.border
        }, pressed && {
          backgroundColor: c.secondary
        }];
      };
      $[0] = c.border;
      $[1] = c.secondary;
      $[2] = last;
      $[3] = t2;
    } else {
      t2 = $[3];
    }
    let t3;
    if ($[4] !== c || $[5] !== tone) {
      t3 = c.alpha(tone, 0.14);
      $[4] = c;
      $[5] = tone;
      $[6] = t3;
    } else {
      t3 = $[6];
    }
    let t4;
    if ($[7] !== t3) {
      t4 = [styles.resultIcon, {
        backgroundColor: t3
      }];
      $[7] = t3;
      $[8] = t4;
    } else {
      t4 = $[8];
    }
    const t5 = won ? "arrow-up-bold" : lost ? "arrow-down-bold" : "minus";
    let t6;
    if ($[9] !== t5 || $[10] !== tone) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: t5,
        size: 16,
        color: tone
      });
      $[9] = t5;
      $[10] = tone;
      $[11] = t6;
    } else {
      t6 = $[11];
    }
    let t7;
    if ($[12] !== t4 || $[13] !== t6) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t4,
        children: t6
      });
      $[12] = t4;
      $[13] = t6;
      $[14] = t7;
    } else {
      t7 = $[14];
    }
    let t8;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
      t8 = {
        flex: 1
      };
      $[15] = t8;
    } else {
      t8 = $[15];
    }
    let t9;
    if ($[16] !== c.foreground) {
      t9 = [styles.rowTitle, {
        color: c.foreground
      }];
      $[16] = c.foreground;
      $[17] = t9;
    } else {
      t9 = $[17];
    }
    const t10 = n.bet?.teamAbbr;
    const t11 = n.bet?.opponentAbbr;
    let t12;
    if ($[18] !== c.league || $[19] !== n.leagueName) {
      t12 = n.leagueName ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: {
          color: c.league
        },
        children: ["  \xB7 ", n.leagueName]
      }) : null;
      $[18] = c.league;
      $[19] = n.leagueName;
      $[20] = t12;
    } else {
      t12 = $[20];
    }
    let t13;
    if ($[21] !== c.accent || $[22] !== friend) {
      t13 = friend ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: {
          color: c.accent
        },
        children: ["  \xB7 vs ", friend]
      }) : null;
      $[21] = c.accent;
      $[22] = friend;
      $[23] = t13;
    } else {
      t13 = $[23];
    }
    let t14;
    if ($[24] !== t10 || $[25] !== t11 || $[26] !== t12 || $[27] !== t13 || $[28] !== t9) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: t9,
        numberOfLines: 1,
        children: [t10, " v ", t11, t12, t13]
      });
      $[24] = t10;
      $[25] = t11;
      $[26] = t12;
      $[27] = t13;
      $[28] = t9;
      $[29] = t14;
    } else {
      t14 = $[29];
    }
    let t15;
    if ($[30] !== c.mutedForeground) {
      t15 = [styles.rowSub, {
        color: c.mutedForeground
      }];
      $[30] = c.mutedForeground;
      $[31] = t15;
    } else {
      t15 = $[31];
    }
    const t16 = won ? "Won" : lost ? "Lost" : "Push";
    let t17;
    if ($[32] !== n.bet?.odds) {
      t17 = n.bet?.odds.toFixed(2);
      $[32] = n.bet?.odds;
      $[33] = t17;
    } else {
      t17 = $[33];
    }
    let t18;
    if ($[34] !== n.bet?.stake) {
      t18 = n.bet?.stake.toLocaleString();
      $[34] = n.bet?.stake;
      $[35] = t18;
    } else {
      t18 = $[35];
    }
    let t19;
    if ($[36] !== t15 || $[37] !== t16 || $[38] !== t17 || $[39] !== t18) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: t15,
        numberOfLines: 1,
        children: [t16, " \xB7 ", t17, "x \xB7 Stake ", t18]
      });
      $[36] = t15;
      $[37] = t16;
      $[38] = t17;
      $[39] = t18;
      $[40] = t19;
    } else {
      t19 = $[40];
    }
    let t20;
    if ($[41] !== t14 || $[42] !== t19) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t8,
        children: [t14, t19]
      });
      $[41] = t14;
      $[42] = t19;
      $[43] = t20;
    } else {
      t20 = $[43];
    }
    const t21 = won && n.bet ? n.bet.payout - n.bet.stake : n.delta;
    const t22 = n.wallet === "league" ? "league" : "credits";
    const t23 = won ? "positive" : lost ? "negative" : "neutral";
    let t24;
    if ($[44] !== t21 || $[45] !== t22 || $[46] !== t23) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
        value: t21,
        currency: t22,
        signed: true,
        size: "sm",
        tone: t23
      });
      $[44] = t21;
      $[45] = t22;
      $[46] = t23;
      $[47] = t24;
    } else {
      t24 = $[47];
    }
    let t25;
    if ($[48] !== c.subtleForeground) {
      t25 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "information-outline",
        size: 18,
        color: c.subtleForeground
      });
      $[48] = c.subtleForeground;
      $[49] = t25;
    } else {
      t25 = $[49];
    }
    let t26;
    if ($[50] !== onPress || $[51] !== t1 || $[52] !== t2 || $[53] !== t20 || $[54] !== t24 || $[55] !== t25 || $[56] !== t7) {
      t26 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        accessibilityRole: "button",
        accessibilityLabel: t1,
        onPress: onPress,
        style: t2,
        children: [t7, t20, t24, t25]
      });
      $[50] = onPress;
      $[51] = t1;
      $[52] = t2;
      $[53] = t20;
      $[54] = t24;
      $[55] = t25;
      $[56] = t7;
      $[57] = t26;
    } else {
      t26 = $[57];
    }
    return t26;
  }
  const styles = StyleSheet.default.create({
    container: {
      flex: 1
    },
    content: {
      paddingHorizontal: 16,
      gap: 12
    },
    h1: {
      fontSize: 28,
      lineHeight: 32,
      fontFamily: "Inter_900Black",
      letterSpacing: -1
    },
    onScene: {
      textShadowColor: "rgba(0,0,0,0.55)",
      textShadowRadius: 8,
      textShadowOffset: {
        width: 0,
        height: 1
      }
    },
    wallet: {
      gap: 8,
      padding: 18,
      borderRadius: 22,
      overflow: "hidden"
    },
    label: {
      fontSize: 11,
      fontFamily: "Inter_800ExtraBold",
      letterSpacing: 1.2
    },
    walletStats: {
      flexDirection: "row",
      gap: 8,
      marginTop: 4
    },
    walletValue: {
      fontSize: 16,
      fontFamily: "Inter_700Bold",
      fontVariant: ["tabular-nums"]
    },
    actions: {
      flexDirection: "row",
      gap: 10,
      marginTop: 8
    },
    rowCard: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12
    },
    rowTitle: {
      fontSize: 14,
      fontFamily: "Inter_600SemiBold"
    },
    rowSub: {
      fontSize: 12,
      fontFamily: "Inter_400Regular"
    },
    leagueRow: {
      gap: 10,
      paddingRight: 16
    },
    leagueCard: {
      width: 168,
      gap: 4
    },
    leagueName: {
      fontSize: 14,
      fontFamily: "Inter_700Bold"
    },
    rankLine: {
      flexDirection: "row",
      alignItems: "baseline",
      gap: 4
    },
    rank: {
      fontSize: 28,
      fontFamily: "Inter_700Bold",
      fontVariant: ["tabular-nums"],
      letterSpacing: -0.5
    },
    rankOf: {
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    },
    result: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      padding: 12
    },
    resultIcon: {
      width: 32,
      height: 32,
      borderRadius: 16,
      alignItems: "center",
      justifyContent: "center"
    },
    record: {
      flexDirection: "row",
      gap: 8,
      flexWrap: "wrap",
      marginTop: 4
    }
  });
},753,[815,871,818,820,817,12,133,28,188,109,827,888,829,889,890,891,892,875,876,877,878,885,886,887,893,851,853,836,894,837,821,858,822,823,838,819,860,895,844,870,816,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return FirstWeekChecklist;
    }
  });
  Object.defineProperty(exports, "ACTIVATION_FRIENDS", {
    enumerable: true,
    get: function () {
      return ACTIVATION_FRIENDS;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _reactNativeAsyncStorageAsyncStorage = require(_dependencyMap[2]);
  var AsyncStorage = _interopDefault(_reactNativeAsyncStorageAsyncStorage);
  var _expoRouter = require(_dependencyMap[3]);
  var _react = require(_dependencyMap[4]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[5]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[6]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[7]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[8]);
  var _componentsUi = require(_dependencyMap[9]);
  var _constantsTheme = require(_dependencyMap[10]);
  var theme = _interopDefault(_constantsTheme);
  var _contextAppContext = require(_dependencyMap[11]);
  var _contextLeagueContext = require(_dependencyMap[12]);
  var _hooksUseColors = require(_dependencyMap[13]);
  var _hooksUseFriends = require(_dependencyMap[14]);
  var _libAnalytics = require(_dependencyMap[15]);
  var _libExperiments = require(_dependencyMap[16]);
  var _libMotion = require(_dependencyMap[17]);
  var _reactJsxRuntime = require(_dependencyMap[18]);
  const WEEK_MS = 604800000;
  /** Friends in the same league for activation. Placeholder until cohorts say otherwise. */
  const ACTIVATION_FRIENDS = 1;
  const ACTIVATION_KEY = "sportdrip.activation.v1";
  function createdAtMs(v) {
    if (typeof v === "number") return v;
    if (v && typeof v === "object" && "toMillis" in v && typeof v.toMillis === "function") {
      return v.toMillis();
    }
    return null;
  }

  /**
   * First-7-days checklist. Derived from existing profile/league/friend state —
   * no new server state. Avatar is pre-checked so progress starts endowed.
   */
  function FirstWeekChecklist() {
    const $ = (0, _reactCompilerRuntime.c)(51);
    const c = (0, _hooksUseColors.useColors)();
    const {
      profile
    } = (0, _contextAppContext.useApp)();
    const {
      leagues
    } = (0, _contextLeagueContext.useLeague)();
    const uid = profile?.uid ?? null;
    const {
      friends
    } = (0, _hooksUseFriends.useFriends)(uid);
    const heldOut = (0, _libExperiments.useHeldOut)(uid);
    const created = createdAtMs(profile?.createdAt);
    const young = created !== null && Date.now() - created < WEEK_MS;
    const p = profile;
    const settled = (p?.stats?.betsWon ?? 0) + (p?.stats?.betsLost ?? 0) + (p?.stats?.betsPush ?? 0) + (p?.dailyRecord?.w ?? 0) + (p?.dailyRecord?.l ?? 0) > 0;
    let t0;
    if ($[0] !== friends) {
      t0 = new Set(friends.map(_temp));
      $[0] = friends;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    const friendIds = t0;
    let t1;
    if ($[2] !== friendIds || $[3] !== leagues) {
      let t2;
      if ($[5] !== friendIds) {
        t2 = l => l.memberIds.filter(m => friendIds.has(m)).length;
        $[5] = friendIds;
        $[6] = t2;
      } else {
        t2 = $[6];
      }
      t1 = Math.max(0, ...leagues.map(t2));
      $[2] = friendIds;
      $[3] = leagues;
      $[4] = t1;
    } else {
      t1 = $[4];
    }
    const friendsInLeague = t1;
    let t2;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
      t2 = {
        key: "avatar",
        label: "Create Your Avatar",
        done: true,
        href: "/(tabs)/avatar"
      };
      $[7] = t2;
    } else {
      t2 = $[7];
    }
    const t3 = (profile?.favoriteTeams?.length ?? 0) > 0;
    let t4;
    if ($[8] !== t3) {
      t4 = {
        key: "teams",
        label: "Pick Your Teams",
        done: t3,
        href: "/(tabs)/avatar"
      };
      $[8] = t3;
      $[9] = t4;
    } else {
      t4 = $[9];
    }
    const t5 = !!profile?.streak?.longest;
    let t6;
    if ($[10] !== t5) {
      t6 = {
        key: "daily",
        label: "Make your first Daily Pick",
        done: t5,
        href: "/(tabs)"
      };
      $[10] = t5;
      $[11] = t6;
    } else {
      t6 = $[11];
    }
    const t7 = friends.length > 0;
    let t8;
    if ($[12] !== t7) {
      t8 = {
        key: "friend",
        label: "Add a Friend",
        done: t7,
        href: "/(tabs)/friends"
      };
      $[12] = t7;
      $[13] = t8;
    } else {
      t8 = $[13];
    }
    const t9 = leagues.length > 0;
    let t10;
    if ($[14] !== t9) {
      t10 = {
        key: "league",
        label: "Join a League",
        done: t9,
        href: "/(tabs)/leagues"
      };
      $[14] = t9;
      $[15] = t10;
    } else {
      t10 = $[15];
    }
    let t11;
    if ($[16] !== settled) {
      t11 = {
        key: "settled",
        label: "Get a Pick Settled",
        done: settled,
        href: "/(tabs)/games"
      };
      $[16] = settled;
      $[17] = t11;
    } else {
      t11 = $[17];
    }
    let t12;
    if ($[18] !== t10 || $[19] !== t11 || $[20] !== t4 || $[21] !== t6 || $[22] !== t8) {
      t12 = [t2, t4, t6, t8, t10, t11];
      $[18] = t10;
      $[19] = t11;
      $[20] = t4;
      $[21] = t6;
      $[22] = t8;
      $[23] = t12;
    } else {
      t12 = $[23];
    }
    const items = t12;
    const activated = settled && friendsInLeague >= ACTIVATION_FRIENDS;
    let t13;
    let t14;
    if ($[24] !== activated || $[25] !== friendsInLeague || $[26] !== uid) {
      t13 = () => {
        if (!activated || !uid) {
          return;
        }
        (async () => {
          try {
            if (await AsyncStorage.default.getItem(`${ACTIVATION_KEY}.${uid}`)) {
              return;
            }
            await AsyncStorage.default.setItem(`${ACTIVATION_KEY}.${uid}`, "1");
          } catch {
            return;
          }
          (0, _libAnalytics.trackEvent)("activation_reached", {
            friends_in_league: friendsInLeague
          });
        })();
      };
      t14 = [activated, uid, friendsInLeague];
      $[24] = activated;
      $[25] = friendsInLeague;
      $[26] = uid;
      $[27] = t13;
      $[28] = t14;
    } else {
      t13 = $[27];
      t14 = $[28];
    }
    (0, _react.useEffect)(t13, t14);
    let t15;
    if ($[29] !== items) {
      t15 = items.filter(_temp2);
      $[29] = items;
      $[30] = t15;
    } else {
      t15 = $[30];
    }
    const done = t15.length;
    if (!profile || !young || heldOut || done === items.length) {
      return null;
    }
    let t16;
    if ($[31] === Symbol.for("react.memo_cache_sentinel")) {
      t16 = {
        gap: 8
      };
      $[31] = t16;
    } else {
      t16 = $[31];
    }
    const t17 = `Your first week · ${done}/${items.length}`;
    let t18;
    if ($[32] !== t17) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
        title: t17
      });
      $[32] = t17;
      $[33] = t18;
    } else {
      t18 = $[33];
    }
    let t19;
    if ($[34] !== c.secondary) {
      t19 = [styles.track, {
        backgroundColor: c.secondary
      }];
      $[34] = c.secondary;
      $[35] = t19;
    } else {
      t19 = $[35];
    }
    const t20 = `${done / items.length * 100}%`;
    let t21;
    if ($[36] !== c.primary || $[37] !== t20) {
      t21 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [styles.fill, {
          backgroundColor: c.primary,
          width: t20
        }]
      });
      $[36] = c.primary;
      $[37] = t20;
      $[38] = t21;
    } else {
      t21 = $[38];
    }
    let t22;
    if ($[39] !== t19 || $[40] !== t21) {
      t22 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t19,
        children: t21
      });
      $[39] = t19;
      $[40] = t21;
      $[41] = t22;
    } else {
      t22 = $[41];
    }
    let t23;
    if ($[42] !== c.foreground || $[43] !== c.mutedForeground || $[44] !== c.positive || $[45] !== items) {
      t23 = items.map(i_0 => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        accessibilityRole: "button",
        accessibilityState: {
          checked: i_0.done
        },
        accessibilityLabel: `${i_0.label}${i_0.done ? ", done" : ""}`,
        disabled: i_0.done,
        onPress: () => {
          _libMotion.haptic.tick();
          _expoRouter.router.navigate(i_0.href);
        },
        style: styles.row,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: i_0.done ? "check-circle" : "checkbox-blank-circle-outline",
          size: 20,
          color: i_0.done ? c.positive : c.mutedForeground
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.label, {
            color: i_0.done ? c.mutedForeground : c.foreground
          }],
          children: i_0.label
        })]
      }, i_0.key));
      $[42] = c.foreground;
      $[43] = c.mutedForeground;
      $[44] = c.positive;
      $[45] = items;
      $[46] = t23;
    } else {
      t23 = $[46];
    }
    let t24;
    if ($[47] !== t18 || $[48] !== t22 || $[49] !== t23) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: t16,
        accessibilityLabel: "Your first week",
        children: [t18, t22, t23]
      });
      $[47] = t18;
      $[48] = t22;
      $[49] = t23;
      $[50] = t24;
    } else {
      t24 = $[50];
    }
    return t24;
  }
  function _temp2(i) {
    return i.done;
  }
  function _temp(f) {
    return f.uid;
  }
  const styles = StyleSheet.default.create({
    track: {
      height: 6,
      borderRadius: 3,
      overflow: "hidden"
    },
    fill: {
      height: 6,
      borderRadius: 3
    },
    row: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      paddingVertical: 4
    },
    label: theme.default.type.body
  });
},875,[815,818,896,817,12,28,188,109,827,836,874,837,858,819,846,897,898,820,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return LadderPromotionHost;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _reactNativeAsyncStorageAsyncStorage = require(_dependencyMap[1]);
  var AsyncStorage = _interopDefault(_reactNativeAsyncStorageAsyncStorage);
  var _expoRouter = require(_dependencyMap[2]);
  var _react = require(_dependencyMap[3]);
  var _reactNativeWebDistExportsModal = require(_dependencyMap[4]);
  var Modal = _interopDefault(_reactNativeWebDistExportsModal);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[5]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[6]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[7]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxBurst = require(_dependencyMap[8]);
  var Burst = _interopDefault(_componentsFxBurst);
  var _componentsFxLightBeams = require(_dependencyMap[9]);
  var LightBeams = _interopDefault(_componentsFxLightBeams);
  var _componentsUi = require(_dependencyMap[10]);
  var _constantsTheme = require(_dependencyMap[11]);
  var theme = _interopDefault(_constantsTheme);
  var _contextAppContext = require(_dependencyMap[12]);
  var _hooksUseColors = require(_dependencyMap[13]);
  var _libCelebrate = require(_dependencyMap[14]);
  var _reactJsxRuntime = require(_dependencyMap[15]);
  const TIER_LABEL = {
    bronze: "Bronze",
    silver: "Silver",
    gold: "Gold",
    platinum: "Platinum",
    diamond: "Diamond"
  };
  const KEY = "sportdrip.ladderSeen.v1";

  /** Tier chip (links to the ladder) plus the "promotion" celebration, once per promotion. */
  function LadderPromotionHost() {
    const $ = (0, _reactCompilerRuntime.c)(45);
    const c = (0, _hooksUseColors.useColors)();
    const {
      profile
    } = (0, _contextAppContext.useApp)();
    const ladder = profile?.ladder;
    const [show, setShow] = (0, _react.useState)(false);
    let t0;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t0 = (0, _libCelebrate.celebrate)("promotion");
      $[0] = t0;
    } else {
      t0 = $[0];
    }
    const fx = t0;
    let t1;
    if ($[1] !== ladder || $[2] !== profile) {
      t1 = () => {
        if (ladder?.lastResult !== "promoted" || !ladder.week || !profile?.uid) {
          return;
        }
        const k = `${KEY}.${profile.uid}`;
        AsyncStorage.default.getItem(k).then(seen => {
          if (seen === ladder.week) {
            return;
          }
          setShow(true);
          return AsyncStorage.default.setItem(k, ladder.week);
        }).catch(_temp);
      };
      $[1] = ladder;
      $[2] = profile;
      $[3] = t1;
    } else {
      t1 = $[3];
    }
    const t2 = ladder?.lastResult;
    const t3 = ladder?.week;
    const t4 = profile?.uid;
    let t5;
    if ($[4] !== t2 || $[5] !== t3 || $[6] !== t4) {
      t5 = [t2, t3, t4];
      $[4] = t2;
      $[5] = t3;
      $[6] = t4;
      $[7] = t5;
    } else {
      t5 = $[7];
    }
    (0, _react.useEffect)(t1, t5);
    if (!ladder?.tier) {
      return null;
    }
    const label = TIER_LABEL[ladder.tier] ?? "Bronze";
    const t6 = `${label} ladder`;
    let t7;
    if ($[8] !== t6) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
        label: t6,
        icon: "stairs-up",
        tone: "accent",
        onPress: _temp2
      });
      $[8] = t6;
      $[9] = t7;
    } else {
      t7 = $[9];
    }
    let t8;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
      t8 = () => setShow(false);
      $[10] = t8;
    } else {
      t8 = $[10];
    }
    let t9;
    if ($[11] !== c.overlay) {
      t9 = [styles.scrim, {
        backgroundColor: c.overlay
      }];
      $[11] = c.overlay;
      $[12] = t9;
    } else {
      t9 = $[12];
    }
    let t10;
    if ($[13] !== c.primary) {
      t10 = fx.beams ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: StyleSheet.default.absoluteFill,
        pointerEvents: "none",
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(LightBeams.default, {
          color: c.primary,
          size: 520,
          beams: 16,
          opacity: 0.5
        })
      }) : null;
      $[13] = c.primary;
      $[14] = t10;
    } else {
      t10 = $[14];
    }
    let t11;
    if ($[15] !== c.accent || $[16] !== c.primary || $[17] !== c.warning) {
      t11 = fx.burst ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Burst.default, {
        colors: [c.primary, c.accent, c.warning, "#FFFFFF"],
        count: fx.burst.count,
        power: fx.burst.power,
        duration: fx.burst.duration,
        originY: 0.35
      }) : null;
      $[15] = c.accent;
      $[16] = c.primary;
      $[17] = c.warning;
      $[18] = t11;
    } else {
      t11 = $[18];
    }
    let t12;
    if ($[19] !== c.border || $[20] !== c.elevated) {
      t12 = [styles.card, {
        backgroundColor: c.elevated,
        borderColor: c.border
      }];
      $[19] = c.border;
      $[20] = c.elevated;
      $[21] = t12;
    } else {
      t12 = $[21];
    }
    let t13;
    if ($[22] !== c.primary) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.kicker, {
          color: c.primary
        }],
        children: "PROMOTED"
      });
      $[22] = c.primary;
      $[23] = t13;
    } else {
      t13 = $[23];
    }
    let t14;
    if ($[24] !== c.foreground) {
      t14 = [styles.big, {
        color: c.foreground
      }];
      $[24] = c.foreground;
      $[25] = t14;
    } else {
      t14 = $[25];
    }
    let t15;
    if ($[26] !== label || $[27] !== t14) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t14,
        children: label
      });
      $[26] = label;
      $[27] = t14;
      $[28] = t15;
    } else {
      t15 = $[28];
    }
    let t16;
    if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        label: "Nice",
        onPress: () => setShow(false)
      });
      $[29] = t16;
    } else {
      t16 = $[29];
    }
    let t17;
    if ($[30] !== t12 || $[31] !== t13 || $[32] !== t15) {
      t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        accessibilityViewIsModal: true,
        style: t12,
        children: [t13, t15, t16]
      });
      $[30] = t12;
      $[31] = t13;
      $[32] = t15;
      $[33] = t17;
    } else {
      t17 = $[33];
    }
    let t18;
    if ($[34] !== t10 || $[35] !== t11 || $[36] !== t17 || $[37] !== t9) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t9,
        children: [t10, t11, t17]
      });
      $[34] = t10;
      $[35] = t11;
      $[36] = t17;
      $[37] = t9;
      $[38] = t18;
    } else {
      t18 = $[38];
    }
    let t19;
    if ($[39] !== show || $[40] !== t18) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Modal.default, {
        visible: show,
        transparent: true,
        animationType: "fade",
        onRequestClose: t8,
        statusBarTranslucent: true,
        children: t18
      });
      $[39] = show;
      $[40] = t18;
      $[41] = t19;
    } else {
      t19 = $[41];
    }
    let t20;
    if ($[42] !== t19 || $[43] !== t7) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [t7, t19]
      });
      $[42] = t19;
      $[43] = t7;
      $[44] = t20;
    } else {
      t20 = $[44];
    }
    return t20;
  }
  function _temp2() {
    return _expoRouter.router.push("/ladder");
  }
  function _temp() {}
  const styles = StyleSheet.default.create({
    scrim: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
      padding: 24
    },
    card: {
      width: "100%",
      maxWidth: 320,
      borderWidth: 1,
      borderRadius: 24,
      padding: 24,
      gap: 10,
      alignItems: "center"
    },
    kicker: theme.default.type.overline,
    big: theme.default.type.display
  });
},876,[815,896,817,12,238,28,188,109,899,900,836,874,837,819,901,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      if (k === 'default') return;
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return QuestsCard;
    }
  });
  var _expoVectorIcons = require(_dependencyMap[0]);
  var _libAnalytics = require(_dependencyMap[1]);
  var _expoRouter = require(_dependencyMap[2]);
  var _componentsFxTap = require(_dependencyMap[3]);
  var _react = require(_dependencyMap[4]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[5]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[6]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[7]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsUi = require(_dependencyMap[8]);
  var _hooksUseColors = require(_dependencyMap[9]);
  var _libApi = require(_dependencyMap[10]);
  var api = _interopNamespace(_libApi);
  var _libDemo = require(_dependencyMap[11]);
  var _libMotion = require(_dependencyMap[12]);
  var _reactJsxRuntime = require(_dependencyMap[13]);
  const ICON = {
    endowed: "check-circle-outline",
    effort: "run-fast",
    social: "calendar-check",
    skill: "target"
  };

  /** This week's quests. Progress is computed on the server; rewards are XP. */
  function QuestsCard() {
    const c = (0, _hooksUseColors.useColors)();
    const focused = (0, _expoRouter.useIsFocused)();
    const [quests, setQuests] = (0, _react.useState)(null);
    const [busy, setBusy] = (0, _react.useState)(null);
    const load = (0, _react.useCallback)(() => {
      if (_libDemo.DEMO) return;
      api.getWeeklyQuests({}).then(r => setQuests(r.quests)).catch(() => {});
    }, []);
    (0, _react.useEffect)(() => {
      if (focused) load();
    }, [focused, load]);
    if (!quests?.length) return null;
    const done = quests.filter(q => q.progress >= q.target).length;
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
      style: {
        gap: 8
      },
      accessibilityLabel: "Weekly quests",
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.head,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "flag-checkered",
          size: 18,
          color: c.accent
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.title, {
            color: c.foreground,
            flex: 1
          }],
          children: "This Week"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.sub, {
            color: c.mutedForeground
          }],
          children: [done, "/", quests.length, " done"]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
          accessibilityRole: "button",
          accessibilityLabel: "Open the season pass",
          hitSlop: 8,
          onPress: () => _expoRouter.router.push("/season"),
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "chevron-right",
            size: 20,
            color: c.mutedForeground
          })
        })]
      }), quests.map(q_0 => {
        const complete = q_0.progress >= q_0.target;
        return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.row,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: complete ? "check-circle" : ICON[q_0.kind],
            size: 18,
            color: complete ? c.positive : c.mutedForeground
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: {
              flex: 1,
              gap: 3
            },
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.qt, {
                color: c.foreground
              }],
              children: q_0.title
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.track, {
                backgroundColor: c.secondary
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
                style: [styles.fill, {
                  width: `${q_0.progress / q_0.target * 100}%`,
                  backgroundColor: complete ? c.positive : c.accent
                }]
              })
            })]
          }), q_0.claimed ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.sub, {
              color: c.subtleForeground
            }],
            children: ["+", q_0.xp, " XP"]
          }) : complete ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
            label: `+${q_0.xp} XP`,
            chevron: false,
            disabled: busy === q_0.id,
            onPress: async () => {
              setBusy(q_0.id);
              try {
                await api.claimQuest({
                  questId: q_0.id
                });
                (0, _libAnalytics.trackEvent)("quest_claimed", {
                  quest_id: q_0.id
                });
                _libMotion.haptic.success();
                load();
              } catch {
                _libMotion.haptic.error();
              } finally {
                setBusy(null);
              }
            }
          }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.sub, {
              color: c.mutedForeground
            }],
            children: [q_0.progress, "/", q_0.target]
          })]
        }, q_0.id);
      })]
    });
  }
  const styles = StyleSheet.default.create({
    head: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    title: {
      fontSize: 15,
      fontFamily: "Inter_800ExtraBold"
    },
    sub: {
      fontSize: 12,
      fontFamily: "Inter_600SemiBold"
    },
    row: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10
    },
    qt: {
      fontSize: 13,
      fontFamily: "Inter_600SemiBold"
    },
    track: {
      height: 5,
      borderRadius: 3,
      overflow: "hidden"
    },
    fill: {
      height: 5,
      borderRadius: 3
    }
  });
},877,[818,897,817,827,12,28,188,109,836,819,863,902,820,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return RewardsCard;
    }
  });
  var _expoVectorIcons = require(_dependencyMap[0]);
  var _componentsStreakBanner = require(_dependencyMap[1]);
  var StreakBanner = _interopDefault(_componentsStreakBanner);
  var _react = require(_dependencyMap[2]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[3]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[4]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[5]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsAdsBonusVideoCard = require(_dependencyMap[6]);
  var BonusVideoCard = _interopDefault(_componentsAdsBonusVideoCard);
  var _componentsFxTap = require(_dependencyMap[7]);
  var _componentsPrizeBox = require(_dependencyMap[8]);
  var PrizeBox = _interopDefault(_componentsPrizeBox);
  var _componentsSpinWheel = require(_dependencyMap[9]);
  var SpinWheel = _interopDefault(_componentsSpinWheel);
  var _constantsPrizeTypes = require(_dependencyMap[10]);
  var _contextAdsContext = require(_dependencyMap[11]);
  var _contextAppContext = require(_dependencyMap[12]);
  var _hooksUseColors = require(_dependencyMap[13]);
  var _reactJsxRuntime = require(_dependencyMap[14]);
  /**
   * Home's prize boxes: start a timer, open a ready box (rattle → wheel), and
   * reset a claimed one, all in place. Credits are committed server-side
   * before the wheel turns; the wheel is presentation.
   */
  function RewardsCard() {
    const c = (0, _hooksUseColors.useColors)();
    const {
      profile,
      prizeBoxes,
      openBox,
      claimBox,
      resetBox,
      error
    } = (0, _contextAppContext.useApp)();
    const {
      breakpoint
    } = (0, _contextAdsContext.useAds)();
    const [spinning, setSpinning] = (0, _react.useState)(null);
    const [reward, setReward] = (0, _react.useState)(null);
    const [busy, setBusy] = (0, _react.useState)(null);
    const [charging, setCharging] = (0, _react.useState)(null);
    const [now, setNow] = (0, _react.useState)(Date.now());
    const [info, setInfo] = (0, _react.useState)(null);
    const showOdds = info === "odds";

    // Optimistic box states: a start or reset shows at once; each override
    // yields when the server snapshot reaches the same state, or rolls back.
    const [local, setLocal] = (0, _react.useState)({});
    const timers = (0, _react.useRef)({});
    const drop = (0, _react.useCallback)(tier => {
      clearTimeout(timers.current[tier]);
      setLocal(l => {
        if (!l[tier]) return l;
        const {
          [tier]: _x,
          ...rest
        } = l;
        return rest;
      });
    }, []);
    const assume = (0, _react.useCallback)((tier_0, next) => {
      setLocal(l_0 => ({
        ...l_0,
        [tier_0]: next
      }));
      clearTimeout(timers.current[tier_0]);
      timers.current[tier_0] = setTimeout(() => drop(tier_0), 15_000);
    }, [drop]);
    (0, _react.useEffect)(() => {
      for (const t of _constantsPrizeTypes.BOX_TIERS) if (local[t] && prizeBoxes[t].state === local[t].state) drop(t);
    }, [prizeBoxes, local, drop]);
    (0, _react.useEffect)(() => () => _constantsPrizeTypes.BOX_TIERS.forEach(t_0 => clearTimeout(timers.current[t_0])), []);
    const boxes = (0, _react.useMemo)(() => {
      const out = {
        ...prizeBoxes
      };
      for (const t_1 of _constantsPrizeTypes.BOX_TIERS) if (local[t_1]) out[t_1] = local[t_1];
      return out;
    }, [prizeBoxes, local]);

    // One 1s tick, only while something counts down.
    const anyWaiting = _constantsPrizeTypes.BOX_TIERS.some(t_2 => {
      const b = boxes[t_2];
      return b.state === "waiting" && (b.readyAt ?? 0) > Date.now();
    });
    (0, _react.useEffect)(() => {
      setNow(Date.now());
      if (!anyWaiting) return;
      const id = setInterval(() => setNow(Date.now()), 1000);
      return () => clearInterval(id);
    }, [anyWaiting]);
    const handleOpen = (0, _react.useCallback)(async tier_1 => {
      const t_3 = Date.now();
      assume(tier_1, {
        ...prizeBoxes[tier_1],
        state: "waiting",
        openedAt: t_3,
        readyAt: t_3 + _constantsPrizeTypes.BOX_DISPLAY[tier_1].waitHours * 3600_000,
        rewardCredits: null
      });
      setNow(t_3);
      if (!(await openBox(tier_1))) drop(tier_1);
    }, [openBox, prizeBoxes, assume, drop]);
    const handleReset = (0, _react.useCallback)(async tier_2 => {
      assume(tier_2, {
        ...prizeBoxes[tier_2],
        state: "idle",
        openedAt: null,
        readyAt: null,
        rewardCredits: null
      });
      await resetBox(tier_2);
    }, [resetBox, prizeBoxes, assume]);
    const handleClaim = (0, _react.useCallback)(async tier_3 => {
      setBusy(tier_3);
      setCharging(tier_3);
      setReward(null);
      const [credits] = await Promise.all([claimBox(tier_3), new Promise(r => setTimeout(r, _componentsPrizeBox.CHARGE_MS))]);
      setCharging(null);
      setReward(credits);
      setSpinning(tier_3);
      setBusy(null);
    }, [claimBox]);
    const closeWheel = (0, _react.useCallback)(async () => {
      const tier_4 = spinning;
      setSpinning(null);
      setReward(null);
      if (tier_4) {
        breakpoint("prize_claimed");
        await handleReset(tier_4);
      }
    }, [spinning, handleReset, breakpoint]);
    const streak = profile?.streak?.count ?? 0;
    const days = Math.min(7, streak);
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
      style: styles.wrap,
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(StreakBanner.default, {
        streak: profile?.streak,
        now: now,
        expanded: info === "streak",
        onPress: () => setInfo(v => v === "streak" ? null : "streak")
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.boxRow,
        children: _constantsPrizeTypes.BOX_TIERS.map(tier_5 => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PrizeBox.default, {
          display: _constantsPrizeTypes.BOX_DISPLAY[tier_5],
          state: boxes[tier_5],
          now: now,
          busy: busy === tier_5,
          charging: charging === tier_5,
          onOpen: () => handleOpen(tier_5),
          onClaim: () => handleClaim(tier_5),
          onReset: () => void handleReset(tier_5),
          bonus: days * (tier_5 === "gold" ? 15 : tier_5 === "silver" ? 10 : 5)
        }, tier_5))
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.metaRow,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
          accessibilityRole: "button",
          accessibilityState: {
            expanded: showOdds
          },
          onPress: () => setInfo(v_0 => v_0 === "odds" ? null : "odds"),
          style: [styles.pill, {
            backgroundColor: c.secondary,
            borderColor: c.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "information-outline",
            size: 13,
            color: c.mutedForeground
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.pillText, {
              color: c.mutedForeground
            }],
            children: "Odds"
          })]
        })
      }), info === "streak" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.odds, {
          backgroundColor: c.card,
          borderColor: c.border
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.oddsTier, {
            color: c.primary
          }],
          children: ["\uD83D\uDD25 ", streak > 0 ? `${streak}-day pick streak` : "Pick streaks", profile?.streak?.longest ? ` · best ${profile.streak.longest}` : ""]
        }), ["Your streak goes up by one for every day (ET) you place at least one bet. Miss a day and it resets.", `Every box you open pays a bonus on top: +5 Bronze, +10 Silver, +15 Gold per streak day, up to 7 days${streak > 0 ? ` — right now +${days * 5} / +${days * 10} / +${days * 15}` : ""}.`, `Every 7 days you bank a freeze 🧊 that covers one missed day${profile?.streak?.freezes ? " (you have one)" : ""}. No freeze? Make two bets the day after a miss to repair it.`].map((t_4, i) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.oddsText, {
            color: c.mutedForeground
          }],
          children: t_4
        }, i))]
      }) : null, showOdds ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.odds, {
          backgroundColor: c.card,
          borderColor: c.border
        }],
        children: [_constantsPrizeTypes.BOX_TIERS.map(tier_6 => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: {
            gap: 2
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.oddsTier, {
              color: _constantsPrizeTypes.BOX_DISPLAY[tier_6].color
            }],
            children: [_constantsPrizeTypes.BOX_DISPLAY[tier_6].label, " \xB7 ", _constantsPrizeTypes.BOX_DISPLAY[tier_6].waitHours, "h"]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.oddsText, {
              color: c.mutedForeground
            }],
            children: _constantsPrizeTypes.BOX_ODDS[tier_6].map(o => `${o.credits}: ${o.pct.toFixed(1)}%`).join("  ·  ")
          })]
        }, tier_6)), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.oddsText, {
            color: c.mutedForeground
          }],
          children: ["Timers run on our servers, even with the app closed. The top prize is guaranteed if you go ", _constantsPrizeTypes.BOX_PITY_AFTER - 1, " boxes of a tier without it. The result is decided before the wheel spins."]
        })]
      }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BonusVideoCard.default, {}), spinning ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(SpinWheel.default, {
        visible: true,
        tier: spinning,
        rewardCredits: reward,
        error: reward === null && !busy ? error : null,
        onClose: closeWheel
      }) : null]
    });
  }
  const styles = StyleSheet.default.create({
    wrap: {
      gap: 10
    },
    boxRow: {
      flexDirection: "row",
      gap: 8
    },
    metaRow: {
      flexDirection: "row",
      gap: 8,
      alignItems: "center"
    },
    pill: {
      flexDirection: "row",
      alignItems: "center",
      gap: 5,
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 999,
      borderWidth: 1,
      flexShrink: 1
    },
    pillText: {
      fontSize: 12,
      fontFamily: "Inter_600SemiBold",
      flexShrink: 1
    },
    odds: {
      borderWidth: 1,
      borderRadius: 14,
      padding: 12,
      gap: 8
    },
    oddsTier: {
      fontSize: 12,
      fontFamily: "Inter_700Bold"
    },
    oddsText: {
      fontSize: 12,
      fontFamily: "Inter_400Regular",
      lineHeight: 17
    }
  });
},878,[818,879,12,28,188,109,880,827,882,883,884,857,837,819,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return StreakBanner;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _expoLinearGradient = require(_dependencyMap[2]);
  require(_dependencyMap[3]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _reactNativeReanimated = require(_dependencyMap[7]);
  var Animated = _interopDefault(_reactNativeReanimated);
  var _componentsFxPressableScale = require(_dependencyMap[8]);
  var PressableScale = _interopDefault(_componentsFxPressableScale);
  var _hooksUseColors = require(_dependencyMap[9]);
  var _hooksUseMotion = require(_dependencyMap[10]);
  var _libStreakGrid = require(_dependencyMap[11]);
  var _reactJsxRuntime = require(_dependencyMap[12]);
  const FIRE = "#FF7A1A";
  const MAX_DAYS = 7;

  /**
   * The streak bonus, front and centre above the prize boxes: a living flame
   * with the day count, the bonus every box pays right now, progress to the
   * max (7 days) and whether today already counts.
   */
  const _worklet_8115233145398_init_data = {
    code: "(function StreakBannerTsx1(){const[interpolate,flame]=this.__closure;return{transform:[{scale:interpolate(flame.value,[0,1],[1,1.14])},{rotate:interpolate(flame.value,[0,1],[-4,4])+\"deg\"}]};})"
  };
  function StreakBanner(t0) {
    const $ = (0, _reactCompilerRuntime.c)(87);
    const {
      streak,
      now,
      expanded,
      onPress
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const count = streak?.count ?? 0;
    const days = Math.min(MAX_DAYS, count);
    let t1;
    if ($[0] !== now) {
      t1 = (0, _libStreakGrid.nyDayOf)(now);
      $[0] = now;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    const today = t1;
    const doneToday = streak?.lastDay === today;
    const alive = count > 0;
    const flame = (0, _hooksUseMotion.useBreathe)(alive, doneToday ? 2400 : 1200);
    const flameStyle = (0, _reactNativeReanimated.useAnimatedStyle)(function StreakBannerTsx1Factory([_worklet_8115233145398_init_data, interpolate, flame]) {
      const StreakBannerTsx1 = function () {
        "use no memo";

        return {
          transform: [{
            scale: interpolate(flame.value, [0, 1], [1, 1.14])
          }, {
            rotate: `${interpolate(flame.value, [0, 1], [-4, 4])}deg`
          }]
        };
      };
      StreakBannerTsx1.__closure = [interpolate, flame];
      StreakBannerTsx1.__workletHash = 8115233145398;
      StreakBannerTsx1.__initData = _worklet_8115233145398_init_data;
      return StreakBannerTsx1;
    }([_worklet_8115233145398_init_data, _reactNativeReanimated.interpolate, flame]));
    const next = Math.min(MAX_DAYS, days + 1);
    const t2 = `${count}-day streak. Bonus on every box: ${days * 5}, ${days * 10} and ${days * 15} credits. ${doneToday ? "Today counted." : "Bet today to keep it."} Tap for details.`;
    let t3;
    if ($[2] !== expanded) {
      t3 = {
        expanded
      };
      $[2] = expanded;
      $[3] = t3;
    } else {
      t3 = $[3];
    }
    const t4 = alive ? FIRE : c.border;
    let t5;
    if ($[4] !== t4) {
      t5 = [styles.card, {
        borderColor: t4
      }];
      $[4] = t4;
      $[5] = t5;
    } else {
      t5 = $[5];
    }
    let t6;
    if ($[6] !== alive || $[7] !== c) {
      t6 = alive ? ["rgba(255,122,26,0.30)", "rgba(255,60,60,0.10)"] : [c.alpha(c.foreground, 0.05), c.alpha(c.foreground, 0.02)];
      $[6] = alive;
      $[7] = c;
      $[8] = t6;
    } else {
      t6 = $[8];
    }
    let t7;
    let t8;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
      t7 = {
        x: 0,
        y: 0
      };
      t8 = {
        x: 1,
        y: 1
      };
      $[9] = t7;
      $[10] = t8;
    } else {
      t7 = $[9];
      t8 = $[10];
    }
    let t9;
    if ($[11] !== t6) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoLinearGradient.LinearGradient, {
        colors: t6,
        start: t7,
        end: t8,
        style: StyleSheet.default.absoluteFill
      });
      $[11] = t6;
      $[12] = t9;
    } else {
      t9 = $[12];
    }
    const t10 = alive ? FIRE : c.subtleForeground;
    let t11;
    if ($[13] !== t10) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "fire",
        size: 46,
        color: t10
      });
      $[13] = t10;
      $[14] = t11;
    } else {
      t11 = $[14];
    }
    let t12;
    if ($[15] !== flameStyle || $[16] !== t11) {
      t12 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Animated.default.View, {
        style: flameStyle,
        children: t11
      });
      $[15] = flameStyle;
      $[16] = t11;
      $[17] = t12;
    } else {
      t12 = $[17];
    }
    const t13 = alive ? "#fff" : c.mutedForeground;
    let t14;
    if ($[18] !== t13) {
      t14 = [styles.count, {
        color: t13
      }];
      $[18] = t13;
      $[19] = t14;
    } else {
      t14 = $[19];
    }
    let t15;
    if ($[20] !== count || $[21] !== t14) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t14,
        children: count
      });
      $[20] = count;
      $[21] = t14;
      $[22] = t15;
    } else {
      t15 = $[22];
    }
    let t16;
    if ($[23] !== t12 || $[24] !== t15) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.flameWrap,
        children: [t12, t15]
      });
      $[23] = t12;
      $[24] = t15;
      $[25] = t16;
    } else {
      t16 = $[25];
    }
    let t17;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
      t17 = {
        flex: 1,
        gap: 4
      };
      $[26] = t17;
    } else {
      t17 = $[26];
    }
    let t18;
    if ($[27] !== c.foreground) {
      t18 = [styles.title, {
        color: c.foreground
      }];
      $[27] = c.foreground;
      $[28] = t18;
    } else {
      t18 = $[28];
    }
    const t19 = alive ? `${count}-Day Streak` : "Start a Streak";
    let t20;
    if ($[29] !== t18 || $[30] !== t19) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t18,
        numberOfLines: 1,
        children: t19
      });
      $[29] = t18;
      $[30] = t19;
      $[31] = t20;
    } else {
      t20 = $[31];
    }
    let t21;
    if ($[32] !== c || $[33] !== doneToday) {
      t21 = doneToday ? c.alpha(c.positive, 0.18) : c.alpha(FIRE, 0.18);
      $[32] = c;
      $[33] = doneToday;
      $[34] = t21;
    } else {
      t21 = $[34];
    }
    const t22 = doneToday ? c.positive : FIRE;
    let t23;
    if ($[35] !== t21 || $[36] !== t22) {
      t23 = [styles.today, {
        backgroundColor: t21,
        borderColor: t22
      }];
      $[35] = t21;
      $[36] = t22;
      $[37] = t23;
    } else {
      t23 = $[37];
    }
    const t24 = doneToday ? "check" : "alert-circle-outline";
    const t25 = doneToday ? c.positive : FIRE;
    let t26;
    if ($[38] !== t24 || $[39] !== t25) {
      t26 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: t24,
        size: 11,
        color: t25
      });
      $[38] = t24;
      $[39] = t25;
      $[40] = t26;
    } else {
      t26 = $[40];
    }
    const t27 = doneToday ? c.positive : FIRE;
    let t28;
    if ($[41] !== t27) {
      t28 = [styles.todayText, {
        color: t27
      }];
      $[41] = t27;
      $[42] = t28;
    } else {
      t28 = $[42];
    }
    const t29 = doneToday ? "TODAY \u2713" : alive ? "BET TODAY" : "BET TO START";
    let t30;
    if ($[43] !== t28 || $[44] !== t29) {
      t30 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t28,
        children: t29
      });
      $[43] = t28;
      $[44] = t29;
      $[45] = t30;
    } else {
      t30 = $[45];
    }
    let t31;
    if ($[46] !== t23 || $[47] !== t26 || $[48] !== t30) {
      t31 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t23,
        children: [t26, t30]
      });
      $[46] = t23;
      $[47] = t26;
      $[48] = t30;
      $[49] = t31;
    } else {
      t31 = $[49];
    }
    let t32;
    if ($[50] !== t20 || $[51] !== t31) {
      t32 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.row,
        children: [t20, t31]
      });
      $[50] = t20;
      $[51] = t31;
      $[52] = t32;
    } else {
      t32 = $[52];
    }
    let t33;
    if ($[53] !== c.foreground) {
      t33 = [styles.bonus, {
        color: c.foreground
      }];
      $[53] = c.foreground;
      $[54] = t33;
    } else {
      t33 = $[54];
    }
    let t34;
    if ($[55] !== alive || $[56] !== days) {
      t34 = alive ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: {
            color: FIRE
          },
          children: ["+", days * 5, " / +", days * 10, " / +", days * 15]
        }), " bonus on every box"]
      }) : "Bet on back-to-back days for bonus credits on every box";
      $[55] = alive;
      $[56] = days;
      $[57] = t34;
    } else {
      t34 = $[57];
    }
    let t35;
    if ($[58] !== t33 || $[59] !== t34) {
      t35 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t33,
        children: t34
      });
      $[58] = t33;
      $[59] = t34;
      $[60] = t35;
    } else {
      t35 = $[60];
    }
    let t36;
    if ($[61] !== c || $[62] !== days) {
      t36 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.pips,
        children: Array.from({
          length: MAX_DAYS
        }, (_, i) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [styles.pip, {
            backgroundColor: i < days ? FIRE : c.alpha(c.foreground, 0.12)
          }]
        }, i))
      });
      $[61] = c;
      $[62] = days;
      $[63] = t36;
    } else {
      t36 = $[63];
    }
    let t37;
    if ($[64] !== c.mutedForeground) {
      t37 = [styles.hint, {
        color: c.mutedForeground
      }];
      $[64] = c.mutedForeground;
      $[65] = t37;
    } else {
      t37 = $[65];
    }
    const t38 = days >= MAX_DAYS ? `Max bonus unlocked${streak?.freezes ? " \xB7 \uD83E\uDDCA freeze banked" : ""}` : `Day ${next}: +${next * 5} / +${next * 10} / +${next * 15} · max at ${MAX_DAYS} days`;
    let t39;
    if ($[66] !== t37 || $[67] !== t38) {
      t39 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t37,
        numberOfLines: 1,
        children: t38
      });
      $[66] = t37;
      $[67] = t38;
      $[68] = t39;
    } else {
      t39 = $[68];
    }
    let t40;
    if ($[69] !== t32 || $[70] !== t35 || $[71] !== t36 || $[72] !== t39) {
      t40 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t17,
        children: [t32, t35, t36, t39]
      });
      $[69] = t32;
      $[70] = t35;
      $[71] = t36;
      $[72] = t39;
      $[73] = t40;
    } else {
      t40 = $[73];
    }
    const t41 = expanded ? "chevron-up" : "information-outline";
    let t42;
    if ($[74] === Symbol.for("react.memo_cache_sentinel")) {
      t42 = {
        alignSelf: "flex-start"
      };
      $[74] = t42;
    } else {
      t42 = $[74];
    }
    let t43;
    if ($[75] !== c.mutedForeground || $[76] !== t41) {
      t43 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: t41,
        size: 16,
        color: c.mutedForeground,
        style: t42
      });
      $[75] = c.mutedForeground;
      $[76] = t41;
      $[77] = t43;
    } else {
      t43 = $[77];
    }
    let t44;
    if ($[78] !== onPress || $[79] !== t16 || $[80] !== t2 || $[81] !== t3 || $[82] !== t40 || $[83] !== t43 || $[84] !== t5 || $[85] !== t9) {
      t44 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(PressableScale.default, {
        accessibilityRole: "button",
        accessibilityLabel: t2,
        accessibilityState: t3,
        onPress: onPress,
        style: t5,
        children: [t9, t16, t40, t43]
      });
      $[78] = onPress;
      $[79] = t16;
      $[80] = t2;
      $[81] = t3;
      $[82] = t40;
      $[83] = t43;
      $[84] = t5;
      $[85] = t9;
      $[86] = t44;
    } else {
      t44 = $[86];
    }
    return t44;
  }
  const styles = StyleSheet.default.create({
    card: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      borderRadius: 18,
      borderWidth: 1.5,
      padding: 12,
      overflow: "hidden"
    },
    flameWrap: {
      width: 56,
      height: 56,
      alignItems: "center",
      justifyContent: "center"
    },
    count: {
      position: "absolute",
      bottom: 8,
      fontSize: 17,
      fontFamily: "Inter_900Black",
      textShadowColor: "rgba(0,0,0,0.5)",
      textShadowRadius: 3
    },
    row: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    title: {
      flex: 1,
      fontSize: 16,
      fontFamily: "Inter_900Black"
    },
    today: {
      flexDirection: "row",
      alignItems: "center",
      gap: 3,
      paddingHorizontal: 7,
      paddingVertical: 3,
      borderRadius: 999,
      borderWidth: 1
    },
    todayText: {
      fontSize: 10,
      letterSpacing: 0.6,
      fontFamily: "Inter_800ExtraBold"
    },
    bonus: {
      fontSize: 13,
      fontFamily: "Inter_700Bold"
    },
    pips: {
      flexDirection: "row",
      gap: 4
    },
    pip: {
      flex: 1,
      height: 6,
      borderRadius: 3
    },
    hint: {
      fontSize: 11,
      fontFamily: "Inter_500Medium"
    }
  });
},879,[815,818,871,12,28,188,109,867,868,819,869,903,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return BonusVideoCard;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _libMotion = require(_dependencyMap[2]);
  var _react = require(_dependencyMap[3]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsUi = require(_dependencyMap[7]);
  var _constantsAds = require(_dependencyMap[8]);
  var _contextAdsContext = require(_dependencyMap[9]);
  var _contextAppContext = require(_dependencyMap[10]);
  var _hooksUseAdRewardsToday = require(_dependencyMap[11]);
  var _hooksUseColors = require(_dependencyMap[12]);
  var _libAdsSdk = require(_dependencyMap[13]);
  var sdk = _interopDefault(_libAdsSdk);
  var _reactJsxRuntime = require(_dependencyMap[14]);
  /**
   * Opt-in rewarded video on the Prize Boxes screen: watch to the end for bonus
   * credits, a few times a day. The video's "earned" event only changes what this
   * card says — the credits are minted by the AdMob SSV callback on the server,
   * and the card confirms once that write shows up in Firestore.
   */
  function BonusVideoCard() {
    const $ = (0, _reactCompilerRuntime.c)(1);
    const {
      enabled
    } = (0, _contextAdsContext.useAds)();
    if (!sdk.default || !enabled) {
      return null;
    }
    let t0;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t0 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BonusVideo, {});
      $[0] = t0;
    } else {
      t0 = $[0];
    }
    return t0;
  }
  const CONFIRM_TIMEOUT_MS = 20_000;
  function BonusVideo() {
    const $ = (0, _reactCompilerRuntime.c)(58);
    const c = (0, _hooksUseColors.useColors)();
    const {
      profile
    } = (0, _contextAppContext.useApp)();
    const {
      rewardedStatus,
      loadRewarded,
      showRewarded
    } = (0, _contextAdsContext.useAds)();
    const used = (0, _hooksUseAdRewardsToday.useAdRewardsToday)(profile?.uid);
    const left = Math.max(0, _constantsAds.AD_REWARD_DISPLAY.dailyLimit - (used ?? 0));
    const [crediting, setCrediting] = (0, _react.useState)(null);
    const [note, setNote] = (0, _react.useState)(null);
    let t0;
    let t1;
    if ($[0] !== left || $[1] !== loadRewarded || $[2] !== rewardedStatus || $[3] !== used) {
      t0 = () => {
        if (used !== null && left > 0 && rewardedStatus === "idle") {
          loadRewarded();
        }
      };
      t1 = [used, left, rewardedStatus, loadRewarded];
      $[0] = left;
      $[1] = loadRewarded;
      $[2] = rewardedStatus;
      $[3] = used;
      $[4] = t0;
      $[5] = t1;
    } else {
      t0 = $[4];
      t1 = $[5];
    }
    (0, _react.useEffect)(t0, t1);
    let t2;
    let t3;
    if ($[6] !== crediting || $[7] !== used) {
      t2 = () => {
        if (crediting === null || used === null || used <= crediting) {
          return;
        }
        setCrediting(null);
        setNote({
          text: `+${_constantsAds.AD_REWARD_DISPLAY.credits} credits added`,
          tone: "ok"
        });
        _libMotion.haptic.success();
      };
      t3 = [used, crediting];
      $[6] = crediting;
      $[7] = used;
      $[8] = t2;
      $[9] = t3;
    } else {
      t2 = $[8];
      t3 = $[9];
    }
    (0, _react.useEffect)(t2, t3);
    let t4;
    let t5;
    if ($[10] !== crediting) {
      t4 = () => {
        if (crediting === null) {
          return;
        }
        const t = setTimeout(() => {
          setCrediting(null);
          setNote({
            text: "Still confirming with the ad network \u2014 your credits will land shortly.",
            tone: "info"
          });
        }, CONFIRM_TIMEOUT_MS);
        return () => clearTimeout(t);
      };
      t5 = [crediting];
      $[10] = crediting;
      $[11] = t4;
      $[12] = t5;
    } else {
      t4 = $[11];
      t5 = $[12];
    }
    (0, _react.useEffect)(t4, t5);
    let t6;
    if ($[13] !== showRewarded || $[14] !== used) {
      t6 = async () => {
        setNote(null);
        const before = used ?? 0;
        const outcome = await showRewarded();
        if (outcome === "earned") {
          setCrediting(before);
        } else {
          if (outcome === "dismissed") {
            setNote({
              text: "Watch to the end to earn the bonus.",
              tone: "info"
            });
          } else {
            setNote({
              text: "No video available right now. Try again in a bit.",
              tone: "info"
            });
          }
        }
      };
      $[13] = showRewarded;
      $[14] = used;
      $[15] = t6;
    } else {
      t6 = $[15];
    }
    const watch = t6;
    const done = left === 0 && crediting === null;
    let t7;
    if ($[16] !== crediting || $[17] !== done || $[18] !== loadRewarded || $[19] !== rewardedStatus || $[20] !== watch) {
      t7 = done ? {
        label: "Back Tomorrow",
        disabled: true,
        loading: false,
        onPress: undefined
      } : crediting !== null ? {
        label: "Adding credits\u2026",
        disabled: true,
        loading: true,
        onPress: undefined
      } : rewardedStatus === "ready" ? {
        label: `Watch · +${_constantsAds.AD_REWARD_DISPLAY.credits}`,
        disabled: false,
        loading: false,
        onPress: watch
      } : rewardedStatus === "unavailable" ? {
        label: "Try Again",
        disabled: false,
        loading: false,
        onPress: loadRewarded
      } : {
        label: "Loading video\u2026",
        disabled: true,
        loading: rewardedStatus !== "showing",
        onPress: undefined
      };
      $[16] = crediting;
      $[17] = done;
      $[18] = loadRewarded;
      $[19] = rewardedStatus;
      $[20] = watch;
      $[21] = t7;
    } else {
      t7 = $[21];
    }
    const button = t7;
    let t8;
    if ($[22] !== c.primarySoft) {
      t8 = [styles.icon, {
        backgroundColor: c.primarySoft
      }];
      $[22] = c.primarySoft;
      $[23] = t8;
    } else {
      t8 = $[23];
    }
    let t9;
    if ($[24] !== c.primary) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "play-circle-outline",
        size: 22,
        color: c.primary
      });
      $[24] = c.primary;
      $[25] = t9;
    } else {
      t9 = $[25];
    }
    let t10;
    if ($[26] !== t8 || $[27] !== t9) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t8,
        children: t9
      });
      $[26] = t8;
      $[27] = t9;
      $[28] = t10;
    } else {
      t10 = $[28];
    }
    let t11;
    if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
      t11 = {
        flex: 1
      };
      $[29] = t11;
    } else {
      t11 = $[29];
    }
    let t12;
    if ($[30] !== c.foreground) {
      t12 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.title, {
          color: c.foreground
        }],
        children: "Bonus Credits"
      });
      $[30] = c.foreground;
      $[31] = t12;
    } else {
      t12 = $[31];
    }
    let t13;
    if ($[32] !== c.mutedForeground) {
      t13 = [styles.sub, {
        color: c.mutedForeground
      }];
      $[32] = c.mutedForeground;
      $[33] = t13;
    } else {
      t13 = $[33];
    }
    const t14 = done ? "You've watched today's bonus videos." : `Watch a short video for +${_constantsAds.AD_REWARD_DISPLAY.credits} credits · ${left} of ${_constantsAds.AD_REWARD_DISPLAY.dailyLimit} left today`;
    let t15;
    if ($[34] !== t13 || $[35] !== t14) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t13,
        children: t14
      });
      $[34] = t13;
      $[35] = t14;
      $[36] = t15;
    } else {
      t15 = $[36];
    }
    let t16;
    if ($[37] !== t12 || $[38] !== t15) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t11,
        children: [t12, t15]
      });
      $[37] = t12;
      $[38] = t15;
      $[39] = t16;
    } else {
      t16 = $[39];
    }
    let t17;
    if ($[40] !== t10 || $[41] !== t16) {
      t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.row,
        children: [t10, t16]
      });
      $[40] = t10;
      $[41] = t16;
      $[42] = t17;
    } else {
      t17 = $[42];
    }
    const t18 = done ? "check" : "play";
    const t19 = done ? "secondary" : "primary";
    let t20;
    if ($[43] !== button.disabled || $[44] !== button.label || $[45] !== button.loading || $[46] !== button.onPress || $[47] !== t18 || $[48] !== t19) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        label: button.label,
        icon: t18,
        size: "sm",
        variant: t19,
        disabled: button.disabled,
        loading: button.loading,
        onPress: button.onPress
      });
      $[43] = button.disabled;
      $[44] = button.label;
      $[45] = button.loading;
      $[46] = button.onPress;
      $[47] = t18;
      $[48] = t19;
      $[49] = t20;
    } else {
      t20 = $[49];
    }
    let t21;
    if ($[50] !== c.mutedForeground || $[51] !== c.positive || $[52] !== note) {
      t21 = note ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.note, {
          color: note.tone === "ok" ? c.positive : c.mutedForeground
        }],
        children: note.text
      }) : null;
      $[50] = c.mutedForeground;
      $[51] = c.positive;
      $[52] = note;
      $[53] = t21;
    } else {
      t21 = $[53];
    }
    let t22;
    if ($[54] !== t17 || $[55] !== t20 || $[56] !== t21) {
      t22 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        tone: "money",
        style: styles.card,
        children: [t17, t20, t21]
      });
      $[54] = t17;
      $[55] = t20;
      $[56] = t21;
      $[57] = t22;
    } else {
      t22 = $[57];
    }
    return t22;
  }
  const styles = StyleSheet.default.create({
    card: {
      gap: 12,
      padding: 16,
      borderRadius: 16
    },
    row: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12
    },
    icon: {
      width: 40,
      height: 40,
      borderRadius: 12,
      alignItems: "center",
      justifyContent: "center"
    },
    title: {
      fontSize: 15,
      fontFamily: "Inter_700Bold"
    },
    sub: {
      fontSize: 12,
      fontFamily: "Inter_400Regular",
      marginTop: 2,
      lineHeight: 17
    },
    note: {
      fontSize: 12,
      fontFamily: "Inter_500Medium",
      textAlign: "center"
    }
  });
},880,[815,818,820,12,28,188,109,836,856,857,837,881,819,904,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.useAdRewardsToday = useAdRewardsToday;
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _firebaseFirestore = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  var _libFirebase = require(_dependencyMap[3]);
  const utcDay = () => new Date().toISOString().slice(0, 10);

  /**
   * Bonus videos credited today (UTC), from users/{uid}/private/ads — written
   * only by the AdMob SSV callback. null until the first snapshot.
   */
  function useAdRewardsToday(uid) {
    const $ = (0, _reactCompilerRuntime.c)(6);
    const [state, setState] = (0, _react.useState)(null);
    let t0;
    let t1;
    if ($[0] !== uid) {
      t0 = () => {
        const db = (0, _libFirebase.getDb)();
        if (!db || !uid) {
          setState({
            day: utcDay(),
            count: 0
          });
          return;
        }
        return (0, _firebaseFirestore.onSnapshot)((0, _firebaseFirestore.doc)(db, "users", uid, "private", "ads"), snap => {
          const d = snap.data();
          setState({
            day: d?.day ?? "",
            count: d?.count ?? 0
          });
        }, () => setState({
          day: utcDay(),
          count: 0
        }));
      };
      t1 = [uid];
      $[0] = uid;
      $[1] = t0;
      $[2] = t1;
    } else {
      t0 = $[1];
      t1 = $[2];
    }
    (0, _react.useEffect)(t0, t1);
    if (!state) {
      return null;
    }
    let t2;
    if ($[3] !== state.count || $[4] !== state.day) {
      t2 = state.day === utcDay() ? state.count : 0;
      $[3] = state.count;
      $[4] = state.day;
      $[5] = t2;
    } else {
      t2 = $[5];
    }
    return t2;
  }
},881,[815,905,12,906]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return PrizeBox;
    }
  });
  Object.defineProperty(exports, "CHARGE_MS", {
    enumerable: true,
    get: function () {
      return CHARGE_MS;
    }
  });
  var _expoVectorIcons = require(_dependencyMap[0]);
  var _react = require(_dependencyMap[1]);
  var _reactNativeWebDistExportsActivityIndicator = require(_dependencyMap[2]);
  var ActivityIndicator = _interopDefault(_reactNativeWebDistExportsActivityIndicator);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[3]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[4]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[5]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _reactNativeReanimated = require(_dependencyMap[6]);
  var Animated = _interopDefault(_reactNativeReanimated);
  var _componentsFxPressableScale = require(_dependencyMap[7]);
  var PressableScale = _interopDefault(_componentsFxPressableScale);
  var _componentsFxShimmer = require(_dependencyMap[8]);
  var Shimmer = _interopDefault(_componentsFxShimmer);
  var _hooksUseColors = require(_dependencyMap[9]);
  var _hooksUseMotion = require(_dependencyMap[10]);
  var _libMotion = require(_dependencyMap[11]);
  var _reactJsxRuntime = require(_dependencyMap[12]);
  /** How long the box rattles before it bursts open (the claim runs underneath). */
  const CHARGE_MS = 1300;
  function countdown(ms) {
    if (ms <= 0) return "Ready";
    const secs = Math.floor(ms / 1000);
    const h = Math.floor(secs / 3600);
    const m = Math.floor(secs % 3600 / 60);
    const s = secs % 60;
    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
  }

  /**
   * One prize box, driven by server state (idle → waiting → ready → claimed).
   *
   * The tick is hoisted to the parent (one timer for the screen, only while
   * something counts down). On top of that, motion:
   *  - idle and ready boxes float and breathe; a ready one glows and its
   *    button glints, so it reads as "open me" from across the screen
   *  - opening it rattles the box harder and harder with escalating haptic
   *    ticks while the claim is committed server-side, then hands over to the
   *    wheel
   */
  const _worklet_4074058780791_init_data = {
    code: "(function PrizeBoxTsx1(f){const[phase,charge]=this.__closure;var _f$timeSincePreviousF;phase.value+=((_f$timeSincePreviousF=f.timeSincePreviousFrame)!==null&&_f$timeSincePreviousF!==void 0?_f$timeSincePreviousF:16)*(0.045+0.06*charge.value);})"
  };
  const _worklet_12102184867203_init_data = {
    code: "(function PrizeBoxTsx2(){const[charge,breathe,phase]=this.__closure;const amp=2+11*charge.value;return{transform:[{translateY:-5*breathe.value},{translateX:Math.sin(phase.value*1.7)*amp*0.35*charge.value},{rotate:Math.sin(phase.value)*amp*(charge.value>0.01?1:0)+\"deg\"},{scale:1+0.035*breathe.value+0.12*charge.value}]};})"
  };
  const _worklet_3599932708802_init_data = {
    code: "(function PrizeBoxTsx3(){const[ready,breathe,charge]=this.__closure;return{opacity:ready?0.25+0.4*breathe.value+0.35*charge.value:0.08+0.1*breathe.value,transform:[{scale:0.9+0.25*breathe.value+0.5*charge.value}]};})"
  };
  function PrizeBox({
    display,
    state,
    now,
    busy,
    charging = false,
    onOpen,
    onClaim,
    onReset,
    bonus = 0
  }) {
    const colors = (0, _hooksUseColors.useColors)();
    const reduced = (0, _reactNativeReanimated.useReducedMotion)();
    const readyAt = state.readyAt ?? 0;
    const waiting = state.state === "waiting" && now < readyAt;
    const ready = (state.state === "waiting" || state.state === "ready") && now >= readyAt;
    const claimed = state.state === "claimed";
    const idle = state.state === "idle";
    const breathe = (0, _hooksUseMotion.useBreathe)((idle || ready) && !charging, ready ? 1600 : 2600);

    // Rattle: amplitude grows over CHARGE_MS, driven per frame on the UI thread.
    const charge = (0, _reactNativeReanimated.useSharedValue)(0);
    const phase = (0, _reactNativeReanimated.useSharedValue)(0);
    const rattle = (0, _reactNativeReanimated.useFrameCallback)(function PrizeBoxTsx1Factory([_worklet_4074058780791_init_data, phase, charge]) {
      const PrizeBoxTsx1 = function (f) {
        "use no memo";

        phase.value += (f.timeSincePreviousFrame ?? 16) * (0.045 + 0.06 * charge.value);
      };
      PrizeBoxTsx1.__closure = [phase, charge];
      PrizeBoxTsx1.__workletHash = 4074058780791;
      PrizeBoxTsx1.__initData = _worklet_4074058780791_init_data;
      return PrizeBoxTsx1;
    }([_worklet_4074058780791_init_data, phase, charge]), false);
    (0, _react.useEffect)(() => {
      if (!charging || reduced) {
        rattle.setActive(false);
        (0, _reactNativeReanimated.cancelAnimation)(charge);
        charge.value = (0, _reactNativeReanimated.withTiming)(0, {
          duration: 150
        });
        return;
      }
      charge.value = 0;
      charge.value = (0, _reactNativeReanimated.withTiming)(1, {
        duration: CHARGE_MS,
        easing: _reactNativeReanimated.Easing.in(_reactNativeReanimated.Easing.quad)
      });
      rattle.setActive(true);
      // Haptic ticks that speed up and hit harder as the box is about to pop.
      let t = 0;
      let timer;
      const step = () => {
        const k = Math.min(1, t / CHARGE_MS);
        (k > 0.75 ? _libMotion.haptic.heavy : k > 0.4 ? _libMotion.haptic.medium : _libMotion.haptic.light)();
        const gap = 210 - 160 * k;
        t += gap;
        if (t < 1700) timer = setTimeout(step, gap);
      };
      step();
      return () => {
        clearTimeout(timer);
        rattle.setActive(false);
      };
    }, [charging, reduced, charge, rattle]);
    const iconStyle = (0, _reactNativeReanimated.useAnimatedStyle)(function PrizeBoxTsx2Factory([_worklet_12102184867203_init_data, charge, breathe, phase]) {
      const PrizeBoxTsx2 = function () {
        "use no memo";

        const amp = 2 + 11 * charge.value;
        return {
          transform: [{
            translateY: -5 * breathe.value
          }, {
            translateX: Math.sin(phase.value * 1.7) * amp * 0.35 * charge.value
          }, {
            rotate: `${Math.sin(phase.value) * amp * (charge.value > 0.01 ? 1 : 0)}deg`
          }, {
            scale: 1 + 0.035 * breathe.value + 0.12 * charge.value
          }]
        };
      };
      PrizeBoxTsx2.__closure = [charge, breathe, phase];
      PrizeBoxTsx2.__workletHash = 12102184867203;
      PrizeBoxTsx2.__initData = _worklet_12102184867203_init_data;
      return PrizeBoxTsx2;
    }([_worklet_12102184867203_init_data, charge, breathe, phase]));
    const glowStyle = (0, _reactNativeReanimated.useAnimatedStyle)(function PrizeBoxTsx3Factory([_worklet_3599932708802_init_data, ready, breathe, charge]) {
      const PrizeBoxTsx3 = function () {
        "use no memo";

        return {
          opacity: ready ? 0.25 + 0.4 * breathe.value + 0.35 * charge.value : 0.08 + 0.1 * breathe.value,
          transform: [{
            scale: 0.9 + 0.25 * breathe.value + 0.5 * charge.value
          }]
        };
      };
      PrizeBoxTsx3.__closure = [ready, breathe, charge];
      PrizeBoxTsx3.__workletHash = 3599932708802;
      PrizeBoxTsx3.__initData = _worklet_3599932708802_init_data;
      return PrizeBoxTsx3;
    }([_worklet_3599932708802_init_data, ready, breathe, charge]));
    function press() {
      if (busy || charging) return;
      _libMotion.haptic.medium();
      if (idle) onOpen();else if (ready) onClaim();else if (claimed) onReset();
    }
    const actionLabel = charging ? "Opening…" : ready ? "Open!" : waiting ? "Waiting" : claimed ? "Open again" : "Start timer";
    const min = Math.min(...display.segments.map(s => s.credits));
    const max = Math.max(...display.segments.map(s_0 => s_0.credits));
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
      style: [styles.card, {
        backgroundColor: colors.card,
        borderColor: ready || charging ? display.color : colors.border,
        borderWidth: ready ? 2 : 1,
        shadowColor: display.glowColor,
        shadowOpacity: ready ? 0.45 : 0
      }],
      children: [ready && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [styles.glowBar, {
          backgroundColor: display.glowColor
        }]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.iconArea,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Animated.default.View, {
          pointerEvents: "none",
          style: [styles.halo, {
            backgroundColor: display.glowColor
          }, glowStyle]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Animated.default.View, {
          style: [styles.iconWrap, {
            backgroundColor: display.color + "22",
            borderColor: display.color + "77"
          }, iconStyle],
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: styles.emoji,
            children: display.emoji
          })
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.tier, {
          color: display.color
        }],
        children: display.label
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.range, {
          color: colors.mutedForeground
        }],
        children: [min.toLocaleString(), "\u2013", max.toLocaleString(), " credits"]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.wait, {
          color: colors.mutedForeground
        }],
        children: [display.waitHours, "h wait"]
      }), bonus > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.bonus,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: styles.bonusText,
          children: ["\uD83D\uDD25 +", bonus, " streak"]
        })
      }) : null, waiting && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.timer, {
          backgroundColor: colors.secondary,
          borderColor: colors.border
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "timer-outline",
          size: 12,
          color: colors.mutedForeground
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.timerText, {
            color: colors.mutedForeground
          }],
          children: countdown(readyAt - now)
        })]
      }), claimed && state.rewardCredits !== null && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.timer, {
          backgroundColor: colors.primary + "22",
          borderColor: colors.primary
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "check",
          size: 12,
          color: colors.primary
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.timerText, {
            color: colors.primary
          }],
          children: ["+", state.rewardCredits.toLocaleString()]
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(PressableScale.default, {
        accessibilityRole: "button",
        accessibilityLabel: `${display.label}: ${actionLabel}`,
        accessibilityState: {
          disabled: waiting || busy || charging,
          busy: busy || charging
        },
        style: [styles.action, {
          backgroundColor: ready || charging ? display.color : colors.secondary,
          borderColor: ready ? display.color : waiting ? colors.border : display.color + "66",
          opacity: waiting || busy && !charging ? 0.6 : 1
        }],
        scaleTo: 0.94,
        onPress: press,
        disabled: waiting || busy || charging,
        children: [ready && !charging ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Shimmer.default, {
          intensity: 0.5,
          every: 1800
        }) : null, busy && !charging ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
          size: "small",
          color: colors.mutedForeground
        }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.actionText, {
            color: ready || charging ? "#000" : waiting ? colors.mutedForeground : display.color
          }],
          children: actionLabel
        })]
      })]
    });
  }
  const styles = StyleSheet.default.create({
    card: {
      flex: 1,
      borderRadius: 16,
      padding: 14,
      alignItems: "center",
      gap: 8,
      minHeight: 222,
      shadowRadius: 18,
      shadowOffset: {
        width: 0,
        height: 0
      }
    },
    glowBar: {
      position: "absolute",
      top: 0,
      left: 14,
      right: 14,
      height: 3,
      borderBottomLeftRadius: 3,
      borderBottomRightRadius: 3,
      opacity: 0.9
    },
    iconArea: {
      width: 84,
      height: 84,
      alignItems: "center",
      justifyContent: "center"
    },
    halo: {
      position: "absolute",
      width: 74,
      height: 74,
      borderRadius: 37
    },
    iconWrap: {
      width: 68,
      height: 68,
      borderRadius: 20,
      borderWidth: 1.5,
      alignItems: "center",
      justifyContent: "center"
    },
    emoji: {
      fontSize: 32
    },
    tier: {
      fontSize: 13,
      fontFamily: "Inter_700Bold"
    },
    range: {
      fontSize: 11,
      fontFamily: "Inter_500Medium",
      textAlign: "center"
    },
    wait: {
      fontSize: 11,
      fontFamily: "Inter_400Regular"
    },
    bonus: {
      paddingHorizontal: 8,
      paddingVertical: 3,
      borderRadius: 999,
      backgroundColor: "rgba(255,122,26,0.18)",
      borderWidth: 1,
      borderColor: "#FF7A1A"
    },
    bonusText: {
      fontSize: 11,
      fontFamily: "Inter_800ExtraBold",
      color: "#FF7A1A"
    },
    timer: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
      paddingHorizontal: 8,
      paddingVertical: 4,
      borderRadius: 12,
      borderWidth: 1
    },
    timerText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold"
    },
    action: {
      width: "100%",
      paddingVertical: 10,
      borderRadius: 12,
      borderWidth: 1.5,
      alignItems: "center",
      marginTop: "auto",
      overflow: "hidden"
    },
    actionText: {
      fontSize: 12,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.4
    }
  });
},882,[818,12,228,28,188,109,867,868,872,819,869,820,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return SpinWheel;
    }
  });
  var _expoVectorIcons = require(_dependencyMap[0]);
  var _react = require(_dependencyMap[1]);
  var _reactNativeWebDistExportsAccessibilityInfo = require(_dependencyMap[2]);
  var AccessibilityInfo = _interopDefault(_reactNativeWebDistExportsAccessibilityInfo);
  var _reactNativeWebDistExportsModal = require(_dependencyMap[3]);
  var Modal = _interopDefault(_reactNativeWebDistExportsModal);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[7]);
  var _reactNativeReanimated = require(_dependencyMap[8]);
  var Animated = _interopDefault(_reactNativeReanimated);
  var _reactNativeSvg = require(_dependencyMap[9]);
  var Svg = _interopDefault(_reactNativeSvg);
  var _reactNativeWorklets = require(_dependencyMap[10]);
  var _componentsFxBurst = require(_dependencyMap[11]);
  var Burst = _interopDefault(_componentsFxBurst);
  var _componentsFxLightBeams = require(_dependencyMap[12]);
  var LightBeams = _interopDefault(_componentsFxLightBeams);
  var _componentsFxRollingNumber = require(_dependencyMap[13]);
  var RollingNumber = _interopDefault(_componentsFxRollingNumber);
  var _componentsFxShimmer = require(_dependencyMap[14]);
  var Shimmer = _interopDefault(_componentsFxShimmer);
  var _componentsUi = require(_dependencyMap[15]);
  var _constantsPrizeTypes = require(_dependencyMap[16]);
  var _hooksUseColors = require(_dependencyMap[17]);
  var _hooksUseMotion = require(_dependencyMap[18]);
  var _libMotion = require(_dependencyMap[19]);
  var _reactJsxRuntime = require(_dependencyMap[20]);
  const SIZE = 290;
  const C = 145;
  const R = 131;
  const SPIN_MS = 5600;
  /** Even deceleration: the last quarter-turn takes ~1/5 of the spin, not most of it. */
  const WHEEL_EASE = _reactNativeReanimated.Easing.bezier(0.2, 0.6, 0.35, 1);
  const WIND_MS = 420;
  function arcPath(index, slice) {
    const start = (index * slice - 90) * Math.PI / 180;
    const end = ((index + 1) * slice - 90) * Math.PI / 180;
    const x1 = C + R * Math.cos(start);
    const y1 = C + R * Math.sin(start);
    const x2 = C + R * Math.cos(end);
    const y2 = C + R * Math.sin(end);
    return `M ${C} ${C} L ${x1} ${y1} A ${R} ${R} 0 ${slice > 180 ? 1 : 0} 1 ${x2} ${y2} Z`;
  }
  function textPos(index, slice) {
    const midDeg = index * slice + slice / 2 - 90;
    const midRad = midDeg * Math.PI / 180;
    return {
      x: C + 83.84 * Math.cos(midRad),
      y: C + 83.84 * Math.sin(midRad),
      rotation: midDeg + 90
    };
  }

  /**
   * The prize wheel, in three acts:
   *
   *  1. Anticipation — the wheel sits in a pulsing halo; it winds back a
   *     notch, then launches.
   *  2. The spin — an even bezier deceleration (WHEEL_EASE). The pointer flicks
   *     and the phone ticks on every peg it passes, from the UI thread. It stops
   *     near the centre of the winning wedge — no staged near misses.
   *  3. The reveal — beams, a confetti burst and a shake coloured by how good
   *     the prize was for this box (blue common, purple rare, gold epic), the
   *     amount rolling up, and a Collect button.
   *
   * Skip jumps straight to the reveal; the credits are already in the ledger
   * either way, so closing at any point loses nothing.
   */
  const _worklet_4425909046966_init_data = {
    code: "(function SpinWheelTsx1(){const[rot,slice]=this.__closure;return Math.floor(rot.value/slice);})"
  };
  const _worklet_3450595932842_init_data = {
    code: "(function SpinWheelTsx2(cur,prev){const[peg,withSequence,withTiming,scheduleOnRN,tick]=this.__closure;if(prev===null||cur===prev)return;peg.value=withSequence(withTiming(1,{duration:35}),withTiming(0,{duration:160}));scheduleOnRN(tick);})"
  };
  const _worklet_13171637450076_init_data = {
    code: "(function SpinWheelTsx3(done){const[scheduleOnRN,reveal]=this.__closure;if(done)scheduleOnRN(reveal);})"
  };
  const _worklet_5694590619945_init_data = {
    code: "(function SpinWheelTsx4(){const[rot]=this.__closure;return{transform:[{rotate:rot.value+\"deg\"}]};})"
  };
  const _worklet_16265167721071_init_data = {
    code: "(function SpinWheelTsx5(){const[peg]=this.__closure;return{transform:[{rotate:-22*peg.value+\"deg\"}]};})"
  };
  const _worklet_12040204321419_init_data = {
    code: "(function SpinWheelTsx6(){const[halo]=this.__closure;return{opacity:0.25+0.45*halo.value,transform:[{scale:1+0.05*halo.value}]};})"
  };
  function SpinWheel({
    visible,
    tier,
    rewardCredits,
    error,
    onClose
  }) {
    const c = (0, _hooksUseColors.useColors)();
    const reduced = (0, _reactNativeReanimated.useReducedMotion)();
    const display = _constantsPrizeTypes.BOX_DISPLAY[tier];
    const n = display.segments.length;
    const slice = 360 / n;
    const table = (0, _react.useMemo)(() => display.segments.map(s => s.credits), [display.segments]);
    const [phase, setPhase] = (0, _react.useState)("ready");
    const rot = (0, _reactNativeReanimated.useSharedValue)(0);
    const peg = (0, _reactNativeReanimated.useSharedValue)(0);
    const target = (0, _react.useRef)(0);
    const halo = (0, _hooksUseMotion.useBreathe)(phase !== "reveal", 1300);
    const {
      style: shakeStyle,
      shake
    } = (0, _hooksUseMotion.useShake)();

    // Peg ticks: throttled so the fast start doesn't turn into one long buzz.
    const lastTick = (0, _react.useRef)(0);
    const tick = (0, _react.useCallback)(() => {
      const t = Date.now();
      if (t - lastTick.current < 42) return;
      lastTick.current = t;
      _libMotion.haptic.tick();
    }, []);
    (0, _reactNativeReanimated.useAnimatedReaction)(// A peg sits on every wedge boundary: the pointer passes one each time the turn crosses a multiple of the slice.
    function SpinWheelTsx1Factory([_worklet_4425909046966_init_data, rot, slice]) {
      const SpinWheelTsx1 = function () {
        "use no memo";

        return Math.floor(rot.value / slice);
      };
      SpinWheelTsx1.__closure = [rot, slice];
      SpinWheelTsx1.__workletHash = 4425909046966;
      SpinWheelTsx1.__initData = _worklet_4425909046966_init_data;
      return SpinWheelTsx1;
    }([_worklet_4425909046966_init_data, rot, slice]), function SpinWheelTsx2Factory([_worklet_3450595932842_init_data, peg, withSequence, withTiming, scheduleOnRN, tick]) {
      const SpinWheelTsx2 = function (cur, prev) {
        "use no memo";

        if (prev === null || cur === prev) return;
        peg.value = withSequence(withTiming(1, {
          duration: 35
        }), withTiming(0, {
          duration: 160
        }));
        scheduleOnRN(tick);
      };
      SpinWheelTsx2.__closure = [peg, withSequence, withTiming, scheduleOnRN, tick];
      SpinWheelTsx2.__workletHash = 3450595932842;
      SpinWheelTsx2.__initData = _worklet_3450595932842_init_data;
      return SpinWheelTsx2;
    }([_worklet_3450595932842_init_data, peg, _reactNativeReanimated.withSequence, _reactNativeReanimated.withTiming, _reactNativeWorklets.scheduleOnRN, tick]));
    const reveal = (0, _react.useCallback)(() => {
      setPhase("reveal");
      _libMotion.haptic.success();
      setTimeout(() => _libMotion.haptic.heavy(), 120);
    }, []);
    const start = (0, _react.useCallback)(() => {
      if (rewardCredits === null) return;
      // Wedges showing the awarded amount. If the display table ever drifts from
      // the server's, the wheel still lands and the reveal shows the real number.
      const wins = display.segments.map((s_0, i) => s_0.credits === rewardCredits ? i : -1).filter(i_0 => i_0 >= 0);
      // Prefer a winning wedge that isn't next to the top prize (no staged near-miss).
      const top = Math.max(...display.segments.map(s_1 => s_1.credits));
      const nearTop = i_1 => rewardCredits !== top && (display.segments[(i_1 + 1) % n].credits === top || display.segments[(i_1 - 1 + n) % n].credits === top);
      const safe = wins.filter(i_2 => !nearTop(i_2));
      const pool = safe.length ? safe : wins;
      const winner = pool.length ? pool[Math.floor(Math.random() * pool.length)] : 0;
      // Land near the winning wedge's centre (± jitter), never on an edge next to a bigger prize.
      const f = 0.5 + (Math.random() - 0.5) * 0.4;
      const land = (360 - (winner + f) * slice + 3600) % 360;
      const from = rot.value % 360;
      target.current = rot.value - from + 2520 + land;
      setPhase("spinning");
      _libMotion.haptic.heavy();
      if (reduced) {
        rot.value = target.current;
        reveal();
        return;
      }
      rot.value = (0, _reactNativeReanimated.withSequence)((0, _reactNativeReanimated.withTiming)(rot.value - 16, {
        duration: WIND_MS,
        easing: _reactNativeReanimated.Easing.inOut(_reactNativeReanimated.Easing.quad)
      }), (0, _reactNativeReanimated.withTiming)(target.current, {
        duration: SPIN_MS,
        easing: WHEEL_EASE
      }, function SpinWheelTsx3Factory([_worklet_13171637450076_init_data, scheduleOnRN, reveal]) {
        const SpinWheelTsx3 = function (done) {
          "use no memo";

          if (done) scheduleOnRN(reveal);
        };
        SpinWheelTsx3.__closure = [scheduleOnRN, reveal];
        SpinWheelTsx3.__workletHash = 13171637450076;
        SpinWheelTsx3.__initData = _worklet_13171637450076_init_data;
        return SpinWheelTsx3;
      }([_worklet_13171637450076_init_data, _reactNativeWorklets.scheduleOnRN, reveal])));
    }, [rewardCredits, display.segments, n, slice, rot, reduced, reveal]);
    const skip = (0, _react.useCallback)(() => {
      (0, _reactNativeReanimated.cancelAnimation)(rot);
      rot.value = target.current;
      reveal();
    }, [rot, reveal]);

    // Launch as soon as the server result is in: one tap ("Open!") on the box, not two.
    (0, _react.useEffect)(() => {
      if (!visible || rewardCredits === null || phase !== "ready") return;
      const t_0 = setTimeout(start, 350);
      return () => clearTimeout(t_0);
    }, [visible, rewardCredits, phase, start]);
    const rarity = rewardCredits !== null ? (0, _libMotion.rewardRarity)(rewardCredits, table) : "common";
    const look = _libMotion.REWARD_RARITY[rarity];
    (0, _react.useEffect)(() => {
      if (phase !== "reveal" || rewardCredits === null) return;
      shake(rarity === "epic" ? 2.2 : rarity === "rare" ? 1.4 : 0.8);
      AccessibilityInfo.default.announceForAccessibility(`${look.label}. You won ${rewardCredits} credits.`);
    }, [phase, rarity, rewardCredits, shake, look.label]);

    // The amount rolls up from zero once the reveal card is in.
    const [shown, setShown] = (0, _react.useState)(0);
    (0, _react.useEffect)(() => {
      if (phase !== "reveal" || rewardCredits === null) return;
      const t_1 = setTimeout(() => setShown(rewardCredits), 250);
      return () => clearTimeout(t_1);
    }, [phase, rewardCredits]);
    const wheelStyle = (0, _reactNativeReanimated.useAnimatedStyle)(function SpinWheelTsx4Factory([_worklet_5694590619945_init_data, rot]) {
      const SpinWheelTsx4 = function () {
        "use no memo";

        return {
          transform: [{
            rotate: `${rot.value}deg`
          }]
        };
      };
      SpinWheelTsx4.__closure = [rot];
      SpinWheelTsx4.__workletHash = 5694590619945;
      SpinWheelTsx4.__initData = _worklet_5694590619945_init_data;
      return SpinWheelTsx4;
    }([_worklet_5694590619945_init_data, rot]));
    const pointerStyle = (0, _reactNativeReanimated.useAnimatedStyle)(function SpinWheelTsx5Factory([_worklet_16265167721071_init_data, peg]) {
      const SpinWheelTsx5 = function () {
        "use no memo";

        return {
          transform: [{
            rotate: `${-22 * peg.value}deg`
          }]
        };
      };
      SpinWheelTsx5.__closure = [peg];
      SpinWheelTsx5.__workletHash = 16265167721071;
      SpinWheelTsx5.__initData = _worklet_16265167721071_init_data;
      return SpinWheelTsx5;
    }([_worklet_16265167721071_init_data, peg]));
    const haloStyle = (0, _reactNativeReanimated.useAnimatedStyle)(function SpinWheelTsx6Factory([_worklet_12040204321419_init_data, halo]) {
      const SpinWheelTsx6 = function () {
        "use no memo";

        return {
          opacity: 0.25 + 0.45 * halo.value,
          transform: [{
            scale: 1 + 0.05 * halo.value
          }]
        };
      };
      SpinWheelTsx6.__closure = [halo];
      SpinWheelTsx6.__workletHash = 12040204321419;
      SpinWheelTsx6.__initData = _worklet_12040204321419_init_data;
      return SpinWheelTsx6;
    }([_worklet_12040204321419_init_data, halo]));
    const pegs = (0, _react.useMemo)(() => Array.from({
      length: n
    }, (_, i_3) => {
      const a = (i_3 * slice - 90) * Math.PI / 180;
      return {
        x: C + 132 * Math.cos(a),
        y: C + 132 * Math.sin(a)
      };
    }), [n, slice]);
    return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Modal.default, {
      visible: visible,
      transparent: true,
      animationType: "fade",
      onRequestClose: onClose,
      statusBarTranslucent: true,
      children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [styles.overlay, {
          backgroundColor: c.overlay
        }],
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Animated.default.View, {
          style: [styles.sheet, {
            backgroundColor: c.elevated,
            borderColor: phase === "reveal" ? look.color : c.border
          }, shakeStyle],
          children: [phase === "reveal" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(LightBeams.default, {
            color: look.color,
            size: 520,
            opacity: 0.4
          }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.headRow,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.title, {
                color: display.color
              }],
              children: display.label
            }), phase === "reveal" || error ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.CloseButton, {
              onPress: onClose
            }) : null]
          }), error ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.errorWrap,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "alert-circle-outline",
              size: 40,
              color: c.destructive
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.errorText, {
                color: c.destructive
              }],
              children: error
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              label: "Close",
              onPress: onClose,
              style: {
                alignSelf: "stretch"
              }
            })]
          }) : phase !== "reveal" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.wheelWrap,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Animated.default.View, {
                pointerEvents: "none",
                style: [styles.halo, {
                  borderColor: display.glowColor,
                  shadowColor: display.glowColor
                }, haloStyle]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Animated.default.View, {
                style: wheelStyle,
                children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Svg.default, {
                  width: SIZE,
                  height: SIZE,
                  children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_reactNativeSvg.Circle, {
                    cx: C,
                    cy: C,
                    r: 141,
                    fill: c.card,
                    stroke: display.color,
                    strokeWidth: 4
                  }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_reactNativeSvg.G, {
                    children: display.segments.map((seg, i_4) => {
                      const p = textPos(i_4, slice);
                      return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactNativeSvg.G, {
                        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_reactNativeSvg.Path, {
                          d: arcPath(i_4, slice),
                          fill: seg.color,
                          stroke: "#00000033",
                          strokeWidth: 1
                        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_reactNativeSvg.Text, {
                          x: p.x,
                          y: p.y,
                          fill: "#FFFFFF",
                          fontSize: seg.credits >= 1000 ? 13 : 15,
                          fontWeight: "bold",
                          textAnchor: "middle",
                          transform: `rotate(${p.rotation}, ${p.x}, ${p.y})`,
                          children: seg.credits.toLocaleString()
                        })]
                      }, i_4);
                    })
                  }), pegs.map((pt, i_5) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_reactNativeSvg.Circle, {
                    cx: pt.x,
                    cy: pt.y,
                    r: 4,
                    fill: "#FFFFFF",
                    stroke: display.color,
                    strokeWidth: 1.5
                  }, i_5)), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_reactNativeSvg.Circle, {
                    cx: C,
                    cy: C,
                    r: 30,
                    fill: c.elevated,
                    stroke: display.color,
                    strokeWidth: 3
                  })]
                })
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
                pointerEvents: "none",
                style: styles.hub,
                children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: styles.hubEmoji,
                  children: display.emoji
                })
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Animated.default.View, {
                style: [styles.pointerWrap, pointerStyle],
                children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
                  style: [styles.pointer, {
                    borderTopColor: display.glowColor
                  }]
                })
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.footer,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.status, {
                  color: c.mutedForeground
                }],
                children: rewardCredits === null ? "Opening…" : phase === "spinning" ? "Come on…" : "Here we go…"
              }), phase === "spinning" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                accessibilityRole: "button",
                accessibilityLabel: "Skip to result",
                hitSlop: 10,
                onPress: skip,
                children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.skip, {
                    color: c.mutedForeground
                  }],
                  children: "Skip"
                })
              }) : null]
            })]
          }) : rewardCredits !== null ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.reveal,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Burst.default, {
              colors: look.confetti,
              count: rarity === "epic" ? 64 : rarity === "rare" ? 50 : 36,
              power: rarity === "epic" ? 1.5 : 1.15,
              originY: 0.38
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Animated.default.View, {
              entering: _reactNativeReanimated.ZoomIn.springify().damping(_libMotion.SPRING.bouncy.damping).stiffness(_libMotion.SPRING.bouncy.stiffness),
              style: [styles.rarity, {
                backgroundColor: look.color
              }],
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: rarity === "epic" ? "crown" : rarity === "rare" ? "diamond-stone" : "star-four-points",
                size: 14,
                color: "#0A0A0A"
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: styles.rarityText,
                children: look.label
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Animated.default.View, {
              entering: _reactNativeReanimated.ZoomIn.delay(120).springify().damping(10).stiffness(180),
              style: [styles.prize, {
                borderColor: look.color,
                shadowColor: look.color,
                backgroundColor: c.alpha(look.color, 0.12)
              }],
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.prizeLabel, {
                  color: c.mutedForeground
                }],
                children: "YOU WON"
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: styles.prizeRow,
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                  name: "lightning-bolt",
                  size: 34,
                  color: c.primary
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(RollingNumber.default, {
                  value: shown,
                  style: [styles.prizeValue, {
                    color: c.foreground
                  }],
                  duration: 1100,
                  flash: false,
                  haptics: true,
                  accessibilityLabel: `${rewardCredits.toLocaleString()} credits`
                })]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.prizeNote, {
                  color: c.mutedForeground
                }],
                children: "credits \xB7 already in your balance"
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Animated.default.View, {
              entering: _reactNativeReanimated.FadeIn.delay(500),
              style: {
                alignSelf: "stretch"
              },
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: styles.collectWrap,
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
                  label: "Collect",
                  icon: "hand-coin",
                  size: "lg",
                  onPress: onClose,
                  haptic: false
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Shimmer.default, {
                  intensity: 0.45,
                  every: 1500,
                  style: {
                    borderRadius: 14
                  }
                })]
              })
            })]
          }) : null]
        })
      })
    });
  }
  const styles = StyleSheet.default.create({
    overlay: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
      padding: 20
    },
    sheet: {
      borderRadius: 26,
      borderWidth: 1.5,
      padding: 20,
      alignItems: "center",
      gap: 14,
      width: "100%",
      maxWidth: 400,
      overflow: "hidden"
    },
    headRow: {
      flexDirection: "row",
      alignItems: "center",
      alignSelf: "stretch",
      justifyContent: "center",
      minHeight: 36
    },
    title: {
      fontSize: 20,
      fontFamily: "Inter_900Black",
      flex: 1,
      textAlign: "center"
    },
    wheelWrap: {
      width: SIZE,
      height: SIZE,
      alignItems: "center",
      justifyContent: "center",
      marginTop: 6
    },
    halo: {
      position: "absolute",
      width: 308,
      height: 308,
      borderRadius: 154,
      borderWidth: 6,
      shadowOpacity: 0.9,
      shadowRadius: 22,
      shadowOffset: {
        width: 0,
        height: 0
      }
    },
    hub: {
      position: "absolute",
      width: 60,
      height: 60,
      alignItems: "center",
      justifyContent: "center"
    },
    hubEmoji: {
      fontSize: 26
    },
    pointerWrap: {
      position: "absolute",
      top: -10,
      width: 30,
      height: 34,
      alignItems: "center",
      transformOrigin: "50% 20%"
    },
    pointer: {
      width: 0,
      height: 0,
      borderLeftWidth: 13,
      borderRightWidth: 13,
      borderTopWidth: 28,
      borderLeftColor: "transparent",
      borderRightColor: "transparent"
    },
    footer: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 16,
      minHeight: 24
    },
    status: {
      fontSize: 14,
      fontFamily: "Inter_600SemiBold"
    },
    skip: {
      fontSize: 13,
      fontFamily: "Inter_700Bold",
      textDecorationLine: "underline"
    },
    errorWrap: {
      alignItems: "center",
      gap: 12,
      paddingVertical: 24,
      alignSelf: "stretch"
    },
    errorText: {
      fontSize: 14,
      fontFamily: "Inter_500Medium",
      textAlign: "center"
    },
    reveal: {
      alignItems: "center",
      gap: 16,
      alignSelf: "stretch",
      paddingVertical: 8
    },
    rarity: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6,
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderRadius: 999
    },
    rarityText: {
      fontSize: 12,
      fontFamily: "Inter_900Black",
      letterSpacing: 1.4,
      color: "#0A0A0A"
    },
    prize: {
      alignItems: "center",
      gap: 4,
      paddingVertical: 20,
      paddingHorizontal: 28,
      borderRadius: 22,
      borderWidth: 2,
      shadowOpacity: 0.7,
      shadowRadius: 24,
      shadowOffset: {
        width: 0,
        height: 0
      },
      elevation: 12
    },
    prizeLabel: {
      fontSize: 11,
      fontFamily: "Inter_800ExtraBold",
      letterSpacing: 1.4
    },
    prizeRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4
    },
    prizeValue: {
      fontSize: 46,
      fontFamily: "Inter_900Black",
      letterSpacing: -1.5
    },
    prizeNote: {
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    },
    collectWrap: {
      borderRadius: 14,
      overflow: "hidden"
    }
  });
},883,[818,12,100,238,28,188,109,827,867,907,908,899,900,909,872,836,884,819,869,820,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "BOX_DISPLAY", {
    enumerable: true,
    get: function () {
      return BOX_DISPLAY;
    }
  });
  Object.defineProperty(exports, "BOX_TIERS", {
    enumerable: true,
    get: function () {
      return BOX_TIERS;
    }
  });
  Object.defineProperty(exports, "BOX_ODDS", {
    enumerable: true,
    get: function () {
      return BOX_ODDS;
    }
  });
  Object.defineProperty(exports, "BOX_PITY_AFTER", {
    enumerable: true,
    get: function () {
      return BOX_PITY_AFTER;
    }
  });
  /**
   * DISPLAY ONLY.
   *
   * The old `PRIZE_BOXES` in this file was the authoritative reward table and the
   * client drew from it with `Math.random()` (AUDIT S3). The real table now lives
   * in `functions/src/lib/economy.ts`, server-side, where the user can't read or
   * influence it.
   *
   * What remains here is the wheel's face: labels, colours and the wait copy. If
   * these drift from the server table the wheel may land on a wedge whose number
   * doesn't match the payout, so keep the `credits` values in sync — but nothing
   * about the payout depends on this file being correct.
   */

  const BOX_DISPLAY = {
    bronze: {
      tier: "bronze",
      label: "Bronze Box",
      waitHours: 1,
      color: "#CD7F32",
      glowColor: "#FF9A3C",
      emoji: "📦",
      segments: [{
        credits: 50,
        color: "#8B4513"
      }, {
        credits: 75,
        color: "#A0522D"
      }, {
        credits: 100,
        color: "#CD7F32"
      }, {
        credits: 50,
        color: "#8B4513"
      }, {
        credits: 125,
        color: "#D2691E"
      }, {
        credits: 75,
        color: "#A0522D"
      }, {
        credits: 200,
        color: "#FF8C00"
      }, {
        credits: 50,
        color: "#8B4513"
      }]
    },
    silver: {
      tier: "silver",
      label: "Silver Box",
      waitHours: 4,
      color: "#9E9E9E",
      glowColor: "#E0E0E0",
      emoji: "🎁",
      segments: [{
        credits: 150,
        color: "#607D8B"
      }, {
        credits: 200,
        color: "#78909C"
      }, {
        credits: 250,
        color: "#90A4AE"
      }, {
        credits: 150,
        color: "#607D8B"
      }, {
        credits: 350,
        color: "#B0BEC5"
      }, {
        credits: 200,
        color: "#78909C"
      }, {
        credits: 500,
        color: "#CFD8DC"
      }, {
        credits: 150,
        color: "#607D8B"
      }]
    },
    gold: {
      tier: "gold",
      label: "Gold Box",
      waitHours: 12,
      color: "#FFD700",
      glowColor: "#FFEC6E",
      emoji: "🏆",
      segments: [{
        credits: 400,
        color: "#B8860B"
      }, {
        credits: 600,
        color: "#DAA520"
      }, {
        credits: 800,
        color: "#C9A227"
      }, {
        credits: 400,
        color: "#B8860B"
      }, {
        credits: 1200,
        color: "#FFC107"
      }, {
        credits: 600,
        color: "#DAA520"
      }, {
        credits: 2000,
        color: "#E0B400"
      }, {
        credits: 400,
        color: "#B8860B"
      }]
    }
  };
  const BOX_TIERS = ["bronze", "silver", "gold"];

  /**
   * Published odds, mirroring functions/src/lib/economy.ts PRIZE_BOXES weights
   * (the server is authoritative). Shown on the Prizes screen.
   */
  const BOX_ODDS = (() => {
    const w = {
      bronze: [[50, 9], [75, 4], [100, 2], [125, 1], [200, 1]],
      silver: [[150, 9], [200, 4], [250, 2], [350, 1], [500, 1]],
      gold: [[400, 9], [600, 4], [800, 2], [1200, 1], [2000, 1]]
    };
    const out = {};
    for (const t of Object.keys(w)) {
      const total = w[t].reduce((s, [, x]) => s + x, 0);
      out[t] = w[t].map(([credits, x]) => ({
        credits,
        pct: x / total * 100
      }));
    }
    return out;
  })();

  /** Mirrors functions/src/callable/prizes.ts PITY_AFTER. */
  const BOX_PITY_AFTER = 15;
},884,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return NextActionCard;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _componentsUi = require(_dependencyMap[2]);
  var _expoRouter = require(_dependencyMap[3]);
  var _firebaseFirestore = require(_dependencyMap[4]);
  var _react = require(_dependencyMap[5]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[6]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[7]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[8]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _reactNativeReanimated = require(_dependencyMap[9]);
  var Animated = _interopDefault(_reactNativeReanimated);
  var _componentsFxPressableScale = require(_dependencyMap[10]);
  var PressableScale = _interopDefault(_componentsFxPressableScale);
  var _componentsFxShimmer = require(_dependencyMap[11]);
  var Shimmer = _interopDefault(_componentsFxShimmer);
  var _constantsPrizeTypes = require(_dependencyMap[12]);
  var _contextAppContext = require(_dependencyMap[13]);
  var _contextChallengeContext = require(_dependencyMap[14]);
  var _hooksUseColors = require(_dependencyMap[15]);
  var _libDemo = require(_dependencyMap[16]);
  var _libFirebase = require(_dependencyMap[17]);
  var _libMotion = require(_dependencyMap[18]);
  var _libOdds = require(_dependencyMap[19]);
  var _libStreakGrid = require(_dependencyMap[20]);
  var _reactJsxRuntime = require(_dependencyMap[21]);
  /**
   * Home's "do this now": the single most useful thing to do right now, picked
   * in priority order — a friend waiting on you, free credits ready, today's
   * Daily Pick, your bet about to kick off, your team tonight, or the board.
   */
  function NextActionCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(119);
    const {
      now,
      games,
      openGameIds,
      teamTonight,
      onOpenGame,
      onScrollTo
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const {
      profile,
      prizeBoxes
    } = (0, _contextAppContext.useApp)();
    const {
      incoming
    } = (0, _contextChallengeContext.useChallenges)();
    const daily = useDailyPickOpen(profile?.uid ?? null, now);
    let T0;
    let T1;
    let T2;
    let a_1;
    let actions;
    let t1;
    let t10;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[0] !== c || $[1] !== daily || $[2] !== games || $[3] !== incoming[0] || $[4] !== incoming.length || $[5] !== now || $[6] !== onOpenGame || $[7] !== onScrollTo || $[8] !== openGameIds || $[9] !== prizeBoxes || $[10] !== teamTonight) {
      t10 = Symbol.for("react.early_return_sentinel");
      bb0: {
        actions = [];
        const ch = incoming[0];
        if (ch) {
          const t11 = ch.away.abbreviation;
          const t12 = ch.home.abbreviation;
          let t13;
          if ($[26] !== ch.pot) {
            t13 = ch.pot.toLocaleString();
            $[26] = ch.pot;
            $[27] = t13;
          } else {
            t13 = $[27];
          }
          actions.push({
            key: `ch_${ch.id}`,
            icon: "sword-cross",
            kicker: "YOUR MOVE",
            title: `${ch.creatorName} challenged you`,
            body: `${t11} @ ${t12} · ${t13} pot${incoming.length > 1 ? ` · +${incoming.length - 1} more` : ""}`,
            cta: "Answer",
            tone: c.accent,
            onPress: _temp
          });
        }
        let t11;
        if ($[28] !== now || $[29] !== prizeBoxes) {
          t11 = _constantsPrizeTypes.BOX_TIERS.filter(t => {
            const b = prizeBoxes[t];
            return b.state === "ready" || b.state === "waiting" && (b.readyAt ?? Infinity) <= now;
          });
          $[28] = now;
          $[29] = prizeBoxes;
          $[30] = t11;
        } else {
          t11 = $[30];
        }
        const ready = t11;
        if (ready.length) {
          let t12;
          if ($[31] !== onScrollTo) {
            t12 = () => onScrollTo("prizes");
            $[31] = onScrollTo;
            $[32] = t12;
          } else {
            t12 = $[32];
          }
          actions.push({
            key: "boxes",
            icon: "gift-open",
            kicker: "FREE CREDITS",
            title: ready.length > 1 ? `${ready.length} prize boxes are ready` : `Your ${_constantsPrizeTypes.BOX_DISPLAY[ready[0]].label} is ready`,
            body: "Crack it open and spin for credits.",
            cta: "Open",
            tone: c.primary,
            onPress: t12
          });
        }
        if (daily) {
          let t12;
          if ($[33] !== daily.startsAt || $[34] !== now) {
            t12 = (0, _libOdds.untilKickoff)(daily.startsAt, now);
            $[33] = daily.startsAt;
            $[34] = now;
            $[35] = t12;
          } else {
            t12 = $[35];
          }
          let t13;
          if ($[36] !== onScrollTo) {
            t13 = () => onScrollTo("daily");
            $[36] = onScrollTo;
            $[37] = t13;
          } else {
            t13 = $[37];
          }
          actions.push({
            key: "daily",
            icon: "calendar-star",
            kicker: "DAILY PICK",
            title: `${daily.away} @ ${daily.home}`,
            body: `Free call, locks ${t12}. Keeps your streak alive.`,
            cta: "Pick",
            tone: c.primary,
            onPress: t13
          });
        }
        let t12;
        if ($[38] !== now || $[39] !== openGameIds) {
          t12 = g => openGameIds.has(g.id) && g.status === "upcoming" && g.startsAt > now && g.startsAt - now < 3600000;
          $[38] = now;
          $[39] = openGameIds;
          $[40] = t12;
        } else {
          t12 = $[40];
        }
        const soon = games.filter(t12).sort(_temp2)[0];
        if (soon) {
          actions.push({
            key: `soon_${soon.id}`,
            icon: "timer-sand",
            kicker: "KICKOFF SOON",
            title: `${soon.awayTeam.abbreviation} @ ${soon.homeTeam.abbreviation} starts ${(0, _libOdds.untilKickoff)(soon.startsAt, now)}`,
            body: "You've got money on it. Last call to add to it.",
            cta: "View",
            tone: c.live,
            onPress: () => onOpenGame(soon.id)
          });
        }
        if (teamTonight && !openGameIds.has(teamTonight.game.id)) {
          const g_0 = teamTonight.game;
          let t13;
          if ($[41] !== g_0.startsAt || $[42] !== g_0.status || $[43] !== now) {
            t13 = g_0.status === "live" ? "is live now" : `plays ${(0, _libOdds.untilKickoff)(g_0.startsAt, now)}`;
            $[41] = g_0.startsAt;
            $[42] = g_0.status;
            $[43] = now;
            $[44] = t13;
          } else {
            t13 = $[44];
          }
          let t14;
          if ($[45] !== g_0.id || $[46] !== onOpenGame) {
            t14 = () => onOpenGame(g_0.id);
            $[45] = g_0.id;
            $[46] = onOpenGame;
            $[47] = t14;
          } else {
            t14 = $[47];
          }
          actions.push({
            key: `team_${g_0.id}`,
            icon: "heart",
            kicker: "YOUR TEAM",
            title: `${teamTonight.abbr} ${t13}`,
            body: `${g_0.awayTeam.abbreviation} @ ${g_0.homeTeam.abbreviation} · you don't have a pick in yet`,
            cta: "Bet",
            tone: c.primary,
            onPress: t14
          });
        }
        if (!actions.length) {
          let t13;
          if ($[48] !== now || $[49] !== openGameIds) {
            t13 = g_1 => g_1.status === "upcoming" && g_1.startsAt > now && !openGameIds.has(g_1.id);
            $[48] = now;
            $[49] = openGameIds;
            $[50] = t13;
          } else {
            t13 = $[50];
          }
          const next = games.filter(t13).sort(_temp3)[0];
          if (next) {
            actions.push({
              key: `next_${next.id}`,
              icon: "scoreboard-outline",
              kicker: "UP NEXT",
              title: `${next.awayTeam.abbreviation} @ ${next.homeTeam.abbreviation} ${(0, _libOdds.untilKickoff)(next.startsAt, now)}`,
              body: "Get a pick in before it locks.",
              cta: "Bet",
              tone: c.primary,
              onPress: () => onOpenGame(next.id)
            });
          }
        }
        a_1 = actions[0];
        if (!a_1) {
          t10 = null;
          break bb0;
        }
        T2 = View.default;
        if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
          t8 = {
            gap: 8
          };
          t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
            title: "Up Next",
            icon: "lightning-bolt"
          });
          $[51] = t8;
          $[52] = t9;
        } else {
          t8 = $[51];
          t9 = $[52];
        }
        T1 = Animated.default.View;
        t6 = a_1.key;
        if ($[53] === Symbol.for("react.memo_cache_sentinel")) {
          t7 = _reactNativeReanimated.FadeIn.duration(220);
          $[53] = t7;
        } else {
          t7 = $[53];
        }
        T0 = PressableScale.default;
        t3 = "button";
        t4 = `${a_1.title}. ${a_1.cta}`;
        t5 = () => {
          _libMotion.haptic.light();
          a_1.onPress();
        };
        t2 = styles.card;
        t1 = c.alpha(a_1.tone, 0.14);
      }
      $[0] = c;
      $[1] = daily;
      $[2] = games;
      $[3] = incoming[0];
      $[4] = incoming.length;
      $[5] = now;
      $[6] = onOpenGame;
      $[7] = onScrollTo;
      $[8] = openGameIds;
      $[9] = prizeBoxes;
      $[10] = teamTonight;
      $[11] = T0;
      $[12] = T1;
      $[13] = T2;
      $[14] = a_1;
      $[15] = actions;
      $[16] = t1;
      $[17] = t10;
      $[18] = t2;
      $[19] = t3;
      $[20] = t4;
      $[21] = t5;
      $[22] = t6;
      $[23] = t7;
      $[24] = t8;
      $[25] = t9;
    } else {
      T0 = $[11];
      T1 = $[12];
      T2 = $[13];
      a_1 = $[14];
      actions = $[15];
      t1 = $[16];
      t10 = $[17];
      t2 = $[18];
      t3 = $[19];
      t4 = $[20];
      t5 = $[21];
      t6 = $[22];
      t7 = $[23];
      t8 = $[24];
      t9 = $[25];
    }
    if (t10 !== Symbol.for("react.early_return_sentinel")) {
      return t10;
    }
    let t11;
    if ($[54] !== a_1.tone || $[55] !== t1) {
      t11 = {
        backgroundColor: t1,
        borderColor: a_1.tone
      };
      $[54] = a_1.tone;
      $[55] = t1;
      $[56] = t11;
    } else {
      t11 = $[56];
    }
    let t12;
    if ($[57] !== t11 || $[58] !== t2) {
      t12 = [t2, t11];
      $[57] = t11;
      $[58] = t2;
      $[59] = t12;
    } else {
      t12 = $[59];
    }
    let t13;
    if ($[60] !== a_1.tone) {
      t13 = [styles.icon, {
        backgroundColor: a_1.tone
      }];
      $[60] = a_1.tone;
      $[61] = t13;
    } else {
      t13 = $[61];
    }
    let t14;
    if ($[62] !== a_1.icon || $[63] !== c.background) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: a_1.icon,
        size: 22,
        color: c.background
      });
      $[62] = a_1.icon;
      $[63] = c.background;
      $[64] = t14;
    } else {
      t14 = $[64];
    }
    let t15;
    if ($[65] !== t13 || $[66] !== t14) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t13,
        children: t14
      });
      $[65] = t13;
      $[66] = t14;
      $[67] = t15;
    } else {
      t15 = $[67];
    }
    let t16;
    if ($[68] === Symbol.for("react.memo_cache_sentinel")) {
      t16 = {
        flex: 1,
        gap: 1
      };
      $[68] = t16;
    } else {
      t16 = $[68];
    }
    let t17;
    if ($[69] !== a_1.tone) {
      t17 = [styles.kicker, {
        color: a_1.tone
      }];
      $[69] = a_1.tone;
      $[70] = t17;
    } else {
      t17 = $[70];
    }
    const t18 = actions.length > 1 ? `  ·  ${actions.length - 1} more to do` : "";
    let t19;
    if ($[71] !== a_1.kicker || $[72] !== t17 || $[73] !== t18) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: t17,
        children: [a_1.kicker, t18]
      });
      $[71] = a_1.kicker;
      $[72] = t17;
      $[73] = t18;
      $[74] = t19;
    } else {
      t19 = $[74];
    }
    let t20;
    if ($[75] !== c.foreground) {
      t20 = [styles.title, {
        color: c.foreground
      }];
      $[75] = c.foreground;
      $[76] = t20;
    } else {
      t20 = $[76];
    }
    let t21;
    if ($[77] !== a_1.title || $[78] !== t20) {
      t21 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t20,
        numberOfLines: 1,
        children: a_1.title
      });
      $[77] = a_1.title;
      $[78] = t20;
      $[79] = t21;
    } else {
      t21 = $[79];
    }
    let t22;
    if ($[80] !== c.mutedForeground) {
      t22 = [styles.body, {
        color: c.mutedForeground
      }];
      $[80] = c.mutedForeground;
      $[81] = t22;
    } else {
      t22 = $[81];
    }
    let t23;
    if ($[82] !== a_1.body || $[83] !== t22) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t22,
        numberOfLines: 1,
        children: a_1.body
      });
      $[82] = a_1.body;
      $[83] = t22;
      $[84] = t23;
    } else {
      t23 = $[84];
    }
    let t24;
    if ($[85] !== t19 || $[86] !== t21 || $[87] !== t23) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t16,
        children: [t19, t21, t23]
      });
      $[85] = t19;
      $[86] = t21;
      $[87] = t23;
      $[88] = t24;
    } else {
      t24 = $[88];
    }
    let t25;
    if ($[89] !== a_1.tone) {
      t25 = [styles.cta, {
        backgroundColor: a_1.tone
      }];
      $[89] = a_1.tone;
      $[90] = t25;
    } else {
      t25 = $[90];
    }
    let t26;
    if ($[91] !== c.background) {
      t26 = [styles.ctaText, {
        color: c.background
      }];
      $[91] = c.background;
      $[92] = t26;
    } else {
      t26 = $[92];
    }
    let t27;
    if ($[93] !== a_1.cta || $[94] !== t26) {
      t27 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t26,
        children: a_1.cta
      });
      $[93] = a_1.cta;
      $[94] = t26;
      $[95] = t27;
    } else {
      t27 = $[95];
    }
    let t28;
    if ($[96] === Symbol.for("react.memo_cache_sentinel")) {
      t28 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Shimmer.default, {
        every: 3200
      });
      $[96] = t28;
    } else {
      t28 = $[96];
    }
    let t29;
    if ($[97] !== t25 || $[98] !== t27) {
      t29 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t25,
        children: [t27, t28]
      });
      $[97] = t25;
      $[98] = t27;
      $[99] = t29;
    } else {
      t29 = $[99];
    }
    let t30;
    if ($[100] !== T0 || $[101] !== t12 || $[102] !== t15 || $[103] !== t24 || $[104] !== t29 || $[105] !== t3 || $[106] !== t4 || $[107] !== t5) {
      t30 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T0, {
        accessibilityRole: t3,
        accessibilityLabel: t4,
        onPress: t5,
        style: t12,
        children: [t15, t24, t29]
      });
      $[100] = T0;
      $[101] = t12;
      $[102] = t15;
      $[103] = t24;
      $[104] = t29;
      $[105] = t3;
      $[106] = t4;
      $[107] = t5;
      $[108] = t30;
    } else {
      t30 = $[108];
    }
    let t31;
    if ($[109] !== T1 || $[110] !== t30 || $[111] !== t6 || $[112] !== t7) {
      t31 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(T1, {
        entering: t7,
        children: t30
      }, t6);
      $[109] = T1;
      $[110] = t30;
      $[111] = t6;
      $[112] = t7;
      $[113] = t31;
    } else {
      t31 = $[113];
    }
    let t32;
    if ($[114] !== T2 || $[115] !== t31 || $[116] !== t8 || $[117] !== t9) {
      t32 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T2, {
        style: t8,
        children: [t9, t31]
      });
      $[114] = T2;
      $[115] = t31;
      $[116] = t8;
      $[117] = t9;
      $[118] = t32;
    } else {
      t32 = $[118];
    }
    return t32;
  }

  /** Today's featured Daily Pick, when it's still open and you haven't picked. */
  function _temp3(a_0, b_1) {
    return a_0.startsAt - b_1.startsAt;
  }
  function _temp2(a, b_0) {
    return a.startsAt - b_0.startsAt;
  }
  function _temp() {
    return _expoRouter.router.push("/challenges");
  }
  function useDailyPickOpen(uid, now) {
    const $ = (0, _reactCompilerRuntime.c)(6);
    let t0;
    if ($[0] !== now) {
      t0 = (0, _libStreakGrid.nyDayOf)(now);
      $[0] = now;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    const day = t0;
    const [featured, setFeatured] = (0, _react.useState)(null);
    const [picked, setPicked] = (0, _react.useState)(true);
    let t1;
    let t2;
    if ($[2] !== day || $[3] !== uid) {
      t1 = () => {
        if (_libDemo.DEMO || !uid) {
          return;
        }
        const db = (0, _libFirebase.getDb)();
        if (!db) {
          return;
        }
        const a = (0, _firebaseFirestore.onSnapshot)((0, _firebaseFirestore.doc)(db, "dailyPick", day), s => {
          const d = s.data();
          setFeatured(d?.startsAt && d.homeTeam && d.awayTeam ? {
            startsAt: d.startsAt,
            home: d.homeTeam.abbreviation ?? "",
            away: d.awayTeam.abbreviation ?? ""
          } : null);
        }, _temp4);
        const b = (0, _firebaseFirestore.onSnapshot)((0, _firebaseFirestore.doc)(db, "users", uid, "dailyPicks", day), s_0 => setPicked(s_0.exists()), _temp5);
        return () => {
          a();
          b();
        };
      };
      t2 = [uid, day];
      $[2] = day;
      $[3] = uid;
      $[4] = t1;
      $[5] = t2;
    } else {
      t1 = $[4];
      t2 = $[5];
    }
    (0, _react.useEffect)(t1, t2);
    return featured && !picked && featured.startsAt > now ? featured : null;
  }
  function _temp5() {}
  function _temp4() {}
  const styles = StyleSheet.default.create({
    card: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      borderRadius: 18,
      borderWidth: 1.5,
      padding: 12
    },
    icon: {
      width: 42,
      height: 42,
      borderRadius: 13,
      alignItems: "center",
      justifyContent: "center"
    },
    kicker: {
      fontSize: 10,
      letterSpacing: 1.2,
      fontFamily: "Inter_800ExtraBold"
    },
    title: {
      fontSize: 15,
      fontFamily: "Inter_800ExtraBold"
    },
    body: {
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    },
    cta: {
      paddingHorizontal: 14,
      paddingVertical: 9,
      borderRadius: 999,
      overflow: "hidden"
    },
    ctaText: {
      fontSize: 13,
      fontFamily: "Inter_800ExtraBold"
    }
  });
},885,[815,818,836,817,905,12,28,188,109,867,868,872,884,837,821,819,902,906,820,870,903,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return LiveSweatCard;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _componentsUi = require(_dependencyMap[2]);
  var _react = require(_dependencyMap[3]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _reactNativeReanimated = require(_dependencyMap[7]);
  var Animated = _interopDefault(_reactNativeReanimated);
  var _componentsFxTap = require(_dependencyMap[8]);
  var _componentsTeamCrest = require(_dependencyMap[9]);
  var TeamCrest = _interopDefault(_componentsTeamCrest);
  var _hooksUseColors = require(_dependencyMap[10]);
  var _libMotion = require(_dependencyMap[11]);
  var _libOdds = require(_dependencyMap[12]);
  var _reactJsxRuntime = require(_dependencyMap[13]);
  const _worklet_5780338508317_init_data = {
    code: "(function LiveSweatCardTsx1(){const[pulse]=this.__closure;return{opacity:0.35+0.65*pulse.value,transform:[{scale:0.8+0.4*pulse.value}]};})"
  };
  /**
   * Home's live sweat: every open bet whose game is live, with the score, the
   * clock and whether you're winning right now. Shown only while games are on.
   */
  function LiveSweatCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(57);
    const {
      bets,
      gameById,
      onOpen
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    let t1;
    if ($[0] !== bets || $[1] !== gameById) {
      let t2;
      if ($[3] !== gameById) {
        t2 = b => gameById.get(b.gameId)?.status === "live";
        $[3] = gameById;
        $[4] = t2;
      } else {
        t2 = $[4];
      }
      t1 = bets.filter(t2);
      $[0] = bets;
      $[1] = gameById;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    const live = t1;
    const pulse = (0, _reactNativeReanimated.useSharedValue)(0);
    const reduced = (0, _reactNativeReanimated.useReducedMotion)();
    let t2;
    let t3;
    if ($[5] !== live.length || $[6] !== pulse || $[7] !== reduced) {
      t2 = () => {
        if (reduced || !live.length) {
          return;
        }
        pulse.value = (0, _reactNativeReanimated.withRepeat)((0, _reactNativeReanimated.withTiming)(1, {
          duration: 900,
          easing: _reactNativeReanimated.Easing.inOut(_reactNativeReanimated.Easing.quad)
        }), -1, true);
      };
      t3 = [reduced, live.length, pulse];
      $[5] = live.length;
      $[6] = pulse;
      $[7] = reduced;
      $[8] = t2;
      $[9] = t3;
    } else {
      t2 = $[8];
      t3 = $[9];
    }
    (0, _react.useEffect)(t2, t3);
    const dot = (0, _reactNativeReanimated.useAnimatedStyle)(function LiveSweatCardTsx1Factory([_worklet_5780338508317_init_data, pulse]) {
      const LiveSweatCardTsx1 = function () {
        "use no memo";

        return {
          opacity: 0.35 + 0.65 * pulse.value,
          transform: [{
            scale: 0.8 + 0.4 * pulse.value
          }]
        };
      };
      LiveSweatCardTsx1.__closure = [pulse];
      LiveSweatCardTsx1.__workletHash = 5780338508317;
      LiveSweatCardTsx1.__initData = _worklet_5780338508317_init_data;
      return LiveSweatCardTsx1;
    }([_worklet_5780338508317_init_data, pulse]));
    if (!live.length) {
      return null;
    }
    let t4;
    if ($[10] !== gameById || $[11] !== live) {
      let t5;
      if ($[13] !== gameById) {
        t5 = b_0 => (0, _libOdds.livePosition)(gameById.get(b_0.gameId), b_0) === "ahead";
        $[13] = gameById;
        $[14] = t5;
      } else {
        t5 = $[14];
      }
      t4 = live.filter(t5);
      $[10] = gameById;
      $[11] = live;
      $[12] = t4;
    } else {
      t4 = $[12];
    }
    const winning = t4.length;
    let t5;
    let t6;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
      t5 = {
        gap: 8
      };
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
        title: "Live Now",
        icon: "broadcast"
      });
      $[15] = t5;
      $[16] = t6;
    } else {
      t5 = $[15];
      t6 = $[16];
    }
    let t7;
    if ($[17] !== c) {
      t7 = c.alpha(c.live, 0.08);
      $[17] = c;
      $[18] = t7;
    } else {
      t7 = $[18];
    }
    let t8;
    if ($[19] !== c) {
      t8 = c.alpha(c.live, 0.55);
      $[19] = c;
      $[20] = t8;
    } else {
      t8 = $[20];
    }
    let t9;
    if ($[21] !== t7 || $[22] !== t8) {
      t9 = [styles.card, {
        backgroundColor: t7,
        borderColor: t8
      }];
      $[21] = t7;
      $[22] = t8;
      $[23] = t9;
    } else {
      t9 = $[23];
    }
    let t10;
    if ($[24] !== c.live) {
      t10 = {
        backgroundColor: c.live
      };
      $[24] = c.live;
      $[25] = t10;
    } else {
      t10 = $[25];
    }
    let t11;
    if ($[26] !== dot || $[27] !== t10) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Animated.default.View, {
        style: [styles.dot, t10, dot]
      });
      $[26] = dot;
      $[27] = t10;
      $[28] = t11;
    } else {
      t11 = $[28];
    }
    let t12;
    if ($[29] !== c.live) {
      t12 = [styles.kicker, {
        color: c.live
      }];
      $[29] = c.live;
      $[30] = t12;
    } else {
      t12 = $[30];
    }
    let t13;
    if ($[31] !== live.length || $[32] !== t12) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: t12,
        children: ["SWEATING \xB7 ", live.length, " LIVE"]
      });
      $[31] = live.length;
      $[32] = t12;
      $[33] = t13;
    } else {
      t13 = $[33];
    }
    let t14;
    if ($[34] !== c.mutedForeground) {
      t14 = [styles.summary, {
        color: c.mutedForeground
      }];
      $[34] = c.mutedForeground;
      $[35] = t14;
    } else {
      t14 = $[35];
    }
    let t15;
    if ($[36] !== live.length || $[37] !== t14 || $[38] !== winning) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: t14,
        children: [winning, "/", live.length, " winning"]
      });
      $[36] = live.length;
      $[37] = t14;
      $[38] = winning;
      $[39] = t15;
    } else {
      t15 = $[39];
    }
    let t16;
    if ($[40] !== t11 || $[41] !== t13 || $[42] !== t15) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.head,
        children: [t11, t13, t15]
      });
      $[40] = t11;
      $[41] = t13;
      $[42] = t15;
      $[43] = t16;
    } else {
      t16 = $[43];
    }
    let t17;
    if ($[44] !== c || $[45] !== gameById || $[46] !== live || $[47] !== onOpen) {
      let t18;
      if ($[49] !== c || $[50] !== gameById || $[51] !== onOpen) {
        t18 = b_1 => {
          const g = gameById.get(b_1.gameId);
          const pos = (0, _libOdds.livePosition)(g, b_1);
          const tone = pos === "ahead" ? c.positive : pos === "behind" ? c.negative : c.mutedForeground;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
            accessibilityRole: "button",
            accessibilityLabel: `${g.awayTeam.abbreviation} ${g.awayScore ?? 0}, ${g.homeTeam.abbreviation} ${g.homeScore ?? 0}. Your pick ${b_1.label ?? b_1.teamAbbr} is ${pos ?? "live"}`,
            onPress: () => {
              _libMotion.haptic.tick();
              onOpen(g.id);
            },
            style: t19 => {
              const {
                pressed
              } = t19;
              return [styles.row, {
                backgroundColor: c.card,
                borderColor: c.border,
                opacity: pressed ? 0.85 : 1
              }];
            },
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(TeamCrest.default, {
              abbr: b_1.teamAbbr,
              color: b_1.teamColor,
              size: 30,
              sport: g.sport
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.score, {
                  color: c.foreground
                }],
                numberOfLines: 1,
                children: [g.awayTeam.abbreviation, " ", g.awayScore ?? 0, " \u2013 ", g.homeScore ?? 0, " ", g.homeTeam.abbreviation]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.meta, {
                  color: c.mutedForeground
                }],
                numberOfLines: 1,
                children: [g.clock ?? "Live", " \xB7 ", b_1.label ?? b_1.teamAbbr, b_1.wallet ? ` · ${b_1.wallet}` : "", " \xB7 ", b_1.stake.toLocaleString(), " \u2192 ", b_1.potentialPayout.toLocaleString()]
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: [styles.pos, {
                backgroundColor: c.alpha(tone, 0.16),
                borderColor: tone
              }],
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: pos === "ahead" ? "arrow-up-bold" : pos === "behind" ? "arrow-down-bold" : "equal",
                size: 12,
                color: tone
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.posText, {
                  color: tone
                }],
                children: pos === "ahead" ? "WINNING" : pos === "behind" ? "LOSING" : "TIED"
              })]
            })]
          }, b_1.key);
        };
        $[49] = c;
        $[50] = gameById;
        $[51] = onOpen;
        $[52] = t18;
      } else {
        t18 = $[52];
      }
      t17 = live.map(t18);
      $[44] = c;
      $[45] = gameById;
      $[46] = live;
      $[47] = onOpen;
      $[48] = t17;
    } else {
      t17 = $[48];
    }
    let t18;
    if ($[53] !== t16 || $[54] !== t17 || $[55] !== t9) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t5,
        children: [t6, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: t9,
          children: [t16, t17]
        })]
      });
      $[53] = t16;
      $[54] = t17;
      $[55] = t9;
      $[56] = t18;
    } else {
      t18 = $[56];
    }
    return t18;
  }
  const styles = StyleSheet.default.create({
    card: {
      borderRadius: 18,
      borderWidth: 1.5,
      padding: 12,
      gap: 8
    },
    head: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    dot: {
      width: 9,
      height: 9,
      borderRadius: 5
    },
    kicker: {
      flex: 1,
      fontSize: 11,
      letterSpacing: 1.2,
      fontFamily: "Inter_800ExtraBold"
    },
    summary: {
      fontSize: 12,
      fontFamily: "Inter_700Bold"
    },
    row: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      borderRadius: 12,
      borderWidth: 1,
      padding: 10
    },
    score: {
      fontSize: 15,
      fontFamily: "Inter_800ExtraBold",
      fontVariant: ["tabular-nums"]
    },
    meta: {
      fontSize: 11,
      fontFamily: "Inter_500Medium"
    },
    pos: {
      flexDirection: "row",
      alignItems: "center",
      gap: 3,
      paddingHorizontal: 7,
      paddingVertical: 4,
      borderRadius: 999,
      borderWidth: 1
    },
    posText: {
      fontSize: 10,
      letterSpacing: 0.6,
      fontFamily: "Inter_800ExtraBold"
    }
  });
},886,[815,818,836,12,28,188,109,867,827,866,819,820,870,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return WeeklyRecapCard;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  require(_dependencyMap[2]);
  var _reactNativeWebDistExportsShare = require(_dependencyMap[3]);
  var Share = _interopDefault(_reactNativeWebDistExportsShare);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[7]);
  var _componentsUi = require(_dependencyMap[8]);
  var _hooksUseColors = require(_dependencyMap[9]);
  var _libSettings = require(_dependencyMap[10]);
  var _libStreakGrid = require(_dependencyMap[11]);
  var _reactJsxRuntime = require(_dependencyMap[12]);
  const DAY = 86_400_000;

  /**
   * Monday–Wednesday recap of last week (ET, Mon–Sun): record, net and best hit,
   * with a share. Dismissed per week.
   */
  function WeeklyRecapCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(89);
    const {
      bets,
      now,
      leagueLine
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const thisWeek = (0, _libStreakGrid.weekDays)(now);
    const t1 = now - 604800000;
    let t2;
    if ($[0] !== t1) {
      t2 = (0, _libStreakGrid.weekDays)(t1);
      $[0] = t1;
      $[1] = t2;
    } else {
      t2 = $[1];
    }
    const lastWeek = t2;
    const key = lastWeek[0];
    let t3;
    if ($[2] !== key) {
      t3 = [key];
      $[2] = key;
      $[3] = t3;
    } else {
      t3 = $[3];
    }
    const unseen = (0, _libSettings.useUnseenCount)("recap.weekly", t3, false);
    const dow = thisWeek.indexOf((0, _libStreakGrid.nyDayOf)(now));
    if (dow < 0 || dow > 2 || !unseen) {
      return null;
    }
    const from = lastWeek[0];
    const to = lastWeek[6];
    let T0;
    let T1;
    let T2;
    let T3;
    let best;
    let inWeek;
    let net;
    let share;
    let t10;
    let t11;
    let t12;
    let t13;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[4] !== bets || $[5] !== c || $[6] !== from || $[7] !== key || $[8] !== leagueLine || $[9] !== to) {
      t13 = Symbol.for("react.early_return_sentinel");
      bb0: {
        let t14;
        if ($[28] !== from || $[29] !== to) {
          t14 = b => {
            if (!b.settledAt || b.status !== "won" && b.status !== "lost" && b.status !== "push") {
              return false;
            }
            const d = (0, _libStreakGrid.nyDayOf)(b.settledAt.seconds * 1000);
            return d >= from && d <= to;
          };
          $[28] = from;
          $[29] = to;
          $[30] = t14;
        } else {
          t14 = $[30];
        }
        inWeek = bets.filter(t14);
        if (!inWeek.length) {
          t13 = null;
          break bb0;
        }
        const w = inWeek.filter(_temp).length;
        const l = inWeek.filter(_temp2).length;
        net = inWeek.reduce(_temp3, 0);
        best = inWeek.filter(_temp4).sort(_temp5)[0];
        let t15;
        if ($[31] !== key) {
          t15 = () => (0, _libSettings.markItemsSeen)("recap.weekly", [key]);
          $[31] = key;
          $[32] = t15;
        } else {
          t15 = $[32];
        }
        const dismiss = t15;
        share = () => {
          const text = [`My SportDrip week: ${w}-${l}, ${net >= 0 ? "+" : ""}${net.toLocaleString()} credits`, best ? `Best hit: ${best.label ?? best.teamName} +${(best.potentialPayout - best.stake).toLocaleString()}` : null, leagueLine].filter(Boolean).join("\n");
          Share.default.share({
            message: text
          }).catch(_temp6);
        };
        T3 = View.default;
        if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
          t11 = {
            gap: 8
          };
          t12 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
            title: "Your Week",
            icon: "calendar-week"
          });
          $[33] = t11;
          $[34] = t12;
        } else {
          t11 = $[33];
          t12 = $[34];
        }
        T2 = View.default;
        const t16 = c.card;
        let t17;
        if ($[35] !== c) {
          t17 = c.alpha(c.accent, 0.5);
          $[35] = c;
          $[36] = t17;
        } else {
          t17 = $[36];
        }
        if ($[37] !== c.card || $[38] !== t17) {
          t9 = [styles.card, {
            backgroundColor: t16,
            borderColor: t17
          }];
          $[37] = c.card;
          $[38] = t17;
          $[39] = t9;
        } else {
          t9 = $[39];
        }
        let t18;
        if ($[40] !== c.accent) {
          t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.kicker, {
              color: c.accent
            }],
            children: "LAST WEEK \xB7 MON\u2013SUN"
          });
          $[40] = c.accent;
          $[41] = t18;
        } else {
          t18 = $[41];
        }
        let t19;
        if ($[42] !== c.mutedForeground) {
          t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "close",
            size: 18,
            color: c.mutedForeground
          });
          $[42] = c.mutedForeground;
          $[43] = t19;
        } else {
          t19 = $[43];
        }
        let t20;
        if ($[44] !== dismiss || $[45] !== t19) {
          t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
            accessibilityRole: "button",
            accessibilityLabel: "Dismiss weekly recap",
            hitSlop: 10,
            onPress: dismiss,
            children: t19
          });
          $[44] = dismiss;
          $[45] = t19;
          $[46] = t20;
        } else {
          t20 = $[46];
        }
        if ($[47] !== t18 || $[48] !== t20) {
          t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.head,
            children: [t18, t20]
          });
          $[47] = t18;
          $[48] = t20;
          $[49] = t10;
        } else {
          t10 = $[49];
        }
        T1 = View.default;
        t7 = styles.stats;
        const t21 = `${w}-${l}`;
        if ($[50] !== c.foreground || $[51] !== t21) {
          t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Stat, {
            label: "RECORD",
            value: t21,
            color: c.foreground
          });
          $[50] = c.foreground;
          $[51] = t21;
          $[52] = t8;
        } else {
          t8 = $[52];
        }
        T0 = Stat;
        t6 = "NET";
        t4 = net >= 0 ? "+" : "";
        t5 = net.toLocaleString();
      }
      $[4] = bets;
      $[5] = c;
      $[6] = from;
      $[7] = key;
      $[8] = leagueLine;
      $[9] = to;
      $[10] = T0;
      $[11] = T1;
      $[12] = T2;
      $[13] = T3;
      $[14] = best;
      $[15] = inWeek;
      $[16] = net;
      $[17] = share;
      $[18] = t10;
      $[19] = t11;
      $[20] = t12;
      $[21] = t13;
      $[22] = t4;
      $[23] = t5;
      $[24] = t6;
      $[25] = t7;
      $[26] = t8;
      $[27] = t9;
    } else {
      T0 = $[10];
      T1 = $[11];
      T2 = $[12];
      T3 = $[13];
      best = $[14];
      inWeek = $[15];
      net = $[16];
      share = $[17];
      t10 = $[18];
      t11 = $[19];
      t12 = $[20];
      t13 = $[21];
      t4 = $[22];
      t5 = $[23];
      t6 = $[24];
      t7 = $[25];
      t8 = $[26];
      t9 = $[27];
    }
    if (t13 !== Symbol.for("react.early_return_sentinel")) {
      return t13;
    }
    const t14 = `${t4}${t5}`;
    const t15 = net >= 0 ? c.positive : c.negative;
    let t16;
    if ($[53] !== T0 || $[54] !== t14 || $[55] !== t15 || $[56] !== t6) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(T0, {
        label: t6,
        value: t14,
        color: t15
      });
      $[53] = T0;
      $[54] = t14;
      $[55] = t15;
      $[56] = t6;
      $[57] = t16;
    } else {
      t16 = $[57];
    }
    const t17 = String(inWeek.length);
    let t18;
    if ($[58] !== c.foreground || $[59] !== t17) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Stat, {
        label: "BETS",
        value: t17,
        color: c.foreground
      });
      $[58] = c.foreground;
      $[59] = t17;
      $[60] = t18;
    } else {
      t18 = $[60];
    }
    let t19;
    if ($[61] !== T1 || $[62] !== t16 || $[63] !== t18 || $[64] !== t7 || $[65] !== t8) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T1, {
        style: t7,
        children: [t8, t16, t18]
      });
      $[61] = T1;
      $[62] = t16;
      $[63] = t18;
      $[64] = t7;
      $[65] = t8;
      $[66] = t19;
    } else {
      t19 = $[66];
    }
    let t20;
    if ($[67] !== best || $[68] !== c.foreground || $[69] !== c.mutedForeground) {
      t20 = best ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.best, {
          color: c.mutedForeground
        }],
        numberOfLines: 1,
        children: ["Best hit: ", /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: {
            color: c.foreground,
            fontFamily: "Inter_700Bold"
          },
          children: best.label ?? best.teamName
        }), " +", (best.potentialPayout - best.stake).toLocaleString()]
      }) : null;
      $[67] = best;
      $[68] = c.foreground;
      $[69] = c.mutedForeground;
      $[70] = t20;
    } else {
      t20 = $[70];
    }
    let t21;
    if ($[71] !== c.mutedForeground || $[72] !== leagueLine) {
      t21 = leagueLine ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.best, {
          color: c.mutedForeground
        }],
        children: leagueLine
      }) : null;
      $[71] = c.mutedForeground;
      $[72] = leagueLine;
      $[73] = t21;
    } else {
      t21 = $[73];
    }
    let t22;
    if ($[74] !== share) {
      t22 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        label: "Share My Week",
        icon: "share-variant",
        size: "sm",
        variant: "secondary",
        onPress: share
      });
      $[74] = share;
      $[75] = t22;
    } else {
      t22 = $[75];
    }
    let t23;
    if ($[76] !== T2 || $[77] !== t10 || $[78] !== t19 || $[79] !== t20 || $[80] !== t21 || $[81] !== t22 || $[82] !== t9) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T2, {
        style: t9,
        children: [t10, t19, t20, t21, t22]
      });
      $[76] = T2;
      $[77] = t10;
      $[78] = t19;
      $[79] = t20;
      $[80] = t21;
      $[81] = t22;
      $[82] = t9;
      $[83] = t23;
    } else {
      t23 = $[83];
    }
    let t24;
    if ($[84] !== T3 || $[85] !== t11 || $[86] !== t12 || $[87] !== t23) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T3, {
        style: t11,
        children: [t12, t23]
      });
      $[84] = T3;
      $[85] = t11;
      $[86] = t12;
      $[87] = t23;
      $[88] = t24;
    } else {
      t24 = $[88];
    }
    return t24;
  }
  function _temp6() {}
  function _temp5(a, b_4) {
    return b_4.potentialPayout - b_4.stake - (a.potentialPayout - a.stake);
  }
  function _temp4(b_3) {
    return b_3.status === "won";
  }
  function _temp3(s, b_2) {
    return s + (b_2.status === "won" ? b_2.potentialPayout : b_2.status === "push" ? b_2.stake : 0) - b_2.stake;
  }
  function _temp2(b_1) {
    return b_1.status === "lost";
  }
  function _temp(b_0) {
    return b_0.status === "won";
  }
  function Stat(t0) {
    const $ = (0, _reactCompilerRuntime.c)(14);
    const {
      label,
      value,
      color
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    let t1;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = {
        flex: 1,
        alignItems: "center"
      };
      $[0] = t1;
    } else {
      t1 = $[0];
    }
    let t2;
    if ($[1] !== color) {
      t2 = [styles.value, {
        color
      }];
      $[1] = color;
      $[2] = t2;
    } else {
      t2 = $[2];
    }
    let t3;
    if ($[3] !== t2 || $[4] !== value) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t2,
        children: value
      });
      $[3] = t2;
      $[4] = value;
      $[5] = t3;
    } else {
      t3 = $[5];
    }
    let t4;
    if ($[6] !== c.mutedForeground) {
      t4 = [styles.label, {
        color: c.mutedForeground
      }];
      $[6] = c.mutedForeground;
      $[7] = t4;
    } else {
      t4 = $[7];
    }
    let t5;
    if ($[8] !== label || $[9] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t4,
        children: label
      });
      $[8] = label;
      $[9] = t4;
      $[10] = t5;
    } else {
      t5 = $[10];
    }
    let t6;
    if ($[11] !== t3 || $[12] !== t5) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t1,
        children: [t3, t5]
      });
      $[11] = t3;
      $[12] = t5;
      $[13] = t6;
    } else {
      t6 = $[13];
    }
    return t6;
  }
  const styles = StyleSheet.default.create({
    card: {
      borderRadius: 18,
      borderWidth: 1.5,
      padding: 14,
      gap: 10
    },
    head: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    kicker: {
      flex: 1,
      fontSize: 11,
      letterSpacing: 1.2,
      fontFamily: "Inter_800ExtraBold"
    },
    stats: {
      flexDirection: "row"
    },
    value: {
      fontSize: 22,
      fontFamily: "Inter_900Black",
      fontVariant: ["tabular-nums"]
    },
    label: {
      fontSize: 10,
      letterSpacing: 1,
      fontFamily: "Inter_700Bold"
    },
    best: {
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    }
  });
},887,[815,818,12,226,28,188,109,827,836,819,816,903,6]);