__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return SettingsScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _expoConstants = require(_dependencyMap[2]);
  var Constants = _interopDefault(_expoConstants);
  var _react = require(_dependencyMap[3]);
  require(_dependencyMap[4]);
  require(_dependencyMap[5]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[6]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[7]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[8]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[9]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[10]);
  var _componentsFavoriteTeamsSheet = require(_dependencyMap[11]);
  var FavoriteTeamsSheet = _interopDefault(_componentsFavoriteTeamsSheet);
  var _componentsPlayLimitsCard = require(_dependencyMap[12]);
  var PlayLimitsCard = _interopDefault(_componentsPlayLimitsCard);
  var _componentsUi = require(_dependencyMap[13]);
  var _contextAdsContext = require(_dependencyMap[14]);
  var _contextAppContext = require(_dependencyMap[15]);
  var _contextAuthContext = require(_dependencyMap[16]);
  var _hooksUseColors = require(_dependencyMap[17]);
  var _libSettings = require(_dependencyMap[18]);
  var _reactJsxRuntime = require(_dependencyMap[19]);
  /** Everything app-level: account, display, alerts & limits, notifications, help, privacy. */
  function SettingsScreen() {
    const $ = (0, _reactCompilerRuntime.c)(58);
    const c = (0, _hooksUseColors.useColors)();
    const bottom = (0, _componentsUi.useBottomPad)(false);
    const oddsFormat = (0, _libSettings.useOddsFormat)();
    const {
      profile
    } = (0, _contextAppContext.useApp)();
    const {
      signOut
    } = (0, _contextAuthContext.useAuth)();
    const {
      privacyOptionsRequired,
      openPrivacyOptions
    } = (0, _contextAdsContext.useAds)();
    const [editTeams, setEditTeams] = (0, _react.useState)(false);
    const [confirmOut, setConfirmOut] = (0, _react.useState)(false);
    const version = Constants.default.expoConfig?.version ?? "";
    let t0;
    if ($[0] !== c.background) {
      t0 = [styles.fill, {
        backgroundColor: c.background
      }];
      $[0] = c.background;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
        back: true,
        title: "Settings"
      });
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    let t2;
    if ($[3] !== bottom) {
      t2 = [styles.content, {
        paddingBottom: bottom
      }];
      $[3] = bottom;
      $[4] = t2;
    } else {
      t2 = $[4];
    }
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
        title: "Account"
      });
      $[5] = t3;
    } else {
      t3 = $[5];
    }
    const t4 = profile?.displayName ?? "Player";
    const t5 = profile?.username ? `@${profile.username}` : undefined;
    let t6;
    if ($[6] !== t4 || $[7] !== t5) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Card, {
        style: styles.card,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Row, {
          icon: "account-circle-outline",
          title: t4,
          sub: t5
        })
      });
      $[6] = t4;
      $[7] = t5;
      $[8] = t6;
    } else {
      t6 = $[8];
    }
    let t7;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
        title: "Display"
      });
      $[9] = t7;
    } else {
      t7 = $[9];
    }
    let t8;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
      t8 = [styles.card, {
        gap: 8,
        padding: 14
      }];
      $[10] = t8;
    } else {
      t8 = $[10];
    }
    let t9;
    if ($[11] !== c.foreground) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.rowTitle, {
          color: c.foreground
        }],
        children: "Odds Format"
      });
      $[11] = c.foreground;
      $[12] = t9;
    } else {
      t9 = $[12];
    }
    let t10;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
      t10 = [{
        value: "decimal",
        label: "Decimal (2.31x)"
      }, {
        value: "american",
        label: "American (+131)"
      }];
      $[13] = t10;
    } else {
      t10 = $[13];
    }
    let t11;
    if ($[14] !== oddsFormat) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SegmentedControl, {
        value: oddsFormat,
        onChange: _temp,
        options: t10
      });
      $[14] = oddsFormat;
      $[15] = t11;
    } else {
      t11 = $[15];
    }
    let t12;
    if ($[16] !== t11 || $[17] !== t9) {
      t12 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: t8,
        children: [t9, t11]
      });
      $[16] = t11;
      $[17] = t9;
      $[18] = t12;
    } else {
      t12 = $[18];
    }
    let t13;
    let t14;
    let t15;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
        title: "Alerts & Limits"
      });
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PlayLimitsCard.default, {});
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
        title: "Notifications"
      });
      $[19] = t13;
      $[20] = t14;
      $[21] = t15;
    } else {
      t13 = $[19];
      t14 = $[20];
      t15 = $[21];
    }
    let t16;
    let t17;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: styles.card,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Row, {
          icon: "heart-outline",
          title: "Favorite Teams & Game Reminders",
          onPress: () => setEditTeams(true)
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Divider, {}), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Row, {
          icon: "bell-cog-outline",
          title: "System Notification Settings",
          sub: "Turn push alerts on or off",
          onPress: _temp2
        })]
      });
      t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
        title: "Help & Privacy"
      });
      $[22] = t16;
      $[23] = t17;
    } else {
      t16 = $[22];
      t17 = $[23];
    }
    let t18;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Row, {
        icon: "compass-outline",
        title: "App Walkthrough",
        sub: "How betting, credits, leagues and chat work",
        onPress: _libSettings.openWalkthrough
      });
      $[24] = t18;
    } else {
      t18 = $[24];
    }
    let t19;
    if ($[25] !== openPrivacyOptions || $[26] !== privacyOptionsRequired) {
      t19 = privacyOptionsRequired ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Divider, {}), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Row, {
          icon: "shield-account-outline",
          title: "Privacy & Ad Choices",
          onPress: openPrivacyOptions
        })]
      }) : null;
      $[25] = openPrivacyOptions;
      $[26] = privacyOptionsRequired;
      $[27] = t19;
    } else {
      t19 = $[27];
    }
    let t20;
    if ($[28] !== t19) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: styles.card,
        children: [t18, t19]
      });
      $[28] = t19;
      $[29] = t20;
    } else {
      t20 = $[29];
    }
    let t21;
    if ($[30] === Symbol.for("react.memo_cache_sentinel")) {
      t21 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        label: "Sign Out",
        icon: "logout",
        variant: "destructive",
        onPress: () => setConfirmOut(true),
        style: {
          marginTop: 8
        }
      });
      $[30] = t21;
    } else {
      t21 = $[30];
    }
    let t22;
    if ($[31] !== c.subtleForeground) {
      t22 = version ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.version, {
          color: c.subtleForeground
        }],
        children: ["SportDrip v", version]
      }) : null;
      $[31] = c.subtleForeground;
      $[32] = t22;
    } else {
      t22 = $[32];
    }
    let t23;
    if ($[33] !== t12 || $[34] !== t2 || $[35] !== t20 || $[36] !== t22 || $[37] !== t6) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        contentContainerStyle: t2,
        showsVerticalScrollIndicator: true,
        children: [t3, t6, t7, t12, t13, t14, t15, t16, t17, t20, t21, t22]
      });
      $[33] = t12;
      $[34] = t2;
      $[35] = t20;
      $[36] = t22;
      $[37] = t6;
      $[38] = t23;
    } else {
      t23 = $[38];
    }
    let t24;
    if ($[39] !== profile?.favoriteTeams) {
      t24 = profile?.favoriteTeams ?? [];
      $[39] = profile?.favoriteTeams;
      $[40] = t24;
    } else {
      t24 = $[40];
    }
    const t25 = !!profile?.teamReminders;
    const t26 = profile?.uid;
    let t27;
    if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
      t27 = () => setEditTeams(false);
      $[41] = t27;
    } else {
      t27 = $[41];
    }
    let t28;
    if ($[42] !== editTeams || $[43] !== t24 || $[44] !== t25 || $[45] !== t26) {
      t28 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FavoriteTeamsSheet.default, {
        visible: editTeams,
        initial: t24,
        initialReminders: t25,
        uid: t26,
        onClose: t27
      });
      $[42] = editTeams;
      $[43] = t24;
      $[44] = t25;
      $[45] = t26;
      $[46] = t28;
    } else {
      t28 = $[46];
    }
    let t29;
    if ($[47] === Symbol.for("react.memo_cache_sentinel")) {
      t29 = () => setConfirmOut(false);
      $[47] = t29;
    } else {
      t29 = $[47];
    }
    let t30;
    if ($[48] !== signOut) {
      t30 = () => {
        setConfirmOut(false);
        signOut();
      };
      $[48] = signOut;
      $[49] = t30;
    } else {
      t30 = $[49];
    }
    let t31;
    if ($[50] !== confirmOut || $[51] !== t30) {
      t31 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ConfirmDialog, {
        visible: confirmOut,
        title: "Sign Out?",
        body: "You can sign back in any time. Your credits, outfits and leagues stay on your account.",
        confirmLabel: "Sign Out",
        destructive: true,
        onCancel: t29,
        onConfirm: t30
      });
      $[50] = confirmOut;
      $[51] = t30;
      $[52] = t31;
    } else {
      t31 = $[52];
    }
    let t32;
    if ($[53] !== t0 || $[54] !== t23 || $[55] !== t28 || $[56] !== t31) {
      t32 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t0,
        children: [t1, t23, t28, t31]
      });
      $[53] = t0;
      $[54] = t23;
      $[55] = t28;
      $[56] = t31;
      $[57] = t32;
    } else {
      t32 = $[57];
    }
    return t32;
  }
  function _temp2() {
    return void Promise.resolve();
  }
  function _temp(v) {
    return void (0, _libSettings.setOddsFormat)(v);
  }
  function Row(t0) {
    const $ = (0, _reactCompilerRuntime.c)(31);
    const {
      icon,
      title,
      sub,
      onPress
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    let t1;
    if ($[0] !== c.primary || $[1] !== icon) {
      t1 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: icon,
        size: 20,
        color: c.primary
      });
      $[0] = c.primary;
      $[1] = icon;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
      t2 = {
        flex: 1
      };
      $[3] = t2;
    } else {
      t2 = $[3];
    }
    let t3;
    if ($[4] !== c.foreground) {
      t3 = [styles.rowTitle, {
        color: c.foreground
      }];
      $[4] = c.foreground;
      $[5] = t3;
    } else {
      t3 = $[5];
    }
    let t4;
    if ($[6] !== t3 || $[7] !== title) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t3,
        children: title
      });
      $[6] = t3;
      $[7] = title;
      $[8] = t4;
    } else {
      t4 = $[8];
    }
    let t5;
    if ($[9] !== c.mutedForeground || $[10] !== sub) {
      t5 = sub ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.rowSub, {
          color: c.mutedForeground
        }],
        children: sub
      }) : null;
      $[9] = c.mutedForeground;
      $[10] = sub;
      $[11] = t5;
    } else {
      t5 = $[11];
    }
    let t6;
    if ($[12] !== t4 || $[13] !== t5) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t2,
        children: [t4, t5]
      });
      $[12] = t4;
      $[13] = t5;
      $[14] = t6;
    } else {
      t6 = $[14];
    }
    let t7;
    if ($[15] !== c.mutedForeground || $[16] !== onPress) {
      t7 = onPress ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "chevron-right",
        size: 20,
        color: c.mutedForeground
      }) : null;
      $[15] = c.mutedForeground;
      $[16] = onPress;
      $[17] = t7;
    } else {
      t7 = $[17];
    }
    let t8;
    if ($[18] !== t1 || $[19] !== t6 || $[20] !== t7) {
      t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [t1, t6, t7]
      });
      $[18] = t1;
      $[19] = t6;
      $[20] = t7;
      $[21] = t8;
    } else {
      t8 = $[21];
    }
    const body = t8;
    if (!onPress) {
      let t9;
      if ($[22] !== body) {
        t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: styles.row,
          children: body
        });
        $[22] = body;
        $[23] = t9;
      } else {
        t9 = $[23];
      }
      return t9;
    }
    let t9;
    if ($[24] !== c.secondary) {
      t9 = t10 => {
        const {
          pressed
        } = t10;
        return [styles.row, pressed && {
          backgroundColor: c.secondary
        }];
      };
      $[24] = c.secondary;
      $[25] = t9;
    } else {
      t9 = $[25];
    }
    let t10;
    if ($[26] !== body || $[27] !== onPress || $[28] !== t9 || $[29] !== title) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
        accessibilityRole: "button",
        accessibilityLabel: title,
        onPress: onPress,
        style: t9,
        children: body
      });
      $[26] = body;
      $[27] = onPress;
      $[28] = t9;
      $[29] = title;
      $[30] = t10;
    } else {
      t10 = $[30];
    }
    return t10;
  }
  function Divider() {
    const $ = (0, _reactCompilerRuntime.c)(2);
    const c = (0, _hooksUseColors.useColors)();
    let t0;
    if ($[0] !== c.border) {
      t0 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: {
          height: StyleSheet.default.hairlineWidth,
          backgroundColor: c.border,
          marginLeft: 46
        }
      });
      $[0] = c.border;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    return t0;
  }
  const styles = StyleSheet.default.create({
    fill: {
      flex: 1
    },
    content: {
      padding: 16,
      gap: 12
    },
    card: {
      padding: 0,
      overflow: "hidden"
    },
    row: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      paddingHorizontal: 14,
      paddingVertical: 13
    },
    rowTitle: {
      fontSize: 15,
      fontFamily: "Inter_600SemiBold"
    },
    rowSub: {
      fontSize: 12,
      fontFamily: "Inter_400Regular",
      marginTop: 1
    },
    version: {
      fontSize: 12,
      fontFamily: "Inter_500Medium",
      textAlign: "center",
      marginTop: 4
    }
  });
},775,[815,818,391,12,221,104,133,28,188,109,827,831,1267,836,857,837,1190,819,816,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      if (k === 'default') return;
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return PlayLimitsCard;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[3]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[4]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[5]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsUi = require(_dependencyMap[6]);
  var _contextAppContext = require(_dependencyMap[7]);
  var _hooksUseColors = require(_dependencyMap[8]);
  var _libApi = require(_dependencyMap[9]);
  var api = _interopNamespace(_libApi);
  var _libMotion = require(_dependencyMap[10]);
  var _reactJsxRuntime = require(_dependencyMap[11]);
  const CAPS = [null, 5, 10, 20];

  /** Optional limits: a daily pick cap and "take a break". Enforced on the server. */
  function PlayLimitsCard() {
    const $ = (0, _reactCompilerRuntime.c)(69);
    const c = (0, _hooksUseColors.useColors)();
    const {
      profile,
      writeProfile
    } = (0, _contextAppContext.useApp)();
    const cap = profile?.limits?.dailyPicks ?? null;
    const breakUntil = profile?.limits?.breakUntil ?? 0;
    const onBreak = breakUntil > Date.now();
    const [busy] = (0, _react.useState)(false);
    const [err, setErr] = (0, _react.useState)(null);
    let t0;
    if ($[0] !== profile?.limits || $[1] !== writeProfile) {
      t0 = args => {
        setErr(null);
        const limits = {
          ...(profile?.limits ?? {})
        };
        if ("dailyPicks" in args) {
          limits.dailyPicks = args.dailyPicks ?? null;
        }
        if (args.breakDays) {
          limits.breakUntil = Date.now() + args.breakDays * 86400000;
        }
        writeProfile({
          limits
        }, () => api.setPlayLimits(args));
        _libMotion.haptic.success();
      };
      $[0] = profile?.limits;
      $[1] = writeProfile;
      $[2] = t0;
    } else {
      t0 = $[2];
    }
    const run = t0;
    let t1;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = {
        gap: 10
      };
      $[3] = t1;
    } else {
      t1 = $[3];
    }
    let t2;
    if ($[4] !== c.accent) {
      t2 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "timer-sand",
        size: 18,
        color: c.accent
      });
      $[4] = c.accent;
      $[5] = t2;
    } else {
      t2 = $[5];
    }
    let t3;
    if ($[6] !== c.foreground) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.title, {
          color: c.foreground
        }],
        children: "Alerts & Limits"
      });
      $[6] = c.foreground;
      $[7] = t3;
    } else {
      t3 = $[7];
    }
    let t4;
    if ($[8] !== t2 || $[9] !== t3) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.head,
        children: [t2, t3]
      });
      $[8] = t2;
      $[9] = t3;
      $[10] = t4;
    } else {
      t4 = $[10];
    }
    let t5;
    if ($[11] !== c.mutedForeground) {
      t5 = [styles.sub, {
        color: c.mutedForeground
      }];
      $[11] = c.mutedForeground;
      $[12] = t5;
    } else {
      t5 = $[12];
    }
    let t6;
    if ($[13] !== breakUntil || $[14] !== cap || $[15] !== onBreak) {
      t6 = onBreak ? `On a break until ${new Date(breakUntil).toLocaleDateString()}.` : `Daily pick limit: ${cap ?? "none"}.`;
      $[13] = breakUntil;
      $[14] = cap;
      $[15] = onBreak;
      $[16] = t6;
    } else {
      t6 = $[16];
    }
    let t7;
    if ($[17] !== t5 || $[18] !== t6) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t5,
        children: t6
      });
      $[17] = t5;
      $[18] = t6;
      $[19] = t7;
    } else {
      t7 = $[19];
    }
    let t8;
    if ($[20] !== busy || $[21] !== cap || $[22] !== run) {
      t8 = CAPS.map(v => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
        label: v === null ? "No limit" : `${v}/day`,
        chevron: false,
        tone: cap === v ? "accent" : "neutral",
        disabled: busy || cap === v,
        onPress: () => run({
          dailyPicks: v
        })
      }, String(v)));
      $[20] = busy;
      $[21] = cap;
      $[22] = run;
      $[23] = t8;
    } else {
      t8 = $[23];
    }
    let t9;
    if ($[24] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.row,
        children: t8
      });
      $[24] = t8;
      $[25] = t9;
    } else {
      t9 = $[25];
    }
    let t10;
    if ($[26] !== busy || $[27] !== onBreak || $[28] !== run) {
      t10 = !onBreak ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.row,
        children: [1, 7, 30].map(d => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
          label: `Break ${d}d`,
          icon: "pause-circle-outline",
          chevron: false,
          disabled: busy,
          onPress: () => run({
            breakDays: d
          })
        }, d))
      }) : null;
      $[26] = busy;
      $[27] = onBreak;
      $[28] = run;
      $[29] = t10;
    } else {
      t10 = $[29];
    }
    const t11 = profile?.sweatAlerts ? "Live sweat alerts: on" : "Live sweat alerts: off";
    const t12 = profile?.sweatAlerts ? "accent" : "neutral";
    let t13;
    if ($[30] !== profile?.sweatAlerts || $[31] !== writeProfile) {
      t13 = () => {
        writeProfile({
          sweatAlerts: !profile?.sweatAlerts
        }, () => api.setAlertPrefs({
          sweat: !profile?.sweatAlerts
        }));
        _libMotion.haptic.tick();
      };
      $[30] = profile?.sweatAlerts;
      $[31] = writeProfile;
      $[32] = t13;
    } else {
      t13 = $[32];
    }
    let t14;
    if ($[33] !== busy || $[34] !== t11 || $[35] !== t12 || $[36] !== t13) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
        label: t11,
        icon: "fire",
        chevron: false,
        tone: t12,
        disabled: busy,
        onPress: t13
      });
      $[33] = busy;
      $[34] = t11;
      $[35] = t12;
      $[36] = t13;
      $[37] = t14;
    } else {
      t14 = $[37];
    }
    const t15 = profile?.quietHours === false ? "Quiet hours: off" : "Quiet hours: 11pm\u20138am";
    const t16 = profile?.quietHours === false ? "neutral" : "accent";
    const t17 = profile?.quietHours === false ? "Turn quiet hours on" : "Turn quiet hours off";
    let t18;
    if ($[38] !== profile?.quietHours || $[39] !== writeProfile) {
      t18 = () => {
        writeProfile({
          quietHours: profile?.quietHours === false
        }, () => api.setAlertPrefs({
          quietHours: profile?.quietHours === false
        }));
        _libMotion.haptic.tick();
      };
      $[38] = profile?.quietHours;
      $[39] = writeProfile;
      $[40] = t18;
    } else {
      t18 = $[40];
    }
    let t19;
    if ($[41] !== busy || $[42] !== t15 || $[43] !== t16 || $[44] !== t17 || $[45] !== t18) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
        label: t15,
        icon: "weather-night",
        chevron: false,
        tone: t16,
        disabled: busy,
        accessibilityLabel: t17,
        onPress: t18
      });
      $[41] = busy;
      $[42] = t15;
      $[43] = t16;
      $[44] = t17;
      $[45] = t18;
      $[46] = t19;
    } else {
      t19 = $[46];
    }
    const t20 = profile?.muteTaunts ? "Taunts: muted" : "Taunts: on";
    const t21 = profile?.muteTaunts ? "neutral" : "accent";
    let t22;
    if ($[47] !== profile?.muteTaunts || $[48] !== writeProfile) {
      t22 = () => {
        writeProfile({
          muteTaunts: !profile?.muteTaunts
        }, () => api.setMuteTaunts({
          mute: !profile?.muteTaunts
        }));
        _libMotion.haptic.tick();
      };
      $[47] = profile?.muteTaunts;
      $[48] = writeProfile;
      $[49] = t22;
    } else {
      t22 = $[49];
    }
    let t23;
    if ($[50] !== busy || $[51] !== t20 || $[52] !== t21 || $[53] !== t22) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
        label: t20,
        icon: "human-handsup",
        chevron: false,
        tone: t21,
        disabled: busy,
        onPress: t22
      });
      $[50] = busy;
      $[51] = t20;
      $[52] = t21;
      $[53] = t22;
      $[54] = t23;
    } else {
      t23 = $[54];
    }
    let t24;
    if ($[55] !== t14 || $[56] !== t19 || $[57] !== t23) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.row,
        children: [t14, t19, t23]
      });
      $[55] = t14;
      $[56] = t19;
      $[57] = t23;
      $[58] = t24;
    } else {
      t24 = $[58];
    }
    let t25;
    if ($[59] !== c.negative || $[60] !== err) {
      t25 = err ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.sub, {
          color: c.negative
        }],
        children: err
      }) : null;
      $[59] = c.negative;
      $[60] = err;
      $[61] = t25;
    } else {
      t25 = $[61];
    }
    let t26;
    if ($[62] !== t10 || $[63] !== t24 || $[64] !== t25 || $[65] !== t4 || $[66] !== t7 || $[67] !== t9) {
      t26 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: t1,
        accessibilityLabel: "Play limits",
        children: [t4, t7, t9, t10, t24, t25]
      });
      $[62] = t10;
      $[63] = t24;
      $[64] = t25;
      $[65] = t4;
      $[66] = t7;
      $[67] = t9;
      $[68] = t26;
    } else {
      t26 = $[68];
    }
    return t26;
  }
  const styles = StyleSheet.default.create({
    head: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    title: {
      fontSize: 15,
      fontFamily: "Inter_800ExtraBold"
    },
    sub: {
      fontSize: 13,
      fontFamily: "Inter_400Regular"
    },
    row: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 8
    }
  });
},1267,[815,818,12,28,188,109,836,837,819,863,820,6]);