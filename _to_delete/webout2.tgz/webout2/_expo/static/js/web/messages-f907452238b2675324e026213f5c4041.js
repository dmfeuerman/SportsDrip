__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return MessagesScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _libMotion = require(_dependencyMap[2]);
  var _expoRouter = require(_dependencyMap[3]);
  var _react = require(_dependencyMap[4]);
  var _reactNativeWebDistExportsFlatList = require(_dependencyMap[5]);
  var FlatList = _interopDefault(_reactNativeWebDistExportsFlatList);
  var _reactNativeWebDistExportsKeyboardAvoidingView = require(_dependencyMap[6]);
  var KeyboardAvoidingView = _interopDefault(_reactNativeWebDistExportsKeyboardAvoidingView);
  require(_dependencyMap[7]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[8]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[9]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[10]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsTextInput = require(_dependencyMap[11]);
  var TextInput = _interopDefault(_reactNativeWebDistExportsTextInput);
  var _reactNativeWebDistExportsView = require(_dependencyMap[12]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[13]);
  var _reactNativeSafeAreaContext = require(_dependencyMap[14]);
  var _componentsChatReplyThread = require(_dependencyMap[15]);
  var _componentsChatBetChatCard = require(_dependencyMap[16]);
  var BetChatCard = _interopDefault(_componentsChatBetChatCard);
  var _componentsChatTauntCard = require(_dependencyMap[17]);
  var TauntCard = _interopDefault(_componentsChatTauntCard);
  var _componentsGameQuickView = require(_dependencyMap[18]);
  var GameQuickView = _interopDefault(_componentsGameQuickView);
  var _componentsMemberAvatar = require(_dependencyMap[19]);
  var MemberAvatar = _interopDefault(_componentsMemberAvatar);
  var _componentsPlayerProfileSheet = require(_dependencyMap[20]);
  var PlayerProfileSheet = _interopDefault(_componentsPlayerProfileSheet);
  var _componentsUi = require(_dependencyMap[21]);
  var _contextAppContext = require(_dependencyMap[22]);
  var _contextChatContext = require(_dependencyMap[23]);
  var _contextLeagueContext = require(_dependencyMap[24]);
  var _hooksUseCatalog = require(_dependencyMap[25]);
  var _hooksUseColors = require(_dependencyMap[26]);
  var _hooksUseFriends = require(_dependencyMap[27]);
  var _hooksUseNow = require(_dependencyMap[28]);
  var _libChatText = require(_dependencyMap[29]);
  var _libDemo = require(_dependencyMap[30]);
  var _libSettings = require(_dependencyMap[31]);
  var _firebaseFirestore = require(_dependencyMap[32]);
  var _libFirebase = require(_dependencyMap[33]);
  var _componentsChatReactionRow = require(_dependencyMap[34]);
  var ReactionRow = _interopDefault(_componentsChatReactionRow);
  var _reactJsxRuntime = require(_dependencyMap[35]);
  /** Sets, switches or clears my one reaction on a DM (rules allow only my own key). */async function reactToDm(m, uid, emoji) {
    const db = (0, _libFirebase.getDb)();
    if (!db || _libDemo.DEMO) return null;
    const same = m.reactors?.[uid] === emoji;
    try {
      await (0, _firebaseFirestore.updateDoc)((0, _firebaseFirestore.doc)(db, "directMessages", m.threadId, "messages", m.id), {
        [`reactors.${uid}`]: same ? (0, _firebaseFirestore.deleteField)() : emoji
      });
      return null;
    } catch {
      return "Couldn't react. Try again.";
    }
  }
  function formatClock(at) {
    return new Date(at).toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit"
    });
  }

  /**
   * Global Direct & League Messaging Center (/messages).
   *
   * Implements the standard messaging app pattern:
   *  - Switch between Direct Messages (DMs) with friends and League Chat rooms.
   *  - FlatList oriented with the newest messages at the bottom.
   *  - Fixed input message box anchored to the bottom with a send button.
   *  - KeyboardAvoidingView so the input is never obscured by the iOS/Android keyboard.
   *  - Inline reply threads with quoted parent bubble and curved stem.
   *  - Tapping any friend's name or avatar opens PlayerProfileSheet with Challenge & Invite actions.
   */
  function MessagesScreen() {
    const $ = (0, _reactCompilerRuntime.c)(184);
    const c = (0, _hooksUseColors.useColors)();
    const insets = (0, _reactNativeSafeAreaContext.useSafeAreaInsets)();
    const params = (0, _expoRouter.useLocalSearchParams)();
    const {
      profile
    } = (0, _contextAppContext.useApp)();
    const {
      byId
    } = (0, _hooksUseCatalog.useCatalog)();
    const myUid = profile?.uid ?? "me";
    const {
      friends: liveFriends
    } = (0, _hooksUseFriends.useFriends)(profile?.uid ?? null);
    let t0;
    if ($[0] !== liveFriends) {
      t0 = liveFriends.length > 0 ? liveFriends : _libDemo.DEMO ? _libDemo.demoFriends : [];
      $[0] = liveFriends;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    const friends = t0;
    const {
      leagues,
      sendMessage: sendLeagueMessage,
      reactToItem
    } = (0, _contextLeagueContext.useLeague)();
    const {
      threadIdFor,
      dmMessagesByThread,
      sendDirectMessage,
      leagueReplyQuotes,
      recordLeagueMessageQuote,
      unreadForFriend,
      unreadDmCount,
      unreadLeagueCount,
      markThreadRead,
      setActiveChatId
    } = (0, _contextChatContext.useChat)();
    const chatSeen = (0, _libSettings.useAllChatSeen)();
    const [mode, setMode] = (0, _react.useState)(params.leagueId ? "league" : "dm");
    const [selectedFriendUid, setSelectedFriendUid] = (0, _react.useState)(params.uid ?? friends[0]?.uid ?? null);
    const [selectedLeagueId, setSelectedLeagueId] = (0, _react.useState)(params.leagueId ?? leagues[0]?.id ?? null);
    const [replyQuote, setReplyQuote] = (0, _react.useState)(null);
    const [text, setText] = (0, _react.useState)("");
    const [sending, setSending] = (0, _react.useState)(false);
    const [profileUid, setProfileUid] = (0, _react.useState)(null);
    const [quickGame, setQuickGame] = (0, _react.useState)(null);
    const [follow, setFollow] = (0, _react.useState)(null);
    const now = (0, _hooksUseNow.useNow)(30000);
    const listRef = (0, _react.useRef)(null);
    let t1;
    let t2;
    if ($[2] !== params.leagueId || $[3] !== params.uid) {
      t1 = () => {
        if (params.uid) {
          setMode("dm");
          setSelectedFriendUid(params.uid);
        } else {
          if (params.leagueId) {
            setMode("league");
            setSelectedLeagueId(params.leagueId);
          }
        }
      };
      t2 = [params.uid, params.leagueId];
      $[2] = params.leagueId;
      $[3] = params.uid;
      $[4] = t1;
      $[5] = t2;
    } else {
      t1 = $[4];
      t2 = $[5];
    }
    (0, _react.useEffect)(t1, t2);
    let t3;
    if ($[6] !== friends[0] || $[7] !== selectedFriendUid) {
      t3 = () => {
        if (!selectedFriendUid && friends[0]?.uid) {
          setSelectedFriendUid(friends[0].uid);
        }
      };
      $[6] = friends[0];
      $[7] = selectedFriendUid;
      $[8] = t3;
    } else {
      t3 = $[8];
    }
    let t4;
    if ($[9] !== friends || $[10] !== selectedFriendUid) {
      t4 = [friends, selectedFriendUid];
      $[9] = friends;
      $[10] = selectedFriendUid;
      $[11] = t4;
    } else {
      t4 = $[11];
    }
    (0, _react.useEffect)(t3, t4);
    let t5;
    if ($[12] !== leagues[0] || $[13] !== selectedLeagueId) {
      t5 = () => {
        if (!selectedLeagueId && leagues[0]?.id) {
          setSelectedLeagueId(leagues[0].id);
        }
      };
      $[12] = leagues[0];
      $[13] = selectedLeagueId;
      $[14] = t5;
    } else {
      t5 = $[14];
    }
    let t6;
    if ($[15] !== leagues || $[16] !== selectedLeagueId) {
      t6 = [leagues, selectedLeagueId];
      $[15] = leagues;
      $[16] = selectedLeagueId;
      $[17] = t6;
    } else {
      t6 = $[17];
    }
    (0, _react.useEffect)(t5, t6);
    profile?.avatar;
    let t7;
    if ($[18] !== friends || $[19] !== params.name || $[20] !== profile?.avatar || $[21] !== selectedFriendUid) {
      t7 = friends.find(f => f.uid === selectedFriendUid) ?? (selectedFriendUid && params.name ? {
        uid: selectedFriendUid,
        username: selectedFriendUid,
        displayName: params.name,
        avatar: profile?.avatar,
        equipped: {}
      } : null);
      $[18] = friends;
      $[19] = params.name;
      $[20] = profile?.avatar;
      $[21] = selectedFriendUid;
      $[22] = t7;
    } else {
      t7 = $[22];
    }
    const activeFriend = t7;
    let t8;
    if ($[23] !== leagues || $[24] !== selectedLeagueId) {
      let t9;
      if ($[26] !== selectedLeagueId) {
        t9 = l => l.id === selectedLeagueId;
        $[26] = selectedLeagueId;
        $[27] = t9;
      } else {
        t9 = $[27];
      }
      t8 = leagues.find(t9);
      $[23] = leagues;
      $[24] = selectedLeagueId;
      $[25] = t8;
    } else {
      t8 = $[25];
    }
    const activeLeague = t8;
    const leagueDetail = (0, _contextLeagueContext.useLeagueDetail)(mode === "league" ? activeLeague : undefined);
    let t9;
    if ($[28] !== mode || $[29] !== selectedFriendUid || $[30] !== selectedLeagueId || $[31] !== threadIdFor) {
      t9 = mode === "dm" && selectedFriendUid ? threadIdFor(selectedFriendUid) : mode === "league" && selectedLeagueId ? selectedLeagueId : null;
      $[28] = mode;
      $[29] = selectedFriendUid;
      $[30] = selectedLeagueId;
      $[31] = threadIdFor;
      $[32] = t9;
    } else {
      t9 = $[32];
    }
    const activeThreadId = t9;
    let t10;
    let t11;
    if ($[33] !== activeThreadId || $[34] !== markThreadRead || $[35] !== setActiveChatId) {
      t10 = () => {
        setActiveChatId(activeThreadId);
        if (activeThreadId) {
          markThreadRead(activeThreadId);
        }
        return () => setActiveChatId(null);
      };
      t11 = [activeThreadId, markThreadRead, setActiveChatId];
      $[33] = activeThreadId;
      $[34] = markThreadRead;
      $[35] = setActiveChatId;
      $[36] = t10;
      $[37] = t11;
    } else {
      t10 = $[36];
      t11 = $[37];
    }
    (0, _react.useEffect)(t10, t11);
    let t12;
    bb0: {
      if (!selectedFriendUid) {
        let t13;
        if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
          t13 = [];
          $[38] = t13;
        } else {
          t13 = $[38];
        }
        t12 = t13;
        break bb0;
      }
      let t13;
      if ($[39] !== selectedFriendUid || $[40] !== threadIdFor) {
        t13 = threadIdFor(selectedFriendUid);
        $[39] = selectedFriendUid;
        $[40] = threadIdFor;
        $[41] = t13;
      } else {
        t13 = $[41];
      }
      const tId = t13;
      let t14;
      if ($[42] !== dmMessagesByThread || $[43] !== tId) {
        t14 = (dmMessagesByThread[tId] ?? []).slice().sort(_temp);
        $[42] = dmMessagesByThread;
        $[43] = tId;
        $[44] = t14;
      } else {
        t14 = $[44];
      }
      t12 = t14;
    }
    const dmMessages = t12;
    let t13;
    bb1: {
      if (mode !== "league") {
        let t14;
        if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
          t14 = [];
          $[45] = t14;
        } else {
          t14 = $[45];
        }
        t13 = t14;
        break bb1;
      }
      let t14;
      if ($[46] !== leagueDetail.messages) {
        t14 = leagueDetail.messages.slice().sort(_temp2);
        $[46] = leagueDetail.messages;
        $[47] = t14;
      } else {
        t14 = $[47];
      }
      t13 = t14;
    }
    const leagueMessages = t13;
    let counts;
    if ($[48] !== dmMessages || $[49] !== leagueMessages || $[50] !== leagueReplyQuotes || $[51] !== mode) {
      counts = {};
      if (mode === "dm") {
        for (const m of dmMessages) {
          if (m.replyTo?.id) {
            counts[m.replyTo.id] = (counts[m.replyTo.id] ?? 0) + 1;
          }
        }
      } else {
        for (const m_0 of leagueMessages) {
          const q = m_0.replyTo ?? leagueReplyQuotes[m_0.id];
          if (q?.id) {
            counts[q.id] = (counts[q.id] ?? 0) + 1;
          }
        }
      }
      $[48] = dmMessages;
      $[49] = leagueMessages;
      $[50] = leagueReplyQuotes;
      $[51] = mode;
      $[52] = counts;
    } else {
      counts = $[52];
    }
    const replyCountByParentId = counts;
    let t14;
    if ($[53] !== activeFriend || $[54] !== activeLeague || $[55] !== mode || $[56] !== recordLeagueMessageQuote || $[57] !== replyQuote || $[58] !== sendDirectMessage || $[59] !== sendLeagueMessage || $[60] !== sending || $[61] !== text) {
      t14 = async () => {
        const body = text.trim();
        if (!body || sending) {
          return;
        }
        setSending(true);
        _libMotion.haptic.light();
        const sentQuote = replyQuote;
        setText("");
        setReplyQuote(null);
        setTimeout(() => listRef.current?.scrollToEnd({
          animated: true
        }), 60);
        const restore = () => {
          setText(cur => cur || body);
          setReplyQuote(cur_0 => cur_0 ?? sentQuote);
        };
        if (mode === "dm" && activeFriend) {
          setSending(false);
          const err = await sendDirectMessage(activeFriend.uid, activeFriend.displayName, body, sentQuote);
          if (err) {
            restore();
          }
        } else {
          if (mode === "league" && activeLeague) {
            const quote = sentQuote ? Object.fromEntries(Object.entries(sentQuote).filter(_temp3)) : null;
            (0, _libSettings.markChatSeen)(activeLeague.id, Date.now());
            setSending(false);
            const err_0 = await sendLeagueMessage(activeLeague.id, body, quote);
            if (err_0) {
              restore();
            } else {
              if (sentQuote) {
                recordLeagueMessageQuote(`latest_${Date.now()}`, sentQuote);
              }
            }
          } else {
            setSending(false);
          }
        }
      };
      $[53] = activeFriend;
      $[54] = activeLeague;
      $[55] = mode;
      $[56] = recordLeagueMessageQuote;
      $[57] = replyQuote;
      $[58] = sendDirectMessage;
      $[59] = sendLeagueMessage;
      $[60] = sending;
      $[61] = text;
      $[62] = t14;
    } else {
      t14 = $[62];
    }
    const handleSend = t14;
    const topPad = 24;
    let t15;
    if ($[63] !== c.background) {
      t15 = [styles.container, {
        backgroundColor: c.background
      }];
      $[63] = c.background;
      $[64] = t15;
    } else {
      t15 = $[64];
    }
    const t16 = 32;
    let t17;
    if ($[65] !== c.background || $[66] !== c.border || $[67] !== t16) {
      t17 = [styles.header, {
        paddingTop: t16,
        borderBottomColor: c.border,
        backgroundColor: c.background
      }];
      $[65] = c.background;
      $[66] = c.border;
      $[67] = t16;
      $[68] = t17;
    } else {
      t17 = $[68];
    }
    let t18;
    if ($[69] === Symbol.for("react.memo_cache_sentinel")) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.BackButton, {});
      $[69] = t18;
    } else {
      t18 = $[69];
    }
    let t19;
    if ($[70] === Symbol.for("react.memo_cache_sentinel")) {
      t19 = {
        flex: 1
      };
      $[70] = t19;
    } else {
      t19 = $[70];
    }
    let t20;
    if ($[71] !== c.foreground) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.headerTitle, {
          color: c.foreground
        }],
        children: "Messages"
      });
      $[71] = c.foreground;
      $[72] = t20;
    } else {
      t20 = $[72];
    }
    let t21;
    if ($[73] !== c.mutedForeground) {
      t21 = [styles.headerSub, {
        color: c.mutedForeground
      }];
      $[73] = c.mutedForeground;
      $[74] = t21;
    } else {
      t21 = $[74];
    }
    let t22;
    if ($[75] !== activeFriend || $[76] !== activeLeague || $[77] !== mode) {
      t22 = mode === "dm" ? activeFriend ? `Direct chat with ${activeFriend.displayName}` : "Direct messages with friends" : activeLeague ? `${activeLeague.name} · ${Object.keys(activeLeague.members ?? {}).length} members` : "League chat rooms";
      $[75] = activeFriend;
      $[76] = activeLeague;
      $[77] = mode;
      $[78] = t22;
    } else {
      t22 = $[78];
    }
    let t23;
    if ($[79] !== t21 || $[80] !== t22) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t21,
        numberOfLines: 1,
        children: t22
      });
      $[79] = t21;
      $[80] = t22;
      $[81] = t23;
    } else {
      t23 = $[81];
    }
    let t24;
    if ($[82] !== t20 || $[83] !== t23) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t19,
        children: [t20, t23]
      });
      $[82] = t20;
      $[83] = t23;
      $[84] = t24;
    } else {
      t24 = $[84];
    }
    let t25;
    if ($[85] !== activeFriend || $[86] !== activeLeague || $[87] !== c.border || $[88] !== c.foreground || $[89] !== c.league || $[90] !== c.leagueSoft || $[91] !== c.primary || $[92] !== c.secondary || $[93] !== mode) {
      t25 = mode === "dm" && activeFriend ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        accessibilityRole: "button",
        accessibilityLabel: `Open ${activeFriend.displayName}'s profile`,
        onPress: () => setProfileUid(activeFriend.uid),
        style: [styles.profileBtn, {
          backgroundColor: c.secondary,
          borderColor: c.border
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "account-details-outline",
          size: 16,
          color: c.primary
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.profileBtnText, {
            color: c.foreground
          }],
          children: "Profile"
        })]
      }) : mode === "league" && activeLeague ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        accessibilityRole: "button",
        accessibilityLabel: `Open ${activeLeague.name}`,
        onPress: () => _expoRouter.router.push({
          pathname: "/league/[id]",
          params: {
            id: activeLeague.id
          }
        }),
        style: [styles.profileBtn, {
          backgroundColor: c.leagueSoft,
          borderColor: c.league
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "trophy-outline",
          size: 16,
          color: c.league
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.profileBtnText, {
            color: c.foreground
          }],
          children: "League"
        })]
      }) : null;
      $[85] = activeFriend;
      $[86] = activeLeague;
      $[87] = c.border;
      $[88] = c.foreground;
      $[89] = c.league;
      $[90] = c.leagueSoft;
      $[91] = c.primary;
      $[92] = c.secondary;
      $[93] = mode;
      $[94] = t25;
    } else {
      t25 = $[94];
    }
    let t26;
    if ($[95] !== t24 || $[96] !== t25) {
      t26 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.headerTop,
        children: [t18, t24, t25]
      });
      $[95] = t24;
      $[96] = t25;
      $[97] = t26;
    } else {
      t26 = $[97];
    }
    let t27;
    if ($[98] === Symbol.for("react.memo_cache_sentinel")) {
      t27 = m_1 => {
        setMode(m_1);
        setReplyQuote(null);
      };
      $[98] = t27;
    } else {
      t27 = $[98];
    }
    const t28 = unreadDmCount || undefined;
    let t29;
    if ($[99] !== t28) {
      t29 = {
        value: "dm",
        label: "Direct Messages",
        badge: t28
      };
      $[99] = t28;
      $[100] = t29;
    } else {
      t29 = $[100];
    }
    const t30 = unreadLeagueCount || undefined;
    let t31;
    if ($[101] !== t30) {
      t31 = {
        value: "league",
        label: "League Chats",
        badge: t30
      };
      $[101] = t30;
      $[102] = t31;
    } else {
      t31 = $[102];
    }
    let t32;
    if ($[103] !== t29 || $[104] !== t31) {
      t32 = [t29, t31];
      $[103] = t29;
      $[104] = t31;
      $[105] = t32;
    } else {
      t32 = $[105];
    }
    let t33;
    if ($[106] !== mode || $[107] !== t32) {
      t33 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.TabStrip, {
        bleed: false,
        value: mode,
        onChange: t27,
        options: t32
      });
      $[106] = mode;
      $[107] = t32;
      $[108] = t33;
    } else {
      t33 = $[108];
    }
    let t34;
    if ($[109] !== byId || $[110] !== c.border || $[111] !== c.foreground || $[112] !== c.league || $[113] !== c.leagueSoft || $[114] !== c.mutedForeground || $[115] !== c.negative || $[116] !== c.primary || $[117] !== c.primarySoft || $[118] !== c.secondary || $[119] !== chatSeen || $[120] !== friends || $[121] !== leagues || $[122] !== mode || $[123] !== selectedFriendUid || $[124] !== selectedLeagueId || $[125] !== unreadForFriend) {
      t34 = mode === "dm" ? friends.length > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ScrollView.default, {
        horizontal: true,
        showsHorizontalScrollIndicator: false,
        contentContainerStyle: styles.roomStrip,
        children: friends.map(f_0 => {
          const active = f_0.uid === selectedFriendUid;
          const unread = unreadForFriend(f_0.uid);
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
            accessibilityRole: "button",
            accessibilityState: {
              selected: active
            },
            onPress: () => {
              setSelectedFriendUid(f_0.uid);
              setReplyQuote(null);
            },
            style: [styles.roomChip, {
              backgroundColor: active ? c.primarySoft : c.secondary,
              borderColor: active ? c.primary : c.border
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(MemberAvatar.default, {
              profile: f_0,
              name: f_0.displayName,
              color: c.primary,
              catalog: byId,
              size: 26
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.roomChipText, {
                color: active ? c.foreground : c.mutedForeground
              }],
              numberOfLines: 1,
              children: f_0.displayName
            }), unread > 0 && !active ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.unreadDot, {
                backgroundColor: c.negative
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: styles.unreadDotText,
                children: unread
              })
            }) : null]
          }, f_0.uid);
        })
      }) : null : leagues.length > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ScrollView.default, {
        horizontal: true,
        showsHorizontalScrollIndicator: false,
        contentContainerStyle: styles.roomStrip,
        children: leagues.map(l_0 => {
          const active_0 = l_0.id === selectedLeagueId;
          const seen = chatSeen[l_0.id] ?? 0;
          const hasNew = (l_0.lastActivityAt ?? 0) > seen && !active_0;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
            accessibilityRole: "button",
            accessibilityState: {
              selected: active_0
            },
            onPress: () => {
              setSelectedLeagueId(l_0.id);
              setReplyQuote(null);
            },
            style: [styles.roomChip, {
              backgroundColor: active_0 ? c.leagueSoft : c.secondary,
              borderColor: active_0 ? c.league : c.border
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "trophy-outline",
              size: 15,
              color: active_0 ? c.league : c.mutedForeground
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.roomChipText, {
                color: active_0 ? c.foreground : c.mutedForeground
              }],
              numberOfLines: 1,
              children: l_0.name
            }), hasNew ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.dotOnly, {
                backgroundColor: c.league
              }]
            }) : null]
          }, l_0.id);
        })
      }) : null;
      $[109] = byId;
      $[110] = c.border;
      $[111] = c.foreground;
      $[112] = c.league;
      $[113] = c.leagueSoft;
      $[114] = c.mutedForeground;
      $[115] = c.negative;
      $[116] = c.primary;
      $[117] = c.primarySoft;
      $[118] = c.secondary;
      $[119] = chatSeen;
      $[120] = friends;
      $[121] = leagues;
      $[122] = mode;
      $[123] = selectedFriendUid;
      $[124] = selectedLeagueId;
      $[125] = unreadForFriend;
      $[126] = t34;
    } else {
      t34 = $[126];
    }
    let t35;
    if ($[127] !== t17 || $[128] !== t26 || $[129] !== t33 || $[130] !== t34) {
      t35 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t17,
        children: [t26, t33, t34]
      });
      $[127] = t17;
      $[128] = t26;
      $[129] = t33;
      $[130] = t34;
      $[131] = t35;
    } else {
      t35 = $[131];
    }
    let t36;
    if ($[132] !== activeFriend || $[133] !== activeLeague || $[134] !== c.border || $[135] !== c.card || $[136] !== c.foreground || $[137] !== c.isDark || $[138] !== c.mutedForeground || $[139] !== c.secondary || $[140] !== c.subtleForeground || $[141] !== dmMessages || $[142] !== leagueMessages || $[143] !== leagueReplyQuotes || $[144] !== mode || $[145] !== myUid || $[146] !== now || $[147] !== reactToItem || $[148] !== replyCountByParentId) {
      t36 = mode === "dm" ? !activeFriend ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.emptyContainer,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
          icon: "message-text-outline",
          title: "No Direct Chats Yet",
          body: "Add a friend to start messaging 1-on-1, share picks, and challenge them head-to-head.",
          action: "Find Friends",
          onAction: _temp4
        })
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FlatList.default, {
        ref: listRef,
        data: dmMessages,
        keyExtractor: _temp5,
        contentContainerStyle: styles.messagesList,
        showsVerticalScrollIndicator: false,
        onContentSizeChange: () => listRef.current?.scrollToEnd({
          animated: false
        }),
        onLayout: () => listRef.current?.scrollToEnd({
          animated: false
        }),
        renderItem: t37 => {
          const {
            item: m_3
          } = t37;
          const mine = m_3.senderUid === myUid;
          const initials = (m_3.senderName || "P").split(" ").map(_temp6).join("").slice(0, 2).toUpperCase();
          const repliesCount = replyCountByParentId[m_3.id] ?? 0;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.msgGroup, mine ? styles.msgGroupRight : styles.msgGroupLeft],
            children: [m_3.replyTo ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsChatReplyThread.QuotedParent, {
              quote: m_3.replyTo,
              isMine: mine,
              replyCount: replyCountByParentId[m_3.replyTo.id]
            }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: [styles.msgRow, mine && styles.msgRowRight],
              children: [!mine && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                accessibilityRole: "button",
                accessibilityLabel: `View ${m_3.senderName}'s profile`,
                onPress: () => setProfileUid(m_3.senderUid),
                style: [styles.senderDisc, {
                  backgroundColor: c.secondary,
                  borderColor: c.border
                }],
                children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.senderDiscText, {
                    color: c.foreground
                  }],
                  children: initials
                })
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: [styles.bubbleCol, mine ? {
                  alignItems: "flex-end"
                } : {
                  alignItems: "flex-start"
                }],
                children: [!mine && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                  onPress: () => setProfileUid(m_3.senderUid),
                  children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: [styles.senderLabel, {
                      color: c.mutedForeground
                    }],
                    children: m_3.senderName
                  })
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
                  onLongPress: () => {
                    _libMotion.haptic.tick();
                    setReplyQuote({
                      id: m_3.id,
                      kind: "message",
                      authorUid: m_3.senderUid,
                      authorName: m_3.senderName,
                      text: (0, _libChatText.chatText)(m_3.text)
                    });
                  },
                  style: [styles.bubble, mine ? {
                    backgroundColor: "#007AFF",
                    borderBottomRightRadius: 4
                  } : {
                    backgroundColor: c.isDark ? c.card : "#E9E9EB",
                    borderColor: c.border,
                    borderWidth: c.isDark ? 1 : 0,
                    borderBottomLeftRadius: 4
                  }],
                  children: [m_3.kind === "taunt" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TauntCard.default, {
                    taunt: m_3
                  }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: [styles.bubbleText, {
                      color: mine ? "#FFFFFF" : c.foreground
                    }],
                    children: (0, _libChatText.chatText)(m_3.text)
                  })]
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                  style: styles.msgMetaRow,
                  children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: [styles.msgTime, {
                      color: c.subtleForeground
                    }],
                    children: formatClock(m_3.at)
                  }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                    hitSlop: 8,
                    onPress: () => {
                      _libMotion.haptic.tick();
                      setReplyQuote({
                        id: m_3.id,
                        kind: "message",
                        authorUid: m_3.senderUid,
                        authorName: m_3.senderName,
                        text: (0, _libChatText.chatText)(m_3.text)
                      });
                    },
                    children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                      style: [styles.replyLink, {
                        color: "#007AFF"
                      }],
                      children: repliesCount > 0 ? `${repliesCount} ${repliesCount === 1 ? "Reply" : "Replies"} · Reply` : "Reply"
                    })
                  })]
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ReactionRow.default, {
                  reactors: m_3.reactors,
                  uid: myUid,
                  align: mine ? "right" : "left",
                  onReact: e => reactToDm(m_3, myUid, e)
                })]
              })]
            })]
          });
        },
        ListEmptyComponent: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: styles.emptyChat,
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.emptyChatText, {
              color: c.mutedForeground
            }],
            children: ["Start the conversation with ", activeFriend.displayName, " below."]
          })
        })
      }) : !activeLeague ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.emptyContainer,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
          icon: "trophy-outline",
          title: "No League Chats Yet",
          body: "Join or start a league to unlock your league's dedicated group chat room.",
          action: "Explore Leagues",
          onAction: _temp7
        })
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FlatList.default, {
        ref: listRef,
        data: leagueMessages,
        keyExtractor: _temp8,
        contentContainerStyle: styles.messagesList,
        showsVerticalScrollIndicator: false,
        onContentSizeChange: () => listRef.current?.scrollToEnd({
          animated: false
        }),
        onLayout: () => listRef.current?.scrollToEnd({
          animated: false
        }),
        renderItem: t38 => {
          const {
            item: m_5
          } = t38;
          const mine_0 = m_5.uid === myUid;
          const quote_0 = m_5.replyTo ?? leagueReplyQuotes[m_5.id] ?? null;
          const initials_0 = (m_5.name || "P").split(" ").map(_temp9).join("").slice(0, 2).toUpperCase();
          const repliesCount_0 = replyCountByParentId[m_5.id] ?? 0;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.msgGroup, mine_0 ? styles.msgGroupRight : styles.msgGroupLeft],
            children: [quote_0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsChatReplyThread.QuotedParent, {
              quote: quote_0,
              isMine: mine_0,
              replyCount: replyCountByParentId[quote_0.id]
            }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: [styles.msgRow, mine_0 && styles.msgRowRight],
              children: [!mine_0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                accessibilityRole: "button",
                accessibilityLabel: `View ${m_5.name}'s profile`,
                onPress: () => setProfileUid(m_5.uid),
                style: [styles.senderDisc, {
                  backgroundColor: c.secondary,
                  borderColor: c.border
                }],
                children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.senderDiscText, {
                    color: c.foreground
                  }],
                  children: initials_0
                })
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: [styles.bubbleCol, mine_0 ? {
                  alignItems: "flex-end"
                } : {
                  alignItems: "flex-start"
                }],
                children: [!mine_0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                  onPress: () => setProfileUid(m_5.uid),
                  children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: [styles.senderLabel, {
                      color: c.mutedForeground
                    }],
                    children: m_5.name
                  })
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
                  onLongPress: () => {
                    _libMotion.haptic.tick();
                    setReplyQuote({
                      id: m_5.id,
                      kind: m_5.kind === "bet" ? "bet_result" : "message",
                      authorUid: m_5.uid,
                      authorName: m_5.name,
                      text: (0, _libChatText.chatText)(m_5.text),
                      teamAbbr: m_5.teamAbbr,
                      opponentAbbr: m_5.opponentAbbr,
                      odds: m_5.odds,
                      stake: m_5.stake
                    });
                  },
                  style: [styles.bubble, mine_0 ? {
                    backgroundColor: "#007AFF",
                    borderBottomRightRadius: 4
                  } : {
                    backgroundColor: c.isDark ? c.card : "#E9E9EB",
                    borderColor: c.border,
                    borderWidth: c.isDark ? 1 : 0,
                    borderBottomLeftRadius: 4
                  }],
                  children: [m_5.kind === "taunt" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TauntCard.default, {
                    taunt: m_5
                  }) : null, m_5.kind === "bet" && activeLeague ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BetChatCard.default, {
                    message: m_5,
                    uid: myUid ?? null,
                    leagueId: activeLeague.id,
                    now: now,
                    onTail: (gameId, intent) => {
                      setFollow(intent);
                      setQuickGame(gameId);
                    }
                  }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: [styles.bubbleText, {
                      color: mine_0 ? "#FFFFFF" : c.foreground
                    }],
                    children: (0, _libChatText.chatText)(m_5.text)
                  })]
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                  style: styles.msgMetaRow,
                  children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: [styles.msgTime, {
                      color: c.subtleForeground
                    }],
                    children: formatClock(m_5.at)
                  }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                    hitSlop: 8,
                    onPress: () => {
                      _libMotion.haptic.tick();
                      setReplyQuote({
                        id: m_5.id,
                        kind: m_5.kind === "bet" ? "bet_result" : "message",
                        authorUid: m_5.uid,
                        authorName: m_5.name,
                        text: (0, _libChatText.chatText)(m_5.text)
                      });
                    },
                    children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                      style: [styles.replyLink, {
                        color: "#007AFF"
                      }],
                      children: repliesCount_0 > 0 ? `${repliesCount_0} ${repliesCount_0 === 1 ? "Reply" : "Replies"} · Reply` : "Reply"
                    })
                  })]
                }), m_5.kind !== "system" && activeLeague ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ReactionRow.default, {
                  reactors: m_5.reactors,
                  reactions: m_5.reactions,
                  uid: myUid,
                  align: mine_0 ? "right" : "left",
                  onReact: e_0 => reactToItem(activeLeague.id, "message", m_5.id, e_0)
                }) : null]
              })]
            })]
          });
        },
        ListEmptyComponent: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: styles.emptyChat,
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.emptyChatText, {
              color: c.mutedForeground
            }],
            children: ["No messages in ", activeLeague.name, " yet. Drop the first message below!"]
          })
        })
      });
      $[132] = activeFriend;
      $[133] = activeLeague;
      $[134] = c.border;
      $[135] = c.card;
      $[136] = c.foreground;
      $[137] = c.isDark;
      $[138] = c.mutedForeground;
      $[139] = c.secondary;
      $[140] = c.subtleForeground;
      $[141] = dmMessages;
      $[142] = leagueMessages;
      $[143] = leagueReplyQuotes;
      $[144] = mode;
      $[145] = myUid;
      $[146] = now;
      $[147] = reactToItem;
      $[148] = replyCountByParentId;
      $[149] = t36;
    } else {
      t36 = $[149];
    }
    let t37;
    if ($[150] === Symbol.for("react.memo_cache_sentinel")) {
      t37 = () => setReplyQuote(null);
      $[150] = t37;
    } else {
      t37 = $[150];
    }
    let t38;
    if ($[151] !== replyQuote) {
      t38 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsChatReplyThread.ReplyComposerBar, {
        quote: replyQuote,
        onCancel: t37
      });
      $[151] = replyQuote;
      $[152] = t38;
    } else {
      t38 = $[152];
    }
    let t39;
    if ($[153] !== activeFriend || $[154] !== activeLeague || $[155] !== c.border || $[156] !== c.card || $[157] !== c.foreground || $[158] !== c.mutedForeground || $[159] !== c.secondary || $[160] !== handleSend || $[161] !== insets || $[162] !== mode || $[163] !== replyQuote || $[164] !== sending || $[165] !== text) {
      t39 = (mode === "dm" && activeFriend || mode === "league" && activeLeague) && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.inputDock, {
          backgroundColor: c.card,
          borderTopColor: c.border,
          paddingBottom: Math.max(insets.bottom, 10)
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(TextInput.default, {
          style: [styles.input, {
            backgroundColor: c.secondary,
            borderColor: c.border,
            color: c.foreground
          }],
          value: text,
          onChangeText: setText,
          placeholder: replyQuote ? `Reply to ${replyQuote.authorName}…` : mode === "dm" && activeFriend ? `Message ${activeFriend.displayName}…` : `Message ${activeLeague?.name ?? "league"}…`,
          placeholderTextColor: c.mutedForeground,
          maxLength: 500,
          returnKeyType: "send",
          onSubmitEditing: handleSend
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
          accessibilityRole: "button",
          accessibilityLabel: "Send message",
          disabled: !text.trim() || sending,
          onPress: handleSend,
          style: t40 => {
            const {
              pressed
            } = t40;
            return [styles.sendBtn, {
              backgroundColor: text.trim() ? "#007AFF" : c.secondary,
              opacity: !text.trim() ? 0.5 : pressed ? 0.8 : 1
            }];
          },
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "arrow-up",
            size: 20,
            color: text.trim() ? "#FFFFFF" : c.mutedForeground
          })
        })]
      });
      $[153] = activeFriend;
      $[154] = activeLeague;
      $[155] = c.border;
      $[156] = c.card;
      $[157] = c.foreground;
      $[158] = c.mutedForeground;
      $[159] = c.secondary;
      $[160] = handleSend;
      $[161] = insets;
      $[162] = mode;
      $[163] = replyQuote;
      $[164] = sending;
      $[165] = text;
      $[166] = t39;
    } else {
      t39 = $[166];
    }
    const t40 = mode === "league" ? selectedLeagueId ?? undefined : undefined;
    let t41;
    if ($[167] === Symbol.for("react.memo_cache_sentinel")) {
      t41 = () => setProfileUid(null);
      $[167] = t41;
    } else {
      t41 = $[167];
    }
    let t42;
    if ($[168] !== profileUid || $[169] !== t40) {
      t42 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PlayerProfileSheet.default, {
        uid: profileUid,
        leagueId: t40,
        onClose: t41
      });
      $[168] = profileUid;
      $[169] = t40;
      $[170] = t42;
    } else {
      t42 = $[170];
    }
    let t43;
    if ($[171] === Symbol.for("react.memo_cache_sentinel")) {
      t43 = () => {
        setQuickGame(null);
        setFollow(null);
      };
      $[171] = t43;
    } else {
      t43 = $[171];
    }
    const t44 = follow?.leagueId;
    let t45;
    if ($[172] !== follow || $[173] !== quickGame || $[174] !== t44) {
      t45 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(GameQuickView.default, {
        gameId: quickGame,
        onClose: t43,
        defaultWallet: t44,
        follow: follow
      });
      $[172] = follow;
      $[173] = quickGame;
      $[174] = t44;
      $[175] = t45;
    } else {
      t45 = $[175];
    }
    let t46;
    if ($[176] !== t15 || $[177] !== t35 || $[178] !== t36 || $[179] !== t38 || $[180] !== t39 || $[181] !== t42 || $[182] !== t45) {
      t46 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(KeyboardAvoidingView.default, {
        style: t15,
        behavior: "height",
        keyboardVerticalOffset: 0,
        children: [t35, t36, t38, t39, t42, t45]
      });
      $[176] = t15;
      $[177] = t35;
      $[178] = t36;
      $[179] = t38;
      $[180] = t39;
      $[181] = t42;
      $[182] = t45;
      $[183] = t46;
    } else {
      t46 = $[183];
    }
    return t46;
  }
  function _temp9(s_0) {
    return s_0[0];
  }
  function _temp8(m_4) {
    return m_4.id;
  }
  function _temp7() {
    return _expoRouter.router.navigate("/(tabs)/leagues");
  }
  function _temp6(s) {
    return s[0];
  }
  function _temp5(m_2) {
    return m_2.id;
  }
  function _temp4() {
    return _expoRouter.router.navigate("/(tabs)/friends");
  }
  function _temp3(t0) {
    const [, v] = t0;
    return v !== undefined;
  }
  function _temp2(a_0, b_0) {
    return a_0.at - b_0.at;
  }
  function _temp(a, b) {
    return a.at - b.at;
  }
  const styles = StyleSheet.default.create({
    container: {
      flex: 1
    },
    header: {
      paddingHorizontal: 16,
      paddingBottom: 10,
      gap: 10,
      borderBottomWidth: StyleSheet.default.hairlineWidth
    },
    headerTop: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10
    },
    headerTitle: {
      fontSize: 22,
      fontFamily: "Inter_900Black",
      letterSpacing: -0.6
    },
    headerSub: {
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    },
    profileBtn: {
      flexDirection: "row",
      alignItems: "center",
      gap: 5,
      paddingHorizontal: 11,
      paddingVertical: 7,
      borderRadius: 999,
      borderWidth: 1
    },
    profileBtnText: {
      fontSize: 12,
      fontFamily: "Inter_700Bold"
    },
    roomStrip: {
      gap: 8,
      paddingTop: 2
    },
    roomChip: {
      flexDirection: "row",
      alignItems: "center",
      gap: 7,
      paddingHorizontal: 11,
      paddingVertical: 6,
      borderRadius: 999,
      borderWidth: 1
    },
    roomChipText: {
      fontSize: 13,
      fontFamily: "Inter_700Bold",
      maxWidth: 130
    },
    unreadDot: {
      minWidth: 18,
      height: 18,
      borderRadius: 9,
      paddingHorizontal: 4,
      alignItems: "center",
      justifyContent: "center"
    },
    unreadDotText: {
      color: "#FFFFFF",
      fontSize: 11,
      fontFamily: "Inter_800ExtraBold"
    },
    dotOnly: {
      width: 8,
      height: 8,
      borderRadius: 4
    },
    emptyContainer: {
      flex: 1,
      padding: 20,
      justifyContent: "center"
    },
    messagesList: {
      paddingHorizontal: 16,
      paddingVertical: 14,
      gap: 12,
      flexGrow: 1,
      justifyContent: "flex-end"
    },
    msgGroup: {
      gap: 2,
      maxWidth: "85%"
    },
    msgGroupLeft: {
      alignSelf: "flex-start"
    },
    msgGroupRight: {
      alignSelf: "flex-end",
      alignItems: "flex-end"
    },
    msgRow: {
      flexDirection: "row",
      alignItems: "flex-end",
      gap: 8
    },
    msgRowRight: {
      justifyContent: "flex-end"
    },
    senderDisc: {
      width: 30,
      height: 30,
      borderRadius: 15,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 16
    },
    senderDiscText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold"
    },
    bubbleCol: {
      gap: 3,
      flexShrink: 1
    },
    senderLabel: {
      fontSize: 11,
      fontFamily: "Inter_600SemiBold",
      marginLeft: 6
    },
    bubble: {
      borderRadius: 18,
      paddingHorizontal: 14,
      paddingVertical: 9
    },
    bubbleText: {
      fontSize: 15,
      lineHeight: 20,
      fontFamily: "Inter_400Regular"
    },
    msgMetaRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      paddingHorizontal: 4
    },
    msgTime: {
      fontSize: 11,
      fontFamily: "Inter_500Medium"
    },
    replyLink: {
      fontSize: 11,
      fontFamily: "Inter_700Bold"
    },
    emptyChat: {
      paddingVertical: 40,
      alignItems: "center"
    },
    emptyChatText: {
      fontSize: 13,
      fontFamily: "Inter_400Regular",
      textAlign: "center"
    },
    inputDock: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      paddingHorizontal: 14,
      paddingTop: 10,
      borderTopWidth: StyleSheet.default.hairlineWidth
    },
    input: {
      flex: 1,
      borderWidth: 1,
      borderRadius: 22,
      paddingHorizontal: 16,
      paddingVertical: 10,
      fontSize: 15,
      fontFamily: "Inter_400Regular"
    },
    sendBtn: {
      width: 38,
      height: 38,
      borderRadius: 19,
      alignItems: "center",
      justifyContent: "center"
    }
  });
},770,[815,818,820,817,12,107,237,104,133,28,188,255,109,827,271,1258,1262,1263,851,1261,832,836,837,822,858,838,819,846,844,1259,902,816,905,906,1265,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return ReactionRow;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[3]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[4]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[5]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _reactNativeReanimated = require(_dependencyMap[6]);
  var Animated = _interopDefault(_reactNativeReanimated);
  var _componentsFxTap = require(_dependencyMap[7]);
  var _constantsLeagueTypes = require(_dependencyMap[8]);
  var _hooksUseColors = require(_dependencyMap[9]);
  var _hooksUseOptimisticReaction = require(_dependencyMap[10]);
  var _libMotion = require(_dependencyMap[11]);
  var _reactJsxRuntime = require(_dependencyMap[12]);
  /**
   * Emoji reactions under a chat message: the ones in use as chips with counts,
   * plus a smiley that opens the full picker. My pick shows instantly.
   */
  function ReactionRow(t0) {
    const $ = (0, _reactCompilerRuntime.c)(39);
    const {
      reactors,
      reactions,
      uid,
      onReact,
      canReact: t1,
      align: t2
    } = t0;
    const canReact = t1 === undefined ? true : t1;
    const align = t2 === undefined ? "left" : t2;
    const c = (0, _hooksUseColors.useColors)();
    const {
      mine,
      counts,
      toggle
    } = (0, _hooksUseOptimisticReaction.useOptimisticReaction)(reactors, uid, reactions);
    const [picking, setPicking] = (0, _react.useState)(false);
    let T0;
    let t3;
    let t4;
    let t5;
    let tap;
    if ($[0] !== align || $[1] !== c || $[2] !== canReact || $[3] !== counts || $[4] !== mine || $[5] !== onReact || $[6] !== toggle) {
      t5 = Symbol.for("react.early_return_sentinel");
      bb0: {
        let t6;
        if ($[12] !== counts) {
          t6 = e => (counts[e] ?? 0) > 0;
          $[12] = counts;
          $[13] = t6;
        } else {
          t6 = $[13];
        }
        const used = _constantsLeagueTypes.REACTION_EMOJIS.filter(t6);
        if (!used.length && !canReact) {
          t5 = null;
          break bb0;
        }
        let t7;
        if ($[14] !== canReact || $[15] !== onReact || $[16] !== toggle) {
          t7 = e_0 => {
            if (!canReact) {
              return;
            }
            _libMotion.haptic.tick();
            setPicking(false);
            toggle(e_0, onReact);
          };
          $[14] = canReact;
          $[15] = onReact;
          $[16] = toggle;
          $[17] = t7;
        } else {
          t7 = $[17];
        }
        tap = t7;
        T0 = View.default;
        let t8;
        if ($[18] !== align) {
          t8 = align === "right" && {
            justifyContent: "flex-end"
          };
          $[18] = align;
          $[19] = t8;
        } else {
          t8 = $[19];
        }
        if ($[20] !== t8) {
          t3 = [styles.row, t8];
          $[20] = t8;
          $[21] = t3;
        } else {
          t3 = $[21];
        }
        let t9;
        if ($[22] !== c || $[23] !== canReact || $[24] !== counts || $[25] !== mine || $[26] !== tap) {
          t9 = e_1 => {
            const on = mine === e_1;
            return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Animated.default.View, {
              entering: _reactNativeReanimated.ZoomIn.springify().damping(14),
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
                accessibilityRole: "button",
                accessibilityLabel: `${e_1} ${counts[e_1]}${on ? ", yours" : ""}`,
                disabled: !canReact,
                hitSlop: 4,
                onPress: () => tap(e_1),
                style: [styles.chip, {
                  borderColor: on ? c.league : c.border,
                  backgroundColor: on ? c.leagueSoft : c.secondary
                }],
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: styles.emoji,
                  children: e_1
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.count, {
                    color: on ? c.league : c.mutedForeground
                  }],
                  children: counts[e_1]
                })]
              })
            }, e_1);
          };
          $[22] = c;
          $[23] = canReact;
          $[24] = counts;
          $[25] = mine;
          $[26] = tap;
          $[27] = t9;
        } else {
          t9 = $[27];
        }
        t4 = used.map(t9);
      }
      $[0] = align;
      $[1] = c;
      $[2] = canReact;
      $[3] = counts;
      $[4] = mine;
      $[5] = onReact;
      $[6] = toggle;
      $[7] = T0;
      $[8] = t3;
      $[9] = t4;
      $[10] = t5;
      $[11] = tap;
    } else {
      T0 = $[7];
      t3 = $[8];
      t4 = $[9];
      t5 = $[10];
      tap = $[11];
    }
    if (t5 !== Symbol.for("react.early_return_sentinel")) {
      return t5;
    }
    let t6;
    if ($[28] !== c || $[29] !== canReact || $[30] !== mine || $[31] !== picking || $[32] !== tap) {
      t6 = canReact ? picking ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Animated.default.View, {
        entering: _reactNativeReanimated.FadeIn.duration(120),
        style: [styles.picker, {
          backgroundColor: c.elevated,
          borderColor: c.border
        }],
        children: [_constantsLeagueTypes.REACTION_EMOJIS.map(e_2 => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
          accessibilityRole: "button",
          accessibilityLabel: `React ${e_2}`,
          hitSlop: 3,
          onPress: () => tap(e_2),
          style: [styles.pick, mine === e_2 && {
            backgroundColor: c.leagueSoft
          }],
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: styles.pickEmoji,
            children: e_2
          })
        }, e_2)), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
          accessibilityRole: "button",
          accessibilityLabel: "Close reactions",
          hitSlop: 6,
          onPress: () => setPicking(false),
          style: styles.pick,
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "close",
            size: 14,
            color: c.mutedForeground
          })
        })]
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
        accessibilityRole: "button",
        accessibilityLabel: "Add reaction",
        hitSlop: 6,
        onPress: () => {
          _libMotion.haptic.tick();
          setPicking(true);
        },
        style: [styles.chip, {
          borderColor: c.border,
          backgroundColor: "transparent"
        }],
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "emoticon-plus-outline",
          size: 14,
          color: c.mutedForeground
        })
      }) : null;
      $[28] = c;
      $[29] = canReact;
      $[30] = mine;
      $[31] = picking;
      $[32] = tap;
      $[33] = t6;
    } else {
      t6 = $[33];
    }
    let t7;
    if ($[34] !== T0 || $[35] !== t3 || $[36] !== t4 || $[37] !== t6) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T0, {
        style: t3,
        children: [t4, t6]
      });
      $[34] = T0;
      $[35] = t3;
      $[36] = t4;
      $[37] = t6;
      $[38] = t7;
    } else {
      t7 = $[38];
    }
    return t7;
  }
  const styles = StyleSheet.default.create({
    row: {
      flexDirection: "row",
      flexWrap: "wrap",
      alignItems: "center",
      gap: 4,
      paddingHorizontal: 4
    },
    chip: {
      flexDirection: "row",
      alignItems: "center",
      gap: 3,
      paddingHorizontal: 7,
      paddingVertical: 2,
      borderRadius: 999,
      borderWidth: 1,
      minHeight: 24
    },
    emoji: {
      fontSize: 13
    },
    count: {
      fontSize: 11,
      fontFamily: "Inter_700Bold"
    },
    picker: {
      flexDirection: "row",
      alignItems: "center",
      gap: 2,
      paddingHorizontal: 4,
      paddingVertical: 2,
      borderRadius: 999,
      borderWidth: 1
    },
    pick: {
      paddingHorizontal: 5,
      paddingVertical: 3,
      borderRadius: 999
    },
    pickEmoji: {
      fontSize: 18
    }
  });
},1265,[815,818,12,28,188,109,867,827,855,819,1257,820,6]);