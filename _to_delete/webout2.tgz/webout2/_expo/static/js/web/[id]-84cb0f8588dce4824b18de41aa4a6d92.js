__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return WrappedScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoRouter = require(_dependencyMap[1]);
  var _firebaseFirestore = require(_dependencyMap[2]);
  var _react = require(_dependencyMap[3]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsAvatarDisplay = require(_dependencyMap[7]);
  var AvatarDisplay = _interopDefault(_componentsAvatarDisplay);
  var _componentsFxTap = require(_dependencyMap[8]);
  var _componentsUi = require(_dependencyMap[9]);
  var _constantsTheme = require(_dependencyMap[10]);
  var theme = _interopDefault(_constantsTheme);
  var _contextAppContext = require(_dependencyMap[11]);
  var _hooksUseCatalog = require(_dependencyMap[12]);
  var _hooksUseColors = require(_dependencyMap[13]);
  var _libFirebase = require(_dependencyMap[14]);
  var _libMotion = require(_dependencyMap[15]);
  var _libShareCard = require(_dependencyMap[16]);
  var _reactJsxRuntime = require(_dependencyMap[17]);
  function storiesFor(w) {
    const out = [{
      key: "record",
      kicker: w.title,
      big: `${w.record.w}–${w.record.l}${w.record.p ? `–${w.record.p}` : ""}`,
      sub: "Your record",
      shareable: true
    }];
    if (w.bestCall) out.push({
      key: "best",
      kicker: "Best call",
      big: `${w.bestCall.odds.toFixed(2)}x`,
      sub: w.bestCall.label,
      shareable: true
    });
    if (w.worstBeat) out.push({
      key: "worst",
      kicker: "The one that got away",
      big: w.worstBeat.label,
      sub: "Only you can see this card",
      shareable: false
    });
    if (w.rival) out.push({
      key: "rival",
      kicker: "Your rival",
      big: w.rival.name,
      sub: `${w.rival.w}–${w.rival.l} across ${w.rival.games} games`,
      shareable: true
    });
    if (w.topTeam) out.push({
      key: "team",
      kicker: "Ride or die",
      big: w.topTeam.abbr,
      sub: `${w.topTeam.picks} picks`,
      shareable: true
    });
    out.push({
      key: "streak",
      kicker: "Best streak",
      big: `${w.streakBest} days`,
      sub: `Level ${w.level} · ${w.achievements} achievements`,
      shareable: true
    });
    out.push({
      key: "end",
      kicker: "That's a wrap",
      big: "See you next season",
      sub: "",
      shareable: true
    });
    return out;
  }

  /** Drip Wrapped in stories format: tap right to advance, left to go back. */
  function WrappedScreen() {
    const $ = (0, _reactCompilerRuntime.c)(93);
    const c = (0, _hooksUseColors.useColors)();
    const top = (0, _componentsUi.useTopPad)();
    const {
      id
    } = (0, _expoRouter.useLocalSearchParams)();
    const {
      profile
    } = (0, _contextAppContext.useApp)();
    const {
      byId
    } = (0, _hooksUseCatalog.useCatalog)();
    const [w, setW] = (0, _react.useState)(null);
    const [i, setI] = (0, _react.useState)(0);
    const ref = (0, _react.useRef)(null);
    let t0;
    if ($[0] !== id || $[1] !== profile) {
      t0 = () => {
        const db = (0, _libFirebase.getDb)();
        if (!db || !profile?.uid || !id) {
          return;
        }
        return (0, _firebaseFirestore.onSnapshot)((0, _firebaseFirestore.doc)(db, "users", profile.uid, "wrapped", id), s => setW(s.exists() ? s.data() : "missing"), () => setW("missing"));
      };
      $[0] = id;
      $[1] = profile;
      $[2] = t0;
    } else {
      t0 = $[2];
    }
    const t1 = profile?.uid;
    let t2;
    if ($[3] !== id || $[4] !== t1) {
      t2 = [t1, id];
      $[3] = id;
      $[4] = t1;
      $[5] = t2;
    } else {
      t2 = $[5];
    }
    (0, _react.useEffect)(t0, t2);
    if (w === "missing") {
      let t3;
      if ($[6] !== c.background || $[7] !== top) {
        t3 = [styles.fill, {
          backgroundColor: c.background,
          paddingTop: top
        }];
        $[6] = c.background;
        $[7] = top;
        $[8] = t3;
      } else {
        t3 = $[8];
      }
      let t4;
      let t5;
      if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.BackButton, {});
        t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
          icon: "gift-outline",
          title: "Not Ready Yet",
          body: "Your Wrapped shows up when the season ends."
        });
        $[9] = t4;
        $[10] = t5;
      } else {
        t4 = $[9];
        t5 = $[10];
      }
      let t6;
      if ($[11] !== t3) {
        t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: t3,
          children: [t4, t5]
        });
        $[11] = t3;
        $[12] = t6;
      } else {
        t6 = $[12];
      }
      return t6;
    }
    if (!w) {
      let t3;
      if ($[13] !== c.background) {
        t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [styles.fill, {
            backgroundColor: c.background
          }]
        });
        $[13] = c.background;
        $[14] = t3;
      } else {
        t3 = $[14];
      }
      return t3;
    }
    let T0;
    let T1;
    let go;
    let last;
    let s_0;
    let t3;
    let t4;
    let t5;
    if ($[15] !== c.background || $[16] !== c.primary || $[17] !== c.secondary || $[18] !== i || $[19] !== top || $[20] !== w) {
      const stories = storiesFor(w);
      s_0 = stories[Math.min(i, stories.length - 1)];
      last = i >= stories.length - 1;
      go = d => {
        _libMotion.haptic.tick();
        const n = i + d;
        if (n >= stories.length) {
          _expoRouter.router.back();
        } else {
          setI(Math.max(0, n));
        }
      };
      T1 = View.default;
      if ($[29] !== c.background || $[30] !== top) {
        t5 = [styles.fill, {
          backgroundColor: c.background,
          paddingTop: top
        }];
        $[29] = c.background;
        $[30] = top;
        $[31] = t5;
      } else {
        t5 = $[31];
      }
      T0 = View.default;
      t3 = styles.bars;
      let t6;
      if ($[32] !== c.primary || $[33] !== c.secondary || $[34] !== i) {
        t6 = (x, k) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [styles.bar, {
            backgroundColor: k <= i ? c.primary : c.secondary
          }]
        }, x.key);
        $[32] = c.primary;
        $[33] = c.secondary;
        $[34] = i;
        $[35] = t6;
      } else {
        t6 = $[35];
      }
      t4 = stories.map(t6);
      $[15] = c.background;
      $[16] = c.primary;
      $[17] = c.secondary;
      $[18] = i;
      $[19] = top;
      $[20] = w;
      $[21] = T0;
      $[22] = T1;
      $[23] = go;
      $[24] = last;
      $[25] = s_0;
      $[26] = t3;
      $[27] = t4;
      $[28] = t5;
    } else {
      T0 = $[21];
      T1 = $[22];
      go = $[23];
      last = $[24];
      s_0 = $[25];
      t3 = $[26];
      t4 = $[27];
      t5 = $[28];
    }
    let t6;
    if ($[36] !== T0 || $[37] !== t3 || $[38] !== t4) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(T0, {
        style: t3,
        children: t4
      });
      $[36] = T0;
      $[37] = t3;
      $[38] = t4;
      $[39] = t6;
    } else {
      t6 = $[39];
    }
    let t7;
    if ($[40] !== c.border || $[41] !== c.card) {
      t7 = [styles.card, {
        backgroundColor: c.card,
        borderColor: c.border
      }];
      $[40] = c.border;
      $[41] = c.card;
      $[42] = t7;
    } else {
      t7 = $[42];
    }
    let t8;
    if ($[43] !== c.primary) {
      t8 = [styles.kicker, {
        color: c.primary
      }];
      $[43] = c.primary;
      $[44] = t8;
    } else {
      t8 = $[44];
    }
    let t9;
    if ($[45] !== s_0.kicker || $[46] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t8,
        children: s_0.kicker
      });
      $[45] = s_0.kicker;
      $[46] = t8;
      $[47] = t9;
    } else {
      t9 = $[47];
    }
    let t10;
    if ($[48] !== c.foreground) {
      t10 = [styles.big, {
        color: c.foreground
      }];
      $[48] = c.foreground;
      $[49] = t10;
    } else {
      t10 = $[49];
    }
    let t11;
    if ($[50] !== s_0.big || $[51] !== t10) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t10,
        accessibilityRole: "header",
        children: s_0.big
      });
      $[50] = s_0.big;
      $[51] = t10;
      $[52] = t11;
    } else {
      t11 = $[52];
    }
    let t12;
    if ($[53] !== c.mutedForeground || $[54] !== s_0.sub) {
      t12 = s_0.sub ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.sub, {
          color: c.mutedForeground
        }],
        children: s_0.sub
      }) : null;
      $[53] = c.mutedForeground;
      $[54] = s_0.sub;
      $[55] = t12;
    } else {
      t12 = $[55];
    }
    let t13;
    if ($[56] !== byId || $[57] !== last || $[58] !== profile) {
      t13 = last && profile ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.dance,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarDisplay.default, {
          avatar: profile.avatar,
          equipped: profile.equipped,
          catalog: byId,
          size: "lg",
          interactive: false,
          move: {
            id: profile.moves?.[0] ?? "cheer",
            n: 1
          }
        })
      }) : null;
      $[56] = byId;
      $[57] = last;
      $[58] = profile;
      $[59] = t13;
    } else {
      t13 = $[59];
    }
    let t14;
    if ($[60] !== t11 || $[61] !== t12 || $[62] !== t13 || $[63] !== t7 || $[64] !== t9) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        ref: ref,
        collapsable: false,
        style: t7,
        children: [t9, t11, t12, t13]
      });
      $[60] = t11;
      $[61] = t12;
      $[62] = t13;
      $[63] = t7;
      $[64] = t9;
      $[65] = t14;
    } else {
      t14 = $[65];
    }
    let t15;
    if ($[66] === Symbol.for("react.memo_cache_sentinel")) {
      t15 = {
        flex: 1
      };
      $[66] = t15;
    } else {
      t15 = $[66];
    }
    let t16;
    if ($[67] !== go) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
        style: t15,
        accessibilityRole: "button",
        accessibilityLabel: "Previous card",
        onPress: () => go(-1)
      });
      $[67] = go;
      $[68] = t16;
    } else {
      t16 = $[68];
    }
    let t17;
    if ($[69] === Symbol.for("react.memo_cache_sentinel")) {
      t17 = {
        flex: 2
      };
      $[69] = t17;
    } else {
      t17 = $[69];
    }
    const t18 = last ? "Close" : "Next card";
    let t19;
    if ($[70] !== go) {
      t19 = () => go(1);
      $[70] = go;
      $[71] = t19;
    } else {
      t19 = $[71];
    }
    let t20;
    if ($[72] !== t18 || $[73] !== t19) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
        style: t17,
        accessibilityRole: "button",
        accessibilityLabel: t18,
        onPress: t19
      });
      $[72] = t18;
      $[73] = t19;
      $[74] = t20;
    } else {
      t20 = $[74];
    }
    let t21;
    if ($[75] !== t16 || $[76] !== t20) {
      t21 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: StyleSheet.default.absoluteFill,
        pointerEvents: "box-none",
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.taps,
          pointerEvents: "box-none",
          children: [t16, t20]
        })
      });
      $[75] = t16;
      $[76] = t20;
      $[77] = t21;
    } else {
      t21 = $[77];
    }
    let t22;
    if ($[78] !== s_0.big || $[79] !== s_0.key || $[80] !== s_0.kicker || $[81] !== s_0.shareable || $[82] !== w) {
      t22 = s_0.shareable ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        label: "Share",
        icon: "share-variant",
        onPress: () => void (0, _libShareCard.shareViewOrText)({
          viewRef: ref,
          kind: "wrapped",
          id: `${w.periodId}_${s_0.key}`,
          message: `${s_0.kicker}: ${s_0.big} — SportDrip Wrapped`
        })
      }) : null;
      $[78] = s_0.big;
      $[79] = s_0.key;
      $[80] = s_0.kicker;
      $[81] = s_0.shareable;
      $[82] = w;
      $[83] = t22;
    } else {
      t22 = $[83];
    }
    let t23;
    if ($[84] !== t22) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.actions,
        children: t22
      });
      $[84] = t22;
      $[85] = t23;
    } else {
      t23 = $[85];
    }
    let t24;
    if ($[86] !== T1 || $[87] !== t14 || $[88] !== t21 || $[89] !== t23 || $[90] !== t5 || $[91] !== t6) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T1, {
        style: t5,
        children: [t6, t14, t21, t23]
      });
      $[86] = T1;
      $[87] = t14;
      $[88] = t21;
      $[89] = t23;
      $[90] = t5;
      $[91] = t6;
      $[92] = t24;
    } else {
      t24 = $[92];
    }
    return t24;
  }
  const styles = StyleSheet.default.create({
    fill: {
      flex: 1,
      paddingHorizontal: 16
    },
    bars: {
      flexDirection: "row",
      gap: 4,
      marginVertical: 12
    },
    bar: {
      flex: 1,
      height: 3,
      borderRadius: 2
    },
    card: {
      flex: 1,
      borderWidth: 1,
      borderRadius: 24,
      padding: 24,
      justifyContent: "center",
      alignItems: "center",
      gap: 10
    },
    kicker: theme.default.type.overline,
    big: {
      ...theme.default.type.display,
      textAlign: "center"
    },
    sub: {
      ...theme.default.type.body,
      textAlign: "center"
    },
    dance: {
      width: "100%",
      height: 260
    },
    taps: {
      flex: 1,
      flexDirection: "row",
      marginTop: 60,
      marginBottom: 90
    },
    actions: {
      paddingVertical: 16,
      zIndex: 2
    }
  });
},778,[815,817,905,12,28,188,109,828,827,836,874,837,838,819,906,820,1198,6]);