__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return FriendsScreen;
    }
  });
  var _componentsBackToLevels = require(_dependencyMap[0]);
  var BackToLevels = _interopDefault(_componentsBackToLevels);
  var _libPresence = require(_dependencyMap[1]);
  var _hooksUseNow = require(_dependencyMap[2]);
  var _libSettings = require(_dependencyMap[3]);
  var _expoVectorIcons = require(_dependencyMap[4]);
  var _libMotion = require(_dependencyMap[5]);
  var _expoRouter = require(_dependencyMap[6]);
  var _react = require(_dependencyMap[7]);
  var _reactNativeWebDistExportsActivityIndicator = require(_dependencyMap[8]);
  var ActivityIndicator = _interopDefault(_reactNativeWebDistExportsActivityIndicator);
  var _reactNativeWebDistExportsFlatList = require(_dependencyMap[9]);
  var FlatList = _interopDefault(_reactNativeWebDistExportsFlatList);
  require(_dependencyMap[10]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[11]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[12]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsTextInput = require(_dependencyMap[13]);
  var TextInput = _interopDefault(_reactNativeWebDistExportsTextInput);
  var _reactNativeWebDistExportsView = require(_dependencyMap[14]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[15]);
  var _reactNativeSafeAreaContext = require(_dependencyMap[16]);
  var _componentsAvatarDisplay = require(_dependencyMap[17]);
  var AvatarDisplay = _interopDefault(_componentsAvatarDisplay);
  var _componentsPlayerProfileSheet = require(_dependencyMap[18]);
  var PlayerProfileSheet = _interopDefault(_componentsPlayerProfileSheet);
  var _componentsInviteFriendsCard = require(_dependencyMap[19]);
  var InviteFriendsCard = _interopDefault(_componentsInviteFriendsCard);
  var _componentsTeamChips = require(_dependencyMap[20]);
  var TeamChips = _interopDefault(_componentsTeamChips);
  var _componentsUi = require(_dependencyMap[21]);
  var _contextAppContext = require(_dependencyMap[22]);
  var _contextChallengeContext = require(_dependencyMap[23]);
  var _contextChatContext = require(_dependencyMap[24]);
  var _contextNotificationContext = require(_dependencyMap[25]);
  var _hooksUseCatalog = require(_dependencyMap[26]);
  var _hooksUseColors = require(_dependencyMap[27]);
  var _hooksUseFriends = require(_dependencyMap[28]);
  var _reactJsxRuntime = require(_dependencyMap[29]);
  /** Stable empty result set. A fresh `[]` is a new identity every render. */
  const EMPTY_RESULTS = [];
  function FriendsScreen() {
    const colors = (0, _hooksUseColors.useColors)();
    const insets = (0, _reactNativeSafeAreaContext.useSafeAreaInsets)();
    const {
      profile
    } = (0, _contextAppContext.useApp)();
    const {
      byId
    } = (0, _hooksUseCatalog.useCatalog)();
    const {
      friends,
      incoming,
      senders,
      friendUids,
      outgoingUids,
      loading,
      error,
      clearError,
      search,
      sendRequest,
      respond,
      remove
    } = (0, _hooksUseFriends.useFriends)(profile?.uid ?? null);
    const [query, setQuery] = (0, _react.useState)("");
    const [results, setResults] = (0, _react.useState)([]);
    const [searching, setSearching] = (0, _react.useState)(false);
    const [selectedUid, setSelectedUid] = (0, _react.useState)(null);
    const presence = (0, _libPresence.usePresence)(friends.map(f => f.uid));
    const clock = (0, _hooksUseNow.useNow)(60_000);
    const params = (0, _expoRouter.useLocalSearchParams)();
    const [busy, setBusy] = (0, _react.useState)(null);
    const {
      unreadCount
    } = (0, _contextNotificationContext.useNotifications)();
    const {
      incoming: challengeInbox,
      live: challengesLive,
      headToHead
    } = (0, _contextChallengeContext.useChallenges)();
    const challengesNew = (0, _libSettings.useUnseenCount)("challenges.inbox", challengeInbox.map(ch => ch.id), false);
    const {
      unreadChatCount,
      unreadForFriend
    } = (0, _contextChatContext.useChat)();
    const topPad = 24;
    const bottomPad = 100;

    // Debounced search. Two characters minimum, matching the callable's floor.
    (0, _react.useEffect)(() => {
      const q = query.trim().toLowerCase();
      if (q.length < 2) {
        setResults(prev => prev.length === 0 ? prev : EMPTY_RESULTS);
        return;
      }
      let cancelled = false;
      setSearching(true);
      const t = setTimeout(async () => {
        try {
          const r = await search(q);
          if (!cancelled) setResults(r);
        } catch {
          if (!cancelled) setResults([]);
        } finally {
          if (!cancelled) setSearching(false);
        }
      }, 350);
      return () => {
        cancelled = true;
        clearTimeout(t);
      };
    }, [query, search]);
    const act = (0, _react.useCallback)(async (key, fn) => {
      setBusy(key);
      _libMotion.haptic.light();
      await fn();
      setBusy(null);
    }, []);
    const searching_ui = query.trim().length >= 2;
    const known = (0, _react.useMemo)(() => {
      const m = new Map();
      for (const u of Object.values(senders)) m.set(u.uid, u);
      for (const u_0 of results) m.set(u_0.uid, u_0);
      for (const u_1 of friends) m.set(u_1.uid, u_1);
      return m;
    }, [senders, results, friends]);
    const selected = selectedUid ? known.get(selectedUid) ?? null : null;

    // Deep link from an invite / friend notification: /(tabs)/friends?open=<uid>
    (0, _react.useEffect)(() => {
      if (params.open) {
        setSelectedUid(params.open);
        _expoRouter.router.setParams({
          open: undefined
        });
      }
    }, [params.open]);
    const incomingFrom = (0, _react.useMemo)(() => new Set(incoming.map(r_0 => r_0.from)), [incoming]);
    const renderActions = uid => {
      if (uid === profile?.uid) return null;
      if (incomingFrom.has(uid)) {
        return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.actionRow,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: "Accept Request",
            icon: "account-check",
            style: {
              flex: 1
            },
            loading: busy === `req:${uid}`,
            onPress: () => act(`req:${uid}`, () => respond(uid, true))
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: "Decline",
            variant: "secondary",
            loading: busy === `dec:${uid}`,
            onPress: () => act(`dec:${uid}`, () => respond(uid, false))
          })]
        });
      }
      if (!friendUids.has(uid)) {
        const pending = outgoingUids.has(uid);
        return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: pending ? "Request sent" : "Add friend",
          icon: pending ? "clock-outline" : "account-plus",
          variant: pending ? "secondary" : "primary",
          disabled: pending,
          loading: busy === uid,
          onPress: () => act(uid, () => sendRequest(uid))
        });
      }
      return null;
    };
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
      style: [styles.container, {
        backgroundColor: colors.background
      }],
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.header, {
          backgroundColor: colors.background,
          borderBottomColor: colors.border,
          paddingTop: 36
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.titleRow,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(BackToLevels.default, {}), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.title, {
              color: colors.foreground,
              flex: 1
            }],
            children: "Friends"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.actionRow,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.IconButton, {
              icon: "chat-processing-outline",
              label: "Chat",
              badge: unreadChatCount || undefined,
              onPress: () => _expoRouter.router.push("/messages")
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.IconButton, {
              icon: "sword-cross",
              label: "Challenges",
              badge: challengesNew || undefined,
              onPress: () => _expoRouter.router.push("/challenges")
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.IconButton, {
              icon: "bell-outline",
              label: "Activity",
              badge: unreadCount,
              onPress: () => _expoRouter.router.push("/activity")
            })]
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.searchBox, {
            backgroundColor: colors.secondary,
            borderColor: colors.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "magnify",
            size: 18,
            color: colors.mutedForeground
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TextInput.default, {
            style: [styles.searchInput, {
              color: colors.foreground
            }],
            value: query,
            onChangeText: setQuery,
            placeholder: "Search by username",
            placeholderTextColor: colors.mutedForeground,
            autoCapitalize: "none",
            autoCorrect: false
          }), searching && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
            size: "small",
            color: colors.mutedForeground
          }), query.length > 0 && !searching && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
            onPress: () => setQuery(""),
            children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "close-circle",
              size: 16,
              color: colors.mutedForeground
            })
          })]
        })]
      }), error && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        style: [styles.banner, {
          backgroundColor: colors.destructive + "22",
          borderColor: colors.destructive
        }],
        onPress: clearError,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "alert-circle-outline",
          size: 15,
          color: colors.destructive
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.bannerText, {
            color: colors.destructive
          }],
          children: error
        })]
      }), !searching_ui && (challengeInbox.length > 0 || challengesLive.length > 0) && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        accessibilityRole: "button",
        onPress: () => _expoRouter.router.push("/challenges"),
        style: [styles.banner, {
          backgroundColor: colors.alpha(colors.accent, 0.12),
          borderColor: colors.alpha(colors.accent, 0.55)
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "sword-cross",
          size: 15,
          color: colors.accent
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.bannerText, {
            color: colors.foreground
          }],
          numberOfLines: 1,
          children: challengeInbox.length > 0 ? `${challengeInbox.length} challenge${challengeInbox.length > 1 ? "s" : ""} waiting on you` : `${challengesLive.length} challenge${challengesLive.length > 1 ? "s" : ""} locked in`
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "chevron-right",
          size: 16,
          color: colors.mutedForeground
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FlatList.default, {
        data: searching_ui ? results : friends,
        keyExtractor: u_2 => u_2.uid,
        contentContainerStyle: [styles.list, {
          paddingBottom: bottomPad
        }],
        showsVerticalScrollIndicator: false,
        ListHeaderComponent: searching_ui ? undefined : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(InviteFriendsCard.default, {}), incoming.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.section,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.sectionTitle, {
                color: colors.foreground
              }],
              children: ["Requests (", incoming.length, ")"]
            }), incoming.map(r_1 => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: [styles.reqRow, {
                backgroundColor: colors.card,
                borderColor: colors.border
              }],
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
                onPress: () => setSelectedUid(r_1.from),
                style: {
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 10,
                  flex: 1
                },
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
                  style: [styles.thumb, {
                    backgroundColor: colors.secondary,
                    width: 34,
                    height: 40
                  }],
                  children: senders[r_1.from] ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarDisplay.default, {
                    avatar: senders[r_1.from].avatar,
                    equipped: senders[r_1.from].equipped,
                    catalog: byId,
                    size: "xs"
                  }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                    name: "account-plus",
                    size: 18,
                    color: colors.primary
                  })
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.reqText, {
                    color: colors.foreground
                  }],
                  numberOfLines: 1,
                  children: senders[r_1.from] ? `${senders[r_1.from].displayName} (@${senders[r_1.from].username})` : "A player wants to be friends"
                })]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                style: [styles.acceptBtn, {
                  backgroundColor: colors.primary
                }],
                disabled: busy === r_1.id,
                onPress: () => act(r_1.id, () => respond(r_1.from, true)),
                children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.acceptText, {
                    color: colors.primaryForeground
                  }],
                  children: "Accept"
                })
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                style: [styles.declineBtn, {
                  borderColor: colors.alpha(colors.foreground, 0.25),
                  backgroundColor: colors.secondary
                }],
                disabled: busy === r_1.id,
                onPress: () => act(r_1.id, () => respond(r_1.from, false)),
                children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                  name: "close",
                  size: 18,
                  color: colors.foreground
                })
              })]
            }, r_1.id))]
          }), friends.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.sectionTitle, {
              color: colors.foreground
            }],
            children: ["Your friends (", friends.length, ")"]
          })]
        }),
        renderItem: ({
          item
        }) => {
          const isFriend = friendUids.has(item.uid);
          const isPending = outgoingUids.has(item.uid);
          const dmUnread = isFriend ? unreadForFriend(item.uid) : 0;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.userRow, {
              backgroundColor: colors.card,
              borderColor: colors.border
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
              style: {
                flexDirection: "row",
                alignItems: "center",
                gap: 12,
                flex: 1
              },
              onPress: () => setSelectedUid(item.uid),
              accessibilityLabel: `View ${item.displayName}'s profile`,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
                  style: [styles.thumb, {
                    backgroundColor: colors.secondary
                  }],
                  children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarDisplay.default, {
                    avatar: item.avatar,
                    equipped: item.equipped,
                    catalog: byId,
                    size: "xs"
                  })
                }), isFriend && (presence[item.uid]?.at ?? 0) > clock - _libPresence.ONLINE_MS ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
                  accessibilityLabel: "Online now",
                  style: [styles.onlineDot, {
                    backgroundColor: colors.positive,
                    borderColor: colors.card
                  }]
                }) : null]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: styles.userInfo,
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.userName, {
                    color: colors.foreground
                  }],
                  numberOfLines: 1,
                  children: item.displayName
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                  style: [styles.userHandle, {
                    color: colors.mutedForeground
                  }],
                  numberOfLines: 1,
                  children: ["@", item.username, isFriend && (0, _libPresence.lastSeenLabel)(presence[item.uid]?.at, clock) ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: {
                      color: (presence[item.uid]?.at ?? 0) > clock - _libPresence.ONLINE_MS ? colors.positive : colors.subtleForeground
                    },
                    children: `  ·  ${(0, _libPresence.lastSeenLabel)(presence[item.uid]?.at, clock)}`
                  }) : null]
                }), isFriend && item.stats && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                  style: [styles.userRecord, {
                    color: colors.mutedForeground
                  }],
                  children: [item.stats.betsWon, "W \xB7 ", item.stats.betsLost, "L", (() => {
                    const r_2 = headToHead(item.uid);
                    return r_2.won + r_2.lost > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                      style: {
                        color: colors.accent
                      },
                      children: `  ·  H2H ${r_2.won}–${r_2.lost}`
                    }) : null;
                  })()]
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TeamChips.default, {
                  teams: item.favoriteTeams,
                  compact: true,
                  max: 3,
                  style: {
                    marginTop: 3
                  }
                })]
              })]
            }), isFriend ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.actionRow,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.IconButton, {
                icon: "message-text-outline",
                label: `Message ${item.displayName}`,
                badge: dmUnread || undefined,
                onPress: () => _expoRouter.router.push({
                  pathname: "/messages",
                  params: {
                    uid: item.uid,
                    name: item.displayName
                  }
                })
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                onPress: () => setSelectedUid(item.uid),
                hitSlop: 8,
                children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                  name: "chevron-right",
                  size: 20,
                  color: colors.mutedForeground
                })
              })]
            }) : isPending ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.pendingPill, {
                borderColor: colors.border
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.pendingText, {
                  color: colors.mutedForeground
                }],
                children: "Sent"
              })
            }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
              style: [styles.addBtn, {
                backgroundColor: colors.primary,
                opacity: busy === item.uid ? 0.5 : 1
              }],
              disabled: busy === item.uid,
              onPress: () => act(item.uid, () => sendRequest(item.uid)),
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.addText, {
                  color: colors.primaryForeground
                }],
                children: "Add"
              })
            })]
          });
        },
        ListEmptyComponent: loading ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
          color: colors.primary,
          style: {
            marginTop: 32
          }
        }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.empty, {
            backgroundColor: colors.card,
            borderColor: colors.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: searching_ui ? "account-search-outline" : "account-group-outline",
            size: 32,
            color: colors.mutedForeground
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.emptyTitle, {
              color: colors.foreground
            }],
            children: searching_ui ? "No one by that name" : "No friends yet"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.emptyBody, {
              color: colors.mutedForeground
            }],
            children: searching_ui ? "Usernames are exact — check the spelling." : "Search a username above to send your first request."
          })]
        })
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PlayerProfileSheet.default, {
        uid: selectedUid,
        onClose: () => setSelectedUid(null),
        seed: selected ? {
          displayName: selected.displayName,
          username: selected.username,
          avatar: selected.avatar,
          equipped: selected.equipped,
          favoriteTeams: selected.favoriteTeams
        } : undefined,
        footer: selectedUid ? renderActions(selectedUid) : null,
        onRemoveFriend: uid_0 => remove(uid_0)
      })]
    });
  }
  const styles = StyleSheet.default.create({
    container: {
      flex: 1
    },
    header: {
      borderBottomWidth: 1,
      paddingHorizontal: 16,
      paddingBottom: 12,
      gap: 10
    },
    titleRow: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between"
    },
    title: {
      fontSize: 24,
      fontFamily: "Inter_900Black"
    },
    searchBox: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      borderWidth: 1,
      borderRadius: 12,
      paddingHorizontal: 12,
      paddingVertical: 10
    },
    searchInput: {
      flex: 1,
      fontSize: 15,
      fontFamily: "Inter_400Regular"
    },
    banner: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      marginHorizontal: 16,
      marginTop: 10,
      padding: 10,
      borderRadius: 10,
      borderWidth: 1
    },
    bannerText: {
      flex: 1,
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    },
    list: {
      padding: 16
    },
    section: {
      gap: 8,
      marginBottom: 16
    },
    sectionTitle: {
      fontSize: 15,
      fontFamily: "Inter_700Bold",
      marginBottom: 8
    },
    reqRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      padding: 12,
      borderRadius: 12,
      borderWidth: 1
    },
    reqText: {
      flex: 1,
      fontSize: 13,
      fontFamily: "Inter_500Medium"
    },
    acceptBtn: {
      paddingHorizontal: 16,
      minHeight: 36,
      justifyContent: "center",
      borderRadius: 10
    },
    acceptText: {
      fontSize: 14,
      fontFamily: "Inter_800ExtraBold"
    },
    declineBtn: {
      width: 36,
      height: 36,
      borderRadius: 18,
      borderWidth: 1.5,
      alignItems: "center",
      justifyContent: "center"
    },
    userRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      padding: 12,
      borderRadius: 14,
      borderWidth: 1,
      marginBottom: 10
    },
    onlineDot: {
      position: "absolute",
      right: -3,
      bottom: -3,
      width: 14,
      height: 14,
      borderRadius: 7,
      borderWidth: 2.5
    },
    thumb: {
      width: 54,
      height: 64,
      borderRadius: 12,
      alignItems: "center",
      justifyContent: "flex-start",
      paddingTop: 4,
      overflow: "hidden"
    },
    userInfo: {
      flex: 1,
      gap: 1
    },
    userName: {
      fontSize: 15,
      fontFamily: "Inter_600SemiBold"
    },
    userHandle: {
      fontSize: 12,
      fontFamily: "Inter_400Regular"
    },
    userRecord: {
      fontSize: 11,
      fontFamily: "Inter_500Medium",
      marginTop: 2
    },
    addBtn: {
      paddingHorizontal: 16,
      minHeight: 36,
      justifyContent: "center",
      borderRadius: 10
    },
    addText: {
      fontSize: 14,
      fontFamily: "Inter_800ExtraBold"
    },
    pendingPill: {
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderRadius: 10,
      borderWidth: 1
    },
    pendingText: {
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    },
    empty: {
      alignItems: "center",
      gap: 8,
      padding: 32,
      borderRadius: 16,
      borderWidth: 1,
      marginTop: 24
    },
    emptyTitle: {
      fontSize: 16,
      fontFamily: "Inter_600SemiBold"
    },
    emptyBody: {
      fontSize: 13,
      fontFamily: "Inter_400Regular",
      textAlign: "center"
    },
    divider: {
      height: StyleSheet.default.hairlineWidth
    },
    actionRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    }
  });
},751,[842,843,844,816,818,820,817,12,228,107,104,28,188,255,109,827,271,828,832,845,833,836,837,821,822,823,838,819,846,6]);