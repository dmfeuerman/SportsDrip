__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return CheckoutScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _libMotion = require(_dependencyMap[2]);
  var _expoRouter = require(_dependencyMap[3]);
  var _react = require(_dependencyMap[4]);
  require(_dependencyMap[5]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[6]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[7]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[8]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[9]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[10]);
  var _reactNativeSafeAreaContext = require(_dependencyMap[11]);
  var _componentsAvatarItemIcon = require(_dependencyMap[12]);
  var ItemIcon = _interopDefault(_componentsAvatarItemIcon);
  var _componentsAvatarDisplay = require(_dependencyMap[13]);
  var AvatarDisplay = _interopDefault(_componentsAvatarDisplay);
  var _componentsFxBurst = require(_dependencyMap[14]);
  var Burst = _interopDefault(_componentsFxBurst);
  var _hooksUseCatalog = require(_dependencyMap[15]);
  var _libShareCard = require(_dependencyMap[16]);
  var _componentsTokenBalance = require(_dependencyMap[17]);
  var TokenBalance = _interopDefault(_componentsTokenBalance);
  var _componentsUi = require(_dependencyMap[18]);
  var _contextAppContext = require(_dependencyMap[19]);
  var _contextCartContext = require(_dependencyMap[20]);
  var _hooksUseCartItems = require(_dependencyMap[21]);
  var _hooksUseColors = require(_dependencyMap[22]);
  var _typesCatalog = require(_dependencyMap[23]);
  var _reactJsxRuntime = require(_dependencyMap[24]);
  const credits = n => n.toLocaleString();
  const cap = s => s[0].toUpperCase() + s.slice(1);

  /**
   * The cart, as its own screen: every selected item as a product card (image,
   * name, details, price, Remove), an order summary, and one Checkout button.
   * Buys each item through the server (which owns balances and inventory and is
   * idempotent), then saves the look they were picked for, so paying means
   * wearing it.
   */
  function CheckoutScreen() {
    const $ = (0, _reactCompilerRuntime.c)(82);
    const c = (0, _hooksUseColors.useColors)();
    const insets = (0, _reactNativeSafeAreaContext.useSafeAreaInsets)();
    const cart = (0, _contextCartContext.useCart)();
    const {
      balance,
      inventory,
      purchaseItem,
      saveLook,
      error,
      clearError,
      profile
    } = (0, _contextAppContext.useApp)();
    const {
      byId
    } = (0, _hooksUseCatalog.useCatalog)();
    const showcaseRef = (0, _react.useRef)(null);
    const {
      from
    } = (0, _expoRouter.useLocalSearchParams)();
    const [phase, setPhase] = (0, _react.useState)("review");
    let t0;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t0 = [];
      $[0] = t0;
    } else {
      t0 = $[0];
    }
    const [failed, setFailed] = (0, _react.useState)(t0);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = [];
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    const [bought, setBought] = (0, _react.useState)(t1);
    const [lookSaved, setLookSaved] = (0, _react.useState)(true);
    const [clearAsk, setClearAsk] = (0, _react.useState)(false);
    let t2;
    if ($[2] !== inventory) {
      t2 = new Set(inventory);
      $[2] = inventory;
      $[3] = t2;
    } else {
      t2 = $[3];
    }
    const owned = t2;
    const {
      items,
      total
    } = (0, _hooksUseCartItems.useCartItems)();
    const after = balance - total;
    const short = after < 0;
    const back = _temp;
    let t3;
    if ($[4] !== from) {
      t3 = () => {
        if ((from === "customize" || from === "shop") && _expoRouter.router.canGoBack()) {
          _expoRouter.router.back();
        } else {
          _expoRouter.router.replace("/shop");
        }
      };
      $[4] = from;
      $[5] = t3;
    } else {
      t3 = $[5];
    }
    const continueShopping = t3;
    const continueLabel = from === "customize" ? "Keep customizing" : "Continue shopping";
    let t4;
    if ($[6] !== cart) {
      t4 = () => {
        setClearAsk(false);
        setFailed([]);
        cart.clear();
        _libMotion.haptic.warning();
      };
      $[6] = cart;
      $[7] = t4;
    } else {
      t4 = $[7];
    }
    const clearCart = t4;
    let t5;
    if ($[8] !== cart || $[9] !== clearError || $[10] !== items || $[11] !== owned || $[12] !== purchaseItem || $[13] !== saveLook || $[14] !== short) {
      t5 = async () => {
        if (!items.length || short) {
          return;
        }
        clearError();
        setFailed([]);
        setPhase("paying");
        const ok = [];
        const bad = [];
        for (const item of items) {
          if (await purchaseItem(item.id, item.price)) {
            ok.push(item);
          } else {
            bad.push(item.id);
          }
        }
        setBought(ok);
        if (bad.length) {
          setFailed(bad);
          setPhase("review");
          _libMotion.haptic.error();
          return;
        }
        const mine = new Set([...owned, ...ok.map(_temp2)]);
        const draft = cart.draft;
        const equipped = draft ? Object.fromEntries(Object.entries(draft.equipped).filter(t6 => {
          const [, id] = t6;
          return !!id && mine.has(id);
        })) : null;
        const saved = draft && equipped ? await saveLook(draft.avatar, equipped) : true;
        cart.checkedOut();
        _libMotion.haptic.success();
        setLookSaved(saved);
        setPhase("done");
      };
      $[8] = cart;
      $[9] = clearError;
      $[10] = items;
      $[11] = owned;
      $[12] = purchaseItem;
      $[13] = saveLook;
      $[14] = short;
      $[15] = t5;
    } else {
      t5 = $[15];
    }
    const pay = t5;
    const top = 18;
    let t6;
    if ($[16] !== c.background) {
      t6 = [styles.fill, {
        backgroundColor: c.background
      }];
      $[16] = c.background;
      $[17] = t6;
    } else {
      t6 = $[17];
    }
    let t7;
    if ($[18] !== c.border || $[19] !== top) {
      t7 = [styles.header, {
        paddingTop: top,
        borderBottomColor: c.border
      }];
      $[18] = c.border;
      $[19] = top;
      $[20] = t7;
    } else {
      t7 = $[20];
    }
    let t8;
    if ($[21] !== c.border || $[22] !== c.secondary) {
      t8 = [styles.round, {
        backgroundColor: c.secondary,
        borderColor: c.border
      }];
      $[21] = c.border;
      $[22] = c.secondary;
      $[23] = t8;
    } else {
      t8 = $[23];
    }
    let t9;
    if ($[24] !== c.foreground) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "chevron-left",
        size: 22,
        color: c.foreground
      });
      $[24] = c.foreground;
      $[25] = t9;
    } else {
      t9 = $[25];
    }
    let t10;
    if ($[26] !== t8 || $[27] !== t9) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
        accessibilityRole: "button",
        accessibilityLabel: "Back",
        onPress: back,
        hitSlop: 10,
        style: t8,
        children: t9
      });
      $[26] = t8;
      $[27] = t9;
      $[28] = t10;
    } else {
      t10 = $[28];
    }
    let t11;
    if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
      t11 = {
        flex: 1
      };
      $[29] = t11;
    } else {
      t11 = $[29];
    }
    let t12;
    if ($[30] !== c.foreground) {
      t12 = [styles.title, {
        color: c.foreground
      }];
      $[30] = c.foreground;
      $[31] = t12;
    } else {
      t12 = $[31];
    }
    const t13 = phase === "done" ? "Order complete" : "Your cart";
    let t14;
    if ($[32] !== t12 || $[33] !== t13) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        accessibilityRole: "header",
        style: t12,
        children: t13
      });
      $[32] = t12;
      $[33] = t13;
      $[34] = t14;
    } else {
      t14 = $[34];
    }
    let t15;
    if ($[35] !== c.mutedForeground || $[36] !== items.length || $[37] !== phase) {
      t15 = phase !== "done" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.subtitle, {
          color: c.mutedForeground
        }],
        children: [items.length, " ", items.length === 1 ? "item" : "items", " in your cart"]
      }) : null;
      $[35] = c.mutedForeground;
      $[36] = items.length;
      $[37] = phase;
      $[38] = t15;
    } else {
      t15 = $[38];
    }
    let t16;
    if ($[39] !== t14 || $[40] !== t15) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t11,
        children: [t14, t15]
      });
      $[39] = t14;
      $[40] = t15;
      $[41] = t16;
    } else {
      t16 = $[41];
    }
    let t17;
    if ($[42] !== balance) {
      t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TokenBalance.default, {
        tokens: balance,
        size: "sm"
      });
      $[42] = balance;
      $[43] = t17;
    } else {
      t17 = $[43];
    }
    let t18;
    if ($[44] !== t10 || $[45] !== t16 || $[46] !== t17 || $[47] !== t7) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t7,
        children: [t10, t16, t17]
      });
      $[44] = t10;
      $[45] = t16;
      $[46] = t17;
      $[47] = t7;
      $[48] = t18;
    } else {
      t18 = $[48];
    }
    let t19;
    if ($[49] !== clearError || $[50] !== error) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ErrorBanner, {
        message: error,
        onDismiss: clearError
      });
      $[49] = clearError;
      $[50] = error;
      $[51] = t19;
    } else {
      t19 = $[51];
    }
    let t20;
    if ($[52] !== after || $[53] !== balance || $[54] !== bought || $[55] !== byId || $[56] !== c || $[57] !== cart || $[58] !== continueLabel || $[59] !== continueShopping || $[60] !== failed || $[61] !== insets || $[62] !== items || $[63] !== lookSaved || $[64] !== pay || $[65] !== phase || $[66] !== profile?.avatar || $[67] !== profile?.equipped || $[68] !== short || $[69] !== total) {
      t20 = phase === "done" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        contentContainerStyle: [styles.doneBody, {
          paddingBottom: insets.bottom + 24
        }],
        children: [lookSaved ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          ref: showcaseRef,
          collapsable: false,
          style: [styles.showcase, {
            backgroundColor: c.positiveSoft
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarDisplay.default, {
            avatar: profile?.avatar,
            equipped: profile?.equipped,
            catalog: byId,
            size: "lg",
            interactive: false,
            focus: "reaction",
            reaction: {
              kind: "win",
              id: 1
            }
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Burst.default, {
            colors: [c.positive, c.accent, "#FFFFFF", "#FFC83D"],
            trigger: 1,
            count: 40,
            originY: 0.35
          })]
        }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [styles.doneIcon, {
            backgroundColor: c.positiveSoft
          }],
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "check-bold",
            size: 30,
            color: c.positive
          })
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.doneTitle, {
            color: c.foreground
          }],
          children: lookSaved ? "You're wearing it" : "Purchase complete"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.doneText, {
            color: c.mutedForeground
          }],
          children: lookSaved ? "Everything below is in your wardrobe and your look is saved." : "Everything below is in your wardrobe. Your look didn't save \u2014 tap Save in Customize."
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.receipt, {
            backgroundColor: c.card,
            borderColor: c.border
          }],
          children: [bought.map(item_0 => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.receiptRow,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.receiptName, {
                color: c.foreground
              }],
              numberOfLines: 1,
              children: item_0.name
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.receiptPrice, {
                color: c.mutedForeground
              }],
              children: credits(item_0.price)
            })]
          }, item_0.id)), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [styles.divider, {
              backgroundColor: c.border
            }]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.receiptRow,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.receiptName, styles.strong, {
                color: c.foreground
              }],
              children: "Paid"
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.receiptPrice, styles.strong, {
                color: c.foreground
              }],
              children: credits(bought.reduce(_temp3, 0))
            })]
          })]
        }), lookSaved ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: "Show the League",
            icon: "share-variant",
            onPress: () => void (0, _libShareCard.shareViewOrText)({
              viewRef: showcaseRef,
              kind: "purchase",
              message: `New fit just dropped: ${bought.map(_temp4).join(", ")} — on SportDrip`
            }),
            style: styles.stretch
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: "Back to Home",
            icon: "home-variant-outline",
            variant: "secondary",
            onPress: _temp5,
            style: styles.stretch
          })]
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: continueLabel,
          variant: "secondary",
          onPress: continueShopping,
          style: styles.stretch
        })]
      }) : items.length === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.empty,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [styles.emptyIcon, {
            backgroundColor: c.secondary
          }],
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "cart-outline",
            size: 34,
            color: c.mutedForeground
          })
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.doneTitle, {
            color: c.foreground
          }],
          children: "Your Cart Is Empty"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.doneText, {
            color: c.mutedForeground
          }],
          children: "Add items in the Drip Shop, or try one on in Customize. They land here, ready to buy."
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: continueLabel,
          icon: "tshirt-crew-outline",
          onPress: continueShopping,
          style: styles.stretch
        })]
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
          style: styles.fill,
          contentContainerStyle: styles.body,
          showsVerticalScrollIndicator: false,
          children: [items.map(item_1 => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(CartItem, {
            item: item_1,
            failed: failed.includes(item_1.id),
            disabled: phase === "paying",
            onRemove: () => {
              _libMotion.haptic.tick();
              cart.remove(item_1.id);
            }
          }, item_1.id)), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.cartActions,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
              label: continueLabel,
              icon: "arrow-left",
              chevron: false,
              tone: "money",
              onPress: continueShopping
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
              accessibilityRole: "button",
              accessibilityLabel: "Clear cart",
              hitSlop: 8,
              disabled: phase === "paying",
              onPress: () => setClearAsk(true),
              style: t21 => {
                const {
                  pressed
                } = t21;
                return [styles.remove, {
                  borderColor: c.alpha(c.negative, 0.5),
                  opacity: phase === "paying" ? 0.4 : pressed ? 0.6 : 1
                }];
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "cart-remove",
                size: 15,
                color: c.negative
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.removeText, {
                  color: c.negative
                }],
                children: "Clear Cart"
              })]
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.summary, {
              backgroundColor: c.card,
              borderColor: c.border
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.summaryTitle, {
                color: c.foreground
              }],
              children: "Order Summary"
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Line, {
              label: `Subtotal (${items.length} ${items.length === 1 ? "item" : "items"})`,
              value: credits(total)
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Line, {
              label: "Fees",
              value: "Free"
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.divider, {
                backgroundColor: c.border
              }]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Line, {
              label: "Total",
              value: `${credits(total)} credits`,
              strong: true
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Line, {
              label: "Your Balance",
              value: credits(balance)
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Line, {
              label: "Balance After",
              value: credits(after),
              tone: short ? c.negative : c.positive
            }), short ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.note, {
                color: c.negative
              }],
              children: ["You're ", credits(Math.abs(after)), " credits short. Remove something or win a few bets first."]
            }) : null, bought.length && failed.length ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.note, {
                color: c.mutedForeground
              }],
              children: ["Bought ", bought.map(_temp6).join(", "), ". The rest are still in your cart."]
            }) : null]
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.footer, {
            borderTopColor: c.border,
            backgroundColor: c.background,
            paddingBottom: insets.bottom + 12
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: {
              flex: 1
            },
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.footLabel, {
                color: c.mutedForeground
              }],
              children: "Total"
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.footTotal,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "lightning-bolt",
                size: 18,
                color: c.primary
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.footValue, {
                  color: c.foreground
                }],
                children: credits(total)
              })]
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: phase === "paying" ? "Paying\u2026" : "Checkout",
            icon: "lock-outline",
            size: "lg",
            onPress: pay,
            loading: phase === "paying",
            disabled: short || phase === "paying",
            style: {
              minWidth: 170
            }
          })]
        })]
      });
      $[52] = after;
      $[53] = balance;
      $[54] = bought;
      $[55] = byId;
      $[56] = c;
      $[57] = cart;
      $[58] = continueLabel;
      $[59] = continueShopping;
      $[60] = failed;
      $[61] = insets;
      $[62] = items;
      $[63] = lookSaved;
      $[64] = pay;
      $[65] = phase;
      $[66] = profile?.avatar;
      $[67] = profile?.equipped;
      $[68] = short;
      $[69] = total;
      $[70] = t20;
    } else {
      t20 = $[70];
    }
    const t21 = `Removes ${items.length === 1 ? "the 1 item" : `all ${items.length} items`} from your cart. Anything you were trying on in Customize comes off too.`;
    let t22;
    if ($[71] === Symbol.for("react.memo_cache_sentinel")) {
      t22 = () => setClearAsk(false);
      $[71] = t22;
    } else {
      t22 = $[71];
    }
    let t23;
    if ($[72] !== clearAsk || $[73] !== clearCart || $[74] !== t21) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ConfirmDialog, {
        visible: clearAsk,
        title: "Clear your cart?",
        body: t21,
        confirmLabel: "Clear Cart",
        destructive: true,
        onConfirm: clearCart,
        onCancel: t22
      });
      $[72] = clearAsk;
      $[73] = clearCart;
      $[74] = t21;
      $[75] = t23;
    } else {
      t23 = $[75];
    }
    let t24;
    if ($[76] !== t18 || $[77] !== t19 || $[78] !== t20 || $[79] !== t23 || $[80] !== t6) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t6,
        children: [t18, t19, t20, t23]
      });
      $[76] = t18;
      $[77] = t19;
      $[78] = t20;
      $[79] = t23;
      $[80] = t6;
      $[81] = t24;
    } else {
      t24 = $[81];
    }
    return t24;
  }

  /** One product in the cart: picture, name, details, price and Remove. */
  function _temp6(b) {
    return b.name;
  }
  function _temp5() {
    return _expoRouter.router.dismissTo("/(tabs)");
  }
  function _temp4(i_1) {
    return i_1.name;
  }
  function _temp3(s, i_0) {
    return s + i_0.price;
  }
  function _temp2(i) {
    return i.id;
  }
  function _temp() {
    return _expoRouter.router.canGoBack() ? _expoRouter.router.back() : _expoRouter.router.replace("/(tabs)/avatar");
  }
  function CartItem(t0) {
    const $ = (0, _reactCompilerRuntime.c)(82);
    const {
      item,
      failed,
      disabled,
      onRemove
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const rarity = _typesCatalog.RARITY_COLORS[item.rarity];
    const t1 = failed ? c.negative : c.border;
    let t2;
    if ($[0] !== c.card || $[1] !== t1) {
      t2 = [styles.card, {
        backgroundColor: c.card,
        borderColor: t1
      }];
      $[0] = c.card;
      $[1] = t1;
      $[2] = t2;
    } else {
      t2 = $[2];
    }
    const t3 = c.secondary;
    let t4;
    if ($[3] !== c || $[4] !== rarity) {
      t4 = c.alpha(rarity, 0.5);
      $[3] = c;
      $[4] = rarity;
      $[5] = t4;
    } else {
      t4 = $[5];
    }
    let t5;
    if ($[6] !== c.secondary || $[7] !== t4) {
      t5 = [styles.image, {
        backgroundColor: t3,
        borderColor: t4
      }];
      $[6] = c.secondary;
      $[7] = t4;
      $[8] = t5;
    } else {
      t5 = $[8];
    }
    let t6;
    if ($[9] !== item) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ItemIcon.default, {
        item: item,
        size: 80
      });
      $[9] = item;
      $[10] = t6;
    } else {
      t6 = $[10];
    }
    let t7;
    if ($[11] !== rarity) {
      t7 = [styles.rarityTag, {
        backgroundColor: rarity
      }];
      $[11] = rarity;
      $[12] = t7;
    } else {
      t7 = $[12];
    }
    let t8;
    if ($[13] !== item.rarity) {
      t8 = item.rarity.toUpperCase();
      $[13] = item.rarity;
      $[14] = t8;
    } else {
      t8 = $[14];
    }
    let t9;
    if ($[15] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: styles.rarityText,
        children: t8
      });
      $[15] = t8;
      $[16] = t9;
    } else {
      t9 = $[16];
    }
    let t10;
    if ($[17] !== t7 || $[18] !== t9) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t7,
        children: t9
      });
      $[17] = t7;
      $[18] = t9;
      $[19] = t10;
    } else {
      t10 = $[19];
    }
    let t11;
    if ($[20] !== t10 || $[21] !== t5 || $[22] !== t6) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t5,
        children: [t6, t10]
      });
      $[20] = t10;
      $[21] = t5;
      $[22] = t6;
      $[23] = t11;
    } else {
      t11 = $[23];
    }
    let t12;
    if ($[24] !== c.foreground) {
      t12 = [styles.name, {
        color: c.foreground
      }];
      $[24] = c.foreground;
      $[25] = t12;
    } else {
      t12 = $[25];
    }
    let t13;
    if ($[26] !== item.name || $[27] !== t12) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t12,
        numberOfLines: 2,
        children: item.name
      });
      $[26] = item.name;
      $[27] = t12;
      $[28] = t13;
    } else {
      t13 = $[28];
    }
    let t14;
    if ($[29] !== c.mutedForeground) {
      t14 = [styles.meta, {
        color: c.mutedForeground
      }];
      $[29] = c.mutedForeground;
      $[30] = t14;
    } else {
      t14 = $[30];
    }
    const t15 = _typesCatalog.SLOT_LABELS[item.slot];
    let t16;
    if ($[31] !== item.rarity) {
      t16 = cap(item.rarity);
      $[31] = item.rarity;
      $[32] = t16;
    } else {
      t16 = $[32];
    }
    let t17;
    if ($[33] !== t14 || $[34] !== t15 || $[35] !== t16) {
      t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: t14,
        numberOfLines: 1,
        children: [t15, " \xB7 ", t16, " \xB7 Qty 1"]
      });
      $[33] = t14;
      $[34] = t15;
      $[35] = t16;
      $[36] = t17;
    } else {
      t17 = $[36];
    }
    let t18;
    if ($[37] !== c.subtleForeground || $[38] !== item.description) {
      t18 = item.description ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.desc, {
          color: c.subtleForeground
        }],
        numberOfLines: 2,
        children: item.description
      }) : null;
      $[37] = c.subtleForeground;
      $[38] = item.description;
      $[39] = t18;
    } else {
      t18 = $[39];
    }
    let t19;
    if ($[40] !== c.negative || $[41] !== failed) {
      t19 = failed ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.meta, {
          color: c.negative
        }],
        children: "Couldn't buy this one. Try again."
      }) : null;
      $[40] = c.negative;
      $[41] = failed;
      $[42] = t19;
    } else {
      t19 = $[42];
    }
    let t20;
    if ($[43] !== c.primary) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "lightning-bolt",
        size: 15,
        color: c.primary
      });
      $[43] = c.primary;
      $[44] = t20;
    } else {
      t20 = $[44];
    }
    let t21;
    if ($[45] !== c.foreground) {
      t21 = [styles.price, {
        color: c.foreground
      }];
      $[45] = c.foreground;
      $[46] = t21;
    } else {
      t21 = $[46];
    }
    let t22;
    if ($[47] !== item.price) {
      t22 = credits(item.price);
      $[47] = item.price;
      $[48] = t22;
    } else {
      t22 = $[48];
    }
    let t23;
    if ($[49] !== t21 || $[50] !== t22) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t21,
        children: t22
      });
      $[49] = t21;
      $[50] = t22;
      $[51] = t23;
    } else {
      t23 = $[51];
    }
    let t24;
    if ($[52] !== t20 || $[53] !== t23) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.priceRow,
        children: [t20, t23]
      });
      $[52] = t20;
      $[53] = t23;
      $[54] = t24;
    } else {
      t24 = $[54];
    }
    const t25 = `Remove ${item.name} from cart`;
    let t26;
    if ($[55] !== c.border || $[56] !== disabled) {
      t26 = t27 => {
        const {
          pressed
        } = t27;
        return [styles.remove, {
          borderColor: c.border,
          opacity: disabled ? 0.4 : pressed ? 0.6 : 1
        }];
      };
      $[55] = c.border;
      $[56] = disabled;
      $[57] = t26;
    } else {
      t26 = $[57];
    }
    let t27;
    if ($[58] !== c.negative) {
      t27 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "trash-can-outline",
        size: 15,
        color: c.negative
      });
      $[58] = c.negative;
      $[59] = t27;
    } else {
      t27 = $[59];
    }
    let t28;
    if ($[60] !== c.negative) {
      t28 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.removeText, {
          color: c.negative
        }],
        children: "Remove"
      });
      $[60] = c.negative;
      $[61] = t28;
    } else {
      t28 = $[61];
    }
    let t29;
    if ($[62] !== disabled || $[63] !== onRemove || $[64] !== t25 || $[65] !== t26 || $[66] !== t27 || $[67] !== t28) {
      t29 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        accessibilityRole: "button",
        accessibilityLabel: t25,
        hitSlop: 8,
        disabled: disabled,
        onPress: onRemove,
        style: t26,
        children: [t27, t28]
      });
      $[62] = disabled;
      $[63] = onRemove;
      $[64] = t25;
      $[65] = t26;
      $[66] = t27;
      $[67] = t28;
      $[68] = t29;
    } else {
      t29 = $[68];
    }
    let t30;
    if ($[69] !== t24 || $[70] !== t29) {
      t30 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.cardFoot,
        children: [t24, t29]
      });
      $[69] = t24;
      $[70] = t29;
      $[71] = t30;
    } else {
      t30 = $[71];
    }
    let t31;
    if ($[72] !== t13 || $[73] !== t17 || $[74] !== t18 || $[75] !== t19 || $[76] !== t30) {
      t31 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.cardBody,
        children: [t13, t17, t18, t19, t30]
      });
      $[72] = t13;
      $[73] = t17;
      $[74] = t18;
      $[75] = t19;
      $[76] = t30;
      $[77] = t31;
    } else {
      t31 = $[77];
    }
    let t32;
    if ($[78] !== t11 || $[79] !== t2 || $[80] !== t31) {
      t32 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t2,
        children: [t11, t31]
      });
      $[78] = t11;
      $[79] = t2;
      $[80] = t31;
      $[81] = t32;
    } else {
      t32 = $[81];
    }
    return t32;
  }
  function Line(t0) {
    const $ = (0, _reactCompilerRuntime.c)(19);
    const {
      label,
      value,
      strong,
      tone
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const t1 = strong ? c.foreground : c.mutedForeground;
    let t2;
    if ($[0] !== t1) {
      t2 = {
        color: t1
      };
      $[0] = t1;
      $[1] = t2;
    } else {
      t2 = $[1];
    }
    const t3 = strong && styles.strong;
    let t4;
    if ($[2] !== t2 || $[3] !== t3) {
      t4 = [styles.lineLabel, t2, t3];
      $[2] = t2;
      $[3] = t3;
      $[4] = t4;
    } else {
      t4 = $[4];
    }
    let t5;
    if ($[5] !== label || $[6] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t4,
        children: label
      });
      $[5] = label;
      $[6] = t4;
      $[7] = t5;
    } else {
      t5 = $[7];
    }
    const t6 = tone ?? (strong ? c.foreground : c.mutedForeground);
    let t7;
    if ($[8] !== t6) {
      t7 = {
        color: t6
      };
      $[8] = t6;
      $[9] = t7;
    } else {
      t7 = $[9];
    }
    const t8 = strong && styles.strong;
    let t9;
    if ($[10] !== t7 || $[11] !== t8) {
      t9 = [styles.lineValue, t7, t8];
      $[10] = t7;
      $[11] = t8;
      $[12] = t9;
    } else {
      t9 = $[12];
    }
    let t10;
    if ($[13] !== t9 || $[14] !== value) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t9,
        children: value
      });
      $[13] = t9;
      $[14] = value;
      $[15] = t10;
    } else {
      t10 = $[15];
    }
    let t11;
    if ($[16] !== t10 || $[17] !== t5) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.line,
        children: [t5, t10]
      });
      $[16] = t10;
      $[17] = t5;
      $[18] = t11;
    } else {
      t11 = $[18];
    }
    return t11;
  }
  const styles = StyleSheet.default.create({
    showcase: {
      alignSelf: "stretch",
      height: 280,
      borderRadius: 22,
      overflow: "hidden"
    },
    fill: {
      flex: 1
    },
    header: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      paddingHorizontal: 14,
      paddingBottom: 10,
      borderBottomWidth: StyleSheet.default.hairlineWidth
    },
    round: {
      width: 36,
      height: 36,
      borderRadius: 18,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center"
    },
    title: {
      fontSize: 20,
      fontFamily: "Inter_900Black"
    },
    subtitle: {
      fontSize: 12,
      fontFamily: "Inter_500Medium",
      marginTop: 1
    },
    body: {
      padding: 16,
      gap: 12,
      paddingBottom: 24
    },
    card: {
      flexDirection: "row",
      gap: 12,
      padding: 12,
      borderRadius: 16,
      borderWidth: 1
    },
    image: {
      width: 96,
      height: 108,
      borderRadius: 12,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden"
    },
    rarityTag: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: 0,
      paddingVertical: 2,
      alignItems: "center"
    },
    rarityText: {
      color: "#fff",
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.6
    },
    cardBody: {
      flex: 1,
      gap: 3
    },
    name: {
      fontSize: 15,
      fontFamily: "Inter_700Bold"
    },
    meta: {
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    },
    desc: {
      fontSize: 12,
      lineHeight: 16,
      fontFamily: "Inter_400Regular"
    },
    cardFoot: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      marginTop: "auto",
      paddingTop: 6
    },
    priceRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 2
    },
    price: {
      fontSize: 16,
      fontFamily: "Inter_700Bold",
      fontVariant: ["tabular-nums"]
    },
    remove: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 10,
      borderWidth: 1
    },
    removeText: {
      fontSize: 12,
      fontFamily: "Inter_600SemiBold"
    },
    cartActions: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 10
    },
    continue: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6,
      alignSelf: "flex-start",
      paddingVertical: 4
    },
    continueText: {
      fontSize: 13,
      fontFamily: "Inter_600SemiBold"
    },
    summary: {
      borderRadius: 16,
      borderWidth: 1,
      padding: 16,
      gap: 8
    },
    summaryTitle: {
      fontSize: 16,
      fontFamily: "Inter_700Bold",
      marginBottom: 2
    },
    divider: {
      height: StyleSheet.default.hairlineWidth,
      marginVertical: 4
    },
    line: {
      flexDirection: "row",
      justifyContent: "space-between",
      gap: 12
    },
    lineLabel: {
      fontSize: 13,
      fontFamily: "Inter_500Medium"
    },
    lineValue: {
      fontSize: 13,
      fontFamily: "Inter_600SemiBold",
      fontVariant: ["tabular-nums"]
    },
    strong: {
      fontSize: 15,
      fontFamily: "Inter_700Bold"
    },
    note: {
      fontSize: 12,
      lineHeight: 17,
      fontFamily: "Inter_400Regular"
    },
    footer: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      borderTopWidth: StyleSheet.default.hairlineWidth,
      paddingHorizontal: 16,
      paddingTop: 12
    },
    footLabel: {
      fontSize: 11,
      fontFamily: "Inter_600SemiBold",
      letterSpacing: 0.4
    },
    footTotal: {
      flexDirection: "row",
      alignItems: "center",
      gap: 2
    },
    footValue: {
      fontSize: 20,
      fontFamily: "Inter_700Bold",
      fontVariant: ["tabular-nums"]
    },
    empty: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
      padding: 24,
      gap: 10
    },
    emptyIcon: {
      width: 72,
      height: 72,
      borderRadius: 36,
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 4
    },
    doneBody: {
      alignItems: "center",
      padding: 24,
      paddingTop: 48,
      gap: 10
    },
    doneIcon: {
      width: 64,
      height: 64,
      borderRadius: 32,
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 6
    },
    doneTitle: {
      fontSize: 22,
      fontFamily: "Inter_700Bold"
    },
    doneText: {
      fontSize: 14,
      lineHeight: 20,
      fontFamily: "Inter_400Regular",
      textAlign: "center",
      marginBottom: 6
    },
    receipt: {
      alignSelf: "stretch",
      borderRadius: 16,
      borderWidth: 1,
      padding: 14,
      gap: 8,
      marginBottom: 8
    },
    receiptRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      gap: 12
    },
    receiptName: {
      flex: 1,
      fontSize: 14,
      fontFamily: "Inter_500Medium"
    },
    receiptPrice: {
      fontSize: 14,
      fontFamily: "Inter_600SemiBold",
      fontVariant: ["tabular-nums"]
    },
    stretch: {
      alignSelf: "stretch"
    }
  });
},760,[815,818,820,817,12,104,133,28,188,109,827,271,834,828,899,838,1198,835,836,837,1191,1215,819,839,6]);