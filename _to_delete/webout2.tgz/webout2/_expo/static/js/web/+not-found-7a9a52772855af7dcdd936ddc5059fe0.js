__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return NotFoundScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoRouter = require(_dependencyMap[1]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[2]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[3]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[4]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _hooksUseColors = require(_dependencyMap[5]);
  var _reactJsxRuntime = require(_dependencyMap[6]);
  function NotFoundScreen() {
    const $ = (0, _reactCompilerRuntime.c)(11);
    const colors = (0, _hooksUseColors.useColors)();
    let t0;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t0 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoRouter.Stack.Screen, {
        options: {
          title: "Oops!"
        }
      });
      $[0] = t0;
    } else {
      t0 = $[0];
    }
    let t1;
    if ($[1] !== colors.background) {
      t1 = [styles.container, {
        backgroundColor: colors.background
      }];
      $[1] = colors.background;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    let t2;
    if ($[3] !== colors.foreground) {
      t2 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.title, {
          color: colors.foreground
        }],
        children: "This screen doesn't exist."
      });
      $[3] = colors.foreground;
      $[4] = t2;
    } else {
      t2 = $[4];
    }
    let t3;
    if ($[5] !== colors.primary) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoRouter.Link, {
        href: "/",
        style: styles.link,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.linkText, {
            color: colors.primary
          }],
          children: "Go to home screen!"
        })
      });
      $[5] = colors.primary;
      $[6] = t3;
    } else {
      t3 = $[6];
    }
    let t4;
    if ($[7] !== t1 || $[8] !== t2 || $[9] !== t3) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [t0, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: t1,
          children: [t2, t3]
        })]
      });
      $[7] = t1;
      $[8] = t2;
      $[9] = t3;
      $[10] = t4;
    } else {
      t4 = $[10];
    }
    return t4;
  }
  const styles = StyleSheet.default.create({
    container: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
      padding: 20
    },
    title: {
      fontSize: 20,
      fontWeight: "bold"
    },
    link: {
      marginTop: 15,
      paddingVertical: 15
    },
    linkText: {
      fontSize: 14
    }
  });
},755,[815,817,28,188,109,819,6]);