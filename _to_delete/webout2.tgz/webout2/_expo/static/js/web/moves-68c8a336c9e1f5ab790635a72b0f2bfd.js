__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return MovesScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _libMotion = require(_dependencyMap[2]);
  var _expoRouter = require(_dependencyMap[3]);
  var _react = require(_dependencyMap[4]);
  require(_dependencyMap[5]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[6]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[7]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[8]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[9]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[10]);
  var _reactNativeSafeAreaContext = require(_dependencyMap[11]);
  var _componentsAvatarDisplay = require(_dependencyMap[12]);
  var AvatarDisplay = _interopDefault(_componentsAvatarDisplay);
  var _componentsTokenBalance = require(_dependencyMap[13]);
  var TokenBalance = _interopDefault(_componentsTokenBalance);
  var _componentsUi = require(_dependencyMap[14]);
  var _constantsAvatarOptions = require(_dependencyMap[15]);
  var _constantsMoves = require(_dependencyMap[16]);
  var _contextAppContext = require(_dependencyMap[17]);
  var _hooksUseCatalog = require(_dependencyMap[18]);
  var _hooksUseColors = require(_dependencyMap[19]);
  var _hooksUseMoves = require(_dependencyMap[20]);
  var _reactJsxRuntime = require(_dependencyMap[21]);
  /**
   * Edit Moves: the moves you own; pick the (up to) four on your dance button.
   * Buying happens in the Drip Shop's Moves tab (/shop?tab=moves).
   */
  function MovesScreen() {
    const $ = (0, _reactCompilerRuntime.c)(163);
    const c = (0, _hooksUseColors.useColors)();
    const insets = (0, _reactNativeSafeAreaContext.useSafeAreaInsets)();
    const focused = (0, _expoRouter.useIsFocused)();
    const {
      profile,
      balance,
      ownedMoves,
      loadout,
      setLoadout,
      error,
      clearError
    } = (0, _contextAppContext.useApp)();
    const {
      byId: catalog
    } = (0, _hooksUseCatalog.useCatalog)();
    const {
      moves,
      byId
    } = (0, _hooksUseMoves.useMoves)();
    const [selected, setSelected] = (0, _react.useState)(loadout[0] ?? "cheer");
    const [play, setPlay] = (0, _react.useState)(null);
    const [note, setNote] = (0, _react.useState)(null);
    const [gesture, setGesture] = (0, _react.useState)(false);
    let t0;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t0 = id => {
        setSelected(id);
        setNote(null);
        setPlay(p => ({
          id,
          n: (p?.n ?? 0) + 1
        }));
      };
      $[0] = t0;
    } else {
      t0 = $[0];
    }
    const preview = t0;
    let t1;
    if ($[1] !== loadout || $[2] !== setLoadout) {
      t1 = async id_0 => {
        _libMotion.haptic.tick();
        if (loadout.includes(id_0)) {
          if (loadout.length === 1) {
            return setNote("Keep at least one move on your dance button.");
          }
          setNote(null);
          await setLoadout(loadout.filter(m => m !== id_0));
        } else {
          if (loadout.length >= _constantsMoves.MAX_LOADOUT) {
            return setNote(`Your dance button holds ${_constantsMoves.MAX_LOADOUT} moves — take one off first.`);
          }
          setNote(null);
          await setLoadout([...loadout, id_0]);
        }
      };
      $[1] = loadout;
      $[2] = setLoadout;
      $[3] = t1;
    } else {
      t1 = $[3];
    }
    const toggle = t1;
    let t2;
    if ($[4] !== moves || $[5] !== ownedMoves) {
      t2 = [...moves].filter(m_0 => ownedMoves.has(m_0.id)).sort(_temp);
      $[4] = moves;
      $[5] = ownedMoves;
      $[6] = t2;
    } else {
      t2 = $[6];
    }
    const sorted = t2;
    let T0;
    let T1;
    let T2;
    let T3;
    let T4;
    let T5;
    let shop;
    let t10;
    let t11;
    let t12;
    let t13;
    let t14;
    let t15;
    let t16;
    let t17;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[7] !== balance || $[8] !== byId || $[9] !== c || $[10] !== catalog || $[11] !== clearError || $[12] !== error || $[13] !== focused || $[14] !== gesture || $[15] !== insets || $[16] !== loadout.length || $[17] !== ownedMoves.size || $[18] !== play || $[19] !== profile?.avatar || $[20] !== profile?.equipped || $[21] !== selected) {
      const sel = byId.get(selected);
      shop = _temp2;
      const top = 24;
      const bottom = 32;
      T5 = View.default;
      if ($[44] !== c.background) {
        t15 = [styles.fill, {
          backgroundColor: c.background
        }];
        $[44] = c.background;
        $[45] = t15;
      } else {
        t15 = $[45];
      }
      const t18 = 36;
      let t19;
      if ($[46] !== c.border || $[47] !== t18) {
        t19 = [styles.header, {
          paddingTop: t18,
          borderBottomColor: c.border
        }];
        $[46] = c.border;
        $[47] = t18;
        $[48] = t19;
      } else {
        t19 = $[48];
      }
      let t20;
      if ($[49] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.BackButton, {});
        $[49] = t20;
      } else {
        t20 = $[49];
      }
      let t21;
      if ($[50] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = {
          flex: 1
        };
        $[50] = t21;
      } else {
        t21 = $[50];
      }
      let t22;
      if ($[51] !== c.foreground) {
        t22 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          accessibilityRole: "header",
          style: [styles.title, {
            color: c.foreground
          }],
          children: "Edit Moves"
        });
        $[51] = c.foreground;
        $[52] = t22;
      } else {
        t22 = $[52];
      }
      let t23;
      if ($[53] !== c.mutedForeground) {
        t23 = [styles.sub, {
          color: c.mutedForeground
        }];
        $[53] = c.mutedForeground;
        $[54] = t23;
      } else {
        t23 = $[54];
      }
      const t24 = `${ownedMoves.size} owned · ${loadout.length} of ${_constantsMoves.MAX_LOADOUT} on your dance button`;
      let t25;
      if ($[55] !== t23 || $[56] !== t24) {
        t25 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: t23,
          children: t24
        });
        $[55] = t23;
        $[56] = t24;
        $[57] = t25;
      } else {
        t25 = $[57];
      }
      let t26;
      if ($[58] !== t22 || $[59] !== t25) {
        t26 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: t21,
          children: [t22, t25]
        });
        $[58] = t22;
        $[59] = t25;
        $[60] = t26;
      } else {
        t26 = $[60];
      }
      let t27;
      if ($[61] !== balance) {
        t27 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TokenBalance.default, {
          tokens: balance
        });
        $[61] = balance;
        $[62] = t27;
      } else {
        t27 = $[62];
      }
      if ($[63] !== t19 || $[64] !== t26 || $[65] !== t27) {
        t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: t19,
          children: [t20, t26, t27]
        });
        $[63] = t19;
        $[64] = t26;
        $[65] = t27;
        $[66] = t16;
      } else {
        t16 = $[66];
      }
      if ($[67] !== clearError || $[68] !== error) {
        t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ErrorBanner, {
          message: error,
          onDismiss: clearError
        });
        $[67] = clearError;
        $[68] = error;
        $[69] = t17;
      } else {
        t17 = $[69];
      }
      T4 = ScrollView.default;
      t12 = !gesture;
      if ($[70] !== bottom) {
        t13 = [styles.content, {
          paddingBottom: bottom
        }];
        $[70] = bottom;
        $[71] = t13;
      } else {
        t13 = $[71];
      }
      t14 = false;
      T3 = View.default;
      if ($[72] !== c.border || $[73] !== c.card) {
        t10 = [styles.stage, {
          backgroundColor: c.card,
          borderColor: c.border
        }];
        $[72] = c.border;
        $[73] = c.card;
        $[74] = t10;
      } else {
        t10 = $[74];
      }
      const t28 = profile?.avatar ?? _constantsAvatarOptions.DEFAULT_AVATAR;
      let t29;
      if ($[75] !== profile?.equipped) {
        t29 = profile?.equipped ?? {};
        $[75] = profile?.equipped;
        $[76] = t29;
      } else {
        t29 = $[76];
      }
      if ($[77] !== catalog || $[78] !== focused || $[79] !== play || $[80] !== t28 || $[81] !== t29) {
        t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: styles.stageInner,
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarDisplay.default, {
            avatar: t28,
            equipped: t29,
            catalog: catalog,
            size: "lg",
            focus: "hero",
            controls: false,
            onGesture: setGesture,
            move: play,
            active: focused
          })
        });
        $[77] = catalog;
        $[78] = focused;
        $[79] = play;
        $[80] = t28;
        $[81] = t29;
        $[82] = t11;
      } else {
        t11 = $[82];
      }
      T2 = View.default;
      if ($[83] !== c.border) {
        t8 = [styles.stageBar, {
          borderTopColor: c.border
        }];
        $[83] = c.border;
        $[84] = t8;
      } else {
        t8 = $[84];
      }
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [styles.icon, {
          backgroundColor: c.alpha(c.rarity(sel?.rarity ?? "common"), 0.16)
        }],
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: sel?.icon ?? "music-note",
          size: 18,
          color: c.rarity(sel?.rarity ?? "common")
        })
      });
      T1 = View.default;
      if ($[85] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
          flex: 1
        };
        $[85] = t6;
      } else {
        t6 = $[85];
      }
      let t30;
      if ($[86] !== c.foreground) {
        t30 = [styles.rowName, {
          color: c.foreground
        }];
        $[86] = c.foreground;
        $[87] = t30;
      } else {
        t30 = $[87];
      }
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t30,
        numberOfLines: 1,
        children: sel?.name ?? "Pick a move"
      });
      T0 = Text.default;
      if ($[88] !== c.mutedForeground) {
        t3 = [styles.rowMeta, {
          color: c.mutedForeground
        }];
        $[88] = c.mutedForeground;
        $[89] = t3;
      } else {
        t3 = $[89];
      }
      t4 = 1;
      t5 = sel ? `${sel.rarity[0].toUpperCase()}${sel.rarity.slice(1)} · ${sel.seconds.toFixed(0)}s` : "Tap any move to preview it";
      $[7] = balance;
      $[8] = byId;
      $[9] = c;
      $[10] = catalog;
      $[11] = clearError;
      $[12] = error;
      $[13] = focused;
      $[14] = gesture;
      $[15] = insets;
      $[16] = loadout.length;
      $[17] = ownedMoves.size;
      $[18] = play;
      $[19] = profile?.avatar;
      $[20] = profile?.equipped;
      $[21] = selected;
      $[22] = T0;
      $[23] = T1;
      $[24] = T2;
      $[25] = T3;
      $[26] = T4;
      $[27] = T5;
      $[28] = shop;
      $[29] = t10;
      $[30] = t11;
      $[31] = t12;
      $[32] = t13;
      $[33] = t14;
      $[34] = t15;
      $[35] = t16;
      $[36] = t17;
      $[37] = t3;
      $[38] = t4;
      $[39] = t5;
      $[40] = t6;
      $[41] = t7;
      $[42] = t8;
      $[43] = t9;
    } else {
      T0 = $[22];
      T1 = $[23];
      T2 = $[24];
      T3 = $[25];
      T4 = $[26];
      T5 = $[27];
      shop = $[28];
      t10 = $[29];
      t11 = $[30];
      t12 = $[31];
      t13 = $[32];
      t14 = $[33];
      t15 = $[34];
      t16 = $[35];
      t17 = $[36];
      t3 = $[37];
      t4 = $[38];
      t5 = $[39];
      t6 = $[40];
      t7 = $[41];
      t8 = $[42];
      t9 = $[43];
    }
    let t18;
    if ($[90] !== T0 || $[91] !== t3 || $[92] !== t4 || $[93] !== t5) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(T0, {
        style: t3,
        numberOfLines: t4,
        children: t5
      });
      $[90] = T0;
      $[91] = t3;
      $[92] = t4;
      $[93] = t5;
      $[94] = t18;
    } else {
      t18 = $[94];
    }
    let t19;
    if ($[95] !== T1 || $[96] !== t18 || $[97] !== t6 || $[98] !== t7) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T1, {
        style: t6,
        children: [t7, t18]
      });
      $[95] = T1;
      $[96] = t18;
      $[97] = t6;
      $[98] = t7;
      $[99] = t19;
    } else {
      t19 = $[99];
    }
    let t20;
    if ($[100] !== selected) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        label: "Play",
        icon: "play",
        size: "sm",
        onPress: () => preview(selected)
      });
      $[100] = selected;
      $[101] = t20;
    } else {
      t20 = $[101];
    }
    let t21;
    if ($[102] !== T2 || $[103] !== t19 || $[104] !== t20 || $[105] !== t8 || $[106] !== t9) {
      t21 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T2, {
        style: t8,
        children: [t9, t19, t20]
      });
      $[102] = T2;
      $[103] = t19;
      $[104] = t20;
      $[105] = t8;
      $[106] = t9;
      $[107] = t21;
    } else {
      t21 = $[107];
    }
    let t22;
    if ($[108] !== T3 || $[109] !== t10 || $[110] !== t11 || $[111] !== t21) {
      t22 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T3, {
        style: t10,
        children: [t11, t21]
      });
      $[108] = T3;
      $[109] = t10;
      $[110] = t11;
      $[111] = t21;
      $[112] = t22;
    } else {
      t22 = $[112];
    }
    let t23;
    if ($[113] !== c.foreground) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.section, {
          color: c.foreground
        }],
        children: "Your Dance Button"
      });
      $[113] = c.foreground;
      $[114] = t23;
    } else {
      t23 = $[114];
    }
    let t24;
    if ($[115] !== byId || $[116] !== c || $[117] !== loadout || $[118] !== selected || $[119] !== toggle) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.slots,
        children: Array.from({
          length: _constantsMoves.MAX_LOADOUT
        }, (_, i) => {
          const id_1 = loadout[i];
          const m_1 = id_1 ? byId.get(id_1) : undefined;
          if (!id_1 || !m_1) {
            return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: [styles.slot, styles.slotEmpty, {
                borderColor: c.border
              }],
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "plus",
                size: 18,
                color: c.subtleForeground
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.slotText, {
                  color: c.subtleForeground
                }],
                children: "Empty"
              })]
            }, `empty-${i}`);
          }
          const color = c.rarity(m_1.rarity);
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
            accessibilityRole: "button",
            accessibilityLabel: `${m_1.name}, slot ${i + 1}. Preview`,
            onPress: () => preview(id_1),
            style: t25 => {
              const {
                pressed
              } = t25;
              return [styles.slot, {
                backgroundColor: c.card,
                borderColor: selected === id_1 ? c.primary : c.border,
                opacity: pressed ? 0.85 : 1
              }];
            },
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.icon, {
                backgroundColor: c.alpha(color, 0.16)
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: m_1.icon,
                size: 18,
                color: color
              })
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.slotText, {
                color: c.foreground
              }],
              numberOfLines: 1,
              children: m_1.name
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
              accessibilityRole: "button",
              accessibilityLabel: `Take ${m_1.name} off your dance button`,
              onPress: () => toggle(id_1),
              hitSlop: 8,
              style: [styles.remove, {
                backgroundColor: c.secondary,
                borderColor: c.border
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "close",
                size: 12,
                color: c.mutedForeground
              })
            })]
          }, id_1);
        })
      });
      $[115] = byId;
      $[116] = c;
      $[117] = loadout;
      $[118] = selected;
      $[119] = toggle;
      $[120] = t24;
    } else {
      t24 = $[120];
    }
    let t25;
    if ($[121] !== c.warning || $[122] !== note) {
      t25 = note ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.note, {
          color: c.warning
        }],
        children: note
      }) : null;
      $[121] = c.warning;
      $[122] = note;
      $[123] = t25;
    } else {
      t25 = $[123];
    }
    let t26;
    if ($[124] !== c.foreground) {
      t26 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.section, {
          color: c.foreground
        }],
        children: "Your Moves"
      });
      $[124] = c.foreground;
      $[125] = t26;
    } else {
      t26 = $[125];
    }
    let t27;
    if ($[126] === Symbol.for("react.memo_cache_sentinel")) {
      t27 = {
        gap: 8
      };
      $[126] = t27;
    } else {
      t27 = $[126];
    }
    let t28;
    if ($[127] !== c || $[128] !== loadout || $[129] !== selected || $[130] !== sorted || $[131] !== toggle) {
      let t29;
      if ($[133] !== c || $[134] !== loadout || $[135] !== selected || $[136] !== toggle) {
        t29 = m_2 => {
          const on = loadout.includes(m_2.id);
          const color_0 = c.rarity(m_2.rarity);
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
            accessibilityRole: "button",
            accessibilityLabel: `${m_2.name}. ${m_2.description}. Preview`,
            onPress: () => preview(m_2.id),
            style: t30 => {
              const {
                pressed: pressed_0
              } = t30;
              return [styles.row, {
                backgroundColor: c.card,
                borderColor: selected === m_2.id ? c.alpha(c.primary, 0.7) : c.border,
                opacity: pressed_0 ? 0.9 : 1
              }];
            },
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.rowIcon, {
                backgroundColor: c.alpha(color_0, 0.16),
                borderColor: c.alpha(color_0, 0.5)
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: m_2.icon,
                size: 22,
                color: color_0
              })
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1,
                gap: 3
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: styles.rowHead,
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.rowName, {
                    color: c.foreground
                  }],
                  numberOfLines: 1,
                  children: m_2.name
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.rarity, {
                    color: color_0
                  }],
                  children: m_2.rarity.toUpperCase()
                })]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.rowMeta, {
                  color: c.mutedForeground
                }],
                numberOfLines: 2,
                children: m_2.description
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              label: on ? "On button" : "Add",
              icon: on ? "check" : "plus",
              size: "sm",
              variant: on ? "secondary" : "primary",
              onPress: () => toggle(m_2.id),
              accessibilityHint: on ? "Takes it off your dance button" : "Puts it on your dance button"
            })]
          }, m_2.id);
        };
        $[133] = c;
        $[134] = loadout;
        $[135] = selected;
        $[136] = toggle;
        $[137] = t29;
      } else {
        t29 = $[137];
      }
      t28 = sorted.map(t29);
      $[127] = c;
      $[128] = loadout;
      $[129] = selected;
      $[130] = sorted;
      $[131] = toggle;
      $[132] = t28;
    } else {
      t28 = $[132];
    }
    let t29;
    if ($[138] !== t28) {
      t29 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t27,
        children: t28
      });
      $[138] = t28;
      $[139] = t29;
    } else {
      t29 = $[139];
    }
    let t30;
    if ($[140] !== shop) {
      t30 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        label: "Get more moves in the Shop",
        icon: "cart-outline",
        onPress: shop
      });
      $[140] = shop;
      $[141] = t30;
    } else {
      t30 = $[141];
    }
    let t31;
    if ($[142] === Symbol.for("react.memo_cache_sentinel")) {
      t31 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
        label: "Free: Cheer & Fist Pump",
        icon: "gift-outline"
      });
      $[142] = t31;
    } else {
      t31 = $[142];
    }
    let t32;
    if ($[143] !== t30) {
      t32 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.footer,
        children: [t30, t31]
      });
      $[143] = t30;
      $[144] = t32;
    } else {
      t32 = $[144];
    }
    let t33;
    if ($[145] !== T4 || $[146] !== t12 || $[147] !== t13 || $[148] !== t14 || $[149] !== t22 || $[150] !== t23 || $[151] !== t24 || $[152] !== t25 || $[153] !== t26 || $[154] !== t29 || $[155] !== t32) {
      t33 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T4, {
        scrollEnabled: t12,
        contentContainerStyle: t13,
        showsVerticalScrollIndicator: t14,
        children: [t22, t23, t24, t25, t26, t29, t32]
      });
      $[145] = T4;
      $[146] = t12;
      $[147] = t13;
      $[148] = t14;
      $[149] = t22;
      $[150] = t23;
      $[151] = t24;
      $[152] = t25;
      $[153] = t26;
      $[154] = t29;
      $[155] = t32;
      $[156] = t33;
    } else {
      t33 = $[156];
    }
    let t34;
    if ($[157] !== T5 || $[158] !== t15 || $[159] !== t16 || $[160] !== t17 || $[161] !== t33) {
      t34 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T5, {
        style: t15,
        children: [t16, t17, t33]
      });
      $[157] = T5;
      $[158] = t15;
      $[159] = t16;
      $[160] = t17;
      $[161] = t33;
      $[162] = t34;
    } else {
      t34 = $[162];
    }
    return t34;
  }
  function _temp2() {
    return _expoRouter.router.push({
      pathname: "/shop",
      params: {
        tab: "moves"
      }
    });
  }
  function _temp(a, b) {
    return a.price - b.price;
  }
  const styles = StyleSheet.default.create({
    fill: {
      flex: 1
    },
    header: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      borderBottomWidth: 1,
      paddingHorizontal: 16,
      paddingBottom: 12
    },
    title: {
      fontSize: 22,
      fontFamily: "Inter_900Black"
    },
    sub: {
      fontSize: 12,
      fontFamily: "Inter_500Medium",
      marginTop: 1
    },
    content: {
      padding: 16,
      gap: 12
    },
    stage: {
      borderRadius: 20,
      borderWidth: 1,
      overflow: "hidden"
    },
    stageInner: {
      height: 360
    },
    stageBar: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      paddingHorizontal: 12,
      paddingVertical: 10,
      borderTopWidth: StyleSheet.default.hairlineWidth
    },
    icon: {
      width: 34,
      height: 34,
      borderRadius: 17,
      alignItems: "center",
      justifyContent: "center"
    },
    section: {
      fontSize: 16,
      fontFamily: "Inter_700Bold",
      marginTop: 6
    },
    slots: {
      flexDirection: "row",
      gap: 8
    },
    slot: {
      flex: 1,
      minHeight: 92,
      borderRadius: 14,
      borderWidth: 1,
      padding: 8,
      alignItems: "center",
      justifyContent: "center",
      gap: 6
    },
    slotEmpty: {
      borderStyle: "dashed"
    },
    slotText: {
      fontSize: 11,
      fontFamily: "Inter_600SemiBold",
      textAlign: "center"
    },
    remove: {
      position: "absolute",
      top: 5,
      right: 5,
      width: 20,
      height: 20,
      borderRadius: 10,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center"
    },
    note: {
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    },
    row: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      padding: 12,
      borderRadius: 16,
      borderWidth: 1
    },
    rowIcon: {
      width: 46,
      height: 46,
      borderRadius: 14,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center"
    },
    rowHead: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    rowName: {
      fontSize: 15,
      fontFamily: "Inter_700Bold",
      flexShrink: 1
    },
    rowMeta: {
      fontSize: 12,
      fontFamily: "Inter_400Regular"
    },
    rarity: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.5
    },
    footer: {
      alignItems: "center",
      marginTop: 6,
      gap: 12
    }
  });
},771,[815,818,820,817,12,104,133,28,188,109,827,271,828,835,836,894,840,837,838,819,1266,6]);