__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return ReferralLink;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoRouter = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  var _libReferrals = require(_dependencyMap[3]);
  var _reactJsxRuntime = require(_dependencyMap[4]);
  /**
   * sportdrip://ref/{CODE}
   *
   * Only reached by someone already signed up (the root layout parks the code
   * and sends everyone else to signup, where it's pre-filled). An existing
   * account can't use an invite code, so this just lands on Friends.
   */
  function ReferralLink() {
    const $ = (0, _reactCompilerRuntime.c)(3);
    const params = (0, _expoRouter.useLocalSearchParams)();
    let t0;
    if ($[0] !== params.code) {
      t0 = [params.code];
      $[0] = params.code;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    (0, _react.useEffect)(_temp, t0);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoRouter.Redirect, {
        href: "/(tabs)/friends"
      });
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    return t1;
  }
  function _temp() {
    (0, _libReferrals.clearPendingReferral)();
  }
},773,[815,817,12,1194,6]);