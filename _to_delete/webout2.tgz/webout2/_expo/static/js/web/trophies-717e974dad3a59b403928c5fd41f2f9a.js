__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      if (k === 'default') return;
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return TrophiesScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _expoLinearGradient = require(_dependencyMap[2]);
  var _firebaseFirestore = require(_dependencyMap[3]);
  var _react = require(_dependencyMap[4]);
  var _reactNativeWebDistExportsModal = require(_dependencyMap[5]);
  var Modal = _interopDefault(_reactNativeWebDistExportsModal);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[6]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[7]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[8]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[9]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _reactNativeReanimated = require(_dependencyMap[10]);
  var Animated = _interopDefault(_reactNativeReanimated);
  var _componentsFxTap = require(_dependencyMap[11]);
  var _componentsUi = require(_dependencyMap[12]);
  var _constantsAchievements = require(_dependencyMap[13]);
  var _componentsTrophyArt = require(_dependencyMap[14]);
  var TrophyArt = _interopDefault(_componentsTrophyArt);
  var _contextAppContext = require(_dependencyMap[15]);
  var _hooksUseColors = require(_dependencyMap[16]);
  var _libMotion = require(_dependencyMap[17]);
  var _libApi = require(_dependencyMap[18]);
  var api = _interopNamespace(_libApi);
  var _libDemo = require(_dependencyMap[19]);
  var _libFirebase = require(_dependencyMap[20]);
  var _reactJsxRuntime = require(_dependencyMap[21]);
  const PER_SHELF = 3;
  const WOOD = {
    hi: "#7A4B28",
    mid: "#5A3418",
    lo: "#2E1A0B"
  };
  function leaguePiece(t, i) {
    const kind = t.kind;
    const {
      metal,
      design
    } = (0, _componentsTrophyArt.trophyLook)(t);
    const name = t.title || t.leagueName || "League Trophy";
    const what = kind === "champion" ? "League Champion" : kind === "h2h_champion" ? "Head-to-Head Champion" : kind === "lock_of_week" ? "Lock of the Week" : kind === "last_place" ? "Last Place" : "League Trophy";
    return {
      key: `${t.id ?? t.leagueId}_${i}`,
      trophyId: t.id,
      title: name,
      icon: kind === "last_place" ? "emoticon-sad-outline" : kind === "lock_of_week" ? "lock" : "trophy",
      metal,
      design,
      earned: true,
      sub: t.leagueName && t.leagueName !== name ? t.leagueName : what,
      detail: [what, t.leagueName, t.rank ? `Finished #${t.rank}` : null].filter(Boolean).join(" · "),
      awardedAt: t.awardedAt
    };
  }

  /**
   * Trophy Case: every trophy and achievement on lit glass shelves. League
   * hardware sits on the top shelf; achievements fill the rest, with locked
   * ones shown as dark silhouettes that say how to earn them.
   */
  function TrophiesScreen() {
    const $ = (0, _reactCompilerRuntime.c)(66);
    const c = (0, _hooksUseColors.useColors)();
    const bottom = (0, _componentsUi.useBottomPad)(false);
    const {
      trophies,
      profile,
      writeProfile
    } = (0, _contextAppContext.useApp)();
    const [open, setOpen] = (0, _react.useState)(null);
    const [stats, setStats] = (0, _react.useState)(null);
    const [pinned] = (0, _react.useState)(undefined);
    const featured = pinned !== undefined ? pinned : profile?.featuredTrophy ?? null;
    let t0;
    let t1;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t0 = () => {
        if (_libDemo.DEMO) {
          return;
        }
        const db = (0, _libFirebase.getDb)();
        if (!db) {
          return;
        }
        return (0, _firebaseFirestore.onSnapshot)((0, _firebaseFirestore.doc)(db, "meta", "achievementStats"), s => setStats(s.exists() ? s.data() : null), _temp);
      };
      t1 = [];
      $[0] = t0;
      $[1] = t1;
    } else {
      t0 = $[0];
      t1 = $[1];
    }
    (0, _react.useEffect)(t0, t1);
    let t2;
    if ($[2] !== writeProfile) {
      t2 = async id => {
        _libMotion.haptic.medium();
        writeProfile({
          featuredTrophy: id
        }, () => api.setFeaturedTrophy({
          trophyId: id
        }));
      };
      $[2] = writeProfile;
      $[3] = t2;
    } else {
      t2 = $[3];
    }
    const pin = t2;
    let t3;
    let t4;
    let t5;
    if ($[4] !== stats || $[5] !== trophies) {
      const got = new Map(trophies.filter(_temp2).map(_temp3));
      const achievements = _constantsAchievements.ACHIEVEMENTS.map(a => {
        const t_1 = got.get(a.id);
        return {
          key: a.id,
          title: a.title,
          icon: a.icon,
          metal: a.metal,
          design: (0, _componentsTrophyArt.achievementLook)(a.id).design,
          earned: !!t_1,
          sub: t_1 ? new Date(t_1.awardedAt).toLocaleDateString() : a.how,
          detail: a.how,
          awardedAt: t_1?.awardedAt,
          trophyId: t_1?.id,
          rarity: stats && stats.players > 0 ? (stats.counts[a.id] ?? 0) / stats.players : null
        };
      }).sort(_temp4);
      let t6;
      if ($[9] !== trophies) {
        t6 = trophies.filter(_temp5).sort(_temp6).map(leaguePiece);
        $[9] = trophies;
        $[10] = t6;
      } else {
        t6 = $[10];
      }
      const league = t6;
      t3 = league;
      t4 = achievements;
      t5 = achievements.filter(_temp7);
      $[4] = stats;
      $[5] = trophies;
      $[6] = t3;
      $[7] = t4;
      $[8] = t5;
    } else {
      t3 = $[6];
      t4 = $[7];
      t5 = $[8];
    }
    let t6;
    if ($[11] !== t3 || $[12] !== t4 || $[13] !== t5.length) {
      t6 = {
        league: t3,
        achievements: t4,
        earnedCount: t5.length
      };
      $[11] = t3;
      $[12] = t4;
      $[13] = t5.length;
      $[14] = t6;
    } else {
      t6 = $[14];
    }
    const {
      league: league_0,
      achievements: achievements_0,
      earnedCount
    } = t6;
    const shelves = _temp8;
    let t7;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
      t7 = p => {
        _libMotion.haptic.light();
        setOpen(p);
      };
      $[15] = t7;
    } else {
      t7 = $[15];
    }
    const tap = t7;
    let t8;
    if ($[16] !== c.background) {
      t8 = [styles.fill, {
        backgroundColor: c.background
      }];
      $[16] = c.background;
      $[17] = t8;
    } else {
      t8 = $[17];
    }
    const t9 = `${earnedCount}/${_constantsAchievements.ACHIEVEMENTS.length} achievements · ${league_0.length} league trophi${league_0.length === 1 ? "y" : "es"}`;
    let t10;
    if ($[18] !== t9) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
        back: true,
        title: "Trophy Case",
        subtitle: t9
      });
      $[18] = t9;
      $[19] = t10;
    } else {
      t10 = $[19];
    }
    let t11;
    if ($[20] !== bottom) {
      t11 = [styles.content, {
        paddingBottom: bottom
      }];
      $[20] = bottom;
      $[21] = t11;
    } else {
      t11 = $[21];
    }
    let t12;
    let t13;
    let t14;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
      t12 = [WOOD.hi, WOOD.mid, WOOD.lo];
      t13 = {
        x: 0,
        y: 0
      };
      t14 = {
        x: 1,
        y: 1
      };
      $[22] = t12;
      $[23] = t13;
      $[24] = t14;
    } else {
      t12 = $[22];
      t13 = $[23];
      t14 = $[24];
    }
    let t15;
    if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
      t15 = [_constantsAchievements.METALS.gold.hi, _constantsAchievements.METALS.gold.mid];
      $[25] = t15;
    } else {
      t15 = $[25];
    }
    let t16;
    if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.crown,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoLinearGradient.LinearGradient, {
          colors: t15,
          style: styles.nameplate,
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: styles.nameplateText,
            children: "HALL OF DRIP"
          })
        })
      });
      $[26] = t16;
    } else {
      t16 = $[26];
    }
    let t17;
    if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
      t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoLinearGradient.LinearGradient, {
        colors: ["#1B2230", "#0D1118", "#080A0F"],
        style: StyleSheet.default.absoluteFill
      });
      $[27] = t17;
    } else {
      t17 = $[27];
    }
    let t18;
    let t19;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoLinearGradient.LinearGradient, {
        colors: ["rgba(255,236,190,0.22)", "rgba(255,236,190,0)"],
        style: styles.spot
      });
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: styles.shelfLabel,
        children: "LEAGUE HARDWARE"
      });
      $[28] = t18;
      $[29] = t19;
    } else {
      t18 = $[28];
      t19 = $[29];
    }
    let t20;
    if ($[30] !== featured || $[31] !== league_0) {
      t20 = league_0.length ? shelves(league_0).map((row, r) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Shelf, {
        row: row,
        base: r * PER_SHELF,
        onPress: tap,
        pinnedId: featured
      }, `l${r}`)) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.emptyShelf,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "trophy-outline",
            size: 22,
            color: "rgba(255,255,255,0.28)"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: styles.emptyText,
            children: "Win a league to put a cup here"
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Plank, {})]
      });
      $[30] = featured;
      $[31] = league_0;
      $[32] = t20;
    } else {
      t20 = $[32];
    }
    let t21;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
      t21 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.shelfLabel, {
          marginTop: 18
        }],
        children: "ACHIEVEMENTS"
      });
      $[33] = t21;
    } else {
      t21 = $[33];
    }
    let t22;
    if ($[34] !== achievements_0) {
      t22 = shelves(achievements_0);
      $[34] = achievements_0;
      $[35] = t22;
    } else {
      t22 = $[35];
    }
    let t23;
    if ($[36] !== featured || $[37] !== league_0.length || $[38] !== t22) {
      t23 = t22.map((row_0, r_0) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Shelf, {
        row: row_0,
        base: (league_0.length + r_0) * PER_SHELF,
        onPress: tap,
        pinnedId: featured
      }, `a${r_0}`));
      $[36] = featured;
      $[37] = league_0.length;
      $[38] = t22;
      $[39] = t23;
    } else {
      t23 = $[39];
    }
    let t24;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoLinearGradient.LinearGradient, {
        pointerEvents: "none",
        colors: ["rgba(255,255,255,0)", "rgba(255,255,255,0.07)", "rgba(255,255,255,0)"],
        start: {
          x: 0,
          y: 0
        },
        end: {
          x: 1,
          y: 0.6
        },
        locations: [0.25, 0.4, 0.55],
        style: StyleSheet.default.absoluteFill
      });
      $[40] = t24;
    } else {
      t24 = $[40];
    }
    let t25;
    if ($[41] !== t20 || $[42] !== t23) {
      t25 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_expoLinearGradient.LinearGradient, {
        colors: t12,
        start: t13,
        end: t14,
        style: styles.cabinet,
        children: [t16, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.glass,
          children: [t17, t18, t19, t20, t21, t23, t24]
        })]
      });
      $[41] = t20;
      $[42] = t23;
      $[43] = t25;
    } else {
      t25 = $[43];
    }
    let t26;
    if ($[44] !== t11 || $[45] !== t25) {
      t26 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ScrollView.default, {
        contentContainerStyle: t11,
        showsVerticalScrollIndicator: false,
        children: t25
      });
      $[44] = t11;
      $[45] = t25;
      $[46] = t26;
    } else {
      t26 = $[46];
    }
    const t27 = !!open;
    let t28;
    if ($[47] === Symbol.for("react.memo_cache_sentinel")) {
      t28 = () => setOpen(null);
      $[47] = t28;
    } else {
      t28 = $[47];
    }
    let t29;
    if ($[48] !== c.accent || $[49] !== c.border || $[50] !== c.elevated || $[51] !== c.foreground || $[52] !== c.mutedForeground || $[53] !== c.overlay || $[54] !== featured || $[55] !== open || $[56] !== pin) {
      t29 = open ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Animated.default.View, {
        entering: _reactNativeReanimated.FadeIn.duration(140),
        exiting: _reactNativeReanimated.FadeOut.duration(140),
        style: [styles.scrim, {
          backgroundColor: c.overlay
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
          style: StyleSheet.default.absoluteFill,
          onPress: () => setOpen(null),
          accessibilityRole: "button",
          accessibilityLabel: "Close"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Animated.default.View, {
          entering: _reactNativeReanimated.ZoomIn.springify().damping(14),
          style: [styles.detail, {
            backgroundColor: c.elevated,
            borderColor: open.earned ? _constantsAchievements.METALS[open.metal].mid : c.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Trophy, {
            piece: open,
            size: 140
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.detailTitle, {
              color: c.foreground
            }],
            children: open.title
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.detailSub, {
              color: open.earned ? _constantsAchievements.METALS[open.metal].mid : c.mutedForeground
            }],
            children: open.earned ? `${open.metal.toUpperCase()} · EARNED` : "LOCKED"
          }), open.rarity != null ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.rarity, {
              color: c.accent
            }],
            children: [open.rarity < 0.005 ? "<0.5%" : `${Math.round(open.rarity * 1000) / 10}%`, " of players have this"]
          }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.detailBody, {
              color: c.mutedForeground
            }],
            children: open.earned ? `${open.detail}${open.awardedAt ? `\nAwarded ${new Date(open.awardedAt).toLocaleDateString()}` : ""}` : `How to earn: ${open.detail}`
          }), open.earned && open.trophyId ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: featured === open.trophyId ? "Unpin From Profile" : "Pin to Profile",
            icon: featured === open.trophyId ? "pin-off-outline" : "pin-outline",
            onPress: () => void pin(featured === open.trophyId ? null : open.trophyId),
            style: {
              alignSelf: "stretch"
            }
          }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: "Close",
            variant: "secondary",
            onPress: () => setOpen(null),
            style: {
              alignSelf: "stretch"
            }
          })]
        })]
      }) : null;
      $[48] = c.accent;
      $[49] = c.border;
      $[50] = c.elevated;
      $[51] = c.foreground;
      $[52] = c.mutedForeground;
      $[53] = c.overlay;
      $[54] = featured;
      $[55] = open;
      $[56] = pin;
      $[57] = t29;
    } else {
      t29 = $[57];
    }
    let t30;
    if ($[58] !== t27 || $[59] !== t29) {
      t30 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Modal.default, {
        visible: t27,
        transparent: true,
        animationType: "none",
        onRequestClose: t28,
        statusBarTranslucent: true,
        children: t29
      });
      $[58] = t27;
      $[59] = t29;
      $[60] = t30;
    } else {
      t30 = $[60];
    }
    let t31;
    if ($[61] !== t10 || $[62] !== t26 || $[63] !== t30 || $[64] !== t8) {
      t31 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t8,
        children: [t10, t26, t30]
      });
      $[61] = t10;
      $[62] = t26;
      $[63] = t30;
      $[64] = t8;
      $[65] = t31;
    } else {
      t31 = $[65];
    }
    return t31;
  }
  function _temp8(items) {
    const rows = [];
    for (let i = 0; i < items.length; i = i + PER_SHELF, i) {
      rows.push(items.slice(i, i + PER_SHELF));
    }
    return rows;
  }
  function _temp7(a_1) {
    return a_1.earned;
  }
  function _temp6(a_0, b) {
    return (b.awardedAt ?? 0) - (a_0.awardedAt ?? 0);
  }
  function _temp5(t_2) {
    return t_2.kind !== "achievement";
  }
  function _temp4(x, y) {
    return Number(y.earned) - Number(x.earned);
  }
  function _temp3(t_0) {
    return [t_0.achievementId ?? t_0.id.replace(/^ach_/, ""), t_0];
  }
  function _temp2(t) {
    return t.kind === "achievement";
  }
  function _temp() {}
  function Shelf(t0) {
    const $ = (0, _reactCompilerRuntime.c)(17);
    const {
      row,
      base,
      onPress,
      pinnedId
    } = t0;
    let t1;
    if ($[0] !== base || $[1] !== onPress || $[2] !== pinnedId || $[3] !== row) {
      let t2;
      if ($[5] !== base || $[6] !== onPress || $[7] !== pinnedId) {
        t2 = (p, i) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Animated.default.View, {
          entering: _reactNativeReanimated.FadeInDown.delay(Math.min(base + i, 14) * 45).springify().damping(16),
          style: styles.slot,
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
            onPress: () => onPress(p),
            accessibilityRole: "button",
            accessibilityLabel: `${p.title}${p.earned ? "" : ", locked"}`,
            style: styles.slotPress,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Trophy, {
              piece: p,
              size: 66
            }), p.trophyId && p.trophyId === pinnedId ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: styles.pinBadge,
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "pin",
                size: 12,
                color: "#4A2C05"
              })
            }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.slotTitle, {
                color: p.earned ? "#F4F1EA" : "rgba(255,255,255,0.4)"
              }],
              numberOfLines: 1,
              children: p.title
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: styles.slotSub,
              numberOfLines: 1,
              children: p.sub
            })]
          })
        }, p.key);
        $[5] = base;
        $[6] = onPress;
        $[7] = pinnedId;
        $[8] = t2;
      } else {
        t2 = $[8];
      }
      t1 = row.map(t2);
      $[0] = base;
      $[1] = onPress;
      $[2] = pinnedId;
      $[3] = row;
      $[4] = t1;
    } else {
      t1 = $[4];
    }
    let t2;
    if ($[9] !== row.length) {
      t2 = Array.from({
        length: PER_SHELF - row.length
      }, _temp9);
      $[9] = row.length;
      $[10] = t2;
    } else {
      t2 = $[10];
    }
    let t3;
    if ($[11] !== t1 || $[12] !== t2) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.row,
        children: [t1, t2]
      });
      $[11] = t1;
      $[12] = t2;
      $[13] = t3;
    } else {
      t3 = $[13];
    }
    let t4;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Plank, {});
      $[14] = t4;
    } else {
      t4 = $[14];
    }
    let t5;
    if ($[15] !== t3) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [t3, t4]
      });
      $[15] = t3;
      $[16] = t5;
    } else {
      t5 = $[16];
    }
    return t5;
  }
  function _temp9(_, i_0) {
    return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
      style: styles.slot
    }, `gap${i_0}`);
  }
  function Plank() {
    const $ = (0, _reactCompilerRuntime.c)(3);
    let t0;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t0 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoLinearGradient.LinearGradient, {
        colors: [WOOD.hi, WOOD.mid],
        style: styles.plankTop
      });
      $[0] = t0;
    } else {
      t0 = $[0];
    }
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoLinearGradient.LinearGradient, {
        colors: [WOOD.mid, WOOD.lo],
        style: styles.plankFront
      });
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
      t2 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.plankWrap,
        children: [t0, t1, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoLinearGradient.LinearGradient, {
          colors: ["rgba(0,0,0,0.55)", "rgba(0,0,0,0)"],
          style: styles.plankShadow
        })]
      });
      $[2] = t2;
    } else {
      t2 = $[2];
    }
    return t2;
  }

  /** A trophy on the shelf: its own design (components/TrophyArt.tsx), locked ones dark with a padlock. */
  function Trophy(t0) {
    const $ = (0, _reactCompilerRuntime.c)(7);
    const {
      piece,
      size
    } = t0;
    let t1;
    if ($[0] !== piece.design || $[1] !== piece.earned || $[2] !== piece.icon || $[3] !== piece.key || $[4] !== piece.metal || $[5] !== size) {
      t1 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TrophyArt.default, {
        design: piece.design,
        metal: piece.metal,
        earned: piece.earned,
        icon: piece.icon,
        size: size,
        uid: piece.key
      });
      $[0] = piece.design;
      $[1] = piece.earned;
      $[2] = piece.icon;
      $[3] = piece.key;
      $[4] = piece.metal;
      $[5] = size;
      $[6] = t1;
    } else {
      t1 = $[6];
    }
    return t1;
  }
  const styles = StyleSheet.default.create({
    fill: {
      flex: 1
    },
    content: {
      padding: 16
    },
    cabinet: {
      borderRadius: 18,
      padding: 10,
      paddingTop: 0,
      shadowColor: "#000",
      shadowOpacity: 0.5,
      shadowRadius: 16,
      shadowOffset: {
        width: 0,
        height: 8
      },
      elevation: 8
    },
    crown: {
      alignItems: "center",
      paddingVertical: 10
    },
    nameplate: {
      paddingHorizontal: 16,
      paddingVertical: 4,
      borderRadius: 4
    },
    nameplateText: {
      color: "#4A2C05",
      fontSize: 11,
      letterSpacing: 2.5,
      fontFamily: "Inter_900Black"
    },
    glass: {
      borderRadius: 10,
      overflow: "hidden",
      paddingHorizontal: 8,
      paddingTop: 14,
      paddingBottom: 6,
      borderWidth: 2,
      borderColor: "rgba(0,0,0,0.5)"
    },
    spot: {
      position: "absolute",
      top: 0,
      left: "15%",
      right: "15%",
      height: 220,
      borderBottomLeftRadius: 200,
      borderBottomRightRadius: 200
    },
    shelfLabel: {
      color: "rgba(255,236,190,0.55)",
      fontSize: 10,
      letterSpacing: 2,
      fontFamily: "Inter_800ExtraBold",
      textAlign: "center",
      marginBottom: 6
    },
    row: {
      flexDirection: "row",
      alignItems: "flex-end",
      paddingHorizontal: 4
    },
    slot: {
      flex: 1,
      alignItems: "center"
    },
    slotPress: {
      alignItems: "center",
      paddingTop: 6,
      paddingHorizontal: 2,
      width: "100%"
    },
    slotTitle: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      marginTop: 2,
      maxWidth: "100%"
    },
    slotSub: {
      fontSize: 9,
      fontFamily: "Inter_500Medium",
      color: "rgba(255,255,255,0.4)",
      marginBottom: 4,
      maxWidth: "100%"
    },
    plankWrap: {
      marginHorizontal: -8,
      marginBottom: 16
    },
    plankTop: {
      height: 6
    },
    plankFront: {
      height: 10,
      borderBottomWidth: 1,
      borderBottomColor: "rgba(0,0,0,0.6)"
    },
    plankShadow: {
      height: 12,
      marginBottom: -12
    },
    emptyShelf: {
      alignItems: "center",
      gap: 6,
      paddingVertical: 26
    },
    emptyText: {
      color: "rgba(255,255,255,0.4)",
      fontSize: 12,
      fontFamily: "Inter_600SemiBold"
    },
    glow: {
      position: "absolute",
      opacity: 0.16
    },
    pinBadge: {
      position: "absolute",
      top: 4,
      right: "22%",
      width: 20,
      height: 20,
      borderRadius: 10,
      backgroundColor: "#F2B925",
      alignItems: "center",
      justifyContent: "center"
    },
    iconWrap: {
      position: "absolute",
      left: 0,
      alignItems: "center",
      justifyContent: "center"
    },
    scrim: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center",
      padding: 24
    },
    detail: {
      width: "100%",
      maxWidth: 360,
      borderRadius: 22,
      borderWidth: 1.5,
      padding: 20,
      alignItems: "center",
      gap: 6
    },
    detailTitle: {
      fontSize: 22,
      fontFamily: "Inter_900Black",
      textAlign: "center",
      marginTop: 6
    },
    detailSub: {
      fontSize: 11,
      letterSpacing: 1.5,
      fontFamily: "Inter_800ExtraBold"
    },
    rarity: {
      fontSize: 13,
      fontFamily: "Inter_800ExtraBold"
    },
    detailBody: {
      fontSize: 13,
      fontFamily: "Inter_500Medium",
      textAlign: "center",
      lineHeight: 19,
      marginBottom: 10
    }
  });
},777,[815,818,871,905,12,238,133,28,188,109,867,827,836,841,1272,837,819,820,863,902,906,6]);