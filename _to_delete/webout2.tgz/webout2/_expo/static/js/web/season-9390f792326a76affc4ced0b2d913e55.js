__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      if (k === 'default') return;
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return SeasonScreen;
    }
  });
  var _firebaseFirestore = require(_dependencyMap[0]);
  var _react = require(_dependencyMap[1]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[2]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[3]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[4]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[5]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsUi = require(_dependencyMap[6]);
  var _constantsTheme = require(_dependencyMap[7]);
  var theme = _interopDefault(_constantsTheme);
  var _contextAppContext = require(_dependencyMap[8]);
  var _hooksUseColors = require(_dependencyMap[9]);
  var _libApi = require(_dependencyMap[10]);
  var api = _interopNamespace(_libApi);
  var _libFirebase = require(_dependencyMap[11]);
  var _libMotion = require(_dependencyMap[12]);
  var _reactJsxRuntime = require(_dependencyMap[13]);
  const rewardLabel = r => r.kind === "credits" ? `${r.amount.toLocaleString()} credits` : `${r.kind}: ${r.id.replace(/_/g, " ")}`;

  /** Season pass, free track. Season XP comes from quests and Daily Picks; lifetime levels are separate. */
  function SeasonScreen() {
    const c = (0, _hooksUseColors.useColors)();
    const bottom = (0, _componentsUi.useBottomPad)(false);
    const {
      profile
    } = (0, _contextAppContext.useApp)();
    const [season, setSeason] = (0, _react.useState)(null);
    const [claimed, setClaimed] = (0, _react.useState)({});
    const [busy, setBusy] = (0, _react.useState)(null);
    (0, _react.useEffect)(() => {
      const db = (0, _libFirebase.getDb)();
      if (!db) return;
      const now = Date.now();
      (0, _firebaseFirestore.getDocs)((0, _firebaseFirestore.query)((0, _firebaseFirestore.collection)(db, "seasons"), (0, _firebaseFirestore.where)("endsAt", ">", now), (0, _firebaseFirestore.orderBy)("endsAt"), (0, _firebaseFirestore.limit)(3))).then(snap => {
        const s = snap.docs.map(d => ({
          ...d.data(),
          id: d.id
        })).find(x => x.startsAt <= now);
        setSeason(s ?? "none");
      }).catch(() => setSeason("none"));
    }, []);
    (0, _react.useEffect)(() => {
      const db_0 = (0, _libFirebase.getDb)();
      if (!db_0 || !profile?.uid || !season || season === "none") return;
      (0, _firebaseFirestore.getDocs)((0, _firebaseFirestore.query)((0, _firebaseFirestore.collection)(db_0, "users", profile.uid, "seasonClaims"), (0, _firebaseFirestore.where)("seasonId", "==", season.id))).then(snap_0 => {
        const out = {};
        snap_0.forEach(d_0 => {
          out[d_0.get("tier")] = true;
        });
        setClaimed(out);
      }).catch(() => {});
    }, [profile?.uid, season]);
    if (season === "none") {
      return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: {
          flex: 1,
          backgroundColor: c.background
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
          title: "Season Pass",
          back: true
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
          icon: "flag-outline",
          title: "No Season Running",
          body: "Keep doing quests and Daily Picks \u2014 the next season starts soon."
        })]
      });
    }
    if (!season) return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
      style: {
        flex: 1,
        backgroundColor: c.background
      }
    });
    const xp = profile?.seasonXp?.[season.id] ?? 0;
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
      style: {
        flex: 1,
        backgroundColor: c.background
      },
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
        title: "Season Pass",
        back: true
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        contentContainerStyle: {
          padding: 16,
          gap: 10,
          paddingBottom: bottom
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.sub, {
            color: c.mutedForeground
          }],
          children: [xp.toLocaleString(), " season XP \xB7 ends ", new Date(season.endsAt).toLocaleDateString()]
        }), season.tiers.map((t, i) => {
          const reached = xp >= t.xp;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
            style: styles.row,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1,
                gap: 2
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.title, {
                  color: c.foreground
                }],
                children: ["Tier ", i + 1]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.sub, {
                  color: c.mutedForeground
                }],
                children: [t.xp.toLocaleString(), " XP \xB7 ", rewardLabel(t.reward)]
              })]
            }), claimed[i] ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
              label: "Claimed",
              tone: "positive"
            }) : reached ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
              label: "Claim",
              chevron: false,
              disabled: busy === i,
              onPress: async () => {
                setBusy(i);
                try {
                  await api.claimSeasonTier({
                    seasonId: season.id,
                    tier: i
                  });
                  _libMotion.haptic.success();
                  setClaimed(m => ({
                    ...m,
                    [i]: true
                  }));
                } catch {
                  _libMotion.haptic.error();
                } finally {
                  setBusy(null);
                }
              }
            }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
              label: "Locked",
              icon: "lock"
            })]
          }, i);
        })]
      })]
    });
  }
  const styles = StyleSheet.default.create({
    row: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10
    },
    title: theme.default.type.bodyStrong,
    sub: theme.default.type.caption
  });
},774,[905,12,133,28,188,109,836,874,837,819,863,906,820,6]);