__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return LeaguesScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _componentsBackToLevels = require(_dependencyMap[1]);
  var BackToLevels = _interopDefault(_componentsBackToLevels);
  var _expoVectorIcons = require(_dependencyMap[2]);
  var _libMotion = require(_dependencyMap[3]);
  var _expoRouter = require(_dependencyMap[4]);
  var _react = require(_dependencyMap[5]);
  var _reactNativeWebDistExportsFlatList = require(_dependencyMap[6]);
  var FlatList = _interopDefault(_reactNativeWebDistExportsFlatList);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[7]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[8]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[9]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsCreateLeagueModal = require(_dependencyMap[10]);
  var CreateLeagueModal = _interopDefault(_componentsCreateLeagueModal);
  var _componentsJoinLeagueSheet = require(_dependencyMap[11]);
  var JoinLeagueSheet = _interopDefault(_componentsJoinLeagueSheet);
  var _componentsUi = require(_dependencyMap[12]);
  var _contextAppContext = require(_dependencyMap[13]);
  var _contextLeagueContext = require(_dependencyMap[14]);
  var _hooksUseColors = require(_dependencyMap[15]);
  var _hooksUseLatestActivity = require(_dependencyMap[16]);
  var _reactJsxRuntime = require(_dependencyMap[17]);
  /**
   * Leagues overview — now a tab of its own.
   *
   * Each card answers what you'd otherwise have to open the league for: your
   * rank and net worth, the field size, the pot, time left, and the last thing
   * that happened. Tap through for standings, bets, the bank and the feed.
   */
  function LeaguesScreen() {
    const $ = (0, _reactCompilerRuntime.c)(61);
    const c = (0, _hooksUseColors.useColors)();
    const bottom = (0, _componentsUi.useBottomPad)();
    const params = (0, _expoRouter.useLocalSearchParams)();
    const {
      balance
    } = (0, _contextAppContext.useApp)();
    const {
      leagues,
      createLeague,
      joinLeague,
      error,
      clearError,
      ready
    } = (0, _contextLeagueContext.useLeague)();
    const {
      summaries
    } = (0, _contextLeagueContext.useLeagueSummaries)();
    let t0;
    if ($[0] !== leagues) {
      t0 = leagues.filter(_temp).map(_temp2);
      $[0] = leagues;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    const latest = (0, _hooksUseLatestActivity.useLatestActivity)(t0);
    const [showCreate, setShowCreate] = (0, _react.useState)(false);
    const [showJoin, setShowJoin] = (0, _react.useState)(false);
    let t1;
    if ($[2] !== params.code || $[3] !== params.create || $[4] !== params.join) {
      t1 = () => {
        if (params.create) {
          setShowCreate(true);
        }
        if (params.join || params.code) {
          setShowJoin(true);
        }
      };
      $[2] = params.code;
      $[3] = params.create;
      $[4] = params.join;
      $[5] = t1;
    } else {
      t1 = $[5];
    }
    let t2;
    if ($[6] !== params.code || $[7] !== params.create || $[8] !== params.join || $[9] !== params.t) {
      t2 = [params.create, params.join, params.code, params.t];
      $[6] = params.code;
      $[7] = params.create;
      $[8] = params.join;
      $[9] = params.t;
      $[10] = t2;
    } else {
      t2 = $[10];
    }
    (0, _react.useEffect)(t1, t2);
    let active;
    let t3;
    if ($[11] !== summaries) {
      active = summaries.filter(_temp3);
      const closed = summaries.filter(_temp4);
      t3 = [...active.map(_temp5), ...(closed.length ? [{
        kind: "header",
        title: "Closed"
      }] : []), ...closed.map(_temp6)];
      $[11] = summaries;
      $[12] = active;
      $[13] = t3;
    } else {
      active = $[12];
      t3 = $[13];
    }
    const rows = t3;
    let t4;
    if ($[14] !== c.background) {
      t4 = [styles.container, {
        backgroundColor: c.background
      }];
      $[14] = c.background;
      $[15] = t4;
    } else {
      t4 = $[15];
    }
    let t5;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BackToLevels.default, {});
      $[16] = t5;
    } else {
      t5 = $[16];
    }
    const t6 = active.length ? `${active.length} running` : "Season-long competitions with friends";
    let t7;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        label: "Join",
        size: "sm",
        variant: "secondary",
        icon: "key-variant",
        onPress: () => setShowJoin(true)
      });
      $[17] = t7;
    } else {
      t7 = $[17];
    }
    let t8;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
      t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [t7, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: "New",
          size: "sm",
          icon: "plus",
          onPress: () => setShowCreate(true)
        })]
      });
      $[18] = t8;
    } else {
      t8 = $[18];
    }
    let t9;
    if ($[19] !== t6) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
        leading: t5,
        title: "Leagues",
        subtitle: t6,
        right: t8
      });
      $[19] = t6;
      $[20] = t9;
    } else {
      t9 = $[20];
    }
    let t10;
    if ($[21] !== clearError || $[22] !== error) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ErrorBanner, {
        message: error,
        onDismiss: clearError
      });
      $[21] = clearError;
      $[22] = error;
      $[23] = t10;
    } else {
      t10 = $[23];
    }
    let t11;
    if ($[24] !== bottom) {
      t11 = [styles.list, {
        paddingBottom: bottom
      }];
      $[24] = bottom;
      $[25] = t11;
    } else {
      t11 = $[25];
    }
    let t12;
    if ($[26] !== latest) {
      t12 = t13 => {
        const {
          item
        } = t13;
        return item.kind === "header" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
          title: item.title
        }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(LeagueCard, {
          s: item.s,
          latest: latest[item.s.league.id]?.text
        });
      };
      $[26] = latest;
      $[27] = t12;
    } else {
      t12 = $[27];
    }
    let t13;
    if ($[28] !== c.foreground || $[29] !== c.league || $[30] !== c.mutedForeground || $[31] !== ready) {
      t13 = ready ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: {
          gap: 12
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
          icon: "trophy-outline",
          title: "No Leagues Yet",
          body: "Everyone starts a season with the same stack of league tokens. Bet them, borrow from the bank or each other, and the best net worth when the clock runs out takes the pot.",
          action: "Start a League",
          onAction: () => setShowCreate(true),
          secondary: "Join With a Code",
          onSecondary: () => setShowJoin(true)
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.howTitle, {
              color: c.foreground
            }],
            children: "How Leagues Work"
          }), [["shield-star", "League tokens are separate from your credits."], ["scale-balance", "Ranked on net worth: tokens, plus what you're owed, minus what you owe."], ["bank-outline", "Loans charge one flat fee \u2014 borrow 100 at 10%, repay 110. Never more."], ["trophy-outline", "Buy-ins form a pot, paid out in credits when the season ends."]].map(t14 => {
            const [icon, text] = t14;
            return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.howRow,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: icon,
                size: 16,
                color: c.league
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.howText, {
                  color: c.mutedForeground
                }],
                children: text
              })]
            }, text);
          })]
        })]
      }) : undefined;
      $[28] = c.foreground;
      $[29] = c.league;
      $[30] = c.mutedForeground;
      $[31] = ready;
      $[32] = t13;
    } else {
      t13 = $[32];
    }
    let t14;
    if ($[33] !== rows || $[34] !== t11 || $[35] !== t12 || $[36] !== t13) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FlatList.default, {
        data: rows,
        keyExtractor: _temp7,
        contentContainerStyle: t11,
        showsVerticalScrollIndicator: false,
        renderItem: t12,
        ListEmptyComponent: t13
      });
      $[33] = rows;
      $[34] = t11;
      $[35] = t12;
      $[36] = t13;
      $[37] = t14;
    } else {
      t14 = $[37];
    }
    let t15;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
      t15 = () => setShowCreate(false);
      $[38] = t15;
    } else {
      t15 = $[38];
    }
    let t16;
    if ($[39] !== createLeague) {
      t16 = async (name, startingLeagueTokens, duration, sports, buyIn, prizeDistribution, bankLoanEnabled, bankInterestRate, bankInterestIntervalHours, mode, matchupsEnabled, matchupCadence, stimulusEnabled, bracketTemplateId, startsAt) => {
        const res = await createLeague({
          name,
          startingLeagueTokens,
          duration,
          sports,
          buyIn,
          prizeDistribution,
          bankLoanEnabled,
          bankInterestRate,
          bankInterestIntervalHours,
          mode,
          matchupsEnabled,
          matchupCadence,
          stimulusEnabled,
          bracketTemplateId,
          startsAt
        });
        if ("error" in res) {
          return res.error;
        }
        _libMotion.haptic.success();
        _expoRouter.router.push({
          pathname: "/league/[id]",
          params: {
            id: res.leagueId,
            created: "1"
          }
        });
        return null;
      };
      $[39] = createLeague;
      $[40] = t16;
    } else {
      t16 = $[40];
    }
    let t17;
    if ($[41] !== balance || $[42] !== showCreate || $[43] !== t16) {
      t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(CreateLeagueModal.default, {
        visible: showCreate,
        onClose: t15,
        yourTokens: balance,
        onConfirm: t16
      });
      $[41] = balance;
      $[42] = showCreate;
      $[43] = t16;
      $[44] = t17;
    } else {
      t17 = $[44];
    }
    let t18;
    if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
      t18 = () => setShowJoin(false);
      $[45] = t18;
    } else {
      t18 = $[45];
    }
    let t19;
    if ($[46] !== joinLeague || $[47] !== params.via) {
      t19 = async code => {
        const res_0 = await joinLeague(code, params.via === "link" ? "link" : params.via === "notification" ? "notification" : "code");
        if ("error" in res_0) {
          return res_0.error;
        }
        _libMotion.haptic.success();
        setShowJoin(false);
        _expoRouter.router.push({
          pathname: "/league/[id]",
          params: {
            id: res_0.leagueId
          }
        });
        return null;
      };
      $[46] = joinLeague;
      $[47] = params.via;
      $[48] = t19;
    } else {
      t19 = $[48];
    }
    let t20;
    if ($[49] !== balance || $[50] !== params.code || $[51] !== showJoin || $[52] !== t19) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(JoinLeagueSheet.default, {
        visible: showJoin,
        initialCode: params.code,
        balance: balance,
        onClose: t18,
        onJoin: t19
      });
      $[49] = balance;
      $[50] = params.code;
      $[51] = showJoin;
      $[52] = t19;
      $[53] = t20;
    } else {
      t20 = $[53];
    }
    let t21;
    if ($[54] !== t10 || $[55] !== t14 || $[56] !== t17 || $[57] !== t20 || $[58] !== t4 || $[59] !== t9) {
      t21 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t4,
        children: [t9, t10, t14, t17, t20]
      });
      $[54] = t10;
      $[55] = t14;
      $[56] = t17;
      $[57] = t20;
      $[58] = t4;
      $[59] = t9;
      $[60] = t21;
    } else {
      t21 = $[60];
    }
    return t21;
  }
  function _temp7(r, i) {
    return r.kind === "league" ? r.s.league.id : `h${i}`;
  }
  function _temp6(s_2) {
    return {
      kind: "league",
      s: s_2
    };
  }
  function _temp5(s_1) {
    return {
      kind: "league",
      s: s_1
    };
  }
  function _temp4(s_0) {
    return s_0.closed;
  }
  function _temp3(s) {
    return !s.closed;
  }
  function _temp2(l_0) {
    return l_0.id;
  }
  function _temp(l) {
    return l.status === "active";
  }
  function LeagueCard({
    s,
    latest
  }) {
    const c = (0, _hooksUseColors.useColors)();
    const {
      league,
      me
    } = s;
    const closed = s.closed;
    const total = Math.max(1, league.endsAt - league.createdAt);
    const progress = closed ? 1 : Math.min(1, Math.max(0, (Date.now() - league.createdAt) / total));
    const leader = s.standings[0];
    const leaderName = leader ? league.members[leader.uid]?.displayName ?? league.results?.find(r => r.memberId === leader.uid)?.memberName : null;
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
      onPress: () => _expoRouter.router.push({
        pathname: "/league/[id]",
        params: {
          id: league.id
        }
      }),
      accessibilityLabel: `${league.name}${closed ? ", closed" : ""}. You're ranked ${me?.rank ?? "unranked"} of ${s.memberCount}.`,
      tone: me?.rank === 1 && !closed ? "money" : undefined,
      style: styles.card,
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.cardTop,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: {
            flex: 1,
            gap: 4
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.name, {
              color: c.foreground
            }],
            numberOfLines: 1,
            children: league.name
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.pills,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
              label: closed ? "Closed" : `${s.daysLeft}d left`,
              tone: closed ? "neutral" : "accent",
              icon: closed ? "lock-outline" : "clock-outline"
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
              label: `${s.memberCount} ${s.memberCount === 1 ? "player" : "players"}`,
              icon: "account-multiple"
            }), league.mode && league.mode !== "bankroll" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
              label: league.mode === "pickem" ? "Pick'em" : "Survivor",
              tone: "league",
              icon: league.mode === "pickem" ? "checkbox-marked-circle-outline" : "skull-outline"
            }) : null, league.pot > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
              label: `${league.pot.toLocaleString()} pot`,
              tone: "money",
              icon: "trophy"
            })]
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.rankBox,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.rankBig, {
              color: me?.rank === 1 ? c.primary : c.foreground
            }],
            children: ["#", me?.rank ?? "–"]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.rankOf, {
              color: c.mutedForeground
            }],
            children: ["of ", s.memberCount]
          })]
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.cardStats,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: {
            flex: 1
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.k, {
              color: c.subtleForeground
            }],
            children: "NET WORTH"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
            value: me?.netWorth ?? 0,
            currency: "league"
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: {
            flex: 1
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.k, {
              color: c.subtleForeground
            }],
            children: me && me.debt > 0 ? "YOU OWE" : "LEADER"
          }), me && me.debt > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
            value: me.debt,
            currency: "league",
            tone: "debt"
          }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.v, {
              color: c.foreground
            }],
            numberOfLines: 1,
            children: leader?.uid === me?.uid ? "You" : leaderName ?? "—"
          })]
        })]
      }), !closed && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [styles.track, {
          backgroundColor: c.secondary
        }],
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [styles.fill, {
            width: `${progress * 100}%`,
            backgroundColor: c.league
          }]
        })
      }), latest ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.latest, {
          color: c.mutedForeground
        }],
        numberOfLines: 1,
        children: latest
      }) : null]
    });
  }
  const styles = StyleSheet.default.create({
    container: {
      flex: 1
    },
    list: {
      padding: 16,
      gap: 12
    },
    card: {
      gap: 12
    },
    cardTop: {
      flexDirection: "row",
      gap: 12
    },
    name: {
      fontSize: 17,
      fontFamily: "Inter_700Bold"
    },
    pills: {
      flexDirection: "row",
      gap: 6,
      flexWrap: "wrap"
    },
    rankBox: {
      alignItems: "flex-end"
    },
    rankBig: {
      fontSize: 30,
      lineHeight: 34,
      fontFamily: "Inter_700Bold",
      fontVariant: ["tabular-nums"],
      letterSpacing: -0.6
    },
    rankOf: {
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    },
    cardStats: {
      flexDirection: "row",
      gap: 12
    },
    k: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.6,
      marginBottom: 2
    },
    v: {
      fontSize: 15,
      fontFamily: "Inter_700Bold"
    },
    track: {
      height: 4,
      borderRadius: 2,
      overflow: "hidden"
    },
    fill: {
      height: 4,
      borderRadius: 2
    },
    latest: {
      fontSize: 12,
      fontFamily: "Inter_400Regular"
    },
    howTitle: {
      fontSize: 15,
      fontFamily: "Inter_700Bold",
      marginBottom: 8
    },
    howRow: {
      flexDirection: "row",
      gap: 10,
      alignItems: "flex-start",
      paddingVertical: 4
    },
    howText: {
      flex: 1,
      fontSize: 13,
      lineHeight: 18,
      fontFamily: "Inter_400Regular"
    }
  });
},754,[815,842,818,820,817,12,107,28,188,109,910,912,836,837,858,819,913,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return CreateLeagueModal;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _firebaseFirestore = require(_dependencyMap[2]);
  var _react = require(_dependencyMap[3]);
  var _reactNativeWebDistExportsKeyboardAvoidingView = require(_dependencyMap[4]);
  var KeyboardAvoidingView = _interopDefault(_reactNativeWebDistExportsKeyboardAvoidingView);
  var _reactNativeWebDistExportsModal = require(_dependencyMap[5]);
  var Modal = _interopDefault(_reactNativeWebDistExportsModal);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[6]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[7]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[8]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsTextInput = require(_dependencyMap[9]);
  var TextInput = _interopDefault(_reactNativeWebDistExportsTextInput);
  var _reactNativeWebDistExportsView = require(_dependencyMap[10]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[11]);
  var _reactNativeSafeAreaContext = require(_dependencyMap[12]);
  var _componentsNumericInput = require(_dependencyMap[13]);
  var NumericInput = _interopDefault(_componentsNumericInput);
  var _componentsUi = require(_dependencyMap[14]);
  var _libFirebase = require(_dependencyMap[15]);
  var _constantsLeagueTypes = require(_dependencyMap[16]);
  var _hooksUseColors = require(_dependencyMap[17]);
  var _libLoanMath = require(_dependencyMap[18]);
  var _constantsSeasons = require(_dependencyMap[19]);
  var _reactJsxRuntime = require(_dependencyMap[20]);
  const DAY_MS = 86_400_000;
  /** A scheduled start: `days` out, on the next whole hour, so it's always more than a day away. */
  function scheduledStart(days, now = Date.now()) {
    const hour = 3_600_000;
    return Math.ceil((now + days * DAY_MS) / hour) * hour;
  }
  const fmtStart = ms => new Date(ms).toLocaleString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit"
  });

  // Must match functions/src/lib/leagueConfig.ts — the server rejects anything else.
  const TOKEN_OPTIONS = _constantsLeagueTypes.TOKEN_START_OPTIONS;
  const SPORT_OPTIONS = ["NFL", "NBA", "MLB", "NHL", "NCAAF", "NCAAB", "Soccer"];
  const TEMPLATES = [{
    id: "sweat",
    label: "Season Sweat",
    icon: "fire",
    desc: "A month-long bankroll league: everyone starts with 10K tokens, bets at real odds and can borrow from the bank, with a new head-to-head opponent every Monday. Highest net worth takes the 100-credit-a-head pot.",
    mode: "bankroll",
    tokens: 10_000,
    buyIn: 100,
    duration: "1 Month",
    bankLoanEnabled: true,
    matchupsEnabled: true,
    matchupCadence: "weekly",
    stimulusEnabled: false
  }, {
    id: "h2h",
    label: "H2H Showdown",
    icon: "sword-cross",
    desc: "Matchups only: twice a week you're paired with one league-mate, and whoever grows their stack more wins the round. The table goes by W-L record and the last round is a playoff. Free to join.",
    mode: "matchups",
    tokens: 10_000,
    buyIn: 0,
    duration: "1 Month",
    bankLoanEnabled: false,
    matchupsEnabled: true,
    matchupCadence: "twice-weekly",
    stimulusEnabled: false
  }, {
    id: "season",
    label: "Full Season",
    icon: "calendar-star",
    desc: "Follows one sport until it crowns a champion (see the end date below). 25K tokens, weekly matchups, and the bank can vote everyone a stimulus if stacks run dry over the long haul.",
    mode: "bankroll",
    tokens: 25_000,
    buyIn: 250,
    duration: "Full Season",
    bankLoanEnabled: true,
    matchupsEnabled: true,
    matchupCadence: "weekly",
    stimulusEnabled: true
  }, {
    id: "high",
    label: "High Rollers",
    icon: "diamond-stone",
    desc: "Three months, 50K-token stacks and a 1,000-credit buy-in. Bank loans and weekly matchups are on — for groups that want big swings and a big pot.",
    mode: "bankroll",
    tokens: 50_000,
    buyIn: 1_000,
    duration: "3 Months",
    bankLoanEnabled: true,
    matchupsEnabled: true,
    matchupCadence: "weekly",
    stimulusEnabled: false
  }, {
    id: "pickem",
    label: "Weekly Pick'em",
    icon: "checkbox-marked-circle-outline",
    desc: "No stakes to manage: pick straight-up winners each week, 1 point per correct pick. Most points after a month wins. Free to join.",
    mode: "pickem",
    tokens: 10_000,
    buyIn: 0,
    duration: "1 Month",
    bankLoanEnabled: false,
    matchupsEnabled: true,
    matchupCadence: "weekly",
    stimulusEnabled: false
  }, {
    id: "survivor",
    label: "Survivor Pool",
    icon: "skull-outline",
    desc: "Pick one team to win each week and never the same team twice. Lose — or miss a week — and you're out. Last one standing takes the 250-credit-a-head pot.",
    mode: "survivor",
    tokens: 10_000,
    buyIn: 250,
    duration: "3 Months",
    bankLoanEnabled: false,
    matchupsEnabled: false,
    matchupCadence: "weekly",
    stimulusEnabled: false
  }];
  function CreateLeagueModal(t0) {
    const $ = (0, _reactCompilerRuntime.c)(420);
    const {
      visible,
      onClose,
      yourTokens,
      onConfirm
    } = t0;
    const colors = (0, _hooksUseColors.useColors)();
    const insets = (0, _reactNativeSafeAreaContext.useSafeAreaInsets)();
    const [name, setName] = (0, _react.useState)("");
    const [mode, setMode] = (0, _react.useState)("bankroll");
    let t1;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = [];
      $[0] = t1;
    } else {
      t1 = $[0];
    }
    const [bracketTemplates, setBracketTemplates] = (0, _react.useState)(t1);
    const [bracketTemplateId, setBracketTemplateId] = (0, _react.useState)(null);
    let t2;
    let t3;
    if ($[1] !== mode) {
      t2 = () => {
        if (mode !== "bracket") {
          return;
        }
        const db = (0, _libFirebase.getDb)();
        if (!db) {
          return;
        }
        (0, _firebaseFirestore.getDocs)((0, _firebaseFirestore.query)((0, _firebaseFirestore.collection)(db, "bracketTemplates"), (0, _firebaseFirestore.where)("locksAt", ">", Date.now()), (0, _firebaseFirestore.limit)(10))).then(snap => {
          const list = snap.docs.map(_temp);
          setBracketTemplates(list);
          setBracketTemplateId(cur => cur ?? list[0]?.id ?? null);
        }).catch(() => setBracketTemplates([]));
      };
      t3 = [mode];
      $[1] = mode;
      $[2] = t2;
      $[3] = t3;
    } else {
      t2 = $[2];
      t3 = $[3];
    }
    (0, _react.useEffect)(t2, t3);
    const [matchupsEnabled, setMatchupsEnabled] = (0, _react.useState)(true);
    const [matchupCadence, setMatchupCadence] = (0, _react.useState)("weekly");
    const [stimulusEnabled, setStimulusEnabled] = (0, _react.useState)(false);
    const [startingLeagueTokens, setStartingLeagueTokens] = (0, _react.useState)(10000);
    const [duration, setDuration] = (0, _react.useState)(_constantsLeagueTypes.DEFAULT_DURATION);
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
      t4 = [...SPORT_OPTIONS];
      $[4] = t4;
    } else {
      t4 = $[4];
    }
    const [sports, setSports] = (0, _react.useState)(t4);
    const [startNow, setStartNow] = (0, _react.useState)(false);
    const [startDays, setStartDays] = (0, _react.useState)(1);
    const startsAt = startNow ? Date.now() : scheduledStart(startDays);
    const fullSeason = duration === "Full Season";
    let t5;
    let t6;
    if ($[5] !== fullSeason || $[6] !== sports.length) {
      t5 = () => {
        if (fullSeason && sports.length > 1) {
          setSports(_temp2);
        }
      };
      t6 = [fullSeason, sports.length];
      $[5] = fullSeason;
      $[6] = sports.length;
      $[7] = t5;
      $[8] = t6;
    } else {
      t5 = $[7];
      t6 = $[8];
    }
    (0, _react.useEffect)(t5, t6);
    const [buyIn, setBuyIn] = (0, _react.useState)(0);
    const [selectedPreset, setSelectedPreset] = (0, _react.useState)("winner-all");
    const [bankLoanEnabled, setBankLoanEnabled] = (0, _react.useState)(true);
    const [bankInterestRate, setBankInterestRate] = (0, _react.useState)("10");
    let t7;
    if ($[9] !== selectedPreset) {
      t7 = _constantsLeagueTypes.PRIZE_PRESETS.find(p => p.value === selectedPreset);
      $[9] = selectedPreset;
      $[10] = t7;
    } else {
      t7 = $[10];
    }
    const preset = t7;
    let t8;
    if ($[11] !== preset.firstPct || $[12] !== preset.secondPct || $[13] !== preset.thirdPct || $[14] !== selectedPreset) {
      t8 = {
        preset: selectedPreset,
        firstPct: preset.firstPct,
        secondPct: preset.secondPct,
        thirdPct: preset.thirdPct
      };
      $[11] = preset.firstPct;
      $[12] = preset.secondPct;
      $[13] = preset.thirdPct;
      $[14] = selectedPreset;
      $[15] = t8;
    } else {
      t8 = $[15];
    }
    const prizeDistribution = t8;
    const [submitting, setSubmitting] = (0, _react.useState)(false);
    const [submitError, setSubmitError] = (0, _react.useState)(null);
    const rateNum = parseFloat(bankInterestRate);
    let t9;
    if ($[16] !== bankLoanEnabled || $[17] !== buyIn || $[18] !== fullSeason || $[19] !== name || $[20] !== rateNum || $[21] !== sports.length || $[22] !== submitting || $[23] !== yourTokens) {
      t9 = !submitting && name.trim().length > 0 && sports.length > 0 && (!fullSeason || sports.length === 1) && buyIn <= yourTokens && (!bankLoanEnabled || rateNum >= 0.5 && rateNum <= 50);
      $[16] = bankLoanEnabled;
      $[17] = buyIn;
      $[18] = fullSeason;
      $[19] = name;
      $[20] = rateNum;
      $[21] = sports.length;
      $[22] = submitting;
      $[23] = yourTokens;
      $[24] = t9;
    } else {
      t9 = $[24];
    }
    const canCreate = t9;
    let t10;
    if ($[25] !== setBankLoanEnabled || $[26] !== yourTokens) {
      t10 = function applyTemplate(t) {
        setMode(t.mode);
        setStartingLeagueTokens(t.tokens);
        setBuyIn(t.buyIn <= yourTokens ? t.buyIn : 0);
        setDuration(t.duration);
        setBankLoanEnabled(t.bankLoanEnabled);
        setMatchupsEnabled(t.matchupsEnabled);
        setMatchupCadence(t.matchupCadence);
        setStimulusEnabled(t.stimulusEnabled);
      };
      $[25] = setBankLoanEnabled;
      $[26] = yourTokens;
      $[27] = t10;
    } else {
      t10 = $[27];
    }
    const applyTemplate = t10;
    let t11;
    if ($[28] !== bankLoanEnabled || $[29] !== buyIn || $[30] !== duration || $[31] !== matchupCadence || $[32] !== matchupsEnabled || $[33] !== mode || $[34] !== startingLeagueTokens || $[35] !== stimulusEnabled || $[36] !== yourTokens) {
      t11 = TEMPLATES.find(t_0 => t_0.mode === mode && t_0.tokens === startingLeagueTokens && (t_0.buyIn <= yourTokens ? t_0.buyIn : 0) === buyIn && t_0.duration === duration && t_0.bankLoanEnabled === bankLoanEnabled && (t_0.mode === "matchups" || t_0.matchupsEnabled === matchupsEnabled) && (!t_0.matchupsEnabled || t_0.matchupCadence === matchupCadence) && t_0.stimulusEnabled === stimulusEnabled);
      $[28] = bankLoanEnabled;
      $[29] = buyIn;
      $[30] = duration;
      $[31] = matchupCadence;
      $[32] = matchupsEnabled;
      $[33] = mode;
      $[34] = startingLeagueTokens;
      $[35] = stimulusEnabled;
      $[36] = yourTokens;
      $[37] = t11;
    } else {
      t11 = $[37];
    }
    const activeTemplate = t11;
    const h2hOn = mode === "matchups" || matchupsEnabled;
    const season = fullSeason ? (0, _constantsSeasons.fullSeasonPlan)(sports, startsAt) : null;
    let t12;
    if ($[38] !== fullSeason) {
      t12 = function toggleSport(sport) {
        setSports(prev_0 => {
          if (prev_0.includes(sport)) {
            return fullSeason ? prev_0 : prev_0.filter(s => s !== sport);
          }
          if (fullSeason) {
            return [sport];
          }
          return [...prev_0, sport];
        });
      };
      $[38] = fullSeason;
      $[39] = t12;
    } else {
      t12 = $[39];
    }
    const toggleSport = t12;
    let t13;
    if ($[40] !== bankInterestRate || $[41] !== bankLoanEnabled || $[42] !== bracketTemplateId || $[43] !== buyIn || $[44] !== canCreate || $[45] !== duration || $[46] !== matchupCadence || $[47] !== matchupsEnabled || $[48] !== mode || $[49] !== name || $[50] !== onClose || $[51] !== onConfirm || $[52] !== prizeDistribution || $[53] !== setBankInterestRate || $[54] !== setBankLoanEnabled || $[55] !== sports || $[56] !== startDays || $[57] !== startNow || $[58] !== startingLeagueTokens || $[59] !== stimulusEnabled) {
      t13 = async function handleConfirm() {
        if (!canCreate) {
          return;
        }
        const rate = parseFloat(bankInterestRate) || 10;
        setSubmitting(true);
        setSubmitError(null);
        const err = await onConfirm(name.trim(), startingLeagueTokens, duration, sports, buyIn, prizeDistribution, bankLoanEnabled, rate, 24, mode, mode === "matchups" || matchupsEnabled, matchupCadence, stimulusEnabled, mode === "bracket" ? bracketTemplateId ?? undefined : undefined, startNow ? null : scheduledStart(startDays));
        setSubmitting(false);
        if (err) {
          setSubmitError(err);
          return;
        }
        setName("");
        setMode("bankroll");
        setMatchupsEnabled(true);
        setMatchupCadence("weekly");
        setStimulusEnabled(false);
        setStartingLeagueTokens(10000);
        setDuration("1 Month");
        setSports([...SPORT_OPTIONS]);
        setStartNow(false);
        setStartDays(1);
        setBuyIn(0);
        setSelectedPreset("winner-all");
        setBankLoanEnabled(true);
        setBankInterestRate("10");
        onClose();
      };
      $[40] = bankInterestRate;
      $[41] = bankLoanEnabled;
      $[42] = bracketTemplateId;
      $[43] = buyIn;
      $[44] = canCreate;
      $[45] = duration;
      $[46] = matchupCadence;
      $[47] = matchupsEnabled;
      $[48] = mode;
      $[49] = name;
      $[50] = onClose;
      $[51] = onConfirm;
      $[52] = prizeDistribution;
      $[53] = setBankInterestRate;
      $[54] = setBankLoanEnabled;
      $[55] = sports;
      $[56] = startDays;
      $[57] = startNow;
      $[58] = startingLeagueTokens;
      $[59] = stimulusEnabled;
      $[60] = t13;
    } else {
      t13 = $[60];
    }
    const handleConfirm = t13;
    const T0 = Modal.default;
    const t14 = true;
    const t15 = "slide";
    const t16 = true;
    const t17 = true;
    const T1 = KeyboardAvoidingView.default;
    const t18 = "padding";
    let t19;
    if ($[61] === Symbol.for("react.memo_cache_sentinel")) {
      t19 = {
        flex: 1
      };
      $[61] = t19;
    } else {
      t19 = $[61];
    }
    let t20;
    if ($[62] !== onClose) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.TouchableOpacity, {
        style: styles.overlay,
        activeOpacity: 1,
        onPress: onClose
      });
      $[62] = onClose;
      $[63] = t20;
    } else {
      t20 = $[63];
    }
    const T2 = View.default;
    let t21;
    if ($[64] !== colors.border || $[65] !== colors.card || $[66] !== insets.bottom) {
      t21 = [styles.sheet, {
        backgroundColor: colors.card,
        borderColor: colors.border,
        paddingBottom: insets.bottom
      }];
      $[64] = colors.border;
      $[65] = colors.card;
      $[66] = insets.bottom;
      $[67] = t21;
    } else {
      t21 = $[67];
    }
    let t22;
    if ($[68] !== colors.border) {
      t22 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [styles.handle, {
          backgroundColor: colors.border
        }]
      });
      $[68] = colors.border;
      $[69] = t22;
    } else {
      t22 = $[69];
    }
    const T3 = ScrollView.default;
    const t23 = false;
    const t24 = false;
    const t25 = "handled";
    const t26 = "interactive";
    let t27;
    if ($[70] !== colors.foreground) {
      t27 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.title, {
          color: colors.foreground
        }],
        children: "Create League"
      });
      $[70] = colors.foreground;
      $[71] = t27;
    } else {
      t27 = $[71];
    }
    let t28;
    if ($[72] !== colors.mutedForeground) {
      t28 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.subtitle, {
          color: colors.mutedForeground
        }],
        children: "Share the invite code with friends. Winners earn credits from the prize pot."
      });
      $[72] = colors.mutedForeground;
      $[73] = t28;
    } else {
      t28 = $[73];
    }
    let t29;
    if ($[74] !== colors.mutedForeground) {
      t29 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.label, {
          color: colors.mutedForeground,
          marginTop: 4
        }],
        children: "QUICK-START TEMPLATES"
      });
      $[74] = colors.mutedForeground;
      $[75] = t29;
    } else {
      t29 = $[75];
    }
    let t30;
    if ($[76] !== activeTemplate?.id || $[77] !== applyTemplate || $[78] !== colors.border || $[79] !== colors.foreground || $[80] !== colors.isDark || $[81] !== colors.positive || $[82] !== colors.primary || $[83] !== colors.secondary) {
      t30 = TEMPLATES.map(t_1 => {
        const on = activeTemplate?.id === t_1.id;
        const onFg = colors.isDark ? "#05200F" : "#FFFFFF";
        return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.TouchableOpacity, {
          accessibilityRole: "button",
          accessibilityState: {
            selected: on
          },
          style: [styles.optionChip, on ? {
            backgroundColor: colors.positive,
            borderColor: colors.positive
          } : {
            backgroundColor: colors.secondary,
            borderColor: colors.border
          }],
          onPress: () => applyTemplate(t_1),
          activeOpacity: 0.8,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: on ? "check-circle" : t_1.icon,
            size: 13,
            color: on ? onFg : colors.primary
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.optionText, {
              color: on ? onFg : colors.foreground
            }],
            children: t_1.label
          })]
        }, t_1.id);
      });
      $[76] = activeTemplate?.id;
      $[77] = applyTemplate;
      $[78] = colors.border;
      $[79] = colors.foreground;
      $[80] = colors.isDark;
      $[81] = colors.positive;
      $[82] = colors.primary;
      $[83] = colors.secondary;
      $[84] = t30;
    } else {
      t30 = $[84];
    }
    let t31;
    if ($[85] !== t30) {
      t31 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.optionRow,
        children: t30
      });
      $[85] = t30;
      $[86] = t31;
    } else {
      t31 = $[86];
    }
    let t32;
    if ($[87] !== activeTemplate || $[88] !== colors.foreground || $[89] !== colors.mutedForeground || $[90] !== colors.positive || $[91] !== colors.subtleForeground) {
      t32 = activeTemplate ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.templateInfo, {
          backgroundColor: colors.positive + "14",
          borderColor: colors.positive + "66"
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: activeTemplate.icon,
          size: 16,
          color: colors.positive
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: {
            flex: 1,
            gap: 3
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.templateTitle, {
              color: colors.positive
            }],
            children: [activeTemplate.label, " template"]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.templateDesc, {
              color: colors.foreground
            }],
            children: activeTemplate.desc
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.templateDesc, {
              color: colors.mutedForeground
            }],
            children: "Everything below is filled in for you \u2014 change anything you like."
          })]
        })]
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.durationHint, {
          color: colors.subtleForeground,
          marginTop: 6
        }],
        children: "Tap a template to fill in the settings below in one go."
      });
      $[87] = activeTemplate;
      $[88] = colors.foreground;
      $[89] = colors.mutedForeground;
      $[90] = colors.positive;
      $[91] = colors.subtleForeground;
      $[92] = t32;
    } else {
      t32 = $[92];
    }
    let t33;
    if ($[93] !== colors.mutedForeground) {
      t33 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.label, {
          color: colors.mutedForeground
        }],
        children: "LEAGUE NAME"
      });
      $[93] = colors.mutedForeground;
      $[94] = t33;
    } else {
      t33 = $[94];
    }
    let t34;
    if ($[95] !== colors.border || $[96] !== colors.foreground || $[97] !== colors.secondary) {
      t34 = [styles.input, {
        color: colors.foreground,
        borderColor: colors.border,
        backgroundColor: colors.secondary
      }];
      $[95] = colors.border;
      $[96] = colors.foreground;
      $[97] = colors.secondary;
      $[98] = t34;
    } else {
      t34 = $[98];
    }
    let t35;
    if ($[99] !== colors.mutedForeground || $[100] !== name || $[101] !== t34) {
      t35 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TextInput.default, {
        style: t34,
        value: name,
        onChangeText: setName,
        placeholder: "e.g. Friday Night Degenz",
        placeholderTextColor: colors.mutedForeground,
        maxLength: 32
      });
      $[99] = colors.mutedForeground;
      $[100] = name;
      $[101] = t34;
      $[102] = t35;
    } else {
      t35 = $[102];
    }
    let t36;
    if ($[103] !== colors.mutedForeground) {
      t36 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.label, {
          color: colors.mutedForeground
        }],
        children: "LEAGUE FORMAT"
      });
      $[103] = colors.mutedForeground;
      $[104] = t36;
    } else {
      t36 = $[104];
    }
    let t37;
    if ($[105] !== colors.border || $[106] !== colors.foreground || $[107] !== colors.mutedForeground || $[108] !== colors.primary || $[109] !== colors.secondary || $[110] !== mode) {
      t37 = _constantsLeagueTypes.LEAGUE_MODES.map(m => {
        const active = mode === m.value;
        return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.TouchableOpacity, {
          style: [styles.presetRow, {
            backgroundColor: active ? colors.primary + "11" : colors.secondary,
            borderColor: active ? colors.primary : colors.border
          }],
          onPress: () => setMode(m.value),
          activeOpacity: 0.8,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [styles.presetRadio, {
              borderColor: active ? colors.primary : colors.border
            }],
            children: active && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.presetRadioFill, {
                backgroundColor: colors.primary
              }]
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.presetInfo,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.presetLabel, {
                color: colors.foreground
              }],
              children: m.label
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.presetSplit, {
                color: colors.mutedForeground
              }],
              children: m.desc
            })]
          })]
        }, m.value);
      });
      $[105] = colors.border;
      $[106] = colors.foreground;
      $[107] = colors.mutedForeground;
      $[108] = colors.primary;
      $[109] = colors.secondary;
      $[110] = mode;
      $[111] = t37;
    } else {
      t37 = $[111];
    }
    let t38;
    if ($[112] !== t37) {
      t38 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.presetList,
        children: t37
      });
      $[112] = t37;
      $[113] = t38;
    } else {
      t38 = $[113];
    }
    let t39;
    if ($[114] !== bracketTemplateId || $[115] !== bracketTemplates || $[116] !== colors.mutedForeground || $[117] !== mode) {
      t39 = mode === "bracket" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: {
          gap: 6,
          marginBottom: 12
        },
        children: bracketTemplates.length === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.presetSplit, {
            color: colors.mutedForeground
          }],
          children: "No open tournaments right now."
        }) : bracketTemplates.map(t_2 => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
          label: t_2.name,
          chevron: false,
          tone: bracketTemplateId === t_2.id ? "accent" : "neutral",
          onPress: () => setBracketTemplateId(t_2.id)
        }, t_2.id))
      }) : null;
      $[114] = bracketTemplateId;
      $[115] = bracketTemplates;
      $[116] = colors.mutedForeground;
      $[117] = mode;
      $[118] = t39;
    } else {
      t39 = $[118];
    }
    let t40;
    if ($[119] !== colors.mutedForeground) {
      t40 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.label, {
          color: colors.mutedForeground
        }],
        children: "LEAGUE TOKENS (per player)"
      });
      $[119] = colors.mutedForeground;
      $[120] = t40;
    } else {
      t40 = $[120];
    }
    const t41 = colors.secondary + "88";
    let t42;
    if ($[121] !== colors.border || $[122] !== t41) {
      t42 = [styles.infoBox, {
        backgroundColor: t41,
        borderColor: colors.border
      }];
      $[121] = colors.border;
      $[122] = t41;
      $[123] = t42;
    } else {
      t42 = $[123];
    }
    let t43;
    if ($[124] !== colors.mutedForeground) {
      t43 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "information-outline",
        size: 13,
        color: colors.mutedForeground
      });
      $[124] = colors.mutedForeground;
      $[125] = t43;
    } else {
      t43 = $[125];
    }
    let t44;
    if ($[126] !== colors.mutedForeground) {
      t44 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.infoText, {
          color: colors.mutedForeground
        }],
        children: "Separate from your credits \u2014 only usable within this league"
      });
      $[126] = colors.mutedForeground;
      $[127] = t44;
    } else {
      t44 = $[127];
    }
    let t45;
    if ($[128] !== t42 || $[129] !== t43 || $[130] !== t44) {
      t45 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t42,
        children: [t43, t44]
      });
      $[128] = t42;
      $[129] = t43;
      $[130] = t44;
      $[131] = t45;
    } else {
      t45 = $[131];
    }
    let t46;
    if ($[132] !== colors.border || $[133] !== colors.mutedForeground || $[134] !== colors.primary || $[135] !== colors.primaryForeground || $[136] !== colors.secondary || $[137] !== startingLeagueTokens) {
      t46 = TOKEN_OPTIONS.map(t_3 => {
        const active_0 = startingLeagueTokens === t_3;
        return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.TouchableOpacity, {
          style: [styles.optionChip, {
            backgroundColor: active_0 ? colors.primary : colors.secondary,
            borderColor: active_0 ? colors.primary : colors.border
          }],
          onPress: () => setStartingLeagueTokens(t_3),
          activeOpacity: 0.8,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "shield-star",
            size: 11,
            color: active_0 ? colors.primaryForeground : colors.mutedForeground
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.optionText, {
              color: active_0 ? colors.primaryForeground : colors.mutedForeground
            }],
            children: t_3 >= 1000 ? `${(t_3 / 1000).toFixed(0)}K` : t_3.toLocaleString()
          })]
        }, t_3);
      });
      $[132] = colors.border;
      $[133] = colors.mutedForeground;
      $[134] = colors.primary;
      $[135] = colors.primaryForeground;
      $[136] = colors.secondary;
      $[137] = startingLeagueTokens;
      $[138] = t46;
    } else {
      t46 = $[138];
    }
    let t47;
    if ($[139] !== t46) {
      t47 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.optionRow,
        children: t46
      });
      $[139] = t46;
      $[140] = t47;
    } else {
      t47 = $[140];
    }
    let t48;
    if ($[141] !== colors.mutedForeground) {
      t48 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.label, {
          color: colors.mutedForeground
        }],
        children: "BUY-IN (credits)"
      });
      $[141] = colors.mutedForeground;
      $[142] = t48;
    } else {
      t48 = $[142];
    }
    const t49 = colors.accent + "11";
    const t50 = colors.accent + "44";
    let t51;
    if ($[143] !== t49 || $[144] !== t50) {
      t51 = [styles.infoBox, {
        backgroundColor: t49,
        borderColor: t50
      }];
      $[143] = t49;
      $[144] = t50;
      $[145] = t51;
    } else {
      t51 = $[145];
    }
    let t52;
    if ($[146] !== colors.accent) {
      t52 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "lightning-bolt",
        size: 13,
        color: colors.accent
      });
      $[146] = colors.accent;
      $[147] = t52;
    } else {
      t52 = $[147];
    }
    let t53;
    if ($[148] !== colors.accent) {
      t53 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.infoText, {
          color: colors.accent
        }],
        children: "Credits paid into the pot \u2014 paid out to the top finishers when the season ends"
      });
      $[148] = colors.accent;
      $[149] = t53;
    } else {
      t53 = $[149];
    }
    let t54;
    if ($[150] !== t51 || $[151] !== t52 || $[152] !== t53) {
      t54 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t51,
        children: [t52, t53]
      });
      $[150] = t51;
      $[151] = t52;
      $[152] = t53;
      $[153] = t54;
    } else {
      t54 = $[153];
    }
    let t55;
    if ($[154] !== buyIn || $[155] !== colors.accent || $[156] !== colors.border || $[157] !== colors.destructive || $[158] !== colors.mutedForeground || $[159] !== colors.secondary || $[160] !== yourTokens) {
      t55 = _constantsLeagueTypes.BUY_IN_OPTIONS.map(b => {
        const active_1 = buyIn === b;
        const tooExpensive = b > yourTokens;
        return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.TouchableOpacity, {
          style: [styles.optionChip, {
            backgroundColor: active_1 ? colors.accent : colors.secondary,
            borderColor: active_1 ? colors.accent : tooExpensive ? colors.destructive + "44" : colors.border,
            opacity: tooExpensive ? 0.5 : 1
          }],
          onPress: () => !tooExpensive && setBuyIn(b),
          activeOpacity: 0.8,
          disabled: tooExpensive,
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.optionText, {
              color: active_1 ? "#FFF" : tooExpensive ? colors.destructive : colors.mutedForeground
            }],
            children: b === 0 ? "Free" : b >= 1000 ? `⚡${(b / 1000).toFixed(0)}K` : `⚡${b}`
          })
        }, b);
      });
      $[154] = buyIn;
      $[155] = colors.accent;
      $[156] = colors.border;
      $[157] = colors.destructive;
      $[158] = colors.mutedForeground;
      $[159] = colors.secondary;
      $[160] = yourTokens;
      $[161] = t55;
    } else {
      t55 = $[161];
    }
    let t56;
    if ($[162] !== t55) {
      t56 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.optionRow,
        children: t55
      });
      $[162] = t55;
      $[163] = t56;
    } else {
      t56 = $[163];
    }
    let t57;
    if ($[164] !== buyIn || $[165] !== colors.accent || $[166] !== colors.mutedForeground) {
      t57 = buyIn > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.potPreview, {
          backgroundColor: colors.accent + "11",
          borderColor: colors.accent + "44"
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.potLabel, {
            color: colors.accent
          }],
          children: "PRIZE POT"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.potNote, {
            color: colors.mutedForeground
          }],
          children: ["Starts at \u26A1", buyIn.toLocaleString(), " \u2014 grows as members join"]
        })]
      });
      $[164] = buyIn;
      $[165] = colors.accent;
      $[166] = colors.mutedForeground;
      $[167] = t57;
    } else {
      t57 = $[167];
    }
    let t58;
    if ($[168] !== colors.mutedForeground) {
      t58 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.label, {
          color: colors.mutedForeground
        }],
        children: "PRIZE DISTRIBUTION"
      });
      $[168] = colors.mutedForeground;
      $[169] = t58;
    } else {
      t58 = $[169];
    }
    let t59;
    if ($[170] !== colors.border || $[171] !== colors.foreground || $[172] !== colors.mutedForeground || $[173] !== colors.primary || $[174] !== colors.secondary || $[175] !== selectedPreset) {
      t59 = _constantsLeagueTypes.PRIZE_PRESETS.map(p_0 => {
        const active_2 = selectedPreset === p_0.value;
        return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.TouchableOpacity, {
          style: [styles.presetRow, {
            backgroundColor: active_2 ? colors.primary + "11" : colors.secondary,
            borderColor: active_2 ? colors.primary : colors.border
          }],
          onPress: () => setSelectedPreset(p_0.value),
          activeOpacity: 0.8,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [styles.presetRadio, {
              borderColor: active_2 ? colors.primary : colors.border
            }],
            children: active_2 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.presetRadioFill, {
                backgroundColor: colors.primary
              }]
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.presetInfo,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.presetLabel, {
                color: colors.foreground
              }],
              children: p_0.label
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.presetSplit, {
                color: colors.mutedForeground
              }],
              children: [p_0.firstPct, "%", p_0.secondPct > 0 ? ` / ${p_0.secondPct}%` : "", p_0.thirdPct > 0 ? ` / ${p_0.thirdPct}%` : ""]
            })]
          })]
        }, p_0.value);
      });
      $[170] = colors.border;
      $[171] = colors.foreground;
      $[172] = colors.mutedForeground;
      $[173] = colors.primary;
      $[174] = colors.secondary;
      $[175] = selectedPreset;
      $[176] = t59;
    } else {
      t59 = $[176];
    }
    let t60;
    if ($[177] !== t59) {
      t60 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.presetList,
        children: t59
      });
      $[177] = t59;
      $[178] = t60;
    } else {
      t60 = $[178];
    }
    let t61;
    if ($[179] !== colors.mutedForeground) {
      t61 = [styles.label, {
        color: colors.mutedForeground
      }];
      $[179] = colors.mutedForeground;
      $[180] = t61;
    } else {
      t61 = $[180];
    }
    const t62 = fullSeason ? "SPORT (ONE PER SEASON)" : "ALLOWED SPORTS";
    let t63;
    if ($[181] !== t61 || $[182] !== t62) {
      t63 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t61,
        children: t62
      });
      $[181] = t61;
      $[182] = t62;
      $[183] = t63;
    } else {
      t63 = $[183];
    }
    let t64;
    if ($[184] !== colors.border || $[185] !== colors.mutedForeground || $[186] !== colors.primary || $[187] !== colors.secondary || $[188] !== fullSeason || $[189] !== sports || $[190] !== toggleSport) {
      t64 = SPORT_OPTIONS.map(sport_0 => {
        const active_3 = sports.includes(sport_0);
        const locked = fullSeason && !active_3 && sports.length > 0;
        return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.TouchableOpacity, {
          style: [styles.sportChip, {
            backgroundColor: active_3 ? colors.primary + "22" : colors.secondary,
            borderColor: active_3 ? colors.primary : colors.border,
            opacity: locked ? 0.45 : 1
          }],
          onPress: () => toggleSport(sport_0),
          accessibilityState: {
            selected: active_3
          },
          accessibilityHint: locked ? `Switches this season to ${sport_0}` : undefined,
          activeOpacity: 0.8,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: locked ? "lock" : _constantsLeagueTypes.SPORT_ICONS[sport_0],
            size: 16,
            color: active_3 ? colors.primary : colors.mutedForeground
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.sportText, {
              color: active_3 ? colors.primary : colors.mutedForeground
            }],
            children: sport_0
          })]
        }, sport_0);
      });
      $[184] = colors.border;
      $[185] = colors.mutedForeground;
      $[186] = colors.primary;
      $[187] = colors.secondary;
      $[188] = fullSeason;
      $[189] = sports;
      $[190] = toggleSport;
      $[191] = t64;
    } else {
      t64 = $[191];
    }
    let t65;
    if ($[192] !== t64) {
      t65 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.sportGrid,
        children: t64
      });
      $[192] = t64;
      $[193] = t65;
    } else {
      t65 = $[193];
    }
    let t66;
    if ($[194] !== colors.subtleForeground || $[195] !== fullSeason || $[196] !== sports.length) {
      t66 = fullSeason ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.durationHint, {
          color: colors.subtleForeground
        }],
        children: sports.length ? "A full season follows one sport. Tap another sport to switch to it." : "Pick the one sport this season follows."
      }) : null;
      $[194] = colors.subtleForeground;
      $[195] = fullSeason;
      $[196] = sports.length;
      $[197] = t66;
    } else {
      t66 = $[197];
    }
    let t67;
    if ($[198] !== colors.mutedForeground) {
      t67 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.label, {
          color: colors.mutedForeground
        }],
        children: "LEAGUE START"
      });
      $[198] = colors.mutedForeground;
      $[199] = t67;
    } else {
      t67 = $[199];
    }
    const t68 = !startNow;
    let t69;
    if ($[200] === Symbol.for("react.memo_cache_sentinel")) {
      t69 = () => setStartNow(false);
      $[200] = t69;
    } else {
      t69 = $[200];
    }
    let t70;
    if ($[201] !== t68) {
      t70 = {
        on: t68,
        label: "Schedule",
        icon: "calendar-clock",
        press: t69
      };
      $[201] = t68;
      $[202] = t70;
    } else {
      t70 = $[202];
    }
    let t71;
    if ($[203] === Symbol.for("react.memo_cache_sentinel")) {
      t71 = () => setStartNow(true);
      $[203] = t71;
    } else {
      t71 = $[203];
    }
    let t72;
    if ($[204] !== startNow) {
      t72 = {
        on: startNow,
        label: "Start Now",
        icon: "flash",
        press: t71
      };
      $[204] = startNow;
      $[205] = t72;
    } else {
      t72 = $[205];
    }
    let t73;
    if ($[206] !== t70 || $[207] !== t72) {
      t73 = [t70, t72];
      $[206] = t70;
      $[207] = t72;
      $[208] = t73;
    } else {
      t73 = $[208];
    }
    let t74;
    if ($[209] !== colors.border || $[210] !== colors.mutedForeground || $[211] !== colors.primary || $[212] !== colors.primaryForeground || $[213] !== colors.secondary || $[214] !== t73) {
      t74 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.optionRow,
        children: t73.map(o => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.TouchableOpacity, {
          style: [styles.optionChip, styles.startChip, {
            backgroundColor: o.on ? colors.primary : colors.secondary,
            borderColor: o.on ? colors.primary : colors.border
          }],
          onPress: o.press,
          activeOpacity: 0.8,
          accessibilityState: {
            selected: o.on
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: o.icon,
            size: 15,
            color: o.on ? colors.primaryForeground : colors.mutedForeground
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.optionText, {
              color: o.on ? colors.primaryForeground : colors.mutedForeground
            }],
            children: o.label
          })]
        }, o.label))
      });
      $[209] = colors.border;
      $[210] = colors.mutedForeground;
      $[211] = colors.primary;
      $[212] = colors.primaryForeground;
      $[213] = colors.secondary;
      $[214] = t73;
      $[215] = t74;
    } else {
      t74 = $[215];
    }
    const t75 = startNow ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
      style: [styles.durationHint, {
        color: colors.warning
      }],
      children: "Starts the moment you create it. Nobody can join once a league has started, so only pick this if you're playing solo \u2014 otherwise schedule it and share the code."
    }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
      style: [styles.startCard, {
        backgroundColor: colors.secondary,
        borderColor: colors.border
      }],
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.TouchableOpacity, {
        accessibilityRole: "button",
        accessibilityLabel: "One day earlier",
        disabled: startDays <= 1,
        onPress: () => setStartDays(_temp3),
        style: [styles.stepBtn, {
          borderColor: colors.border,
          opacity: startDays <= 1 ? 0.35 : 1
        }],
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "minus",
          size: 18,
          color: colors.foreground
        })
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: {
          flex: 1,
          alignItems: "center"
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.startWhen, {
            color: colors.foreground
          }],
          children: fmtStart(startsAt)
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.durationHint, {
            color: colors.subtleForeground,
            marginTop: 2
          }],
          children: ["in ", startDays, " day", startDays > 1 ? "s" : "", " \xB7 friends can join until then"]
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.TouchableOpacity, {
        accessibilityRole: "button",
        accessibilityLabel: "One day later",
        disabled: startDays >= 60,
        onPress: () => setStartDays(_temp4),
        style: [styles.stepBtn, {
          borderColor: colors.border,
          opacity: startDays >= 60 ? 0.35 : 1
        }],
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "plus",
          size: 18,
          color: colors.foreground
        })
      })]
    });
    let t76;
    if ($[216] !== colors.mutedForeground) {
      t76 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.label, {
          color: colors.mutedForeground
        }],
        children: "LEAGUE DURATION"
      });
      $[216] = colors.mutedForeground;
      $[217] = t76;
    } else {
      t76 = $[217];
    }
    let t77;
    if ($[218] !== colors.border || $[219] !== colors.mutedForeground || $[220] !== colors.primary || $[221] !== colors.primaryForeground || $[222] !== colors.secondary || $[223] !== duration) {
      t77 = _constantsLeagueTypes.DURATION_OPTIONS.map(d_2 => {
        const active_4 = duration === d_2;
        return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.TouchableOpacity, {
          style: [styles.optionChip, {
            backgroundColor: active_4 ? colors.primary : colors.secondary,
            borderColor: active_4 ? colors.primary : colors.border
          }],
          onPress: () => setDuration(d_2),
          activeOpacity: 0.8,
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.optionText, {
              color: active_4 ? colors.primaryForeground : colors.mutedForeground
            }],
            children: d_2
          })
        }, d_2);
      });
      $[218] = colors.border;
      $[219] = colors.mutedForeground;
      $[220] = colors.primary;
      $[221] = colors.primaryForeground;
      $[222] = colors.secondary;
      $[223] = duration;
      $[224] = t77;
    } else {
      t77 = $[224];
    }
    let t78;
    if ($[225] !== t77) {
      t78 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.optionRow,
        children: t77
      });
      $[225] = t77;
      $[226] = t78;
    } else {
      t78 = $[226];
    }
    const t79 = season ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
      style: [styles.seasonCard, {
        backgroundColor: colors.primary + "10",
        borderColor: colors.primary + "55"
      }],
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.seasonHead,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "calendar-range",
          size: 16,
          color: colors.primary
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.seasonEnd, {
            color: colors.foreground
          }],
          children: ["Ends ", (0, _constantsSeasons.fmtDate)(season.end)]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.seasonLen, {
            color: colors.primary
          }],
          children: season.days >= 60 ? `~${Math.round(season.days / 30.4)} months` : `${Math.round(season.days / 7)} weeks`
        })]
      }), sports.length === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.templateDesc, {
          color: colors.mutedForeground
        }],
        children: "Pick at least one sport above."
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [season.seasons.map(x => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.seasonRow,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: _constantsLeagueTypes.SPORT_ICONS[x.sport],
            size: 13,
            color: colors.mutedForeground
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.seasonSport, {
              color: colors.foreground
            }],
            children: [x.sport, " ", x.label]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.templateDesc, {
              color: colors.mutedForeground,
              flex: 1,
              textAlign: "right"
            }],
            children: [x.current ? "in progress" : `starts ${(0, _constantsSeasons.fmtDate)(x.start, false)}`, " \xB7 ", x.finale, " ~", (0, _constantsSeasons.fmtDate)(x.end)]
          })]
        }, x.sport)), season.decidedBy ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.templateDesc, {
            color: colors.foreground
          }],
          children: ["The league runs until the ", season.decidedBy.sport, " ", season.decidedBy.finale, ".", season.seasons.some(_temp5) ? " A season that's over half done (or not started) counts from its next full season, so it can run well into next year." : ""]
        }) : null, season.days > 200 ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.templateDesc, {
            color: colors.warning
          }],
          children: ["That's a long season \u2014 make sure everyone's in for ", Math.round(season.days / 30.4), " months. Pick a fixed length to end sooner."]
        }) : null]
      })]
    }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
      style: [styles.durationHint, {
        color: colors.subtleForeground
      }],
      children: [_constantsLeagueTypes.DURATION_DAYS[duration] / 7, " weeks \xB7 ends", " ", (0, _constantsSeasons.fmtDate)(startsAt + _constantsLeagueTypes.DURATION_DAYS[duration] * 86400000, false), ". Leagues run at least a month so the table has time to mean something. Pick Full Season to follow your sports' calendars."]
    });
    let t80;
    if ($[227] !== colors.border || $[228] !== colors.secondary) {
      t80 = [styles.bankCard, {
        backgroundColor: colors.secondary,
        borderColor: colors.border
      }];
      $[227] = colors.border;
      $[228] = colors.secondary;
      $[229] = t80;
    } else {
      t80 = $[229];
    }
    const t81 = matchupsEnabled ? colors.primary : colors.mutedForeground;
    let t82;
    if ($[230] !== t81) {
      t82 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "sword-cross",
        size: 16,
        color: t81
      });
      $[230] = t81;
      $[231] = t82;
    } else {
      t82 = $[231];
    }
    let t83;
    if ($[232] === Symbol.for("react.memo_cache_sentinel")) {
      t83 = {
        flex: 1
      };
      $[232] = t83;
    } else {
      t83 = $[232];
    }
    let t84;
    if ($[233] !== colors.foreground) {
      t84 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.bankToggleTitle, {
          color: colors.foreground
        }],
        children: "Head-to-Head Matchups"
      });
      $[233] = colors.foreground;
      $[234] = t84;
    } else {
      t84 = $[234];
    }
    let t85;
    if ($[235] !== colors.mutedForeground) {
      t85 = [styles.bankToggleDesc, {
        color: colors.mutedForeground
      }];
      $[235] = colors.mutedForeground;
      $[236] = t85;
    } else {
      t85 = $[236];
    }
    const t86 = mode === "matchups" ? "Always on in an H2H League \u2014 pick how often opponents change" : "Pair members each round + a final playoff round";
    let t87;
    if ($[237] !== t85 || $[238] !== t86) {
      t87 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t85,
        children: t86
      });
      $[237] = t85;
      $[238] = t86;
      $[239] = t87;
    } else {
      t87 = $[239];
    }
    let t88;
    if ($[240] !== t84 || $[241] !== t87) {
      t88 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t83,
        children: [t84, t87]
      });
      $[240] = t84;
      $[241] = t87;
      $[242] = t88;
    } else {
      t88 = $[242];
    }
    let t89;
    if ($[243] !== t82 || $[244] !== t88) {
      t89 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.bankToggleLeft,
        children: [t82, t88]
      });
      $[243] = t82;
      $[244] = t88;
      $[245] = t89;
    } else {
      t89 = $[245];
    }
    let t90;
    if ($[246] !== colors.border || $[247] !== colors.mutedForeground || $[248] !== colors.primary || $[249] !== colors.primaryForeground || $[250] !== matchupsEnabled || $[251] !== mode) {
      t90 = mode !== "matchups" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Switch, {
        value: matchupsEnabled,
        onValueChange: setMatchupsEnabled,
        trackColor: {
          false: colors.border,
          true: colors.primary
        },
        thumbColor: matchupsEnabled ? colors.primaryForeground : colors.mutedForeground
      }) : null;
      $[246] = colors.border;
      $[247] = colors.mutedForeground;
      $[248] = colors.primary;
      $[249] = colors.primaryForeground;
      $[250] = matchupsEnabled;
      $[251] = mode;
      $[252] = t90;
    } else {
      t90 = $[252];
    }
    let t91;
    if ($[253] !== t89 || $[254] !== t90) {
      t91 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.bankToggleRow,
        children: [t89, t90]
      });
      $[253] = t89;
      $[254] = t90;
      $[255] = t91;
    } else {
      t91 = $[255];
    }
    let t92;
    if ($[256] !== colors.border || $[257] !== colors.card || $[258] !== colors.mutedForeground || $[259] !== colors.primary || $[260] !== colors.primaryForeground || $[261] !== colors.subtleForeground || $[262] !== h2hOn || $[263] !== matchupCadence) {
      t92 = h2hOn ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.bankOptions, {
          borderTopColor: colors.border,
          marginTop: 12
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.label, {
            color: colors.mutedForeground,
            marginTop: 12
          }],
          children: "HOW OFTEN"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: styles.optionRow,
          children: _constantsLeagueTypes.MATCHUP_CADENCES.map(m_0 => {
            const on_0 = matchupCadence === m_0.value;
            return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.TouchableOpacity, {
              style: [styles.optionChip, {
                backgroundColor: on_0 ? colors.primary : colors.card,
                borderColor: on_0 ? colors.primary : colors.border
              }],
              onPress: () => setMatchupCadence(m_0.value),
              activeOpacity: 0.8,
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.optionText, {
                  color: on_0 ? colors.primaryForeground : colors.mutedForeground
                }],
                children: m_0.label
              })
            }, m_0.value);
          })
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.durationHint, {
            color: colors.subtleForeground
          }],
          children: [_constantsLeagueTypes.MATCHUP_CADENCES.find(m_1 => m_1.value === matchupCadence)?.desc, ". Whoever grows their net worth more in a round wins it."]
        })]
      }) : null;
      $[256] = colors.border;
      $[257] = colors.card;
      $[258] = colors.mutedForeground;
      $[259] = colors.primary;
      $[260] = colors.primaryForeground;
      $[261] = colors.subtleForeground;
      $[262] = h2hOn;
      $[263] = matchupCadence;
      $[264] = t92;
    } else {
      t92 = $[264];
    }
    let t93;
    if ($[265] !== t80 || $[266] !== t91 || $[267] !== t92) {
      t93 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t80,
        children: [t91, t92]
      });
      $[265] = t80;
      $[266] = t91;
      $[267] = t92;
      $[268] = t93;
    } else {
      t93 = $[268];
    }
    let t94;
    if ($[269] !== colors.border || $[270] !== colors.secondary) {
      t94 = [styles.bankCard, {
        backgroundColor: colors.secondary,
        borderColor: colors.border
      }];
      $[269] = colors.border;
      $[270] = colors.secondary;
      $[271] = t94;
    } else {
      t94 = $[271];
    }
    const t95 = bankLoanEnabled ? colors.accent : colors.mutedForeground;
    let t96;
    if ($[272] !== t95) {
      t96 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "bank",
        size: 16,
        color: t95
      });
      $[272] = t95;
      $[273] = t96;
    } else {
      t96 = $[273];
    }
    let t97;
    if ($[274] !== colors.foreground) {
      t97 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.bankToggleTitle, {
          color: colors.foreground
        }],
        children: "League Bank Loans"
      });
      $[274] = colors.foreground;
      $[275] = t97;
    } else {
      t97 = $[275];
    }
    let t98;
    if ($[276] !== colors.mutedForeground) {
      t98 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.bankToggleDesc, {
          color: colors.mutedForeground
        }],
        children: "Let members borrow league tokens at interest"
      });
      $[276] = colors.mutedForeground;
      $[277] = t98;
    } else {
      t98 = $[277];
    }
    let t99;
    if ($[278] !== t97 || $[279] !== t98) {
      t99 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        children: [t97, t98]
      });
      $[278] = t97;
      $[279] = t98;
      $[280] = t99;
    } else {
      t99 = $[280];
    }
    let t100;
    if ($[281] !== t96 || $[282] !== t99) {
      t100 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.bankToggleLeft,
        children: [t96, t99]
      });
      $[281] = t96;
      $[282] = t99;
      $[283] = t100;
    } else {
      t100 = $[283];
    }
    let t101;
    if ($[284] !== colors.accent || $[285] !== colors.border) {
      t101 = {
        false: colors.border,
        true: colors.accent
      };
      $[284] = colors.accent;
      $[285] = colors.border;
      $[286] = t101;
    } else {
      t101 = $[286];
    }
    const t102 = bankLoanEnabled ? colors.accentForeground : colors.mutedForeground;
    let t103;
    if ($[287] !== bankLoanEnabled || $[288] !== setBankLoanEnabled || $[289] !== t101 || $[290] !== t102) {
      t103 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Switch, {
        value: bankLoanEnabled,
        onValueChange: setBankLoanEnabled,
        trackColor: t101,
        thumbColor: t102
      });
      $[287] = bankLoanEnabled;
      $[288] = setBankLoanEnabled;
      $[289] = t101;
      $[290] = t102;
      $[291] = t103;
    } else {
      t103 = $[291];
    }
    let t104;
    if ($[292] !== t100 || $[293] !== t103) {
      t104 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.bankToggleRow,
        children: [t100, t103]
      });
      $[292] = t100;
      $[293] = t103;
      $[294] = t104;
    } else {
      t104 = $[294];
    }
    let t105;
    if ($[295] !== bankInterestRate || $[296] !== bankLoanEnabled || $[297] !== colors.accent || $[298] !== colors.border || $[299] !== colors.card || $[300] !== colors.foreground || $[301] !== colors.mutedForeground || $[302] !== rateNum || $[303] !== setBankInterestRate) {
      t105 = bankLoanEnabled && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.bankOptions, {
          borderTopColor: colors.border
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.label, {
            color: colors.mutedForeground,
            marginTop: 12
          }],
          children: "FLAT INTEREST (% of amount borrowed, charged once, 0.5\u201350)"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(NumericInput.default, {
          style: [styles.input, {
            color: colors.foreground,
            borderColor: colors.border,
            backgroundColor: colors.card
          }],
          value: bankInterestRate,
          onChangeText: setBankInterestRate,
          keyboardType: "decimal-pad",
          placeholder: "e.g. 10",
          placeholderTextColor: colors.mutedForeground,
          maxLength: 5
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.bankSummary, {
            backgroundColor: colors.accent + "14",
            borderColor: colors.accent + "44"
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "information-outline",
            size: 12,
            color: colors.accent
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.bankSummaryText, {
              color: colors.accent
            }],
            children: ["Flat interest: borrow 1,000 and repay", " ", (1000 + (0, _libLoanMath.flatInterest)(1000, rateNum || 0)).toLocaleString(), " \u2014 no more, however long it takes. Members can borrow up to the starting stack. Rate changes only affect new loans."]
          })]
        })]
      });
      $[295] = bankInterestRate;
      $[296] = bankLoanEnabled;
      $[297] = colors.accent;
      $[298] = colors.border;
      $[299] = colors.card;
      $[300] = colors.foreground;
      $[301] = colors.mutedForeground;
      $[302] = rateNum;
      $[303] = setBankInterestRate;
      $[304] = t105;
    } else {
      t105 = $[304];
    }
    let t106;
    if ($[305] !== t104 || $[306] !== t105 || $[307] !== t94) {
      t106 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t94,
        children: [t104, t105]
      });
      $[305] = t104;
      $[306] = t105;
      $[307] = t94;
      $[308] = t106;
    } else {
      t106 = $[308];
    }
    let t107;
    if ($[309] !== colors.border || $[310] !== colors.secondary) {
      t107 = [styles.bankCard, {
        backgroundColor: colors.secondary,
        borderColor: colors.border
      }];
      $[309] = colors.border;
      $[310] = colors.secondary;
      $[311] = t107;
    } else {
      t107 = $[311];
    }
    const t108 = stimulusEnabled ? colors.positive : colors.mutedForeground;
    let t109;
    if ($[312] !== t108) {
      t109 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "cash-plus",
        size: 16,
        color: t108
      });
      $[312] = t108;
      $[313] = t109;
    } else {
      t109 = $[313];
    }
    let t110;
    if ($[314] === Symbol.for("react.memo_cache_sentinel")) {
      t110 = {
        flex: 1
      };
      $[314] = t110;
    } else {
      t110 = $[314];
    }
    let t111;
    if ($[315] !== colors.foreground) {
      t111 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.bankToggleTitle, {
          color: colors.foreground
        }],
        children: "Stimulus Votes"
      });
      $[315] = colors.foreground;
      $[316] = t111;
    } else {
      t111 = $[316];
    }
    let t112;
    if ($[317] !== colors.mutedForeground) {
      t112 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.bankToggleDesc, {
          color: colors.mutedForeground
        }],
        children: "Anyone can ask the bank to give every member 10\u201350% of the starting stack. A majority yes pays everyone the same amount \u2014 free, not a loan. Once a week at most."
      });
      $[317] = colors.mutedForeground;
      $[318] = t112;
    } else {
      t112 = $[318];
    }
    let t113;
    if ($[319] !== t111 || $[320] !== t112) {
      t113 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t110,
        children: [t111, t112]
      });
      $[319] = t111;
      $[320] = t112;
      $[321] = t113;
    } else {
      t113 = $[321];
    }
    let t114;
    if ($[322] !== t109 || $[323] !== t113) {
      t114 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.bankToggleLeft,
        children: [t109, t113]
      });
      $[322] = t109;
      $[323] = t113;
      $[324] = t114;
    } else {
      t114 = $[324];
    }
    let t115;
    if ($[325] !== colors.border || $[326] !== colors.positive) {
      t115 = {
        false: colors.border,
        true: colors.positive
      };
      $[325] = colors.border;
      $[326] = colors.positive;
      $[327] = t115;
    } else {
      t115 = $[327];
    }
    const t116 = stimulusEnabled ? "#FFFFFF" : colors.mutedForeground;
    let t117;
    if ($[328] !== stimulusEnabled || $[329] !== t115 || $[330] !== t116) {
      t117 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Switch, {
        value: stimulusEnabled,
        onValueChange: setStimulusEnabled,
        trackColor: t115,
        thumbColor: t116,
        accessibilityLabel: "Stimulus votes"
      });
      $[328] = stimulusEnabled;
      $[329] = t115;
      $[330] = t116;
      $[331] = t117;
    } else {
      t117 = $[331];
    }
    let t118;
    if ($[332] !== t114 || $[333] !== t117) {
      t118 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.bankToggleRow,
        children: [t114, t117]
      });
      $[332] = t114;
      $[333] = t117;
      $[334] = t118;
    } else {
      t118 = $[334];
    }
    let t119;
    if ($[335] !== t107 || $[336] !== t118) {
      t119 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t107,
        children: t118
      });
      $[335] = t107;
      $[336] = t118;
      $[337] = t119;
    } else {
      t119 = $[337];
    }
    let t120;
    if ($[338] !== buyIn || $[339] !== colors.border || $[340] !== colors.destructive || $[341] !== colors.foreground || $[342] !== colors.mutedForeground || $[343] !== colors.primary || $[344] !== colors.secondary || $[345] !== yourTokens) {
      t120 = buyIn > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.costSummary, {
          backgroundColor: colors.secondary,
          borderColor: colors.border
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.costRow,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.costLabel, {
              color: colors.mutedForeground
            }],
            children: "Your balance"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.costValueRow,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "lightning-bolt",
              size: 12,
              color: colors.foreground
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.costValue, {
                color: colors.foreground
              }],
              children: yourTokens.toLocaleString()
            })]
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.costRow,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.costLabel, {
              color: colors.mutedForeground
            }],
            children: "Buy-in cost"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.costValueRow,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "lightning-bolt",
              size: 12,
              color: colors.destructive
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.costValue, {
                color: colors.destructive
              }],
              children: ["-", buyIn.toLocaleString()]
            })]
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [styles.costDivider, {
            backgroundColor: colors.border
          }]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.costRow,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.costLabel, {
              color: colors.mutedForeground
            }],
            children: "After joining"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.costValueRow,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "lightning-bolt",
              size: 12,
              color: colors.primary
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.costValue, {
                color: colors.primary
              }],
              children: (yourTokens - buyIn).toLocaleString()
            })]
          })]
        })]
      });
      $[338] = buyIn;
      $[339] = colors.border;
      $[340] = colors.destructive;
      $[341] = colors.foreground;
      $[342] = colors.mutedForeground;
      $[343] = colors.primary;
      $[344] = colors.secondary;
      $[345] = yourTokens;
      $[346] = t120;
    } else {
      t120 = $[346];
    }
    const t121 = canCreate ? colors.primary : colors.secondary;
    let t122;
    if ($[347] !== t121) {
      t122 = [styles.createBtn, {
        backgroundColor: t121
      }];
      $[347] = t121;
      $[348] = t122;
    } else {
      t122 = $[348];
    }
    const t123 = !canCreate;
    const t124 = canCreate ? colors.primaryForeground : colors.mutedForeground;
    let t125;
    if ($[349] !== t124) {
      t125 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "trophy",
        size: 18,
        color: t124
      });
      $[349] = t124;
      $[350] = t125;
    } else {
      t125 = $[350];
    }
    const t126 = canCreate ? colors.primaryForeground : colors.mutedForeground;
    let t127;
    if ($[351] !== t126) {
      t127 = [styles.createBtnText, {
        color: t126
      }];
      $[351] = t126;
      $[352] = t127;
    } else {
      t127 = $[352];
    }
    const t128 = submitting ? "Creating\u2026" : buyIn > yourTokens ? "Not enough credits" : "Create League";
    let t129;
    if ($[353] !== t127 || $[354] !== t128) {
      t129 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t127,
        children: t128
      });
      $[353] = t127;
      $[354] = t128;
      $[355] = t129;
    } else {
      t129 = $[355];
    }
    let t130;
    if ($[356] !== handleConfirm || $[357] !== t122 || $[358] !== t123 || $[359] !== t125 || $[360] !== t129) {
      t130 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.TouchableOpacity, {
        style: t122,
        onPress: handleConfirm,
        disabled: t123,
        activeOpacity: 0.8,
        children: [t125, t129]
      });
      $[356] = handleConfirm;
      $[357] = t122;
      $[358] = t123;
      $[359] = t125;
      $[360] = t129;
      $[361] = t130;
    } else {
      t130 = $[361];
    }
    let t131;
    if ($[362] !== colors.destructive || $[363] !== submitError) {
      t131 = submitError ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        accessibilityRole: "alert",
        style: {
          color: colors.destructive,
          fontFamily: "Inter_500Medium",
          fontSize: 13,
          marginTop: 10,
          textAlign: "center"
        },
        children: submitError
      }) : null;
      $[362] = colors.destructive;
      $[363] = submitError;
      $[364] = t131;
    } else {
      t131 = $[364];
    }
    let t132;
    if ($[365] === Symbol.for("react.memo_cache_sentinel")) {
      t132 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: {
          height: 32
        }
      });
      $[365] = t132;
    } else {
      t132 = $[365];
    }
    let t133;
    if ($[366] !== T3 || $[367] !== t106 || $[368] !== t119 || $[369] !== t120 || $[370] !== t130 || $[371] !== t131 || $[372] !== t27 || $[373] !== t28 || $[374] !== t29 || $[375] !== t31 || $[376] !== t32 || $[377] !== t33 || $[378] !== t35 || $[379] !== t36 || $[380] !== t38 || $[381] !== t39 || $[382] !== t40 || $[383] !== t45 || $[384] !== t47 || $[385] !== t48 || $[386] !== t54 || $[387] !== t56 || $[388] !== t57 || $[389] !== t58 || $[390] !== t60 || $[391] !== t63 || $[392] !== t65 || $[393] !== t66 || $[394] !== t67 || $[395] !== t74 || $[396] !== t75 || $[397] !== t76 || $[398] !== t78 || $[399] !== t79 || $[400] !== t93) {
      t133 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T3, {
        showsVerticalScrollIndicator: t23,
        bounces: t24,
        keyboardShouldPersistTaps: t25,
        keyboardDismissMode: t26,
        children: [t27, t28, t29, t31, t32, t33, t35, t36, t38, t39, t40, t45, t47, t48, t54, t56, t57, t58, t60, t63, t65, t66, t67, t74, t75, t76, t78, t79, t93, t106, t119, t120, t130, t131, t132]
      });
      $[366] = T3;
      $[367] = t106;
      $[368] = t119;
      $[369] = t120;
      $[370] = t130;
      $[371] = t131;
      $[372] = t27;
      $[373] = t28;
      $[374] = t29;
      $[375] = t31;
      $[376] = t32;
      $[377] = t33;
      $[378] = t35;
      $[379] = t36;
      $[380] = t38;
      $[381] = t39;
      $[382] = t40;
      $[383] = t45;
      $[384] = t47;
      $[385] = t48;
      $[386] = t54;
      $[387] = t56;
      $[388] = t57;
      $[389] = t58;
      $[390] = t60;
      $[391] = t63;
      $[392] = t65;
      $[393] = t66;
      $[394] = t67;
      $[395] = t74;
      $[396] = t75;
      $[397] = t76;
      $[398] = t78;
      $[399] = t79;
      $[400] = t93;
      $[401] = t133;
    } else {
      t133 = $[401];
    }
    let t134;
    if ($[402] !== onClose) {
      t134 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.CloseButton, {
        onPress: onClose,
        style: styles.close
      });
      $[402] = onClose;
      $[403] = t134;
    } else {
      t134 = $[403];
    }
    let t135;
    if ($[404] !== T2 || $[405] !== t133 || $[406] !== t134 || $[407] !== t21 || $[408] !== t22) {
      t135 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T2, {
        style: t21,
        children: [t22, t133, t134]
      });
      $[404] = T2;
      $[405] = t133;
      $[406] = t134;
      $[407] = t21;
      $[408] = t22;
      $[409] = t135;
    } else {
      t135 = $[409];
    }
    let t136;
    if ($[410] !== T1 || $[411] !== t135 || $[412] !== t19 || $[413] !== t20) {
      t136 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T1, {
        behavior: t18,
        style: t19,
        children: [t20, t135]
      });
      $[410] = T1;
      $[411] = t135;
      $[412] = t19;
      $[413] = t20;
      $[414] = t136;
    } else {
      t136 = $[414];
    }
    let t137;
    if ($[415] !== T0 || $[416] !== onClose || $[417] !== t136 || $[418] !== visible) {
      t137 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(T0, {
        visible: visible,
        transparent: t14,
        animationType: t15,
        onRequestClose: onClose,
        statusBarTranslucent: t16,
        navigationBarTranslucent: t17,
        children: t136
      });
      $[415] = T0;
      $[416] = onClose;
      $[417] = t136;
      $[418] = visible;
      $[419] = t137;
    } else {
      t137 = $[419];
    }
    return t137;
  }
  function _temp5(x_0) {
    return !x_0.current;
  }
  function _temp4(d_1) {
    return Math.min(60, d_1 + 1);
  }
  function _temp3(d_0) {
    return Math.max(1, d_0 - 1);
  }
  function _temp2(prev) {
    return prev.slice(0, 1);
  }
  function _temp(d) {
    return {
      id: d.id,
      name: d.get("name") ?? d.id
    };
  }
  const styles = StyleSheet.default.create({
    overlay: {
      flex: 1,
      backgroundColor: "rgba(0,0,0,0.5)"
    },
    close: {
      position: "absolute",
      top: 12,
      right: 16
    },
    sheet: {
      maxHeight: "92%",
      borderTopLeftRadius: 24,
      borderTopRightRadius: 24,
      borderTopWidth: 1,
      borderLeftWidth: 1,
      borderRightWidth: 1,
      padding: 24,
      paddingTop: 16
    },
    handle: {
      width: 36,
      height: 4,
      borderRadius: 2,
      alignSelf: "center",
      marginBottom: 16
    },
    title: {
      fontSize: 22,
      fontFamily: "Inter_900Black",
      marginBottom: 6
    },
    subtitle: {
      fontSize: 13,
      fontFamily: "Inter_400Regular",
      marginBottom: 20
    },
    label: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 1,
      marginBottom: 8,
      marginTop: 18
    },
    input: {
      borderWidth: 1,
      borderRadius: 12,
      paddingHorizontal: 14,
      paddingVertical: 12,
      fontSize: 16,
      fontFamily: "Inter_500Medium"
    },
    infoBox: {
      flexDirection: "row",
      gap: 6,
      padding: 10,
      borderRadius: 10,
      borderWidth: 1,
      marginBottom: 10,
      alignItems: "flex-start"
    },
    infoText: {
      flex: 1,
      fontSize: 12,
      fontFamily: "Inter_400Regular"
    },
    optionRow: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 8
    },
    optionChip: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
      paddingHorizontal: 14,
      paddingVertical: 9,
      borderRadius: 20,
      borderWidth: 1
    },
    optionText: {
      fontSize: 13,
      fontFamily: "Inter_600SemiBold"
    },
    startChip: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6
    },
    startCard: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      borderWidth: 1,
      borderRadius: 14,
      padding: 10,
      marginTop: 8
    },
    stepBtn: {
      width: 38,
      height: 38,
      borderRadius: 19,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center"
    },
    startWhen: {
      fontSize: 15,
      fontFamily: "Inter_700Bold"
    },
    durationHint: {
      fontSize: 12,
      fontFamily: "Inter_400Regular",
      marginTop: 8
    },
    templateInfo: {
      flexDirection: "row",
      gap: 10,
      padding: 12,
      borderRadius: 14,
      borderWidth: 1,
      marginTop: 10,
      alignItems: "flex-start"
    },
    templateTitle: {
      fontSize: 13,
      fontFamily: "Inter_700Bold"
    },
    templateDesc: {
      fontSize: 12,
      lineHeight: 17,
      fontFamily: "Inter_400Regular"
    },
    seasonCard: {
      gap: 8,
      padding: 12,
      borderRadius: 14,
      borderWidth: 1,
      marginTop: 10
    },
    seasonHead: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6
    },
    seasonEnd: {
      flex: 1,
      fontSize: 15,
      fontFamily: "Inter_700Bold"
    },
    seasonLen: {
      fontSize: 12,
      fontFamily: "Inter_700Bold"
    },
    seasonRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6
    },
    seasonSport: {
      fontSize: 12,
      fontFamily: "Inter_600SemiBold"
    },
    potPreview: {
      padding: 12,
      borderRadius: 12,
      borderWidth: 1,
      marginTop: 10,
      gap: 4
    },
    potLabel: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 1
    },
    potNote: {
      fontSize: 12,
      fontFamily: "Inter_400Regular"
    },
    presetList: {
      gap: 8
    },
    presetRow: {
      flexDirection: "row",
      alignItems: "flex-start",
      gap: 10,
      padding: 12,
      borderRadius: 14,
      borderWidth: 1
    },
    presetRadio: {
      width: 18,
      height: 18,
      borderRadius: 9,
      borderWidth: 2,
      alignItems: "center",
      justifyContent: "center",
      marginTop: 2
    },
    presetRadioFill: {
      width: 8,
      height: 8,
      borderRadius: 4
    },
    presetInfo: {
      flex: 1,
      gap: 2
    },
    presetLabel: {
      fontSize: 14,
      fontFamily: "Inter_600SemiBold"
    },
    presetSplit: {
      fontSize: 12,
      fontFamily: "Inter_400Regular"
    },
    sportGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 8
    },
    sportChip: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6,
      paddingHorizontal: 14,
      paddingVertical: 9,
      borderRadius: 20,
      borderWidth: 1
    },
    sportText: {
      fontSize: 13,
      fontFamily: "Inter_600SemiBold"
    },
    bankCard: {
      borderRadius: 14,
      borderWidth: 1,
      padding: 14,
      marginTop: 18
    },
    bankToggleRow: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 10
    },
    bankToggleLeft: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      flex: 1
    },
    bankToggleTitle: {
      fontSize: 14,
      fontFamily: "Inter_600SemiBold"
    },
    bankToggleDesc: {
      fontSize: 11,
      fontFamily: "Inter_400Regular",
      marginTop: 2
    },
    bankOptions: {
      borderTopWidth: 1,
      paddingTop: 4
    },
    bankSummary: {
      flexDirection: "row",
      gap: 6,
      padding: 10,
      borderRadius: 10,
      borderWidth: 1,
      marginTop: 10,
      alignItems: "flex-start"
    },
    bankSummaryText: {
      flex: 1,
      fontSize: 11,
      fontFamily: "Inter_400Regular"
    },
    costSummary: {
      padding: 14,
      borderRadius: 12,
      borderWidth: 1,
      marginTop: 16,
      gap: 8
    },
    costRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center"
    },
    costLabel: {
      fontSize: 13,
      fontFamily: "Inter_500Medium"
    },
    costValueRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 2
    },
    costValue: {
      fontSize: 14,
      fontFamily: "Inter_700Bold"
    },
    costDivider: {
      height: 1
    },
    createBtn: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      paddingVertical: 16,
      borderRadius: 14,
      marginTop: 20
    },
    createBtnText: {
      fontSize: 16,
      fontFamily: "Inter_700Bold"
    }
  });
},910,[815,818,905,12,237,238,133,28,188,255,109,827,271,914,836,906,855,819,915,911,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "SEASONS", {
    enumerable: true,
    get: function () {
      return SEASONS;
    }
  });
  Object.defineProperty(exports, "MIN_SEASON_DAYS", {
    enumerable: true,
    get: function () {
      return MIN_SEASON_DAYS;
    }
  });
  Object.defineProperty(exports, "MAX_SEASON_DAYS", {
    enumerable: true,
    get: function () {
      return MAX_SEASON_DAYS;
    }
  });
  exports.sportSeason = sportSeason;
  exports.fullSeasonPlan = fullSeasonPlan;
  exports.leagueEndFor = leagueEndFor;
  Object.defineProperty(exports, "fmtDate", {
    enumerable: true,
    get: function () {
      return fmtDate;
    }
  });
  /**
   * Sport seasons for "Full Season" leagues. Approximate regular-season start →
   * last game of the playoffs, as [month, day]; an end before the start means
   * the next year. Mirrors functions/src/lib/leagueConfig.ts, which decides the
   * real end date — this copy only drives the create screen.
   */
  const SEASONS = {
    NFL: {
      start: [9, 4],
      end: [2, 10],
      finale: "Super Bowl"
    },
    NCAAF: {
      start: [8, 23],
      end: [1, 21],
      finale: "CFP title game"
    },
    NBA: {
      start: [10, 21],
      end: [6, 22],
      finale: "NBA Finals"
    },
    NCAAB: {
      start: [11, 3],
      end: [4, 8],
      finale: "Final Four"
    },
    NHL: {
      start: [10, 7],
      end: [6, 24],
      finale: "Stanley Cup Final"
    },
    MLB: {
      start: [3, 26],
      end: [11, 4],
      finale: "World Series"
    },
    Soccer: {
      start: [8, 15],
      end: [5, 31],
      finale: "end of the European season"
    }
  };
  const DAY = 86_400_000;
  const MIN_SEASON_DAYS = 28;
  const MAX_SEASON_DAYS = 500;
  /** The season a league created now covers for one sport: this one if at least half is left, else the next. */
  function sportSeason(sport, now) {
    const w = SEASONS[sport];
    const year = new Date(now).getUTCFullYear();
    const at = (y, [m, d]) => Date.UTC(y, m - 1, d, 23, 59);
    const spans = [year - 1, year, year + 1].map(y => {
      const wraps = w.end[0] < w.start[0] || w.end[0] === w.start[0] && w.end[1] < w.start[1];
      return {
        y,
        wraps,
        start: at(y, w.start),
        end: at(wraps ? y + 1 : y, w.end)
      };
    });
    let i = spans.findIndex(s => s.end > now);
    const cur = spans[i];
    if (now > cur.start && cur.end - now < (cur.end - cur.start) / 2 && spans[i + 1]) i += 1;
    const s = spans[i];
    return {
      sport,
      start: s.start,
      end: s.end,
      current: now >= s.start,
      label: s.wraps ? `${s.y}–${String(s.y + 1).slice(2)}` : String(s.y),
      finale: w.finale
    };
  }

  /** Each sport's season plus the league end (the latest of them, within limits). */
  function fullSeasonPlan(sports, now) {
    const seasons = sports.map(s => sportSeason(s, now)).sort((a, b) => a.end - b.end);
    const latest = seasons[seasons.length - 1];
    const end = Math.min(Math.max(latest?.end ?? 0, now + 2419200000), now + 43200000000);
    return {
      seasons,
      end,
      days: Math.ceil((end - now) / DAY),
      decidedBy: latest ?? null
    };
  }

  /** League end for any duration choice. */
  function leagueEndFor(duration, days, sports, now) {
    return duration === "Full Season" ? fullSeasonPlan(sports, now).end : now + (days ?? 28) * DAY;
  }
  const fmtDate = (ms, withYear = true) => new Date(ms).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    ...(withYear ? {
      year: "numeric"
    } : {})
  });
},911,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return JoinLeagueSheet;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _firebaseFirestore = require(_dependencyMap[2]);
  var _react = require(_dependencyMap[3]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsTextInput = require(_dependencyMap[6]);
  var TextInput = _interopDefault(_reactNativeWebDistExportsTextInput);
  var _reactNativeWebDistExportsView = require(_dependencyMap[7]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsKeyboardSheet = require(_dependencyMap[8]);
  var KeyboardSheet = _interopDefault(_componentsKeyboardSheet);
  var _componentsUi = require(_dependencyMap[9]);
  var _hooksUseColors = require(_dependencyMap[10]);
  var _libFirebase = require(_dependencyMap[11]);
  var _reactJsxRuntime = require(_dependencyMap[12]);
  /**
   * Join by code. Looks the code up as you type so you see the league name and
   * buy-in *before* committing credits — the old sheet charged first and asked
   * questions later.
   */
  function JoinLeagueSheet(t0) {
    const $ = (0, _reactCompilerRuntime.c)(68);
    const {
      visible,
      initialCode,
      balance,
      onClose,
      onJoin
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const [code, setCode] = (0, _react.useState)(initialCode ?? "");
    const [preview, setPreview] = (0, _react.useState)(null);
    const [busy, setBusy] = (0, _react.useState)(false);
    const [error, setError] = (0, _react.useState)(null);
    let t1;
    let t2;
    if ($[0] !== initialCode || $[1] !== visible) {
      t1 = () => {
        if (visible) {
          setCode((initialCode ?? "").toUpperCase());
          setError(null);
        }
      };
      t2 = [visible, initialCode];
      $[0] = initialCode;
      $[1] = visible;
      $[2] = t1;
      $[3] = t2;
    } else {
      t1 = $[2];
      t2 = $[3];
    }
    (0, _react.useEffect)(t1, t2);
    let t3;
    let t4;
    if ($[4] !== code) {
      t3 = () => {
        const clean = code.trim().toUpperCase();
        if (clean.length < 6) {
          setPreview(null);
          return;
        }
        let alive = true;
        const db = (0, _libFirebase.getDb)();
        if (!db) {
          return;
        }
        (0, _firebaseFirestore.getDoc)((0, _firebaseFirestore.doc)(db, "leagueInvites", clean)).then(s => {
          if (!alive) {
            return;
          }
          setPreview(s.exists() ? {
            leagueName: s.get("leagueName"),
            buyIn: s.get("buyIn") ?? 0
          } : "missing");
        }).catch(() => alive && setPreview(null));
        return () => {
          alive = false;
        };
      };
      t4 = [code];
      $[4] = code;
      $[5] = t3;
      $[6] = t4;
    } else {
      t3 = $[5];
      t4 = $[6];
    }
    (0, _react.useEffect)(t3, t4);
    const found = preview && preview !== "missing" ? preview : null;
    const short = found ? found.buyIn > balance : false;
    let t5;
    if ($[7] !== code || $[8] !== onJoin) {
      t5 = async function submit() {
        setBusy(true);
        setError(null);
        const err = await onJoin(code.trim().toUpperCase());
        setBusy(false);
        if (err) {
          setError(err);
        }
      };
      $[7] = code;
      $[8] = onJoin;
      $[9] = t5;
    } else {
      t5 = $[9];
    }
    const submit = t5;
    let t6;
    if ($[10] !== c.foreground) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        accessibilityRole: "header",
        style: [styles.title, {
          color: c.foreground
        }],
        children: "Join a league"
      });
      $[10] = c.foreground;
      $[11] = t6;
    } else {
      t6 = $[11];
    }
    let t7;
    if ($[12] !== c.mutedForeground) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.sub, {
          color: c.mutedForeground
        }],
        children: "Enter the 6-character code a friend shared."
      });
      $[12] = c.mutedForeground;
      $[13] = t7;
    } else {
      t7 = $[13];
    }
    const t8 = error ? c.negative : c.border;
    let t9;
    if ($[14] !== c.foreground || $[15] !== c.secondary || $[16] !== t8) {
      t9 = [styles.input, {
        color: c.foreground,
        borderColor: t8,
        backgroundColor: c.secondary
      }];
      $[14] = c.foreground;
      $[15] = c.secondary;
      $[16] = t8;
      $[17] = t9;
    } else {
      t9 = $[17];
    }
    let t10;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
      t10 = v => setCode(v.toUpperCase().replace(/[^A-Z0-9]/g, ""));
      $[18] = t10;
    } else {
      t10 = $[18];
    }
    const t11 = !initialCode;
    let t12;
    if ($[19] !== busy || $[20] !== code || $[21] !== preview || $[22] !== short || $[23] !== submit) {
      t12 = () => {
        if (code.trim().length >= 6 && preview !== "missing" && !short && !busy) {
          submit();
        }
      };
      $[19] = busy;
      $[20] = code;
      $[21] = preview;
      $[22] = short;
      $[23] = submit;
      $[24] = t12;
    } else {
      t12 = $[24];
    }
    let t13;
    if ($[25] !== c.subtleForeground || $[26] !== code || $[27] !== t11 || $[28] !== t12 || $[29] !== t9) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TextInput.default, {
        style: t9,
        value: code,
        onChangeText: t10,
        placeholder: "AB3CD7",
        placeholderTextColor: c.subtleForeground,
        maxLength: 8,
        autoCapitalize: "characters",
        autoCorrect: false,
        autoFocus: t11,
        accessibilityLabel: "Invite code",
        returnKeyType: "go",
        onSubmitEditing: t12
      });
      $[25] = c.subtleForeground;
      $[26] = code;
      $[27] = t11;
      $[28] = t12;
      $[29] = t9;
      $[30] = t13;
    } else {
      t13 = $[30];
    }
    let t14;
    if ($[31] !== c.border || $[32] !== c.foreground || $[33] !== c.league || $[34] !== c.mutedForeground || $[35] !== c.negative || $[36] !== c.secondary || $[37] !== found || $[38] !== preview) {
      t14 = found ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.preview, {
          backgroundColor: c.secondary,
          borderColor: c.border
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "trophy-outline",
          size: 20,
          color: c.league
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: {
            flex: 1
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.pName, {
              color: c.foreground
            }],
            children: found.leagueName
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.pSub, {
              color: c.mutedForeground
            }],
            children: found.buyIn > 0 ? "Buy-in, paid into the prize pot" : "Free to join"
          })]
        }), found.buyIn > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
          value: found.buyIn,
          size: "sm"
        }) : null]
      }) : preview === "missing" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.pSub, {
          color: c.negative
        }],
        children: "No league uses that code."
      }) : null;
      $[31] = c.border;
      $[32] = c.foreground;
      $[33] = c.league;
      $[34] = c.mutedForeground;
      $[35] = c.negative;
      $[36] = c.secondary;
      $[37] = found;
      $[38] = preview;
      $[39] = t14;
    } else {
      t14 = $[39];
    }
    let t15;
    if ($[40] !== c.negative || $[41] !== found || $[42] !== short) {
      t15 = short && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.pSub, {
          color: c.negative
        }],
        children: ["You need ", found.buyIn.toLocaleString(), " credits to join."]
      });
      $[40] = c.negative;
      $[41] = found;
      $[42] = short;
      $[43] = t15;
    } else {
      t15 = $[43];
    }
    let t16;
    if ($[44] !== c.negative || $[45] !== error) {
      t16 = error ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        accessibilityRole: "alert",
        style: [styles.pSub, {
          color: c.negative
        }],
        children: error
      }) : null;
      $[44] = c.negative;
      $[45] = error;
      $[46] = t16;
    } else {
      t16 = $[46];
    }
    let t17;
    if ($[47] !== found) {
      t17 = found && found.buyIn > 0 ? `Pay ${found.buyIn.toLocaleString()} & join` : "Join league";
      $[47] = found;
      $[48] = t17;
    } else {
      t17 = $[48];
    }
    let t18;
    if ($[49] !== code || $[50] !== preview || $[51] !== short) {
      t18 = code.trim().length < 6 || preview === "missing" || short;
      $[49] = code;
      $[50] = preview;
      $[51] = short;
      $[52] = t18;
    } else {
      t18 = $[52];
    }
    let t19;
    if ($[53] !== busy || $[54] !== submit || $[55] !== t17 || $[56] !== t18) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        label: t17,
        size: "lg",
        onPress: submit,
        loading: busy,
        disabled: t18
      });
      $[53] = busy;
      $[54] = submit;
      $[55] = t17;
      $[56] = t18;
      $[57] = t19;
    } else {
      t19 = $[57];
    }
    let t20;
    if ($[58] !== onClose || $[59] !== t13 || $[60] !== t14 || $[61] !== t15 || $[62] !== t16 || $[63] !== t19 || $[64] !== t6 || $[65] !== t7 || $[66] !== visible) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(KeyboardSheet.default, {
        visible: visible,
        onClose: onClose,
        children: [t6, t7, t13, t14, t15, t16, t19]
      });
      $[58] = onClose;
      $[59] = t13;
      $[60] = t14;
      $[61] = t15;
      $[62] = t16;
      $[63] = t19;
      $[64] = t6;
      $[65] = t7;
      $[66] = visible;
      $[67] = t20;
    } else {
      t20 = $[67];
    }
    return t20;
  }
  const styles = StyleSheet.default.create({
    title: {
      fontSize: 20,
      fontFamily: "Inter_900Black"
    },
    sub: {
      fontSize: 13,
      fontFamily: "Inter_400Regular"
    },
    input: {
      borderWidth: 1,
      borderRadius: 14,
      paddingHorizontal: 16,
      paddingVertical: 14,
      fontSize: 24,
      letterSpacing: 6,
      fontFamily: "Inter_700Bold",
      textAlign: "center"
    },
    preview: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      padding: 12,
      borderRadius: 14,
      borderWidth: 1
    },
    pName: {
      fontSize: 15,
      fontFamily: "Inter_700Bold"
    },
    pSub: {
      fontSize: 13,
      fontFamily: "Inter_500Medium"
    }
  });
},912,[815,818,905,12,28,188,255,109,873,836,819,906,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.useLatestActivity = useLatestActivity;
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _firebaseFirestore = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  var _libFirebase = require(_dependencyMap[3]);
  var _libDemo = require(_dependencyMap[4]);
  /** The newest feed entry per league, for overview cards. */
  function useLatestActivity(leagueIds) {
    const $ = (0, _reactCompilerRuntime.c)(6);
    let t0;
    if ($[0] !== leagueIds) {
      t0 = leagueIds.join(",");
      $[0] = leagueIds;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    const key = t0;
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = _libDemo.DEMO ? Object.fromEntries(Object.entries(_libDemo.demoActivity).map(_temp)) : {};
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    const [map, setMap] = (0, _react.useState)(t1);
    let t2;
    let t3;
    if ($[3] !== key) {
      t2 = () => {
        const db = (0, _libFirebase.getDb)();
        if (!db || !key) {
          return;
        }
        const unsubs = key.split(",").map(id => (0, _firebaseFirestore.onSnapshot)((0, _firebaseFirestore.query)((0, _firebaseFirestore.collection)(db, "leagues", id, "activity"), (0, _firebaseFirestore.orderBy)("at", "desc"), (0, _firebaseFirestore.limit)(1)), s => setMap(p => ({
          ...p,
          [id]: s.docs[0] ? {
            ...s.docs[0].data(),
            id: s.docs[0].id
          } : undefined
        })), _temp2));
        return () => unsubs.forEach(_temp3);
      };
      t3 = [key];
      $[3] = key;
      $[4] = t2;
      $[5] = t3;
    } else {
      t2 = $[4];
      t3 = $[5];
    }
    (0, _react.useEffect)(t2, t3);
    return map;
  }
  function _temp3(u) {
    return u();
  }
  function _temp2() {}
  function _temp(t0) {
    const [k, v] = t0;
    return [k, v[0]];
  }
},913,[815,905,12,906,902]);