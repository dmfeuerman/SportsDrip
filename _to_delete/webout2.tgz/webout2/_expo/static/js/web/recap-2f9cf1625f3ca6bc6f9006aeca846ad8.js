__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return LeagueRecapScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _expoLinearGradient = require(_dependencyMap[2]);
  var _expoRouter = require(_dependencyMap[3]);
  var _react = require(_dependencyMap[4]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[5]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[6]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[7]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[8]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[9]);
  var _componentsUi = require(_dependencyMap[10]);
  var _contextLeagueContext = require(_dependencyMap[11]);
  var _hooksUseColors = require(_dependencyMap[12]);
  var _libShareCard = require(_dependencyMap[13]);
  var _reactJsxRuntime = require(_dependencyMap[14]);
  const CARD_META = {
    biggest_hit: {
      icon: "trophy",
      badge: "BIGGEST HIT",
      tone: "positive"
    },
    bad_beat: {
      icon: "heart-broken",
      badge: "BAD BEAT OF THE WEEK",
      tone: "negative"
    },
    climber: {
      icon: "trending-up",
      badge: "BIGGEST CLIMBER",
      tone: "positive"
    },
    faller: {
      icon: "trending-down",
      badge: "BIGGEST FALLER",
      tone: "negative"
    },
    best_tail: {
      icon: "account-multiple-plus",
      badge: "CROWD PLEASER",
      tone: "league"
    },
    coldest_streak: {
      icon: "snowflake",
      badge: "ICE COLD",
      tone: "accent"
    }
  };
  function LeagueRecapScreen() {
    const $ = (0, _reactCompilerRuntime.c)(39);
    const c = (0, _hooksUseColors.useColors)();
    const bottom = (0, _componentsUi.useBottomPad)(false);
    const params = (0, _expoRouter.useLocalSearchParams)();
    const {
      getLeague
    } = (0, _contextLeagueContext.useLeague)();
    let t0;
    if ($[0] !== getLeague || $[1] !== params.id) {
      t0 = getLeague(params.id);
      $[0] = getLeague;
      $[1] = params.id;
      $[2] = t0;
    } else {
      t0 = $[2];
    }
    const league = t0;
    const detail = (0, _contextLeagueContext.useLeagueDetail)(league);
    const [selectedWeek, setSelectedWeek] = (0, _react.useState)(params.week ?? null);
    if (!league) {
      let t1;
      if ($[3] !== c.background) {
        t1 = [styles.container, {
          backgroundColor: c.background
        }];
        $[3] = c.background;
        $[4] = t1;
      } else {
        t1 = $[4];
      }
      let t2;
      if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
          back: true,
          title: "League Report"
        });
        $[5] = t2;
      } else {
        t2 = $[5];
      }
      let t3;
      if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: {
            padding: 16
          },
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
            icon: "newspaper-variant-outline",
            title: "League Not Found",
            body: "You may have left this league or it's still loading.",
            action: "Back to Leagues",
            onAction: _temp
          })
        });
        $[6] = t3;
      } else {
        t3 = $[6];
      }
      let t4;
      if ($[7] !== t1) {
        t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: t1,
          children: [t2, t3]
        });
        $[7] = t1;
        $[8] = t4;
      } else {
        t4 = $[8];
      }
      return t4;
    }
    const reports = detail.reports;
    let t1;
    if ($[9] !== reports || $[10] !== selectedWeek) {
      t1 = (selectedWeek ? reports.find(r => r.week === selectedWeek) : reports[0]) ?? reports[0];
      $[9] = reports;
      $[10] = selectedWeek;
      $[11] = t1;
    } else {
      t1 = $[11];
    }
    const activeReport = t1;
    let t2;
    if ($[12] !== c.background) {
      t2 = [styles.container, {
        backgroundColor: c.background
      }];
      $[12] = c.background;
      $[13] = t2;
    } else {
      t2 = $[13];
    }
    const t3 = activeReport ? `${league.name} · Week ${activeReport.week}` : league.name;
    let t4;
    if ($[14] !== activeReport?.week || $[15] !== c.border || $[16] !== c.foreground || $[17] !== c.league || $[18] !== c.leagueSoft || $[19] !== c.mutedForeground || $[20] !== c.secondary || $[21] !== reports) {
      t4 = reports.length > 1 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ScrollView.default, {
        horizontal: true,
        showsHorizontalScrollIndicator: false,
        contentContainerStyle: {
          gap: 8
        },
        children: reports.map(r_0 => {
          const on = r_0.week === activeReport?.week;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
            accessibilityRole: "button",
            onPress: () => setSelectedWeek(r_0.week),
            style: [styles.weekChip, {
              backgroundColor: on ? c.leagueSoft : c.secondary,
              borderColor: on ? c.league : c.border
            }],
            children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.weekChipText, {
                color: on ? c.foreground : c.mutedForeground
              }],
              children: r_0.week
            })
          }, r_0.week);
        })
      }) : null;
      $[14] = activeReport?.week;
      $[15] = c.border;
      $[16] = c.foreground;
      $[17] = c.league;
      $[18] = c.leagueSoft;
      $[19] = c.mutedForeground;
      $[20] = c.secondary;
      $[21] = reports;
      $[22] = t4;
    } else {
      t4 = $[22];
    }
    let t5;
    if ($[23] !== t3 || $[24] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
        back: true,
        title: "Tuesday League Report",
        subtitle: t3,
        children: t4
      });
      $[23] = t3;
      $[24] = t4;
      $[25] = t5;
    } else {
      t5 = $[25];
    }
    const t6 = bottom + 24;
    let t7;
    if ($[26] !== t6) {
      t7 = [styles.body, {
        paddingBottom: t6
      }];
      $[26] = t6;
      $[27] = t7;
    } else {
      t7 = $[27];
    }
    let t8;
    if ($[28] !== activeReport || $[29] !== c || $[30] !== league.name) {
      t8 = !activeReport || activeReport.cards.length === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
        icon: "newspaper-variant-outline",
        title: "No Weekly Report Yet",
        body: "Every Tuesday morning, SportDrip compiles the biggest hits, worst bad beats, climbers, fallers, and streaks from your league."
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
          tone: "league",
          style: {
            gap: 6
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.introTitle, {
              color: c.foreground
            }],
            children: ["Week ", activeReport.week, " Wrapped"]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.introSub, {
              color: c.mutedForeground
            }],
            children: "Tap Share on any story card to drop it in the group chat."
          })]
        }), activeReport.cards.map((card, i) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(StoryCard, {
          card: card,
          leagueName: league.name,
          week: activeReport.week,
          c: c
        }, `${card.kind}_${i}`))]
      });
      $[28] = activeReport;
      $[29] = c;
      $[30] = league.name;
      $[31] = t8;
    } else {
      t8 = $[31];
    }
    let t9;
    if ($[32] !== t7 || $[33] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ScrollView.default, {
        contentContainerStyle: t7,
        showsVerticalScrollIndicator: false,
        children: t8
      });
      $[32] = t7;
      $[33] = t8;
      $[34] = t9;
    } else {
      t9 = $[34];
    }
    let t10;
    if ($[35] !== t2 || $[36] !== t5 || $[37] !== t9) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t2,
        children: [t5, t9]
      });
      $[35] = t2;
      $[36] = t5;
      $[37] = t9;
      $[38] = t10;
    } else {
      t10 = $[38];
    }
    return t10;
  }
  function _temp() {
    return _expoRouter.router.navigate("/(tabs)/leagues");
  }
  function StoryCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(94);
    const {
      card,
      leagueName,
      week,
      c
    } = t0;
    const cardRef = (0, _react.useRef)(null);
    let t1;
    if ($[0] !== card.kind) {
      t1 = CARD_META[card.kind] ?? {
        icon: "star",
        badge: "HIGHLIGHT",
        tone: "league"
      };
      $[0] = card.kind;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    const meta = t1;
    const tint = meta.tone === "positive" ? c.positive : meta.tone === "negative" ? c.negative : meta.tone === "accent" ? c.accent : c.league;
    let t2;
    if ($[2] !== card.value) {
      t2 = card.value >= 0 ? `+${card.value.toLocaleString()}` : card.value.toLocaleString();
      $[2] = card.value;
      $[3] = t2;
    } else {
      t2 = $[3];
    }
    const statLabel = t2;
    const t3 = c.card;
    let t4;
    if ($[4] !== c || $[5] !== tint) {
      t4 = c.alpha(tint, 0.55);
      $[4] = c;
      $[5] = tint;
      $[6] = t4;
    } else {
      t4 = $[6];
    }
    let t5;
    if ($[7] !== c.card || $[8] !== t4) {
      t5 = [styles.storyCard, {
        backgroundColor: t3,
        borderColor: t4
      }];
      $[7] = c.card;
      $[8] = t4;
      $[9] = t5;
    } else {
      t5 = $[9];
    }
    let t6;
    if ($[10] !== c || $[11] !== tint) {
      t6 = c.alpha(tint, 0.22);
      $[10] = c;
      $[11] = tint;
      $[12] = t6;
    } else {
      t6 = $[12];
    }
    let t7;
    if ($[13] !== c || $[14] !== tint) {
      t7 = c.alpha(tint, 0.04);
      $[13] = c;
      $[14] = tint;
      $[15] = t7;
    } else {
      t7 = $[15];
    }
    let t8;
    if ($[16] !== t6 || $[17] !== t7) {
      t8 = [t6, t7, "transparent"];
      $[16] = t6;
      $[17] = t7;
      $[18] = t8;
    } else {
      t8 = $[18];
    }
    const t9 = t8;
    let t10;
    let t11;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
      t10 = {
        x: 0,
        y: 0
      };
      t11 = {
        x: 1,
        y: 1
      };
      $[19] = t10;
      $[20] = t11;
    } else {
      t10 = $[19];
      t11 = $[20];
    }
    let t12;
    if ($[21] !== t9) {
      t12 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoLinearGradient.LinearGradient, {
        colors: t9,
        start: t10,
        end: t11,
        style: StyleSheet.default.absoluteFill,
        pointerEvents: "none"
      });
      $[21] = t9;
      $[22] = t12;
    } else {
      t12 = $[22];
    }
    let t13;
    if ($[23] !== meta.badge || $[24] !== meta.icon || $[25] !== meta.tone) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
        label: meta.badge,
        tone: meta.tone,
        icon: meta.icon
      });
      $[23] = meta.badge;
      $[24] = meta.icon;
      $[25] = meta.tone;
      $[26] = t13;
    } else {
      t13 = $[26];
    }
    let t14;
    if ($[27] !== c.subtleForeground) {
      t14 = [styles.storyLeague, {
        color: c.subtleForeground
      }];
      $[27] = c.subtleForeground;
      $[28] = t14;
    } else {
      t14 = $[28];
    }
    let t15;
    if ($[29] !== leagueName || $[30] !== t14 || $[31] !== week) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: t14,
        numberOfLines: 1,
        children: [leagueName, " \xB7 ", week]
      });
      $[29] = leagueName;
      $[30] = t14;
      $[31] = week;
      $[32] = t15;
    } else {
      t15 = $[32];
    }
    let t16;
    if ($[33] !== t13 || $[34] !== t15) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.storyTop,
        children: [t13, t15]
      });
      $[33] = t13;
      $[34] = t15;
      $[35] = t16;
    } else {
      t16 = $[35];
    }
    let t17;
    if ($[36] !== c || $[37] !== tint) {
      t17 = c.alpha(tint, 0.16);
      $[36] = c;
      $[37] = tint;
      $[38] = t17;
    } else {
      t17 = $[38];
    }
    let t18;
    if ($[39] !== c || $[40] !== tint) {
      t18 = c.alpha(tint, 0.45);
      $[39] = c;
      $[40] = tint;
      $[41] = t18;
    } else {
      t18 = $[41];
    }
    let t19;
    if ($[42] !== t17 || $[43] !== t18) {
      t19 = [styles.storyIconWrap, {
        backgroundColor: t17,
        borderColor: t18
      }];
      $[42] = t17;
      $[43] = t18;
      $[44] = t19;
    } else {
      t19 = $[44];
    }
    let t20;
    if ($[45] !== meta.icon || $[46] !== tint) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: meta.icon,
        size: 28,
        color: tint
      });
      $[45] = meta.icon;
      $[46] = tint;
      $[47] = t20;
    } else {
      t20 = $[47];
    }
    let t21;
    if ($[48] !== t19 || $[49] !== t20) {
      t21 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t19,
        children: t20
      });
      $[48] = t19;
      $[49] = t20;
      $[50] = t21;
    } else {
      t21 = $[50];
    }
    let t22;
    if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
      t22 = {
        flex: 1,
        gap: 4
      };
      $[51] = t22;
    } else {
      t22 = $[51];
    }
    let t23;
    if ($[52] !== c.foreground) {
      t23 = [styles.storyTitle, {
        color: c.foreground
      }];
      $[52] = c.foreground;
      $[53] = t23;
    } else {
      t23 = $[53];
    }
    const t24 = card.headline || card.title;
    let t25;
    if ($[54] !== t23 || $[55] !== t24) {
      t25 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t23,
        children: t24
      });
      $[54] = t23;
      $[55] = t24;
      $[56] = t25;
    } else {
      t25 = $[56];
    }
    let t26;
    if ($[57] !== c.mutedForeground) {
      t26 = [styles.storySubtitle, {
        color: c.mutedForeground
      }];
      $[57] = c.mutedForeground;
      $[58] = t26;
    } else {
      t26 = $[58];
    }
    let t27;
    if ($[59] !== card.detail || $[60] !== t26) {
      t27 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t26,
        children: card.detail
      });
      $[59] = card.detail;
      $[60] = t26;
      $[61] = t27;
    } else {
      t27 = $[61];
    }
    let t28;
    if ($[62] !== t25 || $[63] !== t27) {
      t28 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t22,
        children: [t25, t27]
      });
      $[62] = t25;
      $[63] = t27;
      $[64] = t28;
    } else {
      t28 = $[64];
    }
    let t29;
    if ($[65] !== t21 || $[66] !== t28) {
      t29 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.storyMain,
        children: [t21, t28]
      });
      $[65] = t21;
      $[66] = t28;
      $[67] = t29;
    } else {
      t29 = $[67];
    }
    let t30;
    if ($[68] !== c.border) {
      t30 = [styles.storyFooter, {
        borderTopColor: c.border
      }];
      $[68] = c.border;
      $[69] = t30;
    } else {
      t30 = $[69];
    }
    let t31;
    if ($[70] !== tint) {
      t31 = [styles.storyStat, {
        color: tint
      }];
      $[70] = tint;
      $[71] = t31;
    } else {
      t31 = $[71];
    }
    let t32;
    if ($[72] !== statLabel || $[73] !== t31) {
      t32 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t31,
        children: statLabel
      });
      $[72] = statLabel;
      $[73] = t31;
      $[74] = t32;
    } else {
      t32 = $[74];
    }
    let t33;
    if ($[75] !== card.detail || $[76] !== card.headline || $[77] !== card.kind || $[78] !== card.title || $[79] !== leagueName || $[80] !== meta.badge || $[81] !== statLabel || $[82] !== week) {
      t33 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        size: "sm",
        variant: "secondary",
        icon: "share-variant",
        label: "Share Card",
        onPress: () => {
          (0, _libShareCard.shareViewOrText)({
            viewRef: cardRef,
            kind: "league_report",
            id: `${week}_${card.kind}`,
            message: `${meta.badge}: ${card.headline || card.title} (${statLabel}) — ${card.detail} in ${leagueName} on SportDrip`
          });
        }
      });
      $[75] = card.detail;
      $[76] = card.headline;
      $[77] = card.kind;
      $[78] = card.title;
      $[79] = leagueName;
      $[80] = meta.badge;
      $[81] = statLabel;
      $[82] = week;
      $[83] = t33;
    } else {
      t33 = $[83];
    }
    let t34;
    if ($[84] !== t30 || $[85] !== t32 || $[86] !== t33) {
      t34 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t30,
        children: [t32, t33]
      });
      $[84] = t30;
      $[85] = t32;
      $[86] = t33;
      $[87] = t34;
    } else {
      t34 = $[87];
    }
    let t35;
    if ($[88] !== t12 || $[89] !== t16 || $[90] !== t29 || $[91] !== t34 || $[92] !== t5) {
      t35 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        ref: cardRef,
        collapsable: false,
        style: t5,
        children: [t12, t16, t29, t34]
      });
      $[88] = t12;
      $[89] = t16;
      $[90] = t29;
      $[91] = t34;
      $[92] = t5;
      $[93] = t35;
    } else {
      t35 = $[93];
    }
    return t35;
  }
  const styles = StyleSheet.default.create({
    container: {
      flex: 1
    },
    body: {
      padding: 16,
      gap: 14
    },
    weekChip: {
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderRadius: 999,
      borderWidth: 1
    },
    weekChipText: {
      fontSize: 12,
      fontFamily: "Inter_700Bold"
    },
    introTitle: {
      fontSize: 16,
      fontFamily: "Inter_800ExtraBold"
    },
    introSub: {
      fontSize: 12,
      fontFamily: "Inter_400Regular"
    },
    storyCard: {
      borderRadius: 20,
      borderWidth: 1.5,
      padding: 16,
      gap: 14,
      overflow: "hidden"
    },
    storyTop: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 8
    },
    storyLeague: {
      fontSize: 11,
      fontFamily: "Inter_600SemiBold"
    },
    storyMain: {
      flexDirection: "row",
      alignItems: "center",
      gap: 14
    },
    storyIconWrap: {
      width: 54,
      height: 54,
      borderRadius: 16,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center"
    },
    storyTitle: {
      fontSize: 18,
      fontFamily: "Inter_900Black",
      letterSpacing: -0.4
    },
    storySubtitle: {
      fontSize: 13,
      fontFamily: "Inter_500Medium",
      lineHeight: 18
    },
    storyFooter: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      paddingTop: 12,
      borderTopWidth: StyleSheet.default.hairlineWidth
    },
    storyStat: {
      fontSize: 18,
      fontFamily: "Inter_900Black",
      fontVariant: ["tabular-nums"]
    }
  });
},767,[815,818,871,817,12,133,28,188,109,827,836,858,819,1198,6]);