__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return TabLayout;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  require(_dependencyMap[1]);
  var _libSettings = require(_dependencyMap[2]);
  var _expoGlassEffect = require(_dependencyMap[3]);
  var _expoRouter = require(_dependencyMap[4]);
  var _expoRouterNativeTabs = require(_dependencyMap[5]);
  require(_dependencyMap[6]);
  var _expoVectorIcons = require(_dependencyMap[7]);
  var _react = require(_dependencyMap[8]);
  require(_dependencyMap[9]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[10]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsView = require(_dependencyMap[11]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _hooksUseColors = require(_dependencyMap[12]);
  var _libMotion = require(_dependencyMap[13]);
  var _contextChallengeContext = require(_dependencyMap[14]);
  var _contextChatContext = require(_dependencyMap[15]);
  var _contextNotificationContext = require(_dependencyMap[16]);
  var _reactJsxRuntime = require(_dependencyMap[17]);
  const LEAGUE_ACTION = new Set(["loan_request", "loan_countered", "stimulus_request", "margin_call", "league_invite"]);
  const FRIEND_ACTION = new Set(["friend_request"]);

  /** Unread obligations per tab: league chat + money asks on Leagues, requests + challenges on Friends. */
  function useTabBadges() {
    const $ = (0, _reactCompilerRuntime.c)(11);
    const {
      notifications
    } = (0, _contextNotificationContext.useNotifications)();
    const {
      unreadLeagueTokens
    } = (0, _contextChatContext.useChat)();
    const {
      incoming
    } = (0, _contextChallengeContext.useChallenges)();
    const segments = (0, _expoRouter.useSegments)();
    const current = segments[0] === "(tabs)" ? segments[1] ?? "index" : null;
    let friendIds;
    let leagueIds;
    if ($[0] !== incoming || $[1] !== notifications || $[2] !== unreadLeagueTokens) {
      leagueIds = unreadLeagueTokens.map(_temp);
      friendIds = incoming.map(_temp2);
      for (const n of notifications) {
        if (n.read) {
          continue;
        }
        if (LEAGUE_ACTION.has(n.type)) {
          leagueIds.push(`n:${n.id}`);
        } else {
          if (FRIEND_ACTION.has(n.type)) {
            friendIds.push(`n:${n.id}`);
          }
        }
      }
      $[0] = incoming;
      $[1] = notifications;
      $[2] = unreadLeagueTokens;
      $[3] = friendIds;
      $[4] = leagueIds;
    } else {
      friendIds = $[3];
      leagueIds = $[4];
    }
    let t0;
    if ($[5] !== friendIds || $[6] !== leagueIds) {
      t0 = {
        leagueIds,
        friendIds
      };
      $[5] = friendIds;
      $[6] = leagueIds;
      $[7] = t0;
    } else {
      t0 = $[7];
    }
    const {
      leagueIds: leagueIds_0,
      friendIds: friendIds_0
    } = t0;
    const leagues = (0, _libSettings.useUnseenCount)("tab.leagues", leagueIds_0, current === "leagues");
    const friends = (0, _libSettings.useUnseenCount)("tab.friends", friendIds_0, current === "friends");
    let t1;
    if ($[8] !== friends || $[9] !== leagues) {
      t1 = {
        leagues,
        friends
      };
      $[8] = friends;
      $[9] = leagues;
      $[10] = t1;
    } else {
      t1 = $[10];
    }
    return t1;
  }
  function _temp2(ch) {
    return `challenge:${ch.id}`;
  }
  function _temp(t) {
    return `chat:${t}`;
  }
  const badgeText = n => n && n > 0 ? n > 99 ? "99+" : String(n) : undefined;

  /**
   * Five destinations, in the order a session actually goes:
   *
   *   Home     where you stand: balance, open bets, results, league ranks, debt
   *   Games    the board, and the bet slip (credits or any league wallet)
   *   Leagues  promoted from a button inside Friends to a first-class tab —
   *            they're the competitive core, not a social afterthought
   *   Friends  people, requests, head-to-heads, league invites
   *   Locker   your character: outfit, appearance, and the shop
   *
   * My Bets, Prizes, Shop and Activity are pushed screens off these (with a real
   * back gesture) instead of tabs. Six tabs was already the ceiling iOS
   * tolerates, and Prizes and Shop are visited, not lived in.
   */

  const TABS = [{
    name: "index",
    title: "Home",
    sf: "house",
    md: "home-variant-outline"
  }, {
    name: "games",
    title: "Games",
    sf: "sportscourt",
    md: "scoreboard-outline"
  }, {
    name: "leagues",
    title: "Leagues",
    sf: "trophy",
    md: "trophy-outline"
  }, {
    name: "friends",
    title: "Friends",
    sf: "person.2",
    md: "account-group-outline"
  }, {
    name: "avatar",
    title: "Locker",
    sf: "tshirt",
    md: "tshirt-crew-outline"
  }];
  function NativeTabLayout() {
    const $ = (0, _reactCompilerRuntime.c)(4);
    const badges = useTabBadges();
    let t0;
    if ($[0] !== badges) {
      t0 = TABS.map(t => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_expoRouterNativeTabs.NativeTabs.Trigger, {
        name: t.name,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoRouterNativeTabs.NativeTabs.Trigger.Icon, {
          sf: {
            default: t.sf,
            selected: `${t.sf}.fill`
          }
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoRouterNativeTabs.NativeTabs.Trigger.Label, {
          children: t.title
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoRouterNativeTabs.NativeTabs.Trigger.Badge, {
          hidden: !badgeText(badges[t.name]),
          children: badgeText(badges[t.name])
        })]
      }, t.name));
      $[0] = badges;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    let t1;
    if ($[2] !== t0) {
      t1 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoRouterNativeTabs.NativeTabs, {
        children: t0
      });
      $[2] = t0;
      $[3] = t1;
    } else {
      t1 = $[3];
    }
    return t1;
  }
  function ClassicTabLayout() {
    const $ = (0, _reactCompilerRuntime.c)(21);
    const colors = (0, _hooksUseColors.useColors)();
    const isIOS = false;
    const isWeb = true;
    const badges = useTabBadges();
    let t0;
    if ($[0] !== colors.background) {
      t0 = {
        backgroundColor: colors.background
      };
      $[0] = colors.background;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    const t1 = colors.background;
    let t2;
    if ($[2] !== colors.border || $[3] !== t1) {
      t2 = {
        position: "absolute",
        backgroundColor: t1,
        borderTopWidth: StyleSheet.default.hairlineWidth,
        borderTopColor: colors.border,
        elevation: 0,
        height: 72,
        paddingTop: 6
      };
      $[2] = colors.border;
      $[3] = t1;
      $[4] = t2;
    } else {
      t2 = $[4];
    }
    let t3;
    if ($[5] !== colors.background || $[6] !== colors.isDark) {
      t3 = () => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [StyleSheet.default.absoluteFill, {
          backgroundColor: colors.background
        }]
      });
      $[5] = colors.background;
      $[6] = colors.isDark;
      $[7] = t3;
    } else {
      t3 = $[7];
    }
    let t4;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
      t4 = {
        fontFamily: "Inter_600SemiBold",
        fontSize: 11,
        marginBottom: 8
      };
      $[8] = t4;
    } else {
      t4 = $[8];
    }
    let t5;
    if ($[9] !== colors.mutedForeground || $[10] !== colors.primary || $[11] !== t0 || $[12] !== t2 || $[13] !== t3) {
      t5 = {
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.mutedForeground,
        headerShown: false,
        sceneStyle: t0,
        tabBarStyle: t2,
        tabBarBackground: t3,
        tabBarLabelStyle: t4
      };
      $[9] = colors.mutedForeground;
      $[10] = colors.primary;
      $[11] = t0;
      $[12] = t2;
      $[13] = t3;
      $[14] = t5;
    } else {
      t5 = $[14];
    }
    let t6;
    if ($[15] !== badges || $[16] !== colors.accent) {
      t6 = TABS.map(t => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoRouter.Tabs.Screen, {
        name: t.name,
        options: {
          title: t.title,
          tabBarAccessibilityLabel: badges[t.name] ? `${t.title}, ${badges[t.name]} new` : t.title,
          tabBarBadge: badgeText(badges[t.name]),
          tabBarBadgeStyle: {
            backgroundColor: colors.accent,
            fontSize: 11,
            fontFamily: "Inter_700Bold"
          },
          tabBarIcon: t7 => {
            const {
              color
            } = t7;
            return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: t.md,
              size: 22,
              color: color
            });
          }
        }
      }, t.name));
      $[15] = badges;
      $[16] = colors.accent;
      $[17] = t6;
    } else {
      t6 = $[17];
    }
    let t7;
    if ($[18] !== t5 || $[19] !== t6) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoRouter.Tabs, {
        backBehavior: "history",
        screenOptions: t5,
        children: t6
      });
      $[18] = t5;
      $[19] = t6;
      $[20] = t7;
    } else {
      t7 = $[20];
    }
    return t7;
  }
  function TabLayout() {
    const $ = (0, _reactCompilerRuntime.c)(5);
    const tab = (0, _expoRouter.useSegments)()[1] ?? "index";
    const last = (0, _react.useRef)(tab);
    let t0;
    let t1;
    if ($[0] !== tab) {
      t0 = () => {
        if (last.current !== tab) {
          _libMotion.haptic.tick();
        }
        last.current = tab;
      };
      t1 = [tab];
      $[0] = tab;
      $[1] = t0;
      $[2] = t1;
    } else {
      t0 = $[1];
      t1 = $[2];
    }
    (0, _react.useEffect)(t0, t1);
    if ((0, _expoGlassEffect.isLiquidGlassAvailable)()) {
      let t2;
      if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(NativeTabLayout, {});
        $[3] = t2;
      } else {
        t2 = $[3];
      }
      return t2;
    }
    let t2;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
      t2 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ClassicTabLayout, {});
      $[4] = t2;
    } else {
      t2 = $[4];
    }
    return t2;
  }
},749,[815,779,816,671,817,783,806,818,12,104,28,109,819,820,821,822,823,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "BlurView", {
    enumerable: true,
    get: function () {
      return _BlurView2.default;
    }
  });
  Object.defineProperty(exports, "BlurTargetView", {
    enumerable: true,
    get: function () {
      return _BlurTargetView2.default;
    }
  });
  var _BlurView = require(_dependencyMap[0]);
  var _BlurView2 = _interopDefault(_BlurView);
  var _BlurTargetView = require(_dependencyMap[1]);
  var _BlurTargetView2 = _interopDefault(_BlurTargetView);
},779,[780,782]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  // Copyright © 2024 650 Industries.
  'use client';
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _reactJsxRuntime = require(_dependencyMap[0]);
  var _react = require(_dependencyMap[1]);
  var _reactNativeWebDistExportsView = require(_dependencyMap[2]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _getBackgroundColor = require(_dependencyMap[3]);
  var getBackgroundColor = _interopDefault(_getBackgroundColor);
  const BlurView = /*#__PURE__*/(0, _react.forwardRef)(({
    tint = 'default',
    intensity = 50,
    style,
    ...props
  }, ref) => {
    const blurViewRef = (0, _react.useRef)(null);
    const blurStyle = getBlurStyle({
      tint,
      intensity
    });
    (0, _react.useImperativeHandle)(ref, () => ({
      setNativeProps: nativeProps => {
        if (!blurViewRef.current?.style) {
          return;
        }
        // @ts-expect-error: `style.intensity` is not defined in the types
        const nextIntensity = nativeProps.style?.intensity ?? intensity;
        const blurStyle = getBlurStyle({
          intensity: nextIntensity,
          tint: tint ?? 'default'
        });
        if (nativeProps.style) {
          for (const key in nativeProps.style) {
            if (key !== 'intensity') {
              // @ts-expect-error: nativeProps.style[key] may not always be a string
              blurViewRef.current.style[key] = nativeProps.style[key];
            }
          }
        }
        if (blurStyle.backgroundColor) {
          blurViewRef.current.style.backgroundColor = blurStyle.backgroundColor;
        }
        if (blurStyle.backdropFilter) {
          blurViewRef.current.style.backdropFilter = blurStyle.backdropFilter;
        }
        // @ts-expect-error: Webkit-specific legacy property (let's not type this, since it's deprecated)
        blurViewRef.current.style['webkitBackdropFilter'] = blurStyle.WebkitBackdropFilter;
      }
    }), [intensity, tint]);
    return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
      ...props,
      style: [style, blurStyle],
      /** @ts-expect-error: mismatch in ref type to support manually setting style props. */ref: blurViewRef
    });
  });
  function getBlurStyle({
    intensity,
    tint
  }) {
    const blur = `saturate(180%) blur(${Math.min(intensity, 100) * 0.2}px)`;
    return {
      backgroundColor: (0, getBackgroundColor.default)(Math.min(intensity, 100), tint),
      backdropFilter: blur,
      WebkitBackdropFilter: blur
    };
  }
  var _default = BlurView;
},780,[6,12,109,781]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return getBackgroundColor;
    }
  });
  function getBackgroundColor(intensity, tint) {
    const opacity = intensity / 100;
    switch (tint) {
      // From Apple iOS 14 Sketch Kit - https://developer.apple.com/design/resources/
      case 'dark':
      case 'systemMaterialDark':
        return `rgba(25,25,25,${opacity * 0.78})`;
      case 'light':
      case 'extraLight':
      case 'systemMaterialLight':
      case 'systemUltraThinMaterialLight':
      case 'systemThickMaterialLight':
        return `rgba(249,249,249,${opacity * 0.78})`;
      case 'default':
      case 'prominent':
      case 'systemMaterial':
        return `rgba(255,255,255,${opacity * 0.3})`;
      case 'regular':
        return `rgba(179,179,179,${opacity * 0.82})`;
      case 'systemThinMaterial':
        return `rgba(199,199,199,${opacity * 0.97})`;
      case 'systemChromeMaterial':
        return `rgba(255,255,255,${opacity * 0.75})`;
      case 'systemChromeMaterialLight':
        return `rgba(255,255,255,${opacity * 0.97})`;
      case 'systemUltraThinMaterial':
        return `rgba(191,191,191,${opacity * 0.44})`;
      case 'systemThickMaterial':
        return `rgba(191,191,191,${opacity * 0.44})`;
      case 'systemThickMaterialDark':
        return `rgba(37,37,37,${opacity * 0.9})`;
      case 'systemThinMaterialDark':
        return `rgba(37,37,37,${opacity * 0.7})`;
      case 'systemUltraThinMaterialDark':
        return `rgba(37,37,37,${opacity * 0.55})`;
      case 'systemChromeMaterialDark':
        return `rgba(0,0,0,${opacity * 0.75})`;
      case 'systemThinMaterialLight':
        return `rgba(199,199,199,${opacity * 0.78})`;
    }
  }
},781,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return BlurTargetView;
    }
  });
  var _reactJsxRuntime = require(_dependencyMap[0]);
  var _reactNativeWebDistExportsView = require(_dependencyMap[1]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  function BlurTargetView(props) {
    return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
      ...props
    });
  }
},782,[6,109]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  0;
  function _export(target, all) {
    for (var name in all) Object.defineProperty(target, name, {
      enumerable: true,
      get: Object.getOwnPropertyDescriptor(all, name).get
    });
  }
  _export(exports, {
    get NativeTabTrigger() {
      return _NativeTabTrigger.NativeTabTrigger;
    },
    get NativeTabs() {
      return _NativeTabs.NativeTabs;
    },
    get createNativeTabsProps() {
      return _NativeBottomTabsNavigator.createNativeTabsProps;
    }
  });
  const _NativeTabTrigger = require(_dependencyMap[0]);
  const _NativeTabs = require(_dependencyMap[1]);
  const _NativeBottomTabsNavigator = require(_dependencyMap[2]);
},783,[687,784,785]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  // We need this file to re-export the navigator
  // Otherwise rsc would fail
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  Object.defineProperty(exports, "NativeTabs", {
    enumerable: true,
    get: function () {
      return NativeTabs;
    }
  });
  function _jsxruntime() {
    const data = require(_dependencyMap[0]);
    _jsxruntime = function () {
      return data;
    };
    return data;
  }
  const _NativeBottomTabsNavigator = require(_dependencyMap[1]);
  const _NativeTabTrigger = require(_dependencyMap[2]);
  const _elements = require(_dependencyMap[3]);
  const _hooks = require(_dependencyMap[4]);
  const BottomAccessory = Object.assign(_elements.NativeTabsBottomAccessory, {
    usePlacement: _hooks.usePlacement
  });
  const NativeTabs = Object.assign(props => {
    return /*#__PURE__*/(0, _jsxruntime().jsx)(_NativeBottomTabsNavigator.NativeTabsNavigatorWrapper, {
      ...props
    });
  }, {
    Trigger: _NativeTabTrigger.NativeTabTrigger,
    BottomAccessory
  });
},784,[6,785,687,688,805]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use client';
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  0;
  function _export(target, all) {
    for (var name in all) Object.defineProperty(target, name, {
      enumerable: true,
      get: Object.getOwnPropertyDescriptor(all, name).get
    });
  }
  _export(exports, {
    get NativeTabsContext() {
      return NativeTabsContext;
    },
    get NativeTabsNavigatorWrapper() {
      return NativeTabsNavigatorWrapper;
    },
    get createNativeTabsProps() {
      return createNativeTabsProps;
    }
  });
  function _jsxruntime() {
    const data = require(_dependencyMap[0]);
    _jsxruntime = function () {
      return data;
    };
    return data;
  }
  function _react() {
    const data = /*#__PURE__*/_interop_require_wildcard(require(_dependencyMap[1]));
    _react = function () {
      return data;
    };
    return data;
  }
  const _createBaseTabProps = require(_dependencyMap[2]);
  const _native = require(_dependencyMap[3]);
  const _standardnavigation = require(_dependencyMap[4]);
  const _appendMissingPlaceholderTabRoutes = require(_dependencyMap[5]);
  const _usePreloadPlaceholderRoutes = require(_dependencyMap[6]);
  const _useVisibleTabsWithRedirect = require(_dependencyMap[7]);
  const _children = require(_dependencyMap[8]);
  const _NativeBottomTabsRouter = require(_dependencyMap[9]);
  const _NativeTabTrigger = require(_dependencyMap[10]);
  const _NativeTabsView = require(_dependencyMap[11]);
  const _utils = require(_dependencyMap[12]);
  function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function (nodeInterop) {
      return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
  }
  function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
      return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
      return {
        default: obj
      };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
      return cache.get(obj);
    }
    var newObj = {
      __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var key in obj) {
      if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
        var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
        if (desc && (desc.get || desc.set)) {
          Object.defineProperty(newObj, key, desc);
        } else {
          newObj[key] = obj[key];
        }
      }
    }
    newObj.default = obj;
    if (cache) {
      cache.set(obj, newObj);
    }
    return newObj;
  }
  // In Jetpack Compose, the default back behavior is to go back to the initial route.
  const defaultBackBehavior = 'initialRoute';
  const NativeTabsContext = /*#__PURE__*/_react().default.createContext(false);
  function createNativeTabsProps(args) {
    const {
      dispatchSync
    } = args;
    return {
      ...(0, _createBaseTabProps.createBaseTabProps)(args),
      navigateSync: name => dispatchSync(_native.CommonActions.navigate(name))
    };
  }
  function NativeTabsContent({
    state,
    routeNames,
    descriptors,
    actions: _actions,
    emitter,
    preload,
    navigateSync,
    isPreloaded: _isPreloaded,
    isRemovalPrevented: _isRemovalPrevented,
    tabConfigurationKey,
    // These per-tab style props are folded into `screenOptions` by `NativeTabsNavigatorWrapper` and
    // read back per-tab from `descriptors`. Pull them out of `rest` so they aren't forwarded to
    // `NativeTabsView` as top-level props.
    labelStyle,
    iconColor,
    backgroundColor,
    badgeBackgroundColor,
    blurEffect,
    indicatorColor,
    badgeTextColor,
    rippleColor,
    disableIndicator,
    labelVisibilityMode,
    ...rest
  }) {
    if ((0, _react().use)(NativeTabsContext)) {
      throw new Error('Nesting Native Tabs inside each other is not supported natively. Use JS tabs for nesting instead.');
    }
    const {
      routes
    } = state;
    const {
      visibleRoutes,
      focusedIndex,
      focusedFallbackRoute
    } = (0, _useVisibleTabsWithRedirect.useVisibleTabsWithRedirect)({
      routes,
      routeNames,
      focusedRouteKey: routes[state.index]?.key,
      descriptors
    });
    const visibleTabs = (0, _react().useMemo)(() => visibleRoutes.map(route => ({
      options: descriptors[route.key].options,
      name: route.name,
      routeKey: route.key,
      contentRenderer: () => descriptors[route.key].render()
    })), [descriptors, visibleRoutes]);
    (0, _usePreloadPlaceholderRoutes.usePreloadPlaceholderRoutes)({
      routes: visibleRoutes,
      descriptors,
      preload,
      lazyByDefault: false
    });
    const provenanceRef = (0, _react().useRef)(0);
    const onTabChange = (0, _react().useCallback)(({
      selectedKey,
      provenance,
      isNativeAction,
      isPrevented = false
    }) => {
      if (isPrevented) {
        // The native side blocked selecting a disabled tab. Notify listeners, but
        // don't advance navigation or acknowledge a (non-existent) state transition,
        // so the provenance counter is left untouched.
        emitter.emit({
          type: 'tabPress',
          target: routes.find(route => route.name === selectedKey)?.key ?? selectedKey,
          data: {
            __internalTabsType: 'native',
            isPrevented: true
          }
        });
        return;
      }
      // We should always send the last provenance we got from native side
      provenanceRef.current = provenance;
      if (isNativeAction) {
        const selectedRoute = routes.find(route => route.name === selectedKey);
        if (!selectedRoute) {
          return;
        }
        emitter.emit({
          type: 'tabPress',
          target: selectedRoute.key,
          data: {
            __internalTabsType: 'native',
            isPrevented: false
          }
        });
        navigateSync(selectedRoute.name);
      }
    }, [routes, navigateSync, emitter]);
    // Compile-time guard: everything spread onto `<NativeTabsView>` must be a prop it declares. The
    // `Record<…, never>` turns any prop the view doesn't accept into a type error here instead of
    // letting it leak silently through the spread.
    const nativeTabsViewProps = rest;
    if (focusedFallbackRoute) {
      return descriptors[focusedFallbackRoute.key]?.render() ?? null;
    }
    if (visibleTabs.length === 0 || focusedIndex < 0) {
      return null;
    }
    return /*#__PURE__*/(0, _jsxruntime().jsx)(NativeTabsContext, {
      value: true,
      children: /*#__PURE__*/(0, _react().createElement)(_NativeTabsView.NativeTabsView, {
        ...nativeTabsViewProps,
        key: tabConfigurationKey,
        focusedIndex: focusedIndex,
        // Provenance should only be sent with updates, and updates
        // on JS side are only triggered by rerender, so passing ref
        // here is ok.
        provenance: provenanceRef.current,
        tabs: visibleTabs,
        onTabChange: onTabChange
      })
    });
  }
  const NativeTabsNavigatorWithContext = (0, _standardnavigation.createStandardRouterNavigator)(NativeTabsContent, _NativeBottomTabsRouter.NativeBottomTabsRouter, {
    activityDefaultThreshold: 1,
    processDescriptors: _appendMissingPlaceholderTabRoutes.appendMissingPlaceholderTabDescriptors,
    processState: _appendMissingPlaceholderTabRoutes.appendMissingPlaceholderTabRoutes,
    createProps: createNativeTabsProps
  });
  function NativeTabsNavigatorWrapper(props) {
    const triggerChildren = (0, _react().useMemo)(() => (0, _children.getAllChildrenOfType)(props.children, _NativeTabTrigger.NativeTabTrigger).filter(child => !child.props.hidden), [props.children]);
    const nonTriggerChildren = (0, _react().useMemo)(() => (0, _children.getAllChildrenNotOfType)(props.children, _NativeTabTrigger.NativeTabTrigger), [props.children]);
    const tabConfigurationKey = triggerChildren.map(child => child.props.name).join(';');
    const {
      backBehavior = defaultBackBehavior,
      labelStyle,
      iconColor,
      blurEffect,
      backgroundColor,
      badgeBackgroundColor,
      indicatorColor,
      badgeTextColor,
      shadowColor,
      rippleColor,
      disableIndicator,
      labelVisibilityMode,
      tintColor,
      disableTransparentOnScrollEdge
    } = props;
    const screenOptions = (0, _react().useMemo)(() => {
      const processedLabelStyle = (0, _utils.convertLabelStylePropToObject)(labelStyle);
      const processedIconColor = (0, _utils.convertIconColorPropToObject)(iconColor);
      const selectedLabelStyle = processedLabelStyle.selected ? {
        ...processedLabelStyle.selected,
        color: processedLabelStyle.selected.color ?? tintColor
      } : tintColor ? {
        color: tintColor
      } : undefined;
      return {
        disableTransparentOnScrollEdge,
        labelStyle: processedLabelStyle.default,
        selectedLabelStyle,
        iconColor: processedIconColor.default,
        selectedIconColor: processedIconColor.selected ?? tintColor,
        blurEffect,
        backgroundColor,
        badgeBackgroundColor,
        indicatorColor,
        badgeTextColor,
        shadowColor,
        rippleColor,
        disableIndicator,
        labelVisibilityMode,
        tintColor
      };
    }, [labelStyle, iconColor, blurEffect, backgroundColor, badgeBackgroundColor, indicatorColor, badgeTextColor, shadowColor, rippleColor, disableIndicator, labelVisibilityMode, tintColor, disableTransparentOnScrollEdge]);
    return /*#__PURE__*/(0, _jsxruntime().jsx)(_standardnavigation.IsWithinNativeNavigator, {
      value: true,
      children: /*#__PURE__*/(0, _jsxruntime().jsx)(NativeTabsNavigatorWithContext, {
        ...props,
        children: triggerChildren,
        nonTriggerChildren: nonTriggerChildren,
        tabConfigurationKey: tabConfigurationKey,
        screenOptions: screenOptions,
        // Passed to TabRouter
        backBehavior: backBehavior
      })
    });
  }
},785,[6,12,824,408,685,825,609,610,501,786,687,787,803]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  Object.defineProperty(exports, "NativeBottomTabsRouter", {
    enumerable: true,
    get: function () {
      return NativeBottomTabsRouter;
    }
  });
  const _navigationParams = require(_dependencyMap[0]);
  const _native = require(_dependencyMap[1]);
  const _utils = require(_dependencyMap[2]);
  const zoomParamNames = [_navigationParams.INTERNAL_EXPO_ROUTER_ZOOM_TRANSITION_SCREEN_ID_PARAM_NAME, _navigationParams.INTERNAL_EXPO_ROUTER_ZOOM_TRANSITION_SOURCE_ID_PARAM_NAME];
  // TODO(@ubax): Simplify this logic, so it is clearer and easier to understand
  // At the moment this is needed to remove zoom params from current level and all nested levels
  // so that there is no zoom transition in tabs. Check if there are any better ways to address this
  // problem
  function removeZoomParamsFromState(state) {
    let changed = false;
    const routes = state.routes.map(route => {
      const hasZoomParams = route.params && zoomParamNames.some(paramName => paramName in route.params);
      const params = hasZoomParams ? (0, _navigationParams.removeParams)(route.params, zoomParamNames) : route.params;
      const childState = route.state ? removeZoomParamsFromState(route.state) : undefined;
      if (!hasZoomParams && childState === route.state) {
        return route;
      }
      changed = true;
      return {
        ...route,
        ...(hasZoomParams ? {
          params
        } : undefined),
        ...(childState ? {
          state: childState
        } : undefined)
      };
    });
    // The mapped routes preserve the input state's full or partial route shape.
    return changed ? {
      ...state,
      routes
    } : state;
  }
  function appendNoAnimationParamToFocusedRoutes(state) {
    const focusedIndex = state.index ?? state.routes.length - 1;
    const focusedRoute = state.routes[focusedIndex];
    if (!focusedRoute) {
      return state;
    }
    const childState = focusedRoute.state ? appendNoAnimationParamToFocusedRoutes(focusedRoute.state) : undefined;
    const routes = state.routes.map((route, index) => index === focusedIndex ? {
      ...route,
      params: (0, _navigationParams.appendInternalExpoRouterParams)(route.params, {
        [_navigationParams.INTERNAL_EXPO_ROUTER_NO_ANIMATION_PARAM_NAME]: true
      }),
      ...(childState ? {
        state: childState
      } : undefined)
    } : route);
    // The mapped routes preserve the input state's full or partial route shape.
    return {
      ...state,
      routes
    };
  }
  const NativeBottomTabsRouter = (0, _native.extendRouterActions)(_native.TabRouter, (state, action, {
    baseRouter
  }) => {
    switch (action.type) {
      case 'PUSH':
      case 'NAVIGATE':
        {
          const actionResult = baseRouter.getStateForAction(state, action);
          if (!(0, _utils.isActionHandled)(actionResult)) {
            return actionResult;
          }
          const newStateFromNavigation = actionResult.state;
          const focusedRouteKey = state.routes[state.index]?.key;
          const nextFocusedRouteKey = newStateFromNavigation.routes[newStateFromNavigation.index]?.key;
          const didTabChange = focusedRouteKey !== undefined && nextFocusedRouteKey !== undefined && focusedRouteKey !== nextFocusedRouteKey;
          const index = newStateFromNavigation.routes.findIndex(route => route.name === action.payload.name);
          if (index === -1) {
            return actionResult;
          }
          const newState = {
            ...newStateFromNavigation,
            routes: newStateFromNavigation.routes.map(route => {
              if (route.name !== action.payload.name) {
                return route;
              }
              const expoParams = (0, _navigationParams.getInternalExpoRouterParams)(action.payload.params);
              // Zoom transition needs to be disabled for navigation inside tabs
              // Otherwise user can end up in a situation where a view is missing on one tab
              // because it was used to perform zoom transition on another tab
              const params = (0, _navigationParams.removeParams)((0, _navigationParams.appendInternalExpoRouterParams)(route.params, expoParams), zoomParamNames);
              let childState = route.state ? removeZoomParamsFromState(route.state) : undefined;
              if (childState && didTabChange && action.payload.state?.__internal__routerActionState === true) {
                childState = appendNoAnimationParamToFocusedRoutes(childState);
              }
              return {
                ...route,
                ...(childState ? {
                  state: childState
                } : undefined),
                params
              };
            })
          };
          return {
            ...actionResult,
            state: newState
          };
        }
    }
    return _native.RouterActionHandling.Delegate;
  });
},786,[374,408,348]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  Object.defineProperty(exports, "NativeTabsView", {
    enumerable: true,
    get: function () {
      return NativeTabsView;
    }
  });
  function _jsxruntime() {
    const data = require(_dependencyMap[0]);
    _jsxruntime = function () {
      return data;
    };
    return data;
  }
  function _reacttabs() {
    const data = require(_dependencyMap[1]);
    _reacttabs = function () {
      return data;
    };
    return data;
  }
  function _react() {
    const data = require(_dependencyMap[2]);
    _react = function () {
      return data;
    };
    return data;
  }
  const _nativetabsmodulecss = /*#__PURE__*/_interop_require_default(require(_dependencyMap[3]));
  function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }
  function NativeTabsView(props) {
    const {
      tabs,
      focusedIndex
    } = props;
    const currentTab = tabs[focusedIndex];
    const defaultTab = (0, _react().useMemo)(() => currentTab,
    // We don't specify currentTab here, as we don't want to change the default tab when focusedIndex changes
    []);
    const value = currentTab.name;
    const items = tabs.map(tab => /*#__PURE__*/(0, _jsxruntime().jsx)(TabItem, {
      name: tab.name,
      title: tab.options.title ?? tab.name,
      badgeValue: tab.options.badgeValue
    }, tab.name));
    const children = tabs.map(tab => {
      return /*#__PURE__*/(0, _jsxruntime().jsx)(_reacttabs().TabsContent, {
        value: tab.name,
        className: _nativetabsmodulecss.default.tabContent,
        forceMount: true,
        children: tab.contentRenderer()
      }, tab.name);
    });
    return /*#__PURE__*/(0, _jsxruntime().jsxs)(_reacttabs().Tabs, {
      className: _nativetabsmodulecss.default.nativeTabsContainer,
      defaultValue: defaultTab.name,
      value: value,
      onValueChange: value => {
        props.onTabChange({
          selectedKey: value,
          provenance: 0,
          isNativeAction: true
        });
      },
      style: convertNativeTabsPropsToStyleVars(props, currentTab.options),
      children: [/*#__PURE__*/(0, _jsxruntime().jsx)(_reacttabs().TabsList, {
        "aria-label": "Main",
        className: _nativetabsmodulecss.default.navigationMenuRoot,
        children: items
      }), children]
    });
  }
  function TabItem(props) {
    const {
      title,
      badgeValue,
      name
    } = props;
    const isBadgeEmpty = badgeValue === ' ';
    return /*#__PURE__*/(0, _jsxruntime().jsxs)(_reacttabs().TabsTrigger, {
      value: name,
      className: _nativetabsmodulecss.default.navigationMenuTrigger,
      children: [/*#__PURE__*/(0, _jsxruntime().jsx)("span", {
        className: _nativetabsmodulecss.default.tabText,
        children: title
      }), badgeValue && /*#__PURE__*/(0, _jsxruntime().jsx)("div", {
        className: `${_nativetabsmodulecss.default.tabBadge} ${isBadgeEmpty ? _nativetabsmodulecss.default.emptyTabBadge : ''}`,
        children: badgeValue
      })]
    });
  }
  function convertNativeTabsPropsToStyleVars(props, currentTabOptions) {
    const vars = {};
    if (!props) {
      return vars;
    }
    const optionsLabelStyle = currentTabOptions?.labelStyle;
    if (optionsLabelStyle?.fontFamily) {
      vars['--expo-router-tabs-font-family'] = String(optionsLabelStyle.fontFamily);
    }
    if (optionsLabelStyle?.fontSize) {
      vars['--expo-router-tabs-font-size'] = String(optionsLabelStyle.fontSize);
    }
    if (optionsLabelStyle?.fontWeight) {
      vars['--expo-router-tabs-font-weight'] = String(optionsLabelStyle.fontWeight);
    }
    if (optionsLabelStyle?.fontStyle) {
      vars['--expo-router-tabs-font-style'] = String(optionsLabelStyle.fontStyle);
    }
    if (optionsLabelStyle?.color) {
      vars['--expo-router-tabs-text-color'] = String(optionsLabelStyle.color);
    }
    if (currentTabOptions?.selectedLabelStyle?.color) {
      vars['--expo-router-tabs-active-text-color'] = String(currentTabOptions?.selectedLabelStyle?.color);
    } else if (props.tintColor) {
      vars['--expo-router-tabs-active-text-color'] = String(props.tintColor);
    }
    if (currentTabOptions?.selectedLabelStyle?.fontSize) {
      vars['--expo-router-tabs-active-font-size'] = String(currentTabOptions?.selectedLabelStyle?.fontSize);
    }
    if (currentTabOptions?.indicatorColor) {
      vars['--expo-router-tabs-active-background-color'] = String(currentTabOptions.indicatorColor);
    }
    if (currentTabOptions?.backgroundColor) {
      vars['--expo-router-tabs-background-color'] = String(currentTabOptions.backgroundColor);
    }
    if (currentTabOptions?.badgeBackgroundColor) {
      vars['--expo-router-tabs-badge-background-color'] = String(currentTabOptions.badgeBackgroundColor);
    }
    if (currentTabOptions?.badgeTextColor) {
      vars['--expo-router-tabs-badge-text-color'] = String(currentTabOptions.badgeTextColor);
    }
    return vars;
  }
},787,[6,788,12,802]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
  "use client";

  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
    value: mod,
    enumerable: true
  }) : target, mod));
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // src/index.ts
  var index_exports = {};
  __export(index_exports, {
    Content: () => Content,
    List: () => List,
    Root: () => Root2,
    Tabs: () => Tabs,
    TabsContent: () => TabsContent,
    TabsList: () => TabsList,
    TabsTrigger: () => TabsTrigger,
    Trigger: () => Trigger,
    createTabsScope: () => createTabsScope
  });
  module.exports = __toCommonJS(index_exports);

  // src/tabs.tsx
  var React = __toESM(require(_dependencyMap[0]));
  var import_primitive = require(_dependencyMap[1]);
  var import_react_context = require(_dependencyMap[2]);
  var import_react_roving_focus = require(_dependencyMap[3]);
  var import_react_presence = require(_dependencyMap[4]);
  var import_react_primitive = require(_dependencyMap[5]);
  var RovingFocusGroup = __toESM(require(_dependencyMap[3]));
  var import_react_direction = require(_dependencyMap[6]);
  var import_react_use_controllable_state = require(_dependencyMap[7]);
  var import_react_id = require(_dependencyMap[8]);
  var import_jsx_runtime = require(_dependencyMap[9]);
  var TABS_NAME = "Tabs";
  var [createTabsContext, createTabsScope] = (0, import_react_context.createContextScope)(TABS_NAME, [import_react_roving_focus.createRovingFocusGroupScope]);
  var useRovingFocusGroupScope = (0, import_react_roving_focus.createRovingFocusGroupScope)();
  var [TabsProvider, useTabsContext] = createTabsContext(TABS_NAME);
  var Tabs = React.forwardRef((props, forwardedRef) => {
    const {
      __scopeTabs,
      value: valueProp,
      onValueChange,
      defaultValue,
      orientation = "horizontal",
      dir,
      activationMode = "automatic",
      ...tabsProps
    } = props;
    const direction = (0, import_react_direction.useDirection)(dir);
    const [value, setValue] = (0, import_react_use_controllable_state.useControllableState)({
      prop: valueProp,
      onChange: onValueChange,
      defaultProp: defaultValue ?? "",
      caller: TABS_NAME
    });
    return /* @__PURE__ */(0, import_jsx_runtime.jsx)(TabsProvider, {
      scope: __scopeTabs,
      baseId: (0, import_react_id.useId)(),
      value,
      onValueChange: setValue,
      orientation,
      dir: direction,
      activationMode,
      children: /* @__PURE__ */(0, import_jsx_runtime.jsx)(import_react_primitive.Primitive.div, {
        dir: direction,
        "data-orientation": orientation,
        ...tabsProps,
        ref: forwardedRef
      })
    });
  });
  Tabs.displayName = TABS_NAME;
  var TAB_LIST_NAME = "TabsList";
  var TabsList = React.forwardRef((props, forwardedRef) => {
    const {
      __scopeTabs,
      loop = true,
      ...listProps
    } = props;
    const context = useTabsContext(TAB_LIST_NAME, __scopeTabs);
    const rovingFocusGroupScope = useRovingFocusGroupScope(__scopeTabs);
    return /* @__PURE__ */(0, import_jsx_runtime.jsx)(RovingFocusGroup.Root, {
      asChild: true,
      ...rovingFocusGroupScope,
      orientation: context.orientation,
      dir: context.dir,
      loop,
      children: /* @__PURE__ */(0, import_jsx_runtime.jsx)(import_react_primitive.Primitive.div, {
        role: "tablist",
        "aria-orientation": context.orientation,
        ...listProps,
        ref: forwardedRef
      })
    });
  });
  TabsList.displayName = TAB_LIST_NAME;
  var TRIGGER_NAME = "TabsTrigger";
  var TabsTrigger = React.forwardRef((props, forwardedRef) => {
    const {
      __scopeTabs,
      value,
      disabled = false,
      ...triggerProps
    } = props;
    const context = useTabsContext(TRIGGER_NAME, __scopeTabs);
    const rovingFocusGroupScope = useRovingFocusGroupScope(__scopeTabs);
    const triggerId = makeTriggerId(context.baseId, value);
    const contentId = makeContentId(context.baseId, value);
    const isSelected = value === context.value;
    return /* @__PURE__ */(0, import_jsx_runtime.jsx)(RovingFocusGroup.Item, {
      asChild: true,
      ...rovingFocusGroupScope,
      focusable: !disabled,
      active: isSelected,
      children: /* @__PURE__ */(0, import_jsx_runtime.jsx)(import_react_primitive.Primitive.button, {
        type: "button",
        role: "tab",
        "aria-selected": isSelected,
        "aria-controls": contentId,
        "data-state": isSelected ? "active" : "inactive",
        "data-disabled": disabled ? "" : undefined,
        disabled,
        id: triggerId,
        ...triggerProps,
        ref: forwardedRef,
        onMouseDown: (0, import_primitive.composeEventHandlers)(props.onMouseDown, event => {
          if (!disabled && event.button === 0 && event.ctrlKey === false) {
            context.onValueChange(value);
          } else {
            event.preventDefault();
          }
        }),
        onKeyDown: (0, import_primitive.composeEventHandlers)(props.onKeyDown, event => {
          if ([" ", "Enter"].includes(event.key)) context.onValueChange(value);
        }),
        onFocus: (0, import_primitive.composeEventHandlers)(props.onFocus, () => {
          const isAutomaticActivation = context.activationMode !== "manual";
          if (!isSelected && !disabled && isAutomaticActivation) {
            context.onValueChange(value);
          }
        })
      })
    });
  });
  TabsTrigger.displayName = TRIGGER_NAME;
  var CONTENT_NAME = "TabsContent";
  var TabsContent = React.forwardRef((props, forwardedRef) => {
    const {
      __scopeTabs,
      value,
      forceMount,
      children,
      ...contentProps
    } = props;
    const context = useTabsContext(CONTENT_NAME, __scopeTabs);
    const triggerId = makeTriggerId(context.baseId, value);
    const contentId = makeContentId(context.baseId, value);
    const isSelected = value === context.value;
    const isMountAnimationPreventedRef = React.useRef(isSelected);
    React.useEffect(() => {
      const rAF = requestAnimationFrame(() => isMountAnimationPreventedRef.current = false);
      return () => cancelAnimationFrame(rAF);
    }, []);
    return /* @__PURE__ */(0, import_jsx_runtime.jsx)(import_react_presence.Presence, {
      present: forceMount || isSelected,
      children: ({
        present
      }) => /* @__PURE__ */(0, import_jsx_runtime.jsx)(import_react_primitive.Primitive.div, {
        "data-state": isSelected ? "active" : "inactive",
        "data-orientation": context.orientation,
        role: "tabpanel",
        "aria-labelledby": triggerId,
        hidden: !present,
        id: contentId,
        tabIndex: 0,
        ...contentProps,
        ref: forwardedRef,
        style: {
          ...props.style,
          animationDuration: isMountAnimationPreventedRef.current ? "0s" : undefined
        },
        children: present && children
      })
    });
  });
  TabsContent.displayName = CONTENT_NAME;
  function makeTriggerId(baseId, value) {
    return `${baseId}-trigger-${value}`;
  }
  function makeContentId(baseId, value) {
    return `${baseId}-content-${value}`;
  }
  var Root2 = Tabs;
  var List = TabsList;
  var Trigger = TabsTrigger;
  var Content = TabsContent;
},788,[12,789,790,791,801,796,800,798,794,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // src/index.ts
  var index_exports = {};
  __export(index_exports, {
    canUseDOM: () => canUseDOM,
    composeEventHandlers: () => composeEventHandlers,
    getActiveElement: () => getActiveElement,
    getOwnerDocument: () => getOwnerDocument,
    getOwnerWindow: () => getOwnerWindow,
    isFrame: () => isFrame
  });
  module.exports = __toCommonJS(index_exports);

  // src/primitive.tsx
  var canUseDOM = !!(typeof window !== "undefined" && window.document && window.document.createElement);
  function composeEventHandlers(originalEventHandler, ourEventHandler, {
    checkForDefaultPrevented = true
  } = {}) {
    return function handleEvent(event) {
      originalEventHandler?.(event);
      if (checkForDefaultPrevented === false || !event.defaultPrevented) {
        return ourEventHandler?.(event);
      }
    };
  }
  function getOwnerWindow(element) {
    if (!canUseDOM) {
      throw new Error("Cannot access window outside of the DOM");
    }
    return element?.ownerDocument?.defaultView ?? window;
  }
  function getOwnerDocument(element) {
    if (!canUseDOM) {
      throw new Error("Cannot access document outside of the DOM");
    }
    return element?.ownerDocument ?? document;
  }
  function getActiveElement(node, activeDescendant = false) {
    const {
      activeElement
    } = getOwnerDocument(node);
    if (!activeElement?.nodeName) {
      return null;
    }
    if (isFrame(activeElement) && activeElement.contentDocument) {
      return getActiveElement(activeElement.contentDocument.body, activeDescendant);
    }
    if (activeDescendant) {
      const id = activeElement.getAttribute("aria-activedescendant");
      if (id) {
        const element = getOwnerDocument(activeElement).getElementById(id);
        if (element) {
          return element;
        }
      }
    }
    return activeElement;
  }
  function isFrame(element) {
    return element.tagName === "IFRAME";
  }
},789,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
    value: mod,
    enumerable: true
  }) : target, mod));
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // packages/react/context/src/index.ts
  var index_exports = {};
  __export(index_exports, {
    createContext: () => createContext2,
    createContextScope: () => createContextScope
  });
  module.exports = __toCommonJS(index_exports);

  // packages/react/context/src/create-context.tsx
  var React = __toESM(require(_dependencyMap[0]));
  var import_jsx_runtime = require(_dependencyMap[1]);
  function createContext2(rootComponentName, defaultContext) {
    const Context = React.createContext(defaultContext);
    const Provider = props => {
      const {
        children,
        ...context
      } = props;
      const value = React.useMemo(() => context, Object.values(context));
      return /* @__PURE__ */(0, import_jsx_runtime.jsx)(Context.Provider, {
        value,
        children
      });
    };
    Provider.displayName = rootComponentName + "Provider";
    function useContext2(consumerName) {
      const context = React.useContext(Context);
      if (context) return context;
      if (defaultContext !== undefined) return defaultContext;
      throw new Error(`\`${consumerName}\` must be used within \`${rootComponentName}\``);
    }
    return [Provider, useContext2];
  }
  function createContextScope(scopeName, createContextScopeDeps = []) {
    let defaultContexts = [];
    function createContext3(rootComponentName, defaultContext) {
      const BaseContext = React.createContext(defaultContext);
      const index = defaultContexts.length;
      defaultContexts = [...defaultContexts, defaultContext];
      const Provider = props => {
        const {
          scope,
          children,
          ...context
        } = props;
        const Context = scope?.[scopeName]?.[index] || BaseContext;
        const value = React.useMemo(() => context, Object.values(context));
        return /* @__PURE__ */(0, import_jsx_runtime.jsx)(Context.Provider, {
          value,
          children
        });
      };
      Provider.displayName = rootComponentName + "Provider";
      function useContext2(consumerName, scope) {
        const Context = scope?.[scopeName]?.[index] || BaseContext;
        const context = React.useContext(Context);
        if (context) return context;
        if (defaultContext !== undefined) return defaultContext;
        throw new Error(`\`${consumerName}\` must be used within \`${rootComponentName}\``);
      }
      return [Provider, useContext2];
    }
    const createScope = () => {
      const scopeContexts = defaultContexts.map(defaultContext => {
        return React.createContext(defaultContext);
      });
      return function useScope(scope) {
        const contexts = scope?.[scopeName] || scopeContexts;
        return React.useMemo(() => ({
          [`__scope${scopeName}`]: {
            ...scope,
            [scopeName]: contexts
          }
        }), [scope, contexts]);
      };
    };
    createScope.scopeName = scopeName;
    return [createContext3, composeContextScopes(createScope, ...createContextScopeDeps)];
  }
  function composeContextScopes(...scopes) {
    const baseScope = scopes[0];
    if (scopes.length === 1) return baseScope;
    const createScope = () => {
      const scopeHooks = scopes.map(createScope2 => ({
        useScope: createScope2(),
        scopeName: createScope2.scopeName
      }));
      return function useComposedScopes(overrideScopes) {
        const nextScopes = scopeHooks.reduce((nextScopes2, {
          useScope,
          scopeName
        }) => {
          const scopeProps = useScope(overrideScopes);
          const currentScope = scopeProps[`__scope${scopeName}`];
          return {
            ...nextScopes2,
            ...currentScope
          };
        }, {});
        return React.useMemo(() => ({
          [`__scope${baseScope.scopeName}`]: nextScopes
        }), [nextScopes]);
      };
    };
    createScope.scopeName = baseScope.scopeName;
    return createScope;
  }
},790,[12,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
  "use client";

  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
    value: mod,
    enumerable: true
  }) : target, mod));
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // src/index.ts
  var index_exports = {};
  __export(index_exports, {
    Item: () => Item,
    Root: () => Root,
    RovingFocusGroup: () => RovingFocusGroup,
    RovingFocusGroupItem: () => RovingFocusGroupItem,
    createRovingFocusGroupScope: () => createRovingFocusGroupScope
  });
  module.exports = __toCommonJS(index_exports);

  // src/roving-focus-group.tsx
  var React = __toESM(require(_dependencyMap[0]));
  var import_primitive = require(_dependencyMap[1]);
  var import_react_collection = require(_dependencyMap[2]);
  var import_react_compose_refs = require(_dependencyMap[3]);
  var import_react_context = require(_dependencyMap[4]);
  var import_react_id = require(_dependencyMap[5]);
  var import_react_primitive = require(_dependencyMap[6]);
  var import_react_use_callback_ref = require(_dependencyMap[7]);
  var import_react_use_controllable_state = require(_dependencyMap[8]);
  var import_react_direction = require(_dependencyMap[9]);
  var import_jsx_runtime = require(_dependencyMap[10]);
  var ENTRY_FOCUS = "rovingFocusGroup.onEntryFocus";
  var EVENT_OPTIONS = {
    bubbles: false,
    cancelable: true
  };
  var GROUP_NAME = "RovingFocusGroup";
  var [Collection, useCollection, createCollectionScope] = (0, import_react_collection.createCollection)(GROUP_NAME);
  var [createRovingFocusGroupContext, createRovingFocusGroupScope] = (0, import_react_context.createContextScope)(GROUP_NAME, [createCollectionScope]);
  var [RovingFocusProvider, useRovingFocusContext] = createRovingFocusGroupContext(GROUP_NAME);
  var RovingFocusGroup = React.forwardRef((props, forwardedRef) => {
    return /* @__PURE__ */(0, import_jsx_runtime.jsx)(Collection.Provider, {
      scope: props.__scopeRovingFocusGroup,
      children: /* @__PURE__ */(0, import_jsx_runtime.jsx)(Collection.Slot, {
        scope: props.__scopeRovingFocusGroup,
        children: /* @__PURE__ */(0, import_jsx_runtime.jsx)(RovingFocusGroupImpl, {
          ...props,
          ref: forwardedRef
        })
      })
    });
  });
  RovingFocusGroup.displayName = GROUP_NAME;
  var RovingFocusGroupImpl = React.forwardRef((props, forwardedRef) => {
    const {
      __scopeRovingFocusGroup,
      orientation,
      loop = false,
      dir,
      currentTabStopId: currentTabStopIdProp,
      defaultCurrentTabStopId,
      onCurrentTabStopIdChange,
      onEntryFocus,
      preventScrollOnEntryFocus = false,
      ...groupProps
    } = props;
    const ref = React.useRef(null);
    const composedRefs = (0, import_react_compose_refs.useComposedRefs)(forwardedRef, ref);
    const direction = (0, import_react_direction.useDirection)(dir);
    const [currentTabStopId, setCurrentTabStopId] = (0, import_react_use_controllable_state.useControllableState)({
      prop: currentTabStopIdProp,
      defaultProp: defaultCurrentTabStopId ?? null,
      onChange: onCurrentTabStopIdChange,
      caller: GROUP_NAME
    });
    const [isTabbingBackOut, setIsTabbingBackOut] = React.useState(false);
    const handleEntryFocus = (0, import_react_use_callback_ref.useCallbackRef)(onEntryFocus);
    const getItems = useCollection(__scopeRovingFocusGroup);
    const isClickFocusRef = React.useRef(false);
    const [focusableItemsCount, setFocusableItemsCount] = React.useState(0);
    React.useEffect(() => {
      const node = ref.current;
      if (node) {
        node.addEventListener(ENTRY_FOCUS, handleEntryFocus);
        return () => node.removeEventListener(ENTRY_FOCUS, handleEntryFocus);
      }
    }, [handleEntryFocus]);
    return /* @__PURE__ */(0, import_jsx_runtime.jsx)(RovingFocusProvider, {
      scope: __scopeRovingFocusGroup,
      orientation,
      dir: direction,
      loop,
      currentTabStopId,
      onItemFocus: React.useCallback(tabStopId => setCurrentTabStopId(tabStopId), [setCurrentTabStopId]),
      onItemShiftTab: React.useCallback(() => setIsTabbingBackOut(true), []),
      onFocusableItemAdd: React.useCallback(() => setFocusableItemsCount(prevCount => prevCount + 1), []),
      onFocusableItemRemove: React.useCallback(() => setFocusableItemsCount(prevCount => prevCount - 1), []),
      children: /* @__PURE__ */(0, import_jsx_runtime.jsx)(import_react_primitive.Primitive.div, {
        tabIndex: isTabbingBackOut || focusableItemsCount === 0 ? -1 : 0,
        "data-orientation": orientation,
        ...groupProps,
        ref: composedRefs,
        style: {
          outline: "none",
          ...props.style
        },
        onMouseDown: (0, import_primitive.composeEventHandlers)(props.onMouseDown, () => {
          isClickFocusRef.current = true;
        }),
        onFocus: (0, import_primitive.composeEventHandlers)(props.onFocus, event => {
          const isKeyboardFocus = !isClickFocusRef.current;
          if (event.target === event.currentTarget && isKeyboardFocus && !isTabbingBackOut) {
            const entryFocusEvent = new CustomEvent(ENTRY_FOCUS, EVENT_OPTIONS);
            event.currentTarget.dispatchEvent(entryFocusEvent);
            if (!entryFocusEvent.defaultPrevented) {
              const items = getItems().filter(item => item.focusable);
              const activeItem = items.find(item => item.active);
              const currentItem = items.find(item => item.id === currentTabStopId);
              const candidateItems = [activeItem, currentItem, ...items].filter(Boolean);
              const candidateNodes = candidateItems.map(item => item.ref.current);
              focusFirst(candidateNodes, preventScrollOnEntryFocus);
            }
          }
          isClickFocusRef.current = false;
        }),
        onBlur: (0, import_primitive.composeEventHandlers)(props.onBlur, () => setIsTabbingBackOut(false))
      })
    });
  });
  var ITEM_NAME = "RovingFocusGroupItem";
  var RovingFocusGroupItem = React.forwardRef((props, forwardedRef) => {
    const {
      __scopeRovingFocusGroup,
      focusable = true,
      active = false,
      tabStopId,
      children,
      ...itemProps
    } = props;
    const autoId = (0, import_react_id.useId)();
    const id = tabStopId || autoId;
    const context = useRovingFocusContext(ITEM_NAME, __scopeRovingFocusGroup);
    const isCurrentTabStop = context.currentTabStopId === id;
    const getItems = useCollection(__scopeRovingFocusGroup);
    const {
      onFocusableItemAdd,
      onFocusableItemRemove,
      currentTabStopId
    } = context;
    React.useEffect(() => {
      if (focusable) {
        onFocusableItemAdd();
        return () => onFocusableItemRemove();
      }
    }, [focusable, onFocusableItemAdd, onFocusableItemRemove]);
    return /* @__PURE__ */(0, import_jsx_runtime.jsx)(Collection.ItemSlot, {
      scope: __scopeRovingFocusGroup,
      id,
      focusable,
      active,
      children: /* @__PURE__ */(0, import_jsx_runtime.jsx)(import_react_primitive.Primitive.span, {
        tabIndex: isCurrentTabStop ? 0 : -1,
        "data-orientation": context.orientation,
        ...itemProps,
        ref: forwardedRef,
        onMouseDown: (0, import_primitive.composeEventHandlers)(props.onMouseDown, event => {
          if (!focusable) event.preventDefault();else context.onItemFocus(id);
        }),
        onFocus: (0, import_primitive.composeEventHandlers)(props.onFocus, () => context.onItemFocus(id)),
        onKeyDown: (0, import_primitive.composeEventHandlers)(props.onKeyDown, event => {
          if (event.key === "Tab" && event.shiftKey) {
            context.onItemShiftTab();
            return;
          }
          if (event.target !== event.currentTarget) return;
          const focusIntent = getFocusIntent(event, context.orientation, context.dir);
          if (focusIntent !== undefined) {
            if (event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return;
            event.preventDefault();
            const items = getItems().filter(item => item.focusable);
            let candidateNodes = items.map(item => item.ref.current);
            if (focusIntent === "last") candidateNodes.reverse();else if (focusIntent === "prev" || focusIntent === "next") {
              if (focusIntent === "prev") candidateNodes.reverse();
              const currentIndex = candidateNodes.indexOf(event.currentTarget);
              candidateNodes = context.loop ? wrapArray(candidateNodes, currentIndex + 1) : candidateNodes.slice(currentIndex + 1);
            }
            setTimeout(() => focusFirst(candidateNodes));
          }
        }),
        children: typeof children === "function" ? children({
          isCurrentTabStop,
          hasTabStop: currentTabStopId != null
        }) : children
      })
    });
  });
  RovingFocusGroupItem.displayName = ITEM_NAME;
  var MAP_KEY_TO_FOCUS_INTENT = {
    ArrowLeft: "prev",
    ArrowUp: "prev",
    ArrowRight: "next",
    ArrowDown: "next",
    PageUp: "first",
    Home: "first",
    PageDown: "last",
    End: "last"
  };
  function getDirectionAwareKey(key, dir) {
    if (dir !== "rtl") return key;
    return key === "ArrowLeft" ? "ArrowRight" : key === "ArrowRight" ? "ArrowLeft" : key;
  }
  function getFocusIntent(event, orientation, dir) {
    const key = getDirectionAwareKey(event.key, dir);
    if (orientation === "vertical" && ["ArrowLeft", "ArrowRight"].includes(key)) return undefined;
    if (orientation === "horizontal" && ["ArrowUp", "ArrowDown"].includes(key)) return undefined;
    return MAP_KEY_TO_FOCUS_INTENT[key];
  }
  function focusFirst(candidates, preventScroll = false) {
    const PREVIOUSLY_FOCUSED_ELEMENT = document.activeElement;
    for (const candidate of candidates) {
      if (candidate === PREVIOUSLY_FOCUSED_ELEMENT) return;
      candidate.focus({
        preventScroll
      });
      if (document.activeElement !== PREVIOUSLY_FOCUSED_ELEMENT) return;
    }
  }
  function wrapArray(array, startIndex) {
    return array.map((_, index) => array[(startIndex + index) % array.length]);
  }
  var Root = RovingFocusGroup;
  var Item = RovingFocusGroupItem;
},791,[12,789,792,497,790,794,796,797,798,800,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
  "use client";

  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
    value: mod,
    enumerable: true
  }) : target, mod));
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // src/index.ts
  var index_exports = {};
  __export(index_exports, {
    createCollection: () => createCollection,
    unstable_createCollection: () => createCollection2
  });
  module.exports = __toCommonJS(index_exports);

  // src/collection-legacy.tsx
  var import_react = __toESM(require(_dependencyMap[0]));
  var import_react_context = require(_dependencyMap[1]);
  var import_react_compose_refs = require(_dependencyMap[2]);
  var import_react_slot = require(_dependencyMap[3]);
  var import_jsx_runtime = require(_dependencyMap[4]);
  function createCollection(name) {
    const PROVIDER_NAME = name + "CollectionProvider";
    const [createCollectionContext, createCollectionScope] = (0, import_react_context.createContextScope)(PROVIDER_NAME);
    const [CollectionProviderImpl, useCollectionContext] = createCollectionContext(PROVIDER_NAME, {
      collectionRef: {
        current: null
      },
      itemMap: /* @__PURE__ */new Map()
    });
    const CollectionProvider = props => {
      const {
        scope,
        children
      } = props;
      const ref = import_react.default.useRef(null);
      const itemMap = import_react.default.useRef(/* @__PURE__ */new Map()).current;
      return /* @__PURE__ */(0, import_jsx_runtime.jsx)(CollectionProviderImpl, {
        scope,
        itemMap,
        collectionRef: ref,
        children
      });
    };
    CollectionProvider.displayName = PROVIDER_NAME;
    const COLLECTION_SLOT_NAME = name + "CollectionSlot";
    const CollectionSlotImpl = (0, import_react_slot.createSlot)(COLLECTION_SLOT_NAME);
    const CollectionSlot = import_react.default.forwardRef((props, forwardedRef) => {
      const {
        scope,
        children
      } = props;
      const context = useCollectionContext(COLLECTION_SLOT_NAME, scope);
      const composedRefs = (0, import_react_compose_refs.useComposedRefs)(forwardedRef, context.collectionRef);
      return /* @__PURE__ */(0, import_jsx_runtime.jsx)(CollectionSlotImpl, {
        ref: composedRefs,
        children
      });
    });
    CollectionSlot.displayName = COLLECTION_SLOT_NAME;
    const ITEM_SLOT_NAME = name + "CollectionItemSlot";
    const ITEM_DATA_ATTR = "data-radix-collection-item";
    const CollectionItemSlotImpl = (0, import_react_slot.createSlot)(ITEM_SLOT_NAME);
    const CollectionItemSlot = import_react.default.forwardRef((props, forwardedRef) => {
      const {
        scope,
        children,
        ...itemData
      } = props;
      const ref = import_react.default.useRef(null);
      const composedRefs = (0, import_react_compose_refs.useComposedRefs)(forwardedRef, ref);
      const context = useCollectionContext(ITEM_SLOT_NAME, scope);
      import_react.default.useEffect(() => {
        context.itemMap.set(ref, {
          ref,
          ...itemData
        });
        return () => void context.itemMap.delete(ref);
      });
      return /* @__PURE__ */(0, import_jsx_runtime.jsx)(CollectionItemSlotImpl, {
        ...{
          [ITEM_DATA_ATTR]: ""
        },
        ref: composedRefs,
        children
      });
    });
    CollectionItemSlot.displayName = ITEM_SLOT_NAME;
    function useCollection(scope) {
      const context = useCollectionContext(name + "CollectionConsumer", scope);
      const getItems = import_react.default.useCallback(() => {
        const collectionNode = context.collectionRef.current;
        if (!collectionNode) return [];
        const orderedNodes = Array.from(collectionNode.querySelectorAll(`[${ITEM_DATA_ATTR}]`));
        const items = Array.from(context.itemMap.values());
        const orderedItems = items.sort((a, b) => orderedNodes.indexOf(a.ref.current) - orderedNodes.indexOf(b.ref.current));
        return orderedItems;
      }, [context.collectionRef, context.itemMap]);
      return getItems;
    }
    return [{
      Provider: CollectionProvider,
      Slot: CollectionSlot,
      ItemSlot: CollectionItemSlot
    }, useCollection, createCollectionScope];
  }

  // src/collection.tsx
  var import_react2 = __toESM(require(_dependencyMap[0]));
  var import_react_context2 = require(_dependencyMap[1]);
  var import_react_compose_refs2 = require(_dependencyMap[2]);
  var import_react_slot2 = require(_dependencyMap[3]);

  // src/ordered-dictionary.ts
  var __instanciated = /* @__PURE__ */new WeakMap();
  var OrderedDict = class _OrderedDict extends Map {
    #keys;
    constructor(entries) {
      super(entries);
      this.#keys = [...super.keys()];
      __instanciated.set(this, true);
    }
    set(key, value) {
      if (__instanciated.get(this)) {
        if (this.has(key)) {
          this.#keys[this.#keys.indexOf(key)] = key;
        } else {
          this.#keys.push(key);
        }
      }
      super.set(key, value);
      return this;
    }
    insert(index, key, value) {
      const has = this.has(key);
      const length = this.#keys.length;
      const relativeIndex = toSafeInteger(index);
      let actualIndex = relativeIndex >= 0 ? relativeIndex : length + relativeIndex;
      const safeIndex = actualIndex < 0 || actualIndex >= length ? -1 : actualIndex;
      if (safeIndex === this.size || has && safeIndex === this.size - 1 || safeIndex === -1) {
        this.set(key, value);
        return this;
      }
      const size = this.size + (has ? 0 : 1);
      if (relativeIndex < 0) {
        actualIndex++;
      }
      const keys = [...this.#keys];
      let nextValue;
      let shouldSkip = false;
      for (let i = actualIndex; i < size; i++) {
        if (actualIndex === i) {
          let nextKey = keys[i];
          if (keys[i] === key) {
            nextKey = keys[i + 1];
          }
          if (has) {
            this.delete(key);
          }
          nextValue = this.get(nextKey);
          this.set(key, value);
        } else {
          if (!shouldSkip && keys[i - 1] === key) {
            shouldSkip = true;
          }
          const currentKey = keys[shouldSkip ? i : i - 1];
          const currentValue = nextValue;
          nextValue = this.get(currentKey);
          this.delete(currentKey);
          this.set(currentKey, currentValue);
        }
      }
      return this;
    }
    with(index, key, value) {
      const copy = new _OrderedDict(this);
      copy.insert(index, key, value);
      return copy;
    }
    before(key) {
      const index = this.#keys.indexOf(key) - 1;
      if (index < 0) {
        return undefined;
      }
      return this.entryAt(index);
    }
    /**
     * Sets a new key-value pair at the position before the given key.
     */
    setBefore(key, newKey, value) {
      const index = this.#keys.indexOf(key);
      if (index === -1) {
        return this;
      }
      return this.insert(index, newKey, value);
    }
    after(key) {
      let index = this.#keys.indexOf(key);
      index = index === -1 || index === this.size - 1 ? -1 : index + 1;
      if (index === -1) {
        return undefined;
      }
      return this.entryAt(index);
    }
    /**
     * Sets a new key-value pair at the position after the given key.
     */
    setAfter(key, newKey, value) {
      const index = this.#keys.indexOf(key);
      if (index === -1) {
        return this;
      }
      return this.insert(index + 1, newKey, value);
    }
    first() {
      return this.entryAt(0);
    }
    last() {
      return this.entryAt(-1);
    }
    clear() {
      this.#keys = [];
      return super.clear();
    }
    delete(key) {
      const deleted = super.delete(key);
      if (deleted) {
        this.#keys.splice(this.#keys.indexOf(key), 1);
      }
      return deleted;
    }
    deleteAt(index) {
      const key = this.keyAt(index);
      if (key !== undefined) {
        return this.delete(key);
      }
      return false;
    }
    at(index) {
      const key = at(this.#keys, index);
      if (key !== undefined) {
        return this.get(key);
      }
    }
    entryAt(index) {
      const key = at(this.#keys, index);
      if (key !== undefined) {
        return [key, this.get(key)];
      }
    }
    indexOf(key) {
      return this.#keys.indexOf(key);
    }
    keyAt(index) {
      return at(this.#keys, index);
    }
    from(key, offset) {
      const index = this.indexOf(key);
      if (index === -1) {
        return undefined;
      }
      let dest = index + offset;
      if (dest < 0) dest = 0;
      if (dest >= this.size) dest = this.size - 1;
      return this.at(dest);
    }
    keyFrom(key, offset) {
      const index = this.indexOf(key);
      if (index === -1) {
        return undefined;
      }
      let dest = index + offset;
      if (dest < 0) dest = 0;
      if (dest >= this.size) dest = this.size - 1;
      return this.keyAt(dest);
    }
    find(predicate, thisArg) {
      let index = 0;
      for (const entry of this) {
        if (Reflect.apply(predicate, thisArg, [entry, index, this])) {
          return entry;
        }
        index++;
      }
      return undefined;
    }
    findIndex(predicate, thisArg) {
      let index = 0;
      for (const entry of this) {
        if (Reflect.apply(predicate, thisArg, [entry, index, this])) {
          return index;
        }
        index++;
      }
      return -1;
    }
    filter(predicate, thisArg) {
      const entries = [];
      let index = 0;
      for (const entry of this) {
        if (Reflect.apply(predicate, thisArg, [entry, index, this])) {
          entries.push(entry);
        }
        index++;
      }
      return new _OrderedDict(entries);
    }
    map(callbackfn, thisArg) {
      const entries = [];
      let index = 0;
      for (const entry of this) {
        entries.push([entry[0], Reflect.apply(callbackfn, thisArg, [entry, index, this])]);
        index++;
      }
      return new _OrderedDict(entries);
    }
    reduce(...args) {
      const [callbackfn, initialValue] = args;
      let index = 0;
      let accumulator = initialValue ?? this.at(0);
      for (const entry of this) {
        if (index === 0 && args.length === 1) {
          accumulator = entry;
        } else {
          accumulator = Reflect.apply(callbackfn, this, [accumulator, entry, index, this]);
        }
        index++;
      }
      return accumulator;
    }
    reduceRight(...args) {
      const [callbackfn, initialValue] = args;
      let accumulator = initialValue ?? this.at(-1);
      for (let index = this.size - 1; index >= 0; index--) {
        const entry = this.at(index);
        if (index === this.size - 1 && args.length === 1) {
          accumulator = entry;
        } else {
          accumulator = Reflect.apply(callbackfn, this, [accumulator, entry, index, this]);
        }
      }
      return accumulator;
    }
    toSorted(compareFn) {
      const entries = [...this.entries()].sort(compareFn);
      return new _OrderedDict(entries);
    }
    toReversed() {
      const reversed = new _OrderedDict();
      for (let index = this.size - 1; index >= 0; index--) {
        const key = this.keyAt(index);
        const element = this.get(key);
        reversed.set(key, element);
      }
      return reversed;
    }
    toSpliced(...args) {
      const entries = [...this.entries()];
      entries.splice(...args);
      return new _OrderedDict(entries);
    }
    slice(start, end) {
      const result = new _OrderedDict();
      let stop = this.size - 1;
      if (start === undefined) {
        return result;
      }
      if (start < 0) {
        start = start + this.size;
      }
      if (end !== undefined && end > 0) {
        stop = end - 1;
      }
      for (let index = start; index <= stop; index++) {
        const key = this.keyAt(index);
        const element = this.get(key);
        result.set(key, element);
      }
      return result;
    }
    every(predicate, thisArg) {
      let index = 0;
      for (const entry of this) {
        if (!Reflect.apply(predicate, thisArg, [entry, index, this])) {
          return false;
        }
        index++;
      }
      return true;
    }
    some(predicate, thisArg) {
      let index = 0;
      for (const entry of this) {
        if (Reflect.apply(predicate, thisArg, [entry, index, this])) {
          return true;
        }
        index++;
      }
      return false;
    }
  };
  function at(array, index) {
    if ("at" in Array.prototype) {
      return Array.prototype.at.call(array, index);
    }
    const actualIndex = toSafeIndex(array, index);
    return actualIndex === -1 ? undefined : array[actualIndex];
  }
  function toSafeIndex(array, index) {
    const length = array.length;
    const relativeIndex = toSafeInteger(index);
    const actualIndex = relativeIndex >= 0 ? relativeIndex : length + relativeIndex;
    return actualIndex < 0 || actualIndex >= length ? -1 : actualIndex;
  }
  function toSafeInteger(number) {
    return number !== number || number === 0 ? 0 : Math.trunc(number);
  }

  // src/collection.tsx
  var import_jsx_runtime2 = require(_dependencyMap[4]);
  function createCollection2(name) {
    const PROVIDER_NAME = name + "CollectionProvider";
    const [createCollectionContext, createCollectionScope] = (0, import_react_context2.createContextScope)(PROVIDER_NAME);
    const [CollectionContextProvider, useCollectionContext] = createCollectionContext(PROVIDER_NAME, {
      collectionElement: null,
      collectionRef: {
        current: null
      },
      collectionRefObject: {
        current: null
      },
      itemMap: new OrderedDict(),
      setItemMap: () => undefined
    });
    const CollectionProvider = ({
      state,
      ...props
    }) => {
      return state ? /* @__PURE__ */(0, import_jsx_runtime2.jsx)(CollectionProviderImpl, {
        ...props,
        state
      }) : /* @__PURE__ */(0, import_jsx_runtime2.jsx)(CollectionInit, {
        ...props
      });
    };
    CollectionProvider.displayName = PROVIDER_NAME;
    const CollectionInit = props => {
      const state = useInitCollection();
      return /* @__PURE__ */(0, import_jsx_runtime2.jsx)(CollectionProviderImpl, {
        ...props,
        state
      });
    };
    CollectionInit.displayName = PROVIDER_NAME + "Init";
    const CollectionProviderImpl = props => {
      const {
        scope,
        children,
        state
      } = props;
      const ref = import_react2.default.useRef(null);
      const [collectionElement, setCollectionElement] = import_react2.default.useState(null);
      const composeRefs = (0, import_react_compose_refs2.useComposedRefs)(ref, setCollectionElement);
      const [itemMap, setItemMap] = state;
      import_react2.default.useEffect(() => {
        if (!collectionElement) return;
        const observer = getChildListObserver(() => {});
        observer.observe(collectionElement, {
          childList: true,
          subtree: true
        });
        return () => {
          observer.disconnect();
        };
      }, [collectionElement]);
      return /* @__PURE__ */(0, import_jsx_runtime2.jsx)(CollectionContextProvider, {
        scope,
        itemMap,
        setItemMap,
        collectionRef: composeRefs,
        collectionRefObject: ref,
        collectionElement,
        children
      });
    };
    CollectionProviderImpl.displayName = PROVIDER_NAME + "Impl";
    const COLLECTION_SLOT_NAME = name + "CollectionSlot";
    const CollectionSlotImpl = (0, import_react_slot2.createSlot)(COLLECTION_SLOT_NAME);
    const CollectionSlot = import_react2.default.forwardRef((props, forwardedRef) => {
      const {
        scope,
        children
      } = props;
      const context = useCollectionContext(COLLECTION_SLOT_NAME, scope);
      const composedRefs = (0, import_react_compose_refs2.useComposedRefs)(forwardedRef, context.collectionRef);
      return /* @__PURE__ */(0, import_jsx_runtime2.jsx)(CollectionSlotImpl, {
        ref: composedRefs,
        children
      });
    });
    CollectionSlot.displayName = COLLECTION_SLOT_NAME;
    const ITEM_SLOT_NAME = name + "CollectionItemSlot";
    const ITEM_DATA_ATTR = "data-radix-collection-item";
    const CollectionItemSlotImpl = (0, import_react_slot2.createSlot)(ITEM_SLOT_NAME);
    const CollectionItemSlot = import_react2.default.forwardRef((props, forwardedRef) => {
      const {
        scope,
        children,
        ...itemData
      } = props;
      const ref = import_react2.default.useRef(null);
      const [element, setElement] = import_react2.default.useState(null);
      const composedRefs = (0, import_react_compose_refs2.useComposedRefs)(forwardedRef, ref, setElement);
      const context = useCollectionContext(ITEM_SLOT_NAME, scope);
      const {
        setItemMap
      } = context;
      const itemDataRef = import_react2.default.useRef(itemData);
      if (!shallowEqual(itemDataRef.current, itemData)) {
        itemDataRef.current = itemData;
      }
      const memoizedItemData = itemDataRef.current;
      import_react2.default.useEffect(() => {
        const itemData2 = memoizedItemData;
        setItemMap(map => {
          if (!element) {
            return map;
          }
          if (!map.has(element)) {
            map.set(element, {
              ...itemData2,
              element
            });
            return map.toSorted(sortByDocumentPosition);
          }
          return map.set(element, {
            ...itemData2,
            element
          }).toSorted(sortByDocumentPosition);
        });
        return () => {
          setItemMap(map => {
            if (!element || !map.has(element)) {
              return map;
            }
            map.delete(element);
            return new OrderedDict(map);
          });
        };
      }, [element, memoizedItemData, setItemMap]);
      return /* @__PURE__ */(0, import_jsx_runtime2.jsx)(CollectionItemSlotImpl, {
        ...{
          [ITEM_DATA_ATTR]: ""
        },
        ref: composedRefs,
        children
      });
    });
    CollectionItemSlot.displayName = ITEM_SLOT_NAME;
    function useInitCollection() {
      return import_react2.default.useState(new OrderedDict());
    }
    function useCollection(scope) {
      const {
        itemMap
      } = useCollectionContext(name + "CollectionConsumer", scope);
      return itemMap;
    }
    const functions = {
      createCollectionScope,
      useCollection,
      useInitCollection
    };
    return [{
      Provider: CollectionProvider,
      Slot: CollectionSlot,
      ItemSlot: CollectionItemSlot
    }, functions];
  }
  function shallowEqual(a, b) {
    if (a === b) return true;
    if (typeof a !== "object" || typeof b !== "object") return false;
    if (a == null || b == null) return false;
    const keysA = Object.keys(a);
    const keysB = Object.keys(b);
    if (keysA.length !== keysB.length) return false;
    for (const key of keysA) {
      if (!Object.prototype.hasOwnProperty.call(b, key)) return false;
      if (a[key] !== b[key]) return false;
    }
    return true;
  }
  function isElementPreceding(a, b) {
    return !!(b.compareDocumentPosition(a) & Node.DOCUMENT_POSITION_PRECEDING);
  }
  function sortByDocumentPosition(a, b) {
    return !a[1].element || !b[1].element ? 0 : isElementPreceding(a[1].element, b[1].element) ? -1 : 1;
  }
  function getChildListObserver(callback) {
    const observer = new MutationObserver(mutationsList => {
      for (const mutation of mutationsList) {
        if (mutation.type === "childList") {
          callback();
          return;
        }
      }
    });
    return observer;
  }
},792,[12,790,497,793,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
    value: mod,
    enumerable: true
  }) : target, mod));
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // src/index.ts
  var index_exports = {};
  __export(index_exports, {
    Root: () => Slot,
    Slot: () => Slot,
    Slottable: () => Slottable,
    createSlot: () => createSlot,
    createSlottable: () => createSlottable
  });
  module.exports = __toCommonJS(index_exports);

  // src/slot.tsx
  var React = __toESM(require(_dependencyMap[0]));
  var import_react_compose_refs = require(_dependencyMap[1]);
  var import_jsx_runtime = require(_dependencyMap[2]);
  // @__NO_SIDE_EFFECTS__
  function createSlot(ownerName) {
    const SlotClone = /* @__PURE__ */createSlotClone(ownerName);
    const Slot2 = React.forwardRef((props, forwardedRef) => {
      const {
        children,
        ...slotProps
      } = props;
      const childrenArray = React.Children.toArray(children);
      const slottable = childrenArray.find(isSlottable);
      if (slottable) {
        const newElement = slottable.props.children;
        const newChildren = childrenArray.map(child => {
          if (child === slottable) {
            if (React.Children.count(newElement) > 1) return React.Children.only(null);
            return React.isValidElement(newElement) ? newElement.props.children : null;
          } else {
            return child;
          }
        });
        return /* @__PURE__ */(0, import_jsx_runtime.jsx)(SlotClone, {
          ...slotProps,
          ref: forwardedRef,
          children: React.isValidElement(newElement) ? React.cloneElement(newElement, undefined, newChildren) : null
        });
      }
      return /* @__PURE__ */(0, import_jsx_runtime.jsx)(SlotClone, {
        ...slotProps,
        ref: forwardedRef,
        children
      });
    });
    Slot2.displayName = `${ownerName}.Slot`;
    return Slot2;
  }
  var Slot = /* @__PURE__ */createSlot("Slot");
  // @__NO_SIDE_EFFECTS__
  function createSlotClone(ownerName) {
    const SlotClone = React.forwardRef((props, forwardedRef) => {
      const {
        children,
        ...slotProps
      } = props;
      if (React.isValidElement(children)) {
        const childrenRef = getElementRef(children);
        const props2 = mergeProps(slotProps, children.props);
        if (children.type !== React.Fragment) {
          props2.ref = forwardedRef ? (0, import_react_compose_refs.composeRefs)(forwardedRef, childrenRef) : childrenRef;
        }
        return React.cloneElement(children, props2);
      }
      return React.Children.count(children) > 1 ? React.Children.only(null) : null;
    });
    SlotClone.displayName = `${ownerName}.SlotClone`;
    return SlotClone;
  }
  var SLOTTABLE_IDENTIFIER = Symbol("radix.slottable");
  // @__NO_SIDE_EFFECTS__
  function createSlottable(ownerName) {
    const Slottable2 = ({
      children
    }) => {
      return /* @__PURE__ */(0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, {
        children
      });
    };
    Slottable2.displayName = `${ownerName}.Slottable`;
    Slottable2.__radixId = SLOTTABLE_IDENTIFIER;
    return Slottable2;
  }
  var Slottable = /* @__PURE__ */createSlottable("Slottable");
  function isSlottable(child) {
    return React.isValidElement(child) && typeof child.type === "function" && "__radixId" in child.type && child.type.__radixId === SLOTTABLE_IDENTIFIER;
  }
  function mergeProps(slotProps, childProps) {
    const overrideProps = {
      ...childProps
    };
    for (const propName in childProps) {
      const slotPropValue = slotProps[propName];
      const childPropValue = childProps[propName];
      const isHandler = /^on[A-Z]/.test(propName);
      if (isHandler) {
        if (slotPropValue && childPropValue) {
          overrideProps[propName] = (...args) => {
            const result = childPropValue(...args);
            slotPropValue(...args);
            return result;
          };
        } else if (slotPropValue) {
          overrideProps[propName] = slotPropValue;
        }
      } else if (propName === "style") {
        overrideProps[propName] = {
          ...slotPropValue,
          ...childPropValue
        };
      } else if (propName === "className") {
        overrideProps[propName] = [slotPropValue, childPropValue].filter(Boolean).join(" ");
      }
    }
    return {
      ...slotProps,
      ...overrideProps
    };
  }
  function getElementRef(element) {
    let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
    let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
    if (mayWarn) {
      return element.ref;
    }
    getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
    mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
    if (mayWarn) {
      return element.props.ref;
    }
    return element.props.ref || element.ref;
  }
},793,[12,497,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
    value: mod,
    enumerable: true
  }) : target, mod));
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // packages/react/id/src/index.ts
  var index_exports = {};
  __export(index_exports, {
    useId: () => useId
  });
  module.exports = __toCommonJS(index_exports);

  // packages/react/id/src/id.tsx
  var React = __toESM(require(_dependencyMap[0]));
  var import_react_use_layout_effect = require(_dependencyMap[1]);
  var useReactId = React[" useId ".trim().toString()] || (() => undefined);
  var count = 0;
  function useId(deterministicId) {
    const [id, setId] = React.useState(useReactId());
    (0, import_react_use_layout_effect.useLayoutEffect)(() => {
      if (!deterministicId) setId(reactId => reactId ?? String(count++));
    }, [deterministicId]);
    return deterministicId || (id ? `radix-${id}` : "");
  }
},794,[12,795]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
    value: mod,
    enumerable: true
  }) : target, mod));
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // packages/react/use-layout-effect/src/index.ts
  var index_exports = {};
  __export(index_exports, {
    useLayoutEffect: () => useLayoutEffect2
  });
  module.exports = __toCommonJS(index_exports);

  // packages/react/use-layout-effect/src/use-layout-effect.tsx
  var React = __toESM(require(_dependencyMap[0]));
  var useLayoutEffect2 = globalThis?.document ? React.useLayoutEffect : () => {};
},795,[12]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
    value: mod,
    enumerable: true
  }) : target, mod));
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // src/index.ts
  var index_exports = {};
  __export(index_exports, {
    Primitive: () => Primitive,
    Root: () => Root,
    dispatchDiscreteCustomEvent: () => dispatchDiscreteCustomEvent
  });
  module.exports = __toCommonJS(index_exports);

  // src/primitive.tsx
  var React = __toESM(require(_dependencyMap[0]));
  var ReactDOM = __toESM(require(_dependencyMap[1]));
  var import_react_slot = require(_dependencyMap[2]);
  var import_jsx_runtime = require(_dependencyMap[3]);
  var NODES = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "select", "span", "svg", "ul"];
  var Primitive = NODES.reduce((primitive, node) => {
    const Slot = (0, import_react_slot.createSlot)(`Primitive.${node}`);
    const Node = React.forwardRef((props, forwardedRef) => {
      const {
        asChild,
        ...primitiveProps
      } = props;
      const Comp = asChild ? Slot : node;
      if (typeof window !== "undefined") {
        window[Symbol.for("radix-ui")] = true;
      }
      return /* @__PURE__ */(0, import_jsx_runtime.jsx)(Comp, {
        ...primitiveProps,
        ref: forwardedRef
      });
    });
    Node.displayName = `Primitive.${node}`;
    return {
      ...primitive,
      [node]: Node
    };
  }, {});
  function dispatchDiscreteCustomEvent(target, event) {
    if (target) ReactDOM.flushSync(() => target.dispatchEvent(event));
  }
  var Root = Primitive;
},796,[12,91,793,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
    value: mod,
    enumerable: true
  }) : target, mod));
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // packages/react/use-callback-ref/src/index.ts
  var index_exports = {};
  __export(index_exports, {
    useCallbackRef: () => useCallbackRef
  });
  module.exports = __toCommonJS(index_exports);

  // packages/react/use-callback-ref/src/use-callback-ref.tsx
  var React = __toESM(require(_dependencyMap[0]));
  function useCallbackRef(callback) {
    const callbackRef = React.useRef(callback);
    React.useEffect(() => {
      callbackRef.current = callback;
    });
    return React.useMemo(() => (...args) => callbackRef.current?.(...args), []);
  }
},797,[12]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
    value: mod,
    enumerable: true
  }) : target, mod));
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // src/index.ts
  var index_exports = {};
  __export(index_exports, {
    useControllableState: () => useControllableState,
    useControllableStateReducer: () => useControllableStateReducer
  });
  module.exports = __toCommonJS(index_exports);

  // src/use-controllable-state.tsx
  var React = __toESM(require(_dependencyMap[0]));
  var import_react_use_layout_effect = require(_dependencyMap[1]);
  var useInsertionEffect = React[" useInsertionEffect ".trim().toString()] || import_react_use_layout_effect.useLayoutEffect;
  function useControllableState({
    prop,
    defaultProp,
    onChange = () => {},
    caller
  }) {
    const [uncontrolledProp, setUncontrolledProp, onChangeRef] = useUncontrolledState({
      defaultProp,
      onChange
    });
    const isControlled = prop !== undefined;
    const value = isControlled ? prop : uncontrolledProp;
    {
      const isControlledRef = React.useRef(prop !== undefined);
      React.useEffect(() => {
        const wasControlled = isControlledRef.current;
        if (wasControlled !== isControlled) {
          const from = wasControlled ? "controlled" : "uncontrolled";
          const to = isControlled ? "controlled" : "uncontrolled";
          console.warn(`${caller} is changing from ${from} to ${to}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`);
        }
        isControlledRef.current = isControlled;
      }, [isControlled, caller]);
    }
    const setValue = React.useCallback(nextValue => {
      if (isControlled) {
        const value2 = isFunction(nextValue) ? nextValue(prop) : nextValue;
        if (value2 !== prop) {
          onChangeRef.current?.(value2);
        }
      } else {
        setUncontrolledProp(nextValue);
      }
    }, [isControlled, prop, setUncontrolledProp, onChangeRef]);
    return [value, setValue];
  }
  function useUncontrolledState({
    defaultProp,
    onChange
  }) {
    const [value, setValue] = React.useState(defaultProp);
    const prevValueRef = React.useRef(value);
    const onChangeRef = React.useRef(onChange);
    useInsertionEffect(() => {
      onChangeRef.current = onChange;
    }, [onChange]);
    React.useEffect(() => {
      if (prevValueRef.current !== value) {
        onChangeRef.current?.(value);
        prevValueRef.current = value;
      }
    }, [value, prevValueRef]);
    return [value, setValue, onChangeRef];
  }
  function isFunction(value) {
    return typeof value === "function";
  }

  // src/use-controllable-state-reducer.tsx
  var React2 = __toESM(require(_dependencyMap[0]));
  var import_react_use_effect_event = require(_dependencyMap[2]);
  var SYNC_STATE = Symbol("RADIX:SYNC_STATE");
  function useControllableStateReducer(reducer, userArgs, initialArg, init) {
    const {
      prop: controlledState,
      defaultProp,
      onChange: onChangeProp,
      caller
    } = userArgs;
    const isControlled = controlledState !== undefined;
    const onChange = (0, import_react_use_effect_event.useEffectEvent)(onChangeProp);
    {
      const isControlledRef = React2.useRef(controlledState !== undefined);
      React2.useEffect(() => {
        const wasControlled = isControlledRef.current;
        if (wasControlled !== isControlled) {
          const from = wasControlled ? "controlled" : "uncontrolled";
          const to = isControlled ? "controlled" : "uncontrolled";
          console.warn(`${caller} is changing from ${from} to ${to}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`);
        }
        isControlledRef.current = isControlled;
      }, [isControlled, caller]);
    }
    const args = [{
      ...initialArg,
      state: defaultProp
    }];
    if (init) {
      args.push(init);
    }
    const [internalState, dispatch] = React2.useReducer((state2, action) => {
      if (action.type === SYNC_STATE) {
        return {
          ...state2,
          state: action.state
        };
      }
      const next = reducer(state2, action);
      if (isControlled && !Object.is(next.state, state2.state)) {
        onChange(next.state);
      }
      return next;
    }, ...args);
    const uncontrolledState = internalState.state;
    const prevValueRef = React2.useRef(uncontrolledState);
    React2.useEffect(() => {
      if (prevValueRef.current !== uncontrolledState) {
        prevValueRef.current = uncontrolledState;
        if (!isControlled) {
          onChange(uncontrolledState);
        }
      }
    }, [onChange, uncontrolledState, prevValueRef, isControlled]);
    const state = React2.useMemo(() => {
      const isControlled2 = controlledState !== undefined;
      if (isControlled2) {
        return {
          ...internalState,
          state: controlledState
        };
      }
      return internalState;
    }, [internalState, controlledState]);
    React2.useEffect(() => {
      if (isControlled && !Object.is(controlledState, internalState.state)) {
        dispatch({
          type: SYNC_STATE,
          state: controlledState
        });
      }
    }, [controlledState, internalState.state, isControlled]);
    return [state, dispatch];
  }
},798,[12,795,799]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
    value: mod,
    enumerable: true
  }) : target, mod));
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // src/index.ts
  var index_exports = {};
  __export(index_exports, {
    useEffectEvent: () => useEffectEvent
  });
  module.exports = __toCommonJS(index_exports);

  // src/use-effect-event.tsx
  var import_react_use_layout_effect = require(_dependencyMap[0]);
  var React = __toESM(require(_dependencyMap[1]));
  var useReactEffectEvent = React[" useEffectEvent ".trim().toString()];
  var useReactInsertionEffect = React[" useInsertionEffect ".trim().toString()];
  function useEffectEvent(callback) {
    if (typeof useReactEffectEvent === "function") {
      return useReactEffectEvent(callback);
    }
    const ref = React.useRef(() => {
      throw new Error("Cannot call an event handler while rendering.");
    });
    if (typeof useReactInsertionEffect === "function") {
      useReactInsertionEffect(() => {
        ref.current = callback;
      });
    } else {
      (0, import_react_use_layout_effect.useLayoutEffect)(() => {
        ref.current = callback;
      });
    }
    return React.useMemo(() => (...args) => ref.current?.(...args), []);
  }
},799,[795,12]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
    value: mod,
    enumerable: true
  }) : target, mod));
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // packages/react/direction/src/index.ts
  var index_exports = {};
  __export(index_exports, {
    DirectionProvider: () => DirectionProvider,
    Provider: () => Provider,
    useDirection: () => useDirection
  });
  module.exports = __toCommonJS(index_exports);

  // packages/react/direction/src/direction.tsx
  var React = __toESM(require(_dependencyMap[0]));
  var import_jsx_runtime = require(_dependencyMap[1]);
  var DirectionContext = React.createContext(undefined);
  var DirectionProvider = props => {
    const {
      dir,
      children
    } = props;
    return /* @__PURE__ */(0, import_jsx_runtime.jsx)(DirectionContext.Provider, {
      value: dir,
      children
    });
  };
  function useDirection(localDir) {
    const globalDir = React.useContext(DirectionContext);
    return localDir || globalDir || "ltr";
  }
  var Provider = DirectionProvider;
},800,[12,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
  "use client";

  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all) __defProp(target, name, {
      get: all[name],
      enumerable: true
    });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from)) if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
        get: () => from[key],
        enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
      });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
    value: mod,
    enumerable: true
  }) : target, mod));
  var __toCommonJS = mod => __copyProps(__defProp({}, "__esModule", {
    value: true
  }), mod);

  // src/index.ts
  var index_exports = {};
  __export(index_exports, {
    Presence: () => Presence,
    Root: () => Root
  });
  module.exports = __toCommonJS(index_exports);

  // src/presence.tsx
  var React2 = __toESM(require(_dependencyMap[0]));
  var import_react_compose_refs = require(_dependencyMap[1]);
  var import_react_use_layout_effect = require(_dependencyMap[2]);

  // src/use-state-machine.tsx
  var React = __toESM(require(_dependencyMap[0]));
  function useStateMachine(initialState, machine) {
    return React.useReducer((state, event) => {
      const nextState = machine[state][event];
      return nextState ?? state;
    }, initialState);
  }

  // src/presence.tsx
  var Presence = props => {
    const {
      present,
      children
    } = props;
    const presence = usePresence(present);
    const child = typeof children === "function" ? children({
      present: presence.isPresent
    }) : React2.Children.only(children);
    const ref = (0, import_react_compose_refs.useComposedRefs)(presence.ref, getElementRef(child));
    const forceMount = typeof children === "function";
    return forceMount || presence.isPresent ? React2.cloneElement(child, {
      ref
    }) : null;
  };
  Presence.displayName = "Presence";
  function usePresence(present) {
    const [node, setNode] = React2.useState();
    const stylesRef = React2.useRef(null);
    const prevPresentRef = React2.useRef(present);
    const prevAnimationNameRef = React2.useRef("none");
    const initialState = present ? "mounted" : "unmounted";
    const [state, send] = useStateMachine(initialState, {
      mounted: {
        UNMOUNT: "unmounted",
        ANIMATION_OUT: "unmountSuspended"
      },
      unmountSuspended: {
        MOUNT: "mounted",
        ANIMATION_END: "unmounted"
      },
      unmounted: {
        MOUNT: "mounted"
      }
    });
    React2.useEffect(() => {
      const currentAnimationName = getAnimationName(stylesRef.current);
      prevAnimationNameRef.current = state === "mounted" ? currentAnimationName : "none";
    }, [state]);
    (0, import_react_use_layout_effect.useLayoutEffect)(() => {
      const styles = stylesRef.current;
      const wasPresent = prevPresentRef.current;
      const hasPresentChanged = wasPresent !== present;
      if (hasPresentChanged) {
        const prevAnimationName = prevAnimationNameRef.current;
        const currentAnimationName = getAnimationName(styles);
        if (present) {
          send("MOUNT");
        } else if (currentAnimationName === "none" || styles?.display === "none") {
          send("UNMOUNT");
        } else {
          const isAnimating = prevAnimationName !== currentAnimationName;
          if (wasPresent && isAnimating) {
            send("ANIMATION_OUT");
          } else {
            send("UNMOUNT");
          }
        }
        prevPresentRef.current = present;
      }
    }, [present, send]);
    (0, import_react_use_layout_effect.useLayoutEffect)(() => {
      if (node) {
        let timeoutId;
        const ownerWindow = node.ownerDocument.defaultView ?? window;
        const handleAnimationEnd = event => {
          const currentAnimationName = getAnimationName(stylesRef.current);
          const isCurrentAnimation = currentAnimationName.includes(CSS.escape(event.animationName));
          if (event.target === node && isCurrentAnimation) {
            send("ANIMATION_END");
            if (!prevPresentRef.current) {
              const currentFillMode = node.style.animationFillMode;
              node.style.animationFillMode = "forwards";
              timeoutId = ownerWindow.setTimeout(() => {
                if (node.style.animationFillMode === "forwards") {
                  node.style.animationFillMode = currentFillMode;
                }
              });
            }
          }
        };
        const handleAnimationStart = event => {
          if (event.target === node) {
            prevAnimationNameRef.current = getAnimationName(stylesRef.current);
          }
        };
        node.addEventListener("animationstart", handleAnimationStart);
        node.addEventListener("animationcancel", handleAnimationEnd);
        node.addEventListener("animationend", handleAnimationEnd);
        return () => {
          ownerWindow.clearTimeout(timeoutId);
          node.removeEventListener("animationstart", handleAnimationStart);
          node.removeEventListener("animationcancel", handleAnimationEnd);
          node.removeEventListener("animationend", handleAnimationEnd);
        };
      } else {
        send("ANIMATION_END");
      }
    }, [node, send]);
    return {
      isPresent: ["mounted", "unmountSuspended"].includes(state),
      ref: React2.useCallback(node2 => {
        stylesRef.current = node2 ? getComputedStyle(node2) : null;
        setNode(node2);
      }, [])
    };
  }
  function getAnimationName(styles) {
    return styles?.animationName || "none";
  }
  function getElementRef(element) {
    let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
    let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
    if (mayWarn) {
      return element.ref;
    }
    getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
    mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
    if (mayWarn) {
      return element.props.ref;
    }
    return element.props.ref || element.ref;
  }
  var Root = Presence;
},801,[12,497,795]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, dependencyMap) {
  module.exports = Object.assign({
    "navigationMenuTrigger": "dXbz_W_navigationMenuTrigger",
    "nativeTabsContainer": "dXbz_W_nativeTabsContainer",
    "tabBadge": "dXbz_W_tabBadge",
    "emptyTabBadge": "dXbz_W_emptyTabBadge",
    "navigationMenuRoot": "dXbz_W_navigationMenuRoot",
    "tabContent": "dXbz_W_tabContent",
    "tabText": "dXbz_W_tabText"
  }, {
    unstable_styles: {
      "navigationMenuTrigger": {
        "$$css": true,
        "_": "dXbz_W_navigationMenuTrigger"
      },
      "nativeTabsContainer": {
        "$$css": true,
        "_": "dXbz_W_nativeTabsContainer"
      },
      "tabBadge": {
        "$$css": true,
        "_": "dXbz_W_tabBadge"
      },
      "emptyTabBadge": {
        "$$css": true,
        "_": "dXbz_W_emptyTabBadge"
      },
      "navigationMenuRoot": {
        "$$css": true,
        "_": "dXbz_W_navigationMenuRoot"
      },
      "tabContent": {
        "$$css": true,
        "_": "dXbz_W_tabContent"
      },
      "tabText": {
        "$$css": true,
        "_": "dXbz_W_tabText"
      }
    }
  }, {});
},802,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  0;
  function _export(target, all) {
    for (var name in all) Object.defineProperty(target, name, {
      enumerable: true,
      get: Object.getOwnPropertyDescriptor(all, name).get
    });
  }
  _export(exports, {
    get convertIconColorPropToObject() {
      return _icon.convertIconColorPropToObject;
    },
    get convertLabelStylePropToObject() {
      return _label.convertLabelStylePropToObject;
    }
  });
  const _label = require(_dependencyMap[0]);
  const _icon = require(_dependencyMap[1]);
},803,[804,691]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  Object.defineProperty(exports, "convertLabelStylePropToObject", {
    enumerable: true,
    get: function () {
      return convertLabelStylePropToObject;
    }
  });
  function _reactnative() {
    const data = require(_dependencyMap[0]);
    _reactnative = function () {
      return data;
    };
    return data;
  }
  function convertLabelStylePropToObject(labelStyle) {
    if (labelStyle) {
      if (typeof labelStyle === 'object' && ('default' in labelStyle || 'selected' in labelStyle)) {
        return {
          default: labelStyle.default ? _reactnative().StyleSheet.flatten(labelStyle.default) : undefined,
          selected: labelStyle.selected ? _reactnative().StyleSheet.flatten(labelStyle.selected) : undefined
        };
      }
      return {
        default: _reactnative().StyleSheet.flatten(labelStyle)
      };
    }
    return {};
  }
},804,[15]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use client';
  "use strict";

  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  0;
  function _export(target, all) {
    for (var name in all) Object.defineProperty(target, name, {
      enumerable: true,
      get: Object.getOwnPropertyDescriptor(all, name).get
    });
  }
  _export(exports, {
    get BottomAccessoryPlacementContext() {
      return BottomAccessoryPlacementContext;
    },
    get usePlacement() {
      return usePlacement;
    }
  });
  function _react() {
    const data = require(_dependencyMap[0]);
    _react = function () {
      return data;
    };
    return data;
  }
  const BottomAccessoryPlacementContext = (0, _react().createContext)(undefined);
  const usePlacement = () => {
    const value = (0, _react().use)(BottomAccessoryPlacementContext);
    if (!value) {
      throw new Error('usePlacement can only be used within a <NativeTabs.BottomAccessory> component.');
    }
    return value;
  };
},805,[12]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "unstable_getMaterialSymbolSourceAsync", {
    enumerable: true,
    get: function () {
      return _materialImageSource.unstable_getMaterialSymbolSourceAsync;
    }
  });
  Object.defineProperty(exports, "SymbolView", {
    enumerable: true,
    get: function () {
      return _SymbolView.SymbolView;
    }
  });
  var _materialImageSource = require(_dependencyMap[0]);
  var _SymbolView = require(_dependencyMap[1]);
},806,[807,814]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.unstable_getMaterialSymbolSourceAsync = unstable_getMaterialSymbolSourceAsync;
  var _expoFont = require(_dependencyMap[0]);
  var _android = require(_dependencyMap[1]);
  var _utils = require(_dependencyMap[2]);
  /**
   * Renders a Material Symbol to an image source. Useful for APIs that require an `ImageSourcePropType` instead of a component, such as tab bar icons.
   *
   * @platform android
   */
  async function unstable_getMaterialSymbolSourceAsync(symbol, size, color) {
    if (!symbol) return null;
    if (typeof _expoFont.renderToImageAsync !== 'function') {
      console.warn(`Font.renderToImageAsync is not available. Please update expo-font.`);
      return null;
    }
    const fontChar = (0, _android.androidSymbolToString)(symbol);
    if (!fontChar) return null;
    const font = (0, _utils.getFont)('regular');
    await (0, _expoFont.loadAsync)({
      [font.name]: font.font
    });
    const image = await (0, _expoFont.renderToImageAsync)(fontChar, {
      fontFamily: font.name,
      size,
      color,
      lineHeight: size
    });
    return image;
  }
},807,[826,808,810]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.androidSymbolToString = androidSymbolToString;
  var _symbolsJson = require(_dependencyMap[0]);
  var symbols = _interopDefault(_symbolsJson);
  /**
   * Regenerate this file using a request captured from https://fonts.google.com/icons and this script:
   * https://gist.github.com/aleqsio/63a2f378286c727780ef6056d66d8e43
   */
  function androidSymbolToString(symbol) {
    if (!symbol) return null;
    return String.fromCharCode(symbols.default[symbol]);
  }
},808,[809]);
__d(function(global, require, _importDefaultUnused, _importAllUnused, module, exports, _dependencyMapUnused) {
  module.exports = {
  "123": 60301,
  "360": 58743,
  "10k": 59729,
  "10mp": 59730,
  "11mp": 59731,
  "12mp": 59732,
  "13mp": 59733,
  "14mp": 59734,
  "15mp": 59735,
  "16mp": 59736,
  "17mp": 59737,
  "18_up_rating": 63741,
  "18mp": 59738,
  "19mp": 59739,
  "1k": 59740,
  "1k_plus": 59741,
  "1x_mobiledata": 61389,
  "1x_mobiledata_badge": 63473,
  "20mp": 59742,
  "21mp": 59743,
  "22mp": 59744,
  "23mp": 59745,
  "24fps_select": 62450,
  "24mp": 59746,
  "2d": 61239,
  "2k": 59747,
  "2k_plus": 59748,
  "2mp": 59749,
  "30fps": 61390,
  "30fps_select": 61391,
  "3d": 60728,
  "3d_rotation": 59469,
  "3g_mobiledata": 61392,
  "3g_mobiledata_badge": 63472,
  "3k": 59750,
  "3k_plus": 59751,
  "3mp": 59752,
  "3p": 61393,
  "4g_mobiledata": 61394,
  "4g_mobiledata_badge": 63471,
  "4g_plus_mobiledata": 61395,
  "4k": 57458,
  "4k_plus": 59753,
  "4mp": 59754,
  "50mp": 63219,
  "5g": 61240,
  "5g_mobiledata_badge": 63470,
  "5k": 59755,
  "5k_plus": 59756,
  "5mp": 59757,
  "60fps": 61396,
  "60fps_select": 61397,
  "6_ft_apart": 61982,
  "6k": 59758,
  "6k_plus": 59759,
  "6mp": 59760,
  "7k": 59761,
  "7k_plus": 59762,
  "7mp": 59763,
  "8k": 59764,
  "8k_plus": 59765,
  "8mp": 59766,
  "9k": 59767,
  "9k_plus": 59768,
  "9mp": 59769,
  "abc": 60308,
  "ac_unit": 60219,
  "access_alarm": 57744,
  "access_alarms": 57745,
  "access_time": 57746,
  "access_time_filled": 61398,
  "accessibility": 59470,
  "accessibility_new": 59692,
  "accessible": 59668,
  "accessible_forward": 59700,
  "accessible_menu": 62286,
  "account_balance": 59471,
  "account_balance_wallet": 59472,
  "account_box": 59473,
  "account_child": 59474,
  "account_child_invert": 58969,
  "account_circle": 59475,
  "account_circle_off": 63411,
  "account_tree": 59770,
  "action_key": 62722,
  "activity_zone": 57830,
  "acupuncture": 62148,
  "acute": 58571,
  "ad": 58970,
  "ad_group": 58971,
  "ad_group_off": 60133,
  "ad_off": 63410,
  "ad_units": 61241,
  "adaptive_audio_mic": 62668,
  "adaptive_audio_mic_off": 62667,
  "adb": 58894,
  "add": 57669,
  "add_2": 62429,
  "add_a_photo": 58425,
  "add_ad": 59178,
  "add_alarm": 57747,
  "add_alert": 57347,
  "add_box": 57670,
  "add_business": 59177,
  "add_call": 57576,
  "add_card": 60294,
  "add_chart": 59771,
  "add_circle": 57671,
  "add_circle_outline": 57672,
  "add_column_left": 62501,
  "add_column_right": 62500,
  "add_comment": 57958,
  "add_diamond": 62620,
  "add_home": 63723,
  "add_home_work": 63725,
  "add_ic_call": 59772,
  "add_link": 57720,
  "add_location": 58727,
  "add_location_alt": 61242,
  "add_moderator": 59773,
  "add_notes": 57489,
  "add_photo_alternate": 58430,
  "add_reaction": 57811,
  "add_road": 61243,
  "add_row_above": 62499,
  "add_row_below": 62498,
  "add_shopping_cart": 59476,
  "add_task": 62010,
  "add_to_drive": 58972,
  "add_to_home_screen": 57854,
  "add_to_photos": 58269,
  "add_to_queue": 57436,
  "add_triangle": 62606,
  "addchart": 61244,
  "adf_scanner": 60122,
  "adjust": 58270,
  "admin_meds": 58509,
  "admin_panel_settings": 61245,
  "ads_click": 59234,
  "agender": 63624,
  "agriculture": 60025,
  "air": 61400,
  "air_freshener": 58058,
  "air_purifier": 59774,
  "air_purifier_gen": 59433,
  "airline_seat_flat": 58928,
  "airline_seat_flat_angled": 58929,
  "airline_seat_individual_suite": 58930,
  "airline_seat_legroom_extra": 58931,
  "airline_seat_legroom_normal": 58932,
  "airline_seat_legroom_reduced": 58933,
  "airline_seat_recline_extra": 58934,
  "airline_seat_recline_normal": 58935,
  "airline_stops": 59344,
  "airlines": 59338,
  "airplane_ticket": 61401,
  "airplanemode_active": 57749,
  "airplanemode_inactive": 57748,
  "airplay": 57429,
  "airport_shuttle": 60220,
  "airwave": 58012,
  "alarm": 59477,
  "alarm_add": 59478,
  "alarm_off": 59479,
  "alarm_on": 59480,
  "alarm_pause": 62299,
  "alarm_smart_wake": 63152,
  "album": 57369,
  "align_center": 58198,
  "align_end": 63383,
  "align_flex_center": 63382,
  "align_flex_end": 63381,
  "align_flex_start": 63380,
  "align_horizontal_center": 57359,
  "align_horizontal_left": 57357,
  "align_horizontal_right": 57360,
  "align_items_stretch": 63379,
  "align_justify_center": 63378,
  "align_justify_flex_end": 63377,
  "align_justify_flex_start": 63376,
  "align_justify_space_around": 63375,
  "align_justify_space_between": 63374,
  "align_justify_space_even": 63373,
  "align_justify_stretch": 63372,
  "align_self_stretch": 63371,
  "align_space_around": 63370,
  "align_space_between": 63369,
  "align_space_even": 63368,
  "align_start": 63367,
  "align_stretch": 63366,
  "align_vertical_bottom": 57365,
  "align_vertical_center": 57361,
  "align_vertical_top": 57356,
  "all_inbox": 59775,
  "all_inclusive": 60221,
  "all_match": 57491,
  "all_out": 59659,
  "allergies": 57492,
  "allergy": 58958,
  "alt_route": 61828,
  "alternate_email": 57574,
  "altitude": 63603,
  "ambulance": 63491,
  "amend": 63490,
  "amp_stories": 59923,
  "analytics": 61246,
  "anchor": 61901,
  "android": 59481,
  "android_cell_4_bar": 61190,
  "android_cell_4_bar_alert": 61193,
  "android_cell_4_bar_off": 61192,
  "android_cell_4_bar_plus": 61191,
  "android_cell_5_bar": 61186,
  "android_cell_5_bar_alert": 61189,
  "android_cell_5_bar_off": 61188,
  "android_cell_5_bar_plus": 61187,
  "android_cell_dual_4_bar": 61197,
  "android_cell_dual_4_bar_alert": 61199,
  "android_cell_dual_4_bar_plus": 61198,
  "android_cell_dual_5_bar": 61194,
  "android_cell_dual_5_bar_alert": 61196,
  "android_cell_dual_5_bar_plus": 61195,
  "android_wifi_3_bar": 61206,
  "android_wifi_3_bar_alert": 61211,
  "android_wifi_3_bar_lock": 61210,
  "android_wifi_3_bar_off": 61209,
  "android_wifi_3_bar_plus": 61208,
  "android_wifi_3_bar_question": 61207,
  "android_wifi_4_bar": 61200,
  "android_wifi_4_bar_alert": 61205,
  "android_wifi_4_bar_lock": 61204,
  "android_wifi_4_bar_off": 61203,
  "android_wifi_4_bar_plus": 61202,
  "android_wifi_4_bar_question": 61201,
  "animated_images": 62618,
  "animation": 59164,
  "announcement": 59482,
  "aod": 61402,
  "aod_tablet": 63647,
  "aod_watch": 63148,
  "apartment": 59968,
  "api": 61879,
  "apk_document": 63630,
  "apk_install": 63631,
  "app_badging": 63279,
  "app_blocking": 61247,
  "app_registration": 61248,
  "app_settings_alt": 61249,
  "app_shortcut": 60132,
  "apparel": 61307,
  "approval": 59778,
  "approval_delegation": 63562,
  "approval_delegation_off": 62149,
  "apps": 58819,
  "apps_outage": 59340,
  "aq": 62810,
  "aq_indoor": 62811,
  "ar_on_you": 61308,
  "ar_stickers": 59779,
  "architecture": 59963,
  "archive": 57673,
  "area_chart": 59248,
  "arming_countdown": 59274,
  "arrow_and_edge": 62935,
  "arrow_back": 58820,
  "arrow_back_2": 62522,
  "arrow_back_ios": 58848,
  "arrow_back_ios_new": 58090,
  "arrow_circle_down": 61825,
  "arrow_circle_left": 60071,
  "arrow_circle_right": 60074,
  "arrow_circle_up": 61826,
  "arrow_cool_down": 62646,
  "arrow_downward": 58843,
  "arrow_downward_alt": 59780,
  "arrow_drop_down": 58821,
  "arrow_drop_down_circle": 58822,
  "arrow_drop_up": 58823,
  "arrow_forward": 58824,
  "arrow_forward_ios": 58849,
  "arrow_insert": 63543,
  "arrow_left": 58846,
  "arrow_left_alt": 61309,
  "arrow_menu_close": 62419,
  "arrow_menu_open": 62418,
  "arrow_or_edge": 62934,
  "arrow_outward": 63694,
  "arrow_range": 63131,
  "arrow_right": 58847,
  "arrow_right_alt": 59713,
  "arrow_selector_tool": 63535,
  "arrow_shape_up": 61174,
  "arrow_shape_up_stack": 61175,
  "arrow_shape_up_stack_2": 61176,
  "arrow_split": 59781,
  "arrow_top_left": 63278,
  "arrow_top_right": 63277,
  "arrow_upload_progress": 62452,
  "arrow_upload_ready": 62453,
  "arrow_upward": 58840,
  "arrow_upward_alt": 59782,
  "arrow_warm_up": 62645,
  "arrows_input": 62356,
  "arrows_more_down": 63659,
  "arrows_more_up": 63660,
  "arrows_output": 62355,
  "arrows_outward": 63276,
  "art_track": 57440,
  "article": 61250,
  "article_person": 62312,
  "article_shortcut": 62855,
  "artist": 57370,
  "aspect_ratio": 59483,
  "assessment": 59484,
  "assignment": 59485,
  "assignment_add": 63560,
  "assignment_ind": 59486,
  "assignment_late": 59487,
  "assignment_return": 59488,
  "assignment_returned": 59489,
  "assignment_turned_in": 59490,
  "assist_walker": 63701,
  "assistant": 58271,
  "assistant_device": 59783,
  "assistant_direction": 59784,
  "assistant_navigation": 59785,
  "assistant_on_hub": 63169,
  "assistant_photo": 58272,
  "assured_workload": 60271,
  "asterisk": 62757,
  "atm": 58739,
  "atr": 60359,
  "attach_email": 59998,
  "attach_file": 57894,
  "attach_file_add": 63553,
  "attach_file_off": 62681,
  "attach_money": 57895,
  "attachment": 58044,
  "attractions": 59986,
  "attribution": 61403,
  "audio_description": 62860,
  "audio_file": 60290,
  "audio_video_receiver": 62931,
  "audiotrack": 58273,
  "auto_awesome": 58975,
  "auto_awesome_mosaic": 58976,
  "auto_awesome_motion": 58977,
  "auto_delete": 59980,
  "auto_fix_high": 58979,
  "auto_fix_normal": 58980,
  "auto_fix_off": 58981,
  "auto_graph": 58619,
  "auto_mode": 60448,
  "auto_read_pause": 61977,
  "auto_read_play": 61974,
  "auto_stories": 58982,
  "auto_stories_off": 62055,
  "auto_towing": 59166,
  "auto_transmission": 62783,
  "autofps_select": 61404,
  "automation": 62497,
  "autopause": 63158,
  "autoplay": 63157,
  "autorenew": 59491,
  "autostop": 63106,
  "av1": 62640,
  "av_timer": 57371,
  "avc": 62639,
  "avg_pace": 63163,
  "avg_time": 63507,
  "award_meal": 62017,
  "award_star": 62994,
  "azm": 63212,
  "baby_changing_station": 61851,
  "back_hand": 59236,
  "back_to_tab": 63275,
  "background_dot_large": 63390,
  "background_dot_small": 62740,
  "background_grid_small": 63389,
  "background_replace": 61962,
  "backlight_high": 63469,
  "backlight_high_off": 62703,
  "backlight_low": 63468,
  "backpack": 61852,
  "backspace": 57674,
  "backup": 59492,
  "backup_table": 61251,
  "badge": 60007,
  "badge_critical_battery": 61767,
  "badminton": 62120,
  "bakery_dining": 59987,
  "balance": 60150,
  "balcony": 58767,
  "ballot": 57714,
  "bar_chart": 57963,
  "bar_chart_4_bars": 63105,
  "bar_chart_off": 62481,
  "barcode": 59147,
  "barcode_reader": 63580,
  "barcode_scanner": 59148,
  "barefoot": 63601,
  "batch_prediction": 61685,
  "bath_bedrock": 62086,
  "bath_outdoor": 63227,
  "bath_private": 63226,
  "bath_public_large": 63225,
  "bath_soak": 62112,
  "bathroom": 61405,
  "bathtub": 59969,
  "battery_0_bar": 60380,
  "battery_1_bar": 60377,
  "battery_20": 61596,
  "battery_2_bar": 60384,
  "battery_30": 61597,
  "battery_3_bar": 60381,
  "battery_4_bar": 60386,
  "battery_50": 61598,
  "battery_5_bar": 60372,
  "battery_60": 61599,
  "battery_6_bar": 60370,
  "battery_80": 61600,
  "battery_90": 61601,
  "battery_alert": 57756,
  "battery_android_0": 62221,
  "battery_android_1": 62220,
  "battery_android_2": 62219,
  "battery_android_3": 62218,
  "battery_android_4": 62217,
  "battery_android_5": 62216,
  "battery_android_6": 62215,
  "battery_android_alert": 62214,
  "battery_android_bolt": 62213,
  "battery_android_frame_1": 62039,
  "battery_android_frame_2": 62038,
  "battery_android_frame_3": 62037,
  "battery_android_frame_4": 62036,
  "battery_android_frame_5": 62035,
  "battery_android_frame_6": 62034,
  "battery_android_frame_alert": 62033,
  "battery_android_frame_bolt": 62032,
  "battery_android_frame_full": 62031,
  "battery_android_frame_plus": 62030,
  "battery_android_frame_question": 62029,
  "battery_android_frame_share": 62028,
  "battery_android_frame_shield": 62027,
  "battery_android_full": 62212,
  "battery_android_plus": 62211,
  "battery_android_question": 62210,
  "battery_android_share": 62209,
  "battery_android_shield": 62208,
  "battery_change": 63467,
  "battery_charging_20": 61602,
  "battery_charging_30": 61603,
  "battery_charging_50": 61604,
  "battery_charging_60": 61605,
  "battery_charging_80": 61606,
  "battery_charging_90": 61607,
  "battery_charging_full": 57763,
  "battery_error": 63466,
  "battery_full": 57764,
  "battery_full_alt": 61755,
  "battery_horiz_000": 63662,
  "battery_horiz_050": 63663,
  "battery_horiz_075": 63664,
  "battery_low": 61781,
  "battery_plus": 63465,
  "battery_profile": 57862,
  "battery_saver": 61406,
  "battery_share": 63102,
  "battery_status_good": 63101,
  "battery_std": 57765,
  "battery_unknown": 57766,
  "battery_very_low": 61782,
  "beach_access": 60222,
  "bed": 61407,
  "bedroom_baby": 61408,
  "bedroom_child": 61409,
  "bedroom_parent": 61410,
  "bedtime": 61252,
  "bedtime_off": 60278,
  "beenhere": 58669,
  "beer_meal": 62085,
  "bento": 61940,
  "bia": 63211,
  "bid_landscape": 58983,
  "bid_landscape_disabled": 61313,
  "bigtop_updates": 58985,
  "bike_dock": 62587,
  "bike_lane": 62586,
  "bike_scooter": 61253,
  "biotech": 59962,
  "blanket": 59432,
  "blender": 61411,
  "blind": 63702,
  "blinds": 57990,
  "blinds_closed": 60447,
  "block": 57675,
  "block_flipped": 61254,
  "blood_pressure": 57495,
  "bloodtype": 61412,
  "bluetooth": 57767,
  "bluetooth_audio": 58895,
  "bluetooth_connected": 57768,
  "bluetooth_disabled": 57769,
  "bluetooth_drive": 61413,
  "bluetooth_searching": 57770,
  "blur_circular": 58274,
  "blur_linear": 58275,
  "blur_medium": 59468,
  "blur_off": 58276,
  "blur_on": 58277,
  "blur_short": 59599,
  "boat_bus": 62317,
  "boat_railway": 62316,
  "body_fat": 57496,
  "body_system": 57497,
  "bolt": 59915,
  "bomb": 62824,
  "book": 59493,
  "book_2": 62782,
  "book_3": 62781,
  "book_4": 62780,
  "book_5": 62779,
  "book_6": 62431,
  "book_online": 61975,
  "book_ribbon": 62439,
  "bookmark": 59494,
  "bookmark_add": 58776,
  "bookmark_added": 58777,
  "bookmark_bag": 62480,
  "bookmark_border": 59495,
  "bookmark_check": 62551,
  "bookmark_flag": 62550,
  "bookmark_heart": 62549,
  "bookmark_manager": 63409,
  "bookmark_remove": 58778,
  "bookmark_star": 62548,
  "bookmarks": 59787,
  "books_movies_and_music": 61314,
  "border_all": 57896,
  "border_bottom": 57897,
  "border_clear": 57898,
  "border_color": 57899,
  "border_horizontal": 57900,
  "border_inner": 57901,
  "border_left": 57902,
  "border_outer": 57903,
  "border_right": 57904,
  "border_style": 57905,
  "border_top": 57906,
  "border_vertical": 57907,
  "borg": 62477,
  "bottom_app_bar": 59184,
  "bottom_drawer": 59181,
  "bottom_navigation": 59788,
  "bottom_panel_close": 63274,
  "bottom_panel_open": 63273,
  "bottom_right_click": 63108,
  "bottom_sheets": 59789,
  "box": 62884,
  "box_add": 62885,
  "box_edit": 62886,
  "boy": 60263,
  "brand_awareness": 59790,
  "brand_family": 62705,
  "branding_watermark": 57451,
  "breakfast_dining": 59988,
  "breaking_news": 59912,
  "breaking_news_alt_1": 61626,
  "breastfeeding": 63574,
  "brick": 62344,
  "briefcase_meal": 62022,
  "brightness_1": 58278,
  "brightness_2": 58279,
  "brightness_3": 58280,
  "brightness_4": 58281,
  "brightness_5": 58282,
  "brightness_6": 58283,
  "brightness_7": 58284,
  "brightness_alert": 62927,
  "brightness_auto": 57771,
  "brightness_empty": 63464,
  "brightness_high": 57772,
  "brightness_low": 57773,
  "brightness_medium": 57774,
  "bring_your_own_ip": 57366,
  "broadcast_on_home": 63736,
  "broadcast_on_personal": 63737,
  "broken_image": 58285,
  "browse": 60179,
  "browse_activity": 63653,
  "browse_gallery": 60369,
  "browser_not_supported": 61255,
  "browser_updated": 59343,
  "brunch_dining": 60019,
  "brush": 58286,
  "bubble": 61315,
  "bubble_chart": 59101,
  "bubbles": 63054,
  "bucket_check": 61226,
  "bug_report": 59496,
  "build": 59497,
  "build_circle": 61256,
  "bungalow": 58769,
  "burst_mode": 58428,
  "bus_alert": 59791,
  "bus_railway": 62315,
  "business": 57519,
  "business_center": 60223,
  "business_chip": 63564,
  "business_messages": 61316,
  "buttons_alt": 59183,
  "cabin": 58761,
  "cable": 61414,
  "cable_car": 62585,
  "cached": 59498,
  "cadence": 62644,
  "cake": 59369,
  "cake_add": 63579,
  "calculate": 59999,
  "calendar_add_on": 61317,
  "calendar_apps_script": 61627,
  "calendar_check": 62019,
  "calendar_clock": 62784,
  "calendar_lock": 62018,
  "calendar_meal": 62102,
  "calendar_meal_2": 62016,
  "calendar_month": 60364,
  "calendar_today": 59701,
  "calendar_view_day": 59702,
  "calendar_view_month": 61415,
  "calendar_view_week": 61416,
  "call": 57520,
  "call_end": 57521,
  "call_log": 57486,
  "call_made": 57522,
  "call_merge": 57523,
  "call_missed": 57524,
  "call_missed_outgoing": 57572,
  "call_quality": 63058,
  "call_received": 57525,
  "call_split": 57526,
  "call_to_action": 57452,
  "camera": 58287,
  "camera_alt": 58288,
  "camera_enhance": 59644,
  "camera_front": 58289,
  "camera_indoor": 61417,
  "camera_outdoor": 61418,
  "camera_rear": 58290,
  "camera_roll": 58291,
  "camera_video": 63398,
  "cameraswitch": 61419,
  "campaign": 61257,
  "camping": 63650,
  "cancel": 58825,
  "cancel_presentation": 57577,
  "cancel_schedule_send": 59961,
  "candle": 62856,
  "candlestick_chart": 60116,
  "cannabis": 62195,
  "captive_portal": 63272,
  "capture": 63271,
  "car_crash": 60402,
  "car_defrost_left": 62276,
  "car_defrost_low_left": 62275,
  "car_defrost_low_right": 62274,
  "car_defrost_mid_left": 62072,
  "car_defrost_mid_low_left": 62273,
  "car_defrost_mid_low_right": 62071,
  "car_defrost_mid_right": 62272,
  "car_defrost_right": 62271,
  "car_fan_low_left": 62270,
  "car_fan_low_mid_left": 62269,
  "car_fan_low_right": 62268,
  "car_fan_mid_left": 62267,
  "car_fan_mid_low_right": 62266,
  "car_fan_mid_right": 62265,
  "car_fan_recirculate": 62264,
  "car_gear": 62263,
  "car_lock": 62262,
  "car_mirror_heat": 62261,
  "car_rental": 59989,
  "car_repair": 59990,
  "car_tag": 62691,
  "card_giftcard": 59638,
  "card_membership": 59639,
  "card_travel": 59640,
  "cardio_load": 62649,
  "cardiology": 57500,
  "cards": 59793,
  "cards_star": 62325,
  "carpenter": 61944,
  "carry_on_bag": 60168,
  "carry_on_bag_checked": 60171,
  "carry_on_bag_inactive": 60170,
  "carry_on_bag_question": 60169,
  "cases": 59794,
  "casino": 60224,
  "cast": 58119,
  "cast_connected": 58120,
  "cast_for_education": 61420,
  "cast_pause": 62960,
  "cast_warning": 62959,
  "castle": 60081,
  "catching_pokemon": 58632,
  "category": 58740,
  "category_search": 62519,
  "celebration": 60005,
  "cell_merge": 63534,
  "cell_tower": 60346,
  "cell_wifi": 57580,
  "center_focus_strong": 58292,
  "center_focus_weak": 58293,
  "chair": 61421,
  "chair_alt": 61422,
  "chair_counter": 62111,
  "chair_fireplace": 62110,
  "chair_umbrella": 62109,
  "chalet": 58757,
  "change_circle": 58087,
  "change_history": 59499,
  "charger": 58030,
  "charging_station": 61853,
  "chart_data": 58483,
  "chat": 57527,
  "chat_add_on": 61683,
  "chat_apps_script": 61629,
  "chat_bubble": 57546,
  "chat_bubble_outline": 57547,
  "chat_error": 63404,
  "chat_info": 62763,
  "chat_paste_go": 63165,
  "chat_paste_go_2": 62411,
  "check": 58826,
  "check_box": 59444,
  "check_box_outline_blank": 59445,
  "check_circle": 59500,
  "check_circle_outline": 59693,
  "check_circle_unread": 62078,
  "check_in_out": 63222,
  "check_indeterminate_small": 63626,
  "check_small": 63627,
  "checkbook": 59149,
  "checked_bag": 60172,
  "checked_bag_question": 60173,
  "checklist": 59057,
  "checklist_rtl": 59059,
  "checkroom": 61854,
  "cheer": 63144,
  "chef_hat": 62295,
  "chess": 62951,
  "chess_bishop": 62049,
  "chess_bishop_2": 62050,
  "chess_king": 62047,
  "chess_king_2": 62048,
  "chess_knight": 62046,
  "chess_pawn": 62390,
  "chess_pawn_2": 62045,
  "chess_queen": 62044,
  "chess_rook": 62043,
  "chevron_backward": 62571,
  "chevron_forward": 62570,
  "chevron_left": 58827,
  "chevron_right": 58828,
  "child_care": 60225,
  "child_friendly": 60226,
  "child_hat": 61232,
  "chip_extraction": 63521,
  "chips": 59795,
  "chrome_reader_mode": 59501,
  "chromecast_2": 61819,
  "chromecast_device": 59452,
  "chronic": 60338,
  "church": 60078,
  "cinematic_blur": 63571,
  "circle": 61258,
  "circle_notifications": 59796,
  "circles": 59370,
  "circles_ext": 59372,
  "clarify": 61631,
  "class": 59502,
  "clean_hands": 61983,
  "cleaning": 59797,
  "cleaning_bucket": 63668,
  "cleaning_services": 61695,
  "clear": 57676,
  "clear_all": 57528,
  "clear_day": 61783,
  "climate_mini_split": 63669,
  "clinical_notes": 57502,
  "clock_arrow_down": 62338,
  "clock_arrow_up": 62337,
  "clock_loader_10": 63270,
  "clock_loader_20": 63269,
  "clock_loader_40": 63268,
  "clock_loader_60": 63267,
  "clock_loader_80": 63266,
  "clock_loader_90": 63265,
  "close": 58829,
  "close_fullscreen": 61903,
  "close_small": 62728,
  "closed_caption": 57372,
  "closed_caption_add": 62638,
  "closed_caption_disabled": 61916,
  "closed_caption_off": 59798,
  "cloud": 58045,
  "cloud_alert": 62412,
  "cloud_circle": 58046,
  "cloud_done": 58047,
  "cloud_download": 58048,
  "cloud_lock": 62342,
  "cloud_off": 58049,
  "cloud_queue": 58050,
  "cloud_sync": 60250,
  "cloud_upload": 58051,
  "cloudy_snowing": 59408,
  "co2": 59312,
  "co_present": 60144,
  "code": 59503,
  "code_blocks": 63565,
  "code_off": 58611,
  "coffee": 61423,
  "coffee_maker": 61424,
  "cognition": 57503,
  "cognition_2": 62389,
  "collapse_all": 59716,
  "collapse_content": 62727,
  "collections": 58294,
  "collections_bookmark": 58417,
  "color_lens": 58295,
  "colorize": 58296,
  "colors": 59799,
  "combine_columns": 62496,
  "comedy_mask": 62678,
  "comic_bubble": 62941,
  "comment": 57529,
  "comment_bank": 59982,
  "comments_disabled": 59298,
  "commit": 60149,
  "communication": 57980,
  "communities": 59373,
  "commute": 59712,
  "compare": 58297,
  "compare_arrows": 59669,
  "compass_calibration": 58748,
  "component_exchange": 61927,
  "compost": 59233,
  "compress": 59725,
  "computer": 58122,
  "computer_arrow_up": 62199,
  "computer_cancel": 62198,
  "concierge": 62817,
  "conditions": 57504,
  "confirmation_number": 58936,
  "congenital": 57505,
  "connect_without_contact": 61987,
  "connected_tv": 59800,
  "connecting_airports": 59337,
  "construction": 59964,
  "contact_emergency": 63697,
  "contact_mail": 57552,
  "contact_page": 61998,
  "contact_phone": 57551,
  "contact_support": 59724,
  "contactless": 60017,
  "contactless_off": 63576,
  "contacts": 57530,
  "contacts_product": 59801,
  "content_copy": 57677,
  "content_cut": 57678,
  "content_paste": 57679,
  "content_paste_go": 60046,
  "content_paste_off": 58616,
  "content_paste_search": 60059,
  "contextual_token": 62598,
  "contextual_token_add": 62597,
  "contract": 62880,
  "contract_delete": 62882,
  "contract_edit": 62881,
  "contrast": 60215,
  "contrast_circle": 62623,
  "contrast_rtl_off": 60530,
  "contrast_square": 62624,
  "control_camera": 57460,
  "control_point": 58298,
  "control_point_duplicate": 58299,
  "controller_gen": 59453,
  "conversation": 61231,
  "conversion_path": 61633,
  "conversion_path_off": 63412,
  "convert_to_text": 62495,
  "conveyor_belt": 63591,
  "cookie": 60076,
  "cookie_off": 63386,
  "cooking": 58038,
  "cool_to_dry": 57974,
  "copy_all": 58092,
  "copyright": 59660,
  "coronavirus": 61985,
  "corporate_fare": 61904,
  "cottage": 58759,
  "counter_0": 63365,
  "counter_1": 63364,
  "counter_2": 63363,
  "counter_3": 63362,
  "counter_4": 63361,
  "counter_5": 63360,
  "counter_6": 63359,
  "counter_7": 63358,
  "counter_8": 63357,
  "counter_9": 63356,
  "countertops": 61943,
  "create": 57680,
  "create_new_folder": 58060,
  "credit_card": 59504,
  "credit_card_clock": 62520,
  "credit_card_gear": 62765,
  "credit_card_heart": 62764,
  "credit_card_off": 58612,
  "credit_score": 61425,
  "crib": 58760,
  "crisis_alert": 60393,
  "crop": 58302,
  "crop_16_9": 58300,
  "crop_3_2": 58301,
  "crop_5_4": 58303,
  "crop_7_5": 58304,
  "crop_9_16": 62793,
  "crop_din": 58305,
  "crop_free": 58306,
  "crop_landscape": 58307,
  "crop_original": 58308,
  "crop_portrait": 58309,
  "crop_rotate": 58423,
  "crop_square": 58310,
  "crossword": 62949,
  "crowdsource": 60184,
  "crown": 60595,
  "cruelty_free": 59289,
  "css": 60307,
  "csv": 59087,
  "currency_bitcoin": 60357,
  "currency_exchange": 60272,
  "currency_franc": 60154,
  "currency_lira": 60143,
  "currency_pound": 60145,
  "currency_ruble": 60140,
  "currency_rupee": 60151,
  "currency_rupee_circle": 62560,
  "currency_yen": 60155,
  "currency_yuan": 60153,
  "curtains": 60446,
  "curtains_closed": 60445,
  "custom_typography": 59186,
  "cycle": 63572,
  "cyclone": 60373,
  "dangerous": 59802,
  "dark_mode": 58652,
  "dashboard": 59505,
  "dashboard_2": 62442,
  "dashboard_customize": 59803,
  "data_alert": 63478,
  "data_array": 60113,
  "data_check": 63474,
  "data_exploration": 59247,
  "data_info_alert": 63477,
  "data_loss_prevention": 58076,
  "data_object": 60115,
  "data_saver_off": 61426,
  "data_saver_on": 61427,
  "data_table": 59804,
  "data_thresholding": 60319,
  "data_usage": 57775,
  "database": 61966,
  "database_off": 62484,
  "database_search": 62350,
  "database_upload": 62428,
  "dataset": 63726,
  "dataset_linked": 63727,
  "date_range": 59670,
  "deblur": 60279,
  "deceased": 57509,
  "decimal_decrease": 63533,
  "decimal_increase": 63532,
  "deck": 59970,
  "dehaze": 58311,
  "delete": 59506,
  "delete_forever": 59691,
  "delete_history": 62744,
  "delete_outline": 59694,
  "delete_sweep": 57708,
  "delivery_dining": 60018,
  "delivery_truck_bolt": 62370,
  "delivery_truck_speed": 62369,
  "demography": 58505,
  "density_large": 60329,
  "density_medium": 60318,
  "density_small": 60328,
  "dentistry": 57510,
  "departure_board": 58742,
  "deployed_code": 63264,
  "deployed_code_account": 62747,
  "deployed_code_alert": 62962,
  "deployed_code_history": 62963,
  "deployed_code_update": 62964,
  "dermatology": 57511,
  "description": 59507,
  "deselect": 60342,
  "design_services": 61706,
  "desk": 63732,
  "deskphone": 63482,
  "desktop_access_disabled": 59805,
  "desktop_cloud": 62427,
  "desktop_cloud_stack": 62398,
  "desktop_landscape": 62558,
  "desktop_landscape_add": 62521,
  "desktop_mac": 58123,
  "desktop_portrait": 62557,
  "desktop_windows": 58124,
  "destruction": 62853,
  "details": 58312,
  "detection_and_zone": 58015,
  "detector": 57986,
  "detector_alarm": 57847,
  "detector_battery": 57860,
  "detector_co": 58031,
  "detector_offline": 57891,
  "detector_smoke": 57989,
  "detector_status": 57832,
  "developer_board": 58125,
  "developer_board_off": 58623,
  "developer_guide": 59806,
  "developer_mode": 57776,
  "developer_mode_tv": 59508,
  "device_band": 62197,
  "device_hub": 58165,
  "device_thermostat": 57855,
  "device_unknown": 58169,
  "devices": 57777,
  "devices_fold": 60382,
  "devices_fold_2": 62470,
  "devices_off": 63397,
  "devices_other": 58167,
  "devices_wearables": 63147,
  "dew_point": 63609,
  "diagnosis": 57512,
  "diagonal_line": 62494,
  "dialer_sip": 57531,
  "dialogs": 59807,
  "dialpad": 57532,
  "diamond": 60117,
  "diamond_shine": 62130,
  "dictionary": 62777,
  "difference": 60285,
  "digital_out_of_home": 61918,
  "digital_wellbeing": 61318,
  "dine_heart": 62108,
  "dine_in": 62101,
  "dine_lamp": 62107,
  "dining": 61428,
  "dinner_dining": 59991,
  "directions": 58670,
  "directions_alt": 63616,
  "directions_alt_off": 63617,
  "directions_bike": 58671,
  "directions_boat": 58674,
  "directions_boat_filled": 61429,
  "directions_bus": 58672,
  "directions_bus_filled": 61430,
  "directions_car": 58673,
  "directions_car_filled": 61431,
  "directions_off": 61711,
  "directions_railway": 58676,
  "directions_railway_2": 62562,
  "directions_railway_filled": 61432,
  "directions_run": 58726,
  "directions_subway": 58675,
  "directions_subway_filled": 61433,
  "directions_transit": 58677,
  "directions_transit_filled": 61434,
  "directions_walk": 58678,
  "directory_sync": 58260,
  "dirty_lens": 61259,
  "disabled_by_default": 62000,
  "disabled_visible": 59246,
  "disc_full": 58896,
  "discount": 60361,
  "discover_tune": 57368,
  "dishwasher": 59808,
  "dishwasher_gen": 59442,
  "display_external_input": 63463,
  "display_settings": 60311,
  "distance": 63210,
  "diversity_1": 63703,
  "diversity_2": 63704,
  "diversity_3": 63705,
  "diversity_4": 63575,
  "dns": 59509,
  "do_disturb": 61580,
  "do_disturb_alt": 61581,
  "do_disturb_off": 61582,
  "do_disturb_on": 61583,
  "do_not_disturb": 58898,
  "do_not_disturb_alt": 58897,
  "do_not_disturb_off": 58947,
  "do_not_disturb_on": 58948,
  "do_not_disturb_on_total_silence": 61435,
  "do_not_step": 61855,
  "do_not_touch": 61872,
  "dock": 58126,
  "dock_to_bottom": 63462,
  "dock_to_left": 63461,
  "dock_to_right": 63460,
  "docs": 60029,
  "docs_add_on": 61634,
  "docs_apps_script": 61635,
  "document_scanner": 58874,
  "document_search": 62341,
  "domain": 59374,
  "domain_add": 60258,
  "domain_disabled": 57583,
  "domain_verification": 61260,
  "domain_verification_off": 63408,
  "domino_mask": 62948,
  "done": 59510,
  "done_all": 59511,
  "done_outline": 59695,
  "donut_large": 59671,
  "donut_small": 59672,
  "door_back": 61436,
  "door_front": 61437,
  "door_open": 59260,
  "door_sensor": 57994,
  "door_sliding": 61438,
  "doorbell": 61439,
  "doorbell_3p": 57831,
  "doorbell_chime": 57843,
  "double_arrow": 59984,
  "downhill_skiing": 58633,
  "download": 61584,
  "download_2": 62755,
  "download_done": 61585,
  "download_for_offline": 61440,
  "downloading": 61441,
  "draft": 58989,
  "draft_orders": 59315,
  "drafts": 57681,
  "drag_click": 63263,
  "drag_handle": 57949,
  "drag_indicator": 59717,
  "drag_pan": 63262,
  "draw": 59206,
  "draw_abstract": 63480,
  "draw_collage": 63479,
  "dresser": 57872,
  "drive_eta": 58899,
  "drive_export": 62493,
  "drive_file_move": 58997,
  "drive_file_move_outline": 59809,
  "drive_file_move_rtl": 59245,
  "drive_file_rename_outline": 59810,
  "drive_folder_upload": 59811,
  "drone": 62042,
  "drone_2": 62041,
  "dropdown": 59812,
  "dropper_eye": 62289,
  "dry": 61875,
  "dry_cleaning": 59992,
  "dual_screen": 63183,
  "duo": 59813,
  "dvr": 57778,
  "dynamic_feed": 59924,
  "dynamic_form": 61887,
  "e911_avatar": 61722,
  "e911_emergency": 61721,
  "e_mobiledata": 61442,
  "e_mobiledata_badge": 63459,
  "ear_sound": 62294,
  "earbud_case": 62247,
  "earbud_left": 62246,
  "earbud_right": 62245,
  "earbuds": 61443,
  "earbuds_2": 62244,
  "earbuds_battery": 61444,
  "early_on": 58042,
  "earthquake": 63055,
  "east": 61919,
  "ecg": 63503,
  "ecg_heart": 63209,
  "eco": 59957,
  "eda": 63208,
  "edgesensor_high": 61445,
  "edgesensor_low": 61446,
  "edit": 58313,
  "edit_arrow_down": 62336,
  "edit_arrow_up": 62335,
  "edit_attributes": 58744,
  "edit_audio": 62509,
  "edit_calendar": 59202,
  "edit_document": 63628,
  "edit_location": 58728,
  "edit_location_alt": 57797,
  "edit_note": 59205,
  "edit_notifications": 58661,
  "edit_off": 59728,
  "edit_road": 61261,
  "edit_square": 63629,
  "editor_choice": 62760,
  "egg": 60108,
  "egg_alt": 60104,
  "eject": 59643,
  "elderly": 61978,
  "elderly_woman": 60265,
  "electric_bike": 60187,
  "electric_bolt": 60444,
  "electric_car": 60188,
  "electric_meter": 60443,
  "electric_moped": 60189,
  "electric_rickshaw": 60190,
  "electric_scooter": 60191,
  "electrical_services": 61698,
  "elevation": 63207,
  "elevator": 61856,
  "email": 57534,
  "emergency": 57835,
  "emergency_heat": 61789,
  "emergency_heat_2": 62693,
  "emergency_home": 59434,
  "emergency_recording": 60404,
  "emergency_share": 60406,
  "emergency_share_off": 62878,
  "emoji_emotions": 59938,
  "emoji_events": 59939,
  "emoji_food_beverage": 59931,
  "emoji_language": 62669,
  "emoji_nature": 59932,
  "emoji_objects": 59940,
  "emoji_people": 59933,
  "emoji_symbols": 59934,
  "emoji_transportation": 59935,
  "emoticon": 58867,
  "empty_dashboard": 63556,
  "enable": 61832,
  "encrypted": 58771,
  "encrypted_add": 62505,
  "encrypted_add_circle": 62506,
  "encrypted_minus_circle": 62504,
  "encrypted_off": 62503,
  "endocrinology": 57513,
  "energy": 59814,
  "energy_program_saving": 61791,
  "energy_program_time_used": 61793,
  "energy_savings_leaf": 60442,
  "engineering": 59965,
  "enhanced_encryption": 58943,
  "ent": 57514,
  "enterprise": 59150,
  "enterprise_off": 60237,
  "equal": 63355,
  "equalizer": 57373,
  "eraser_size_1": 62460,
  "eraser_size_2": 62459,
  "eraser_size_3": 62458,
  "eraser_size_4": 62457,
  "eraser_size_5": 62456,
  "error": 57344,
  "error_med": 58523,
  "error_outline": 57345,
  "escalator": 61857,
  "escalator_warning": 61868,
  "euro": 59925,
  "euro_symbol": 59686,
  "ev_mobiledata_badge": 63458,
  "ev_shadow": 61327,
  "ev_shadow_add": 62848,
  "ev_shadow_minus": 62847,
  "ev_station": 58733,
  "event": 59512,
  "event_available": 58900,
  "event_busy": 58901,
  "event_list": 63107,
  "event_note": 58902,
  "event_repeat": 60283,
  "event_seat": 59651,
  "event_upcoming": 62008,
  "exclamation": 61999,
  "exercise": 63206,
  "exit_to_app": 59513,
  "expand": 59727,
  "expand_all": 59718,
  "expand_circle_down": 59341,
  "expand_circle_right": 62865,
  "expand_circle_up": 62930,
  "expand_content": 63536,
  "expand_less": 58830,
  "expand_more": 58831,
  "expansion_panels": 58880,
  "experiment": 59014,
  "explicit": 57374,
  "explore": 59514,
  "explore_nearby": 58680,
  "explore_off": 59816,
  "explosion": 63109,
  "export_notes": 57516,
  "exposure": 58314,
  "exposure_neg_1": 58315,
  "exposure_neg_2": 58316,
  "exposure_plus_1": 58317,
  "exposure_plus_2": 58318,
  "exposure_zero": 58319,
  "extension": 59515,
  "extension_off": 58613,
  "eye_tracking": 62665,
  "eyeglasses": 63214,
  "eyeglasses_2": 62151,
  "eyeglasses_2_sound": 62053,
  "face": 59516,
  "face_2": 63706,
  "face_3": 63707,
  "face_4": 63708,
  "face_5": 63709,
  "face_6": 63710,
  "face_down": 62466,
  "face_left": 62465,
  "face_nod": 62464,
  "face_retouching_natural": 61262,
  "face_retouching_off": 61447,
  "face_right": 62463,
  "face_shake": 62462,
  "face_unlock": 61448,
  "face_up": 62461,
  "fact_check": 61637,
  "factory": 60348,
  "falling": 62989,
  "familiar_face_and_zone": 57884,
  "family_group": 61170,
  "family_history": 57517,
  "family_home": 60198,
  "family_link": 60185,
  "family_restroom": 61858,
  "family_star": 62759,
  "fan_focus": 62260,
  "fan_indirect": 62259,
  "farsight_digital": 62809,
  "fast_forward": 57375,
  "fast_rewind": 57376,
  "fastfood": 58746,
  "faucet": 57976,
  "favorite": 59517,
  "favorite_border": 59518,
  "fax": 60120,
  "feature_search": 59817,
  "featured_play_list": 57453,
  "featured_seasonal_and_gifts": 61329,
  "featured_video": 57454,
  "feed": 61449,
  "feedback": 59519,
  "female": 58768,
  "femur": 63633,
  "femur_alt": 63634,
  "fence": 61942,
  "fertile": 63205,
  "festival": 60008,
  "fiber_dvr": 57437,
  "fiber_manual_record": 57441,
  "fiber_new": 57438,
  "fiber_pin": 57450,
  "fiber_smart_record": 57442,
  "file_copy": 57715,
  "file_copy_off": 62680,
  "file_download": 58052,
  "file_download_done": 59818,
  "file_download_off": 58622,
  "file_export": 62386,
  "file_json": 62395,
  "file_map": 58053,
  "file_map_stack": 62434,
  "file_open": 60147,
  "file_png": 62396,
  "file_present": 59918,
  "file_save": 61823,
  "file_save_off": 58629,
  "file_upload": 58054,
  "file_upload_off": 63622,
  "files": 60037,
  "filter": 58323,
  "filter_1": 58320,
  "filter_2": 58321,
  "filter_3": 58322,
  "filter_4": 58324,
  "filter_5": 58325,
  "filter_6": 58326,
  "filter_7": 58327,
  "filter_8": 58328,
  "filter_9": 58329,
  "filter_9_plus": 58330,
  "filter_alt": 61263,
  "filter_alt_off": 60210,
  "filter_arrow_right": 62417,
  "filter_b_and_w": 58331,
  "filter_center_focus": 58332,
  "filter_drama": 58333,
  "filter_frames": 58334,
  "filter_hdr": 58335,
  "filter_list": 57682,
  "filter_list_alt": 59726,
  "filter_list_off": 60247,
  "filter_none": 58336,
  "filter_retrolux": 58337,
  "filter_tilt_shift": 58338,
  "filter_vintage": 58339,
  "finance": 59071,
  "finance_chip": 63566,
  "finance_mode": 61330,
  "find_in_page": 59520,
  "find_replace": 59521,
  "fingerprint": 59661,
  "fingerprint_off": 62621,
  "fire_extinguisher": 61912,
  "fire_hydrant": 61859,
  "fire_hydrant_alt": 63729,
  "fire_truck": 63730,
  "fireplace": 59971,
  "first_page": 58844,
  "fit_page": 63354,
  "fit_page_height": 62359,
  "fit_page_width": 62358,
  "fit_screen": 59920,
  "fit_width": 63353,
  "fitbit": 59435,
  "fitness_center": 60227,
  "fitness_tracker": 62563,
  "fitness_trackers": 61169,
  "flag": 57683,
  "flag_2": 62479,
  "flag_check": 62424,
  "flag_circle": 60152,
  "flaky": 61264,
  "flare": 58340,
  "flash_auto": 58341,
  "flash_off": 58342,
  "flash_on": 58343,
  "flashlight_off": 61450,
  "flashlight_on": 61451,
  "flatware": 61452,
  "flex_direction": 63352,
  "flex_no_wrap": 63351,
  "flex_wrap": 63350,
  "flight": 58681,
  "flight_class": 59339,
  "flight_land": 59652,
  "flight_takeoff": 59653,
  "flights_and_hotels": 59819,
  "flip": 58344,
  "flip_camera_android": 59959,
  "flip_camera_ios": 59960,
  "flip_to_back": 59522,
  "flip_to_front": 59523,
  "float_landscape_2": 62556,
  "float_portrait_2": 62555,
  "flood": 60390,
  "floor": 63204,
  "floor_lamp": 57886,
  "flowchart": 62349,
  "flowsheet": 57518,
  "fluid": 58499,
  "fluid_balance": 63501,
  "fluid_med": 63500,
  "fluorescent": 60465,
  "flutter": 61917,
  "flutter_dash": 57355,
  "flyover": 62584,
  "fmd_bad": 61454,
  "fmd_good": 61455,
  "foggy": 59416,
  "folded_hands": 62957,
  "folder": 58055,
  "folder_check": 62423,
  "folder_check_2": 62422,
  "folder_code": 62408,
  "folder_copy": 60349,
  "folder_data": 62854,
  "folder_delete": 60212,
  "folder_eye": 62421,
  "folder_info": 62357,
  "folder_limited": 62692,
  "folder_managed": 63349,
  "folder_match": 62420,
  "folder_off": 60291,
  "folder_open": 58056,
  "folder_shared": 58057,
  "folder_special": 58903,
  "folder_supervised": 63348,
  "folder_zip": 60204,
  "follow_the_signs": 61986,
  "font_download": 57703,
  "font_download_off": 58617,
  "food_bank": 61938,
  "foot_bones": 63635,
  "footprint": 63613,
  "for_you": 59820,
  "forest": 60057,
  "fork_left": 60320,
  "fork_right": 60332,
  "fork_spoon": 62436,
  "forklift": 63592,
  "format_align_center": 57908,
  "format_align_justify": 57909,
  "format_align_left": 57910,
  "format_align_right": 57911,
  "format_bold": 57912,
  "format_clear": 57913,
  "format_color_fill": 57914,
  "format_color_reset": 57915,
  "format_color_text": 57916,
  "format_h1": 63581,
  "format_h2": 63582,
  "format_h3": 63583,
  "format_h4": 63584,
  "format_h5": 63585,
  "format_h6": 63586,
  "format_image_left": 63587,
  "format_image_right": 63588,
  "format_indent_decrease": 57917,
  "format_indent_increase": 57918,
  "format_ink_highlighter": 63531,
  "format_italic": 57919,
  "format_letter_spacing": 63347,
  "format_letter_spacing_2": 63000,
  "format_letter_spacing_standard": 62999,
  "format_letter_spacing_wide": 62998,
  "format_letter_spacing_wider": 62997,
  "format_line_spacing": 57920,
  "format_list_bulleted": 57921,
  "format_list_bulleted_add": 63561,
  "format_list_numbered": 57922,
  "format_list_numbered_rtl": 57959,
  "format_overline": 60261,
  "format_paint": 57923,
  "format_paragraph": 63589,
  "format_quote": 57924,
  "format_quote_off": 62483,
  "format_shapes": 57950,
  "format_size": 57925,
  "format_strikethrough": 57926,
  "format_text_clip": 63530,
  "format_text_overflow": 63529,
  "format_text_wrap": 63528,
  "format_textdirection_l_to_r": 57927,
  "format_textdirection_r_to_l": 57928,
  "format_textdirection_vertical": 62648,
  "format_underlined": 57929,
  "format_underlined_squiggle": 63621,
  "forms_add_on": 61639,
  "forms_apps_script": 61640,
  "fort": 60077,
  "forum": 57535,
  "forward": 57684,
  "forward_10": 57430,
  "forward_30": 57431,
  "forward_5": 57432,
  "forward_circle": 63221,
  "forward_media": 63220,
  "forward_to_inbox": 61831,
  "foundation": 61952,
  "fragrance": 62277,
  "frame_inspect": 63346,
  "frame_person": 63654,
  "frame_person_mic": 62677,
  "frame_person_off": 63441,
  "frame_reload": 63345,
  "frame_source": 63344,
  "free_breakfast": 60228,
  "free_cancellation": 59208,
  "front_hand": 59241,
  "front_loader": 63593,
  "full_coverage": 60178,
  "full_hd": 62859,
  "full_stacked_bar_chart": 61970,
  "fullscreen": 58832,
  "fullscreen_exit": 58833,
  "fullscreen_portrait": 62554,
  "function": 63590,
  "functions": 57930,
  "funicular": 62583,
  "g_mobiledata": 61456,
  "g_mobiledata_badge": 63457,
  "g_translate": 59687,
  "gallery_thumbnail": 63599,
  "gamepad": 58127,
  "games": 57377,
  "garage": 61457,
  "garage_check": 62093,
  "garage_door": 59156,
  "garage_home": 59437,
  "garage_money": 62092,
  "garden_cart": 63657,
  "gas_meter": 60441,
  "gastroenterology": 57585,
  "gate": 57975,
  "gavel": 59662,
  "general_device": 59102,
  "generating_tokens": 59209,
  "genetics": 57587,
  "genres": 57378,
  "gesture": 57685,
  "gesture_select": 63063,
  "get_app": 59524,
  "gif": 59656,
  "gif_2": 62478,
  "gif_box": 59299,
  "girl": 60264,
  "gite": 58763,
  "glass_cup": 63203,
  "globe": 58956,
  "globe_asia": 63385,
  "globe_book": 62409,
  "globe_location_pin": 62301,
  "globe_uk": 63384,
  "glucose": 58528,
  "glyphs": 63651,
  "go_to_line": 63261,
  "golf_course": 60229,
  "gondola_lift": 62582,
  "google_home_devices": 59157,
  "google_tv_remote": 62939,
  "google_wifi": 59456,
  "gpp_bad": 61458,
  "gpp_good": 61459,
  "gpp_maybe": 61460,
  "gps_fixed": 57779,
  "gps_not_fixed": 57780,
  "gps_off": 57781,
  "grade": 59525,
  "gradient": 58345,
  "grading": 59983,
  "grain": 58346,
  "graph_1": 62368,
  "graph_2": 62367,
  "graph_3": 62366,
  "graph_4": 62365,
  "graph_5": 62364,
  "graph_6": 62363,
  "graph_7": 62278,
  "graphic_eq": 57784,
  "grass": 61957,
  "grid_3x3": 61461,
  "grid_3x3_off": 63100,
  "grid_4x4": 61462,
  "grid_goldenratio": 61463,
  "grid_guides": 63343,
  "grid_off": 58347,
  "grid_on": 58348,
  "grid_view": 59824,
  "grocery": 61335,
  "group": 59375,
  "group_add": 59376,
  "group_off": 59207,
  "group_remove": 59309,
  "group_search": 62414,
  "group_work": 59526,
  "grouped_bar_chart": 61969,
  "groups": 62003,
  "groups_2": 63711,
  "groups_3": 63712,
  "guardian": 62657,
  "gynecology": 57588,
  "h_mobiledata": 61464,
  "h_mobiledata_badge": 63456,
  "h_plus_mobiledata": 61465,
  "h_plus_mobiledata_badge": 63455,
  "hail": 59825,
  "hallway": 59128,
  "hanami_dango": 62015,
  "hand_bones": 63636,
  "hand_gesture": 61340,
  "hand_gesture_off": 62451,
  "hand_meal": 62100,
  "hand_package": 62099,
  "handheld_controller": 62662,
  "handshake": 60363,
  "handyman": 61707,
  "hangout_video": 57537,
  "hangout_video_off": 57538,
  "hard_disk": 62426,
  "hard_drive": 63502,
  "hard_drive_2": 63396,
  "hardware": 59993,
  "hd": 57426,
  "hdr_auto": 61466,
  "hdr_auto_select": 61467,
  "hdr_enhanced_select": 61265,
  "hdr_off": 58349,
  "hdr_off_select": 61468,
  "hdr_on": 58350,
  "hdr_on_select": 61469,
  "hdr_plus": 61470,
  "hdr_plus_off": 58351,
  "hdr_strong": 58353,
  "hdr_weak": 58354,
  "head_mounted_device": 62661,
  "headphones": 61471,
  "headphones_battery": 61472,
  "headset": 58128,
  "headset_mic": 58129,
  "headset_off": 58170,
  "healing": 58355,
  "health_and_beauty": 61341,
  "health_and_safety": 57813,
  "health_cross": 62147,
  "health_metrics": 63202,
  "heap_snapshot_large": 63342,
  "heap_snapshot_multiple": 63341,
  "heap_snapshot_thumbnail": 63340,
  "hearing": 57379,
  "hearing_aid": 62564,
  "hearing_aid_disabled": 62384,
  "hearing_aid_disabled_left": 62188,
  "hearing_aid_left": 62189,
  "hearing_disabled": 61700,
  "heart_broken": 60098,
  "heart_check": 62986,
  "heart_minus": 63619,
  "heart_plus": 63620,
  "heart_smile": 62098,
  "heat": 62775,
  "heat_pump": 60440,
  "heat_pump_balance": 57982,
  "height": 59926,
  "helicopter": 62988,
  "help": 59527,
  "help_center": 61888,
  "help_clinic": 63504,
  "help_outline": 59645,
  "hematology": 57590,
  "hevc": 61473,
  "hexagon": 60217,
  "hide": 61342,
  "hide_image": 61474,
  "hide_source": 61475,
  "high_chair": 62106,
  "high_density": 63388,
  "high_quality": 57380,
  "high_res": 62795,
  "highlight": 57951,
  "highlight_alt": 61266,
  "highlight_keyboard_focus": 62736,
  "highlight_mouse_cursor": 62737,
  "highlight_off": 59528,
  "highlight_text_cursor": 62738,
  "highlighter_size_1": 63339,
  "highlighter_size_2": 63338,
  "highlighter_size_3": 63337,
  "highlighter_size_4": 63336,
  "highlighter_size_5": 63335,
  "hiking": 58634,
  "history": 59529,
  "history_2": 62438,
  "history_edu": 59966,
  "history_off": 62682,
  "history_toggle_off": 61821,
  "hive": 60070,
  "hls": 60298,
  "hls_off": 60300,
  "holiday_village": 58762,
  "home": 59530,
  "home_and_garden": 61343,
  "home_app_logo": 58005,
  "home_filled": 59826,
  "home_health": 58553,
  "home_improvement_and_tools": 61344,
  "home_iot_device": 57987,
  "home_max": 61476,
  "home_max_dots": 59465,
  "home_mini": 61477,
  "home_pin": 61773,
  "home_repair_service": 61696,
  "home_speaker": 61724,
  "home_storage": 63596,
  "home_work": 59913,
  "horizontal_distribute": 57364,
  "horizontal_rule": 61704,
  "horizontal_split": 59719,
  "host": 62425,
  "hot_tub": 60230,
  "hotel": 58682,
  "hotel_class": 59203,
  "hourglass": 60415,
  "hourglass_arrow_down": 62334,
  "hourglass_arrow_up": 62333,
  "hourglass_bottom": 59996,
  "hourglass_disabled": 61267,
  "hourglass_empty": 59531,
  "hourglass_full": 59532,
  "hourglass_pause": 62348,
  "hourglass_top": 59995,
  "house": 59972,
  "house_siding": 61954,
  "house_with_shield": 59270,
  "houseboat": 58756,
  "household_supplies": 61345,
  "hov": 62581,
  "how_to_reg": 57716,
  "how_to_vote": 57717,
  "hr_resting": 63162,
  "html": 60286,
  "http": 59650,
  "https": 59533,
  "hub": 59892,
  "humerus": 63637,
  "humerus_alt": 63638,
  "humidity_high": 61795,
  "humidity_indoor": 62808,
  "humidity_low": 61796,
  "humidity_mid": 61797,
  "humidity_percentage": 63614,
  "hvac": 61710,
  "hvac_max_defrost": 62258,
  "ice_skating": 58635,
  "icecream": 60009,
  "id_card": 62666,
  "identity_aware_proxy": 58077,
  "identity_platform": 60343,
  "ifl": 57381,
  "iframe": 63259,
  "iframe_off": 63260,
  "image": 58356,
  "image_arrow_up": 62231,
  "image_aspect_ratio": 58357,
  "image_inset": 62023,
  "image_not_supported": 61718,
  "image_search": 58431,
  "imagesearch_roller": 59828,
  "imagesmode": 61346,
  "immunology": 57595,
  "import_contacts": 57568,
  "import_export": 57539,
  "important_devices": 59666,
  "in_home_mode": 59443,
  "inactive_order": 57596,
  "inbox": 57686,
  "inbox_customize": 63577,
  "inbox_text": 62361,
  "inbox_text_asterisk": 62304,
  "inbox_text_person": 62302,
  "inbox_text_share": 62300,
  "incomplete_circle": 59291,
  "indeterminate_check_box": 59657,
  "indeterminate_question_box": 62829,
  "info": 59534,
  "info_i": 62875,
  "info_outline": 59535,
  "infrared": 63612,
  "ink_eraser": 59088,
  "ink_eraser_off": 59363,
  "ink_highlighter": 59089,
  "ink_highlighter_move": 62756,
  "ink_marker": 59090,
  "ink_pen": 59091,
  "ink_selection": 59092,
  "inpatient": 57598,
  "input": 59536,
  "input_circle": 63258,
  "insert_chart": 57931,
  "insert_chart_outlined": 57962,
  "insert_comment": 57932,
  "insert_drive_file": 57933,
  "insert_emoticon": 57934,
  "insert_invitation": 57935,
  "insert_link": 57936,
  "insert_page_break": 60106,
  "insert_photo": 57937,
  "insert_text": 63527,
  "insights": 61586,
  "install_desktop": 60273,
  "install_mobile": 60274,
  "instant_mix": 57382,
  "integration_instructions": 61268,
  "interactive_space": 63487,
  "interests": 59336,
  "interpreter_mode": 59451,
  "inventory": 57721,
  "inventory_2": 57761,
  "invert_colors": 59537,
  "invert_colors_off": 57540,
  "ios": 57383,
  "ios_share": 59064,
  "iron": 58755,
  "iso": 58358,
  "jamboard_kiosk": 59829,
  "japanese_curry": 62084,
  "japanese_flag": 62083,
  "javascript": 60284,
  "join": 63567,
  "join_full": 60139,
  "join_inner": 60148,
  "join_left": 60146,
  "join_right": 60138,
  "joystick": 62958,
  "jump_to_element": 63257,
  "kanji_alcohol": 62014,
  "kayaking": 58636,
  "kebab_dining": 59458,
  "keep": 59050,
  "keep_off": 59129,
  "keep_public": 62831,
  "kettle": 58041,
  "key": 59196,
  "key_off": 60292,
  "key_vertical": 62746,
  "key_visualizer": 61849,
  "keyboard": 58130,
  "keyboard_alt": 61480,
  "keyboard_arrow_down": 58131,
  "keyboard_arrow_left": 58132,
  "keyboard_arrow_right": 58133,
  "keyboard_arrow_up": 58134,
  "keyboard_backspace": 58135,
  "keyboard_capslock": 58136,
  "keyboard_capslock_badge": 63454,
  "keyboard_command_key": 60135,
  "keyboard_control_key": 60134,
  "keyboard_double_arrow_down": 60112,
  "keyboard_double_arrow_left": 60099,
  "keyboard_double_arrow_right": 60105,
  "keyboard_double_arrow_up": 60111,
  "keyboard_external_input": 63453,
  "keyboard_full": 63452,
  "keyboard_hide": 58138,
  "keyboard_keys": 63099,
  "keyboard_lock": 62610,
  "keyboard_lock_off": 62609,
  "keyboard_off": 63098,
  "keyboard_onscreen": 63451,
  "keyboard_option_key": 60136,
  "keyboard_previous_language": 63450,
  "keyboard_return": 58139,
  "keyboard_tab": 58140,
  "keyboard_tab_rtl": 60531,
  "keyboard_voice": 58141,
  "kid_star": 62758,
  "king_bed": 59973,
  "kitchen": 60231,
  "kitesurfing": 58637,
  "lab_panel": 57603,
  "lab_profile": 57604,
  "lab_research": 63499,
  "label": 59538,
  "label_important": 59703,
  "label_important_outline": 59720,
  "label_off": 59830,
  "labs": 57605,
  "lan": 60207,
  "landscape": 58359,
  "landscape_2": 62660,
  "landscape_2_edit": 62224,
  "landscape_2_off": 62659,
  "landslide": 60375,
  "language": 59540,
  "language_chinese_array": 63334,
  "language_chinese_cangjie": 63333,
  "language_chinese_dayi": 63332,
  "language_chinese_pinyin": 63331,
  "language_chinese_quick": 63330,
  "language_chinese_wubi": 63329,
  "language_french": 63328,
  "language_gb_english": 63327,
  "language_international": 63326,
  "language_japanese_kana": 62739,
  "language_korean_latin": 63325,
  "language_pinyin": 63324,
  "language_spanish": 62953,
  "language_us": 63321,
  "language_us_colemak": 63323,
  "language_us_dvorak": 63322,
  "laps": 63161,
  "laptop": 58142,
  "laptop_car": 62413,
  "laptop_chromebook": 58143,
  "laptop_mac": 58144,
  "laptop_windows": 58145,
  "lasso_select": 60163,
  "last_page": 58845,
  "launch": 59541,
  "laundry": 58024,
  "layers": 58683,
  "layers_clear": 58684,
  "lda": 57606,
  "leaderboard": 61964,
  "leak_add": 58360,
  "leak_remove": 58361,
  "left_click": 63256,
  "left_panel_close": 63255,
  "left_panel_open": 63254,
  "legend_toggle": 61723,
  "lens": 58362,
  "lens_blur": 61481,
  "letter_switch": 63320,
  "library_add": 57390,
  "library_add_check": 59831,
  "library_books": 57391,
  "library_music": 57392,
  "license": 60164,
  "lift_to_talk": 61347,
  "light": 61482,
  "light_group": 57995,
  "light_mode": 58648,
  "light_off": 59832,
  "lightbulb": 57584,
  "lightbulb_2": 62435,
  "lightbulb_circle": 60414,
  "lightbulb_outline": 59663,
  "lightning_stand": 61348,
  "line_axis": 60058,
  "line_curve": 63319,
  "line_end": 63526,
  "line_end_arrow": 63517,
  "line_end_arrow_notch": 63516,
  "line_end_circle": 63515,
  "line_end_diamond": 63514,
  "line_end_square": 63513,
  "line_start": 63525,
  "line_start_arrow": 63512,
  "line_start_arrow_notch": 63511,
  "line_start_circle": 63510,
  "line_start_diamond": 63509,
  "line_start_square": 63508,
  "line_style": 59673,
  "line_weight": 59674,
  "linear_scale": 57952,
  "link": 57687,
  "link_off": 57711,
  "linked_camera": 58424,
  "linked_services": 62773,
  "liquor": 60000,
  "list": 59542,
  "list_alt": 57582,
  "list_alt_add": 63318,
  "list_alt_check": 62430,
  "lists": 59833,
  "live_help": 57542,
  "live_tv": 58937,
  "living": 61483,
  "local_activity": 58687,
  "local_airport": 58685,
  "local_atm": 58686,
  "local_bar": 58688,
  "local_cafe": 58689,
  "local_car_wash": 58690,
  "local_convenience_store": 58691,
  "local_dining": 58710,
  "local_drink": 58692,
  "local_fire_department": 61269,
  "local_florist": 58693,
  "local_gas_station": 58694,
  "local_grocery_store": 58695,
  "local_hospital": 58696,
  "local_hotel": 58697,
  "local_laundry_service": 58698,
  "local_library": 58699,
  "local_mall": 58700,
  "local_movies": 58701,
  "local_offer": 58702,
  "local_parking": 58703,
  "local_pharmacy": 58704,
  "local_phone": 58705,
  "local_pizza": 58706,
  "local_play": 58707,
  "local_police": 61270,
  "local_post_office": 58708,
  "local_printshop": 58709,
  "local_see": 58711,
  "local_shipping": 58712,
  "local_taxi": 58713,
  "location_away": 61776,
  "location_chip": 63568,
  "location_city": 59377,
  "location_disabled": 57782,
  "location_home": 61778,
  "location_off": 57543,
  "location_on": 57544,
  "location_pin": 61915,
  "location_searching": 57783,
  "lock": 59543,
  "lock_clock": 61271,
  "lock_open": 59544,
  "lock_open_circle": 62305,
  "lock_open_right": 63062,
  "lock_outline": 59545,
  "lock_person": 63731,
  "lock_reset": 60126,
  "login": 60023,
  "logo_dev": 60118,
  "logout": 59834,
  "looks": 58364,
  "looks_3": 58363,
  "looks_4": 58365,
  "looks_5": 58366,
  "looks_6": 58367,
  "looks_one": 58368,
  "looks_two": 58369,
  "loop": 57384,
  "loupe": 58370,
  "low_density": 63387,
  "low_priority": 57709,
  "lowercase": 62602,
  "loyalty": 59546,
  "lte_mobiledata": 61484,
  "lte_mobiledata_badge": 63449,
  "lte_plus_mobiledata": 61485,
  "lte_plus_mobiledata_badge": 63448,
  "luggage": 62005,
  "lunch_dining": 60001,
  "lyrics": 60427,
  "macro_auto": 63218,
  "macro_off": 63698,
  "magnification_large": 63549,
  "magnification_small": 63548,
  "magnify_docked": 63446,
  "magnify_fullscreen": 63445,
  "mail": 57688,
  "mail_asterisk": 61172,
  "mail_lock": 60426,
  "mail_off": 62603,
  "mail_outline": 57569,
  "mail_shield": 62025,
  "male": 58766,
  "man": 58603,
  "man_2": 63713,
  "man_3": 63714,
  "man_4": 63715,
  "manage_accounts": 61486,
  "manage_history": 60391,
  "manage_search": 61487,
  "manga": 62947,
  "manufacturing": 59174,
  "map": 58715,
  "map_pin_heart": 62104,
  "map_pin_review": 62103,
  "map_search": 62410,
  "maps_home_work": 61488,
  "maps_ugc": 61272,
  "margin": 59835,
  "mark_as_unread": 59836,
  "mark_chat_read": 61835,
  "mark_chat_unread": 61833,
  "mark_email_read": 61836,
  "mark_email_unread": 61834,
  "mark_unread_chat_alt": 60317,
  "markdown": 62802,
  "markdown_copy": 62803,
  "markdown_paste": 62804,
  "markunread": 57689,
  "markunread_mailbox": 59547,
  "masked_transitions": 59182,
  "masked_transitions_add": 62507,
  "masks": 61976,
  "massage": 62146,
  "match_case": 63217,
  "match_case_off": 62319,
  "match_word": 63216,
  "matter": 59655,
  "maximize": 59696,
  "meal_dinner": 62013,
  "meal_lunch": 62012,
  "measuring_tape": 63151,
  "media_bluetooth_off": 61489,
  "media_bluetooth_on": 61490,
  "media_link": 63551,
  "media_output": 62706,
  "media_output_off": 62707,
  "mediation": 61351,
  "medical_information": 60397,
  "medical_mask": 63498,
  "medical_services": 61705,
  "medication": 61491,
  "medication_liquid": 60039,
  "meeting_room": 60239,
  "memory": 58146,
  "memory_alt": 63395,
  "menstrual_health": 63201,
  "menu": 58834,
  "menu_book": 59929,
  "menu_book_2": 62097,
  "menu_open": 59837,
  "merge": 60312,
  "merge_type": 57938,
  "message": 57545,
  "metabolism": 57611,
  "metro": 62580,
  "mfg_nest_yale_lock": 61725,
  "mic": 57385,
  "mic_alert": 62354,
  "mic_double": 62929,
  "mic_external_off": 61273,
  "mic_external_on": 61274,
  "mic_none": 57386,
  "mic_off": 57387,
  "microbiology": 57612,
  "microwave": 61956,
  "microwave_gen": 59463,
  "military_tech": 59967,
  "mimo": 59838,
  "mimo_disconnect": 59839,
  "mindfulness": 63200,
  "minimize": 59697,
  "minor_crash": 60401,
  "mintmark": 61353,
  "miscellaneous_services": 61708,
  "missed_video_call": 57459,
  "missing_controller": 59137,
  "mist": 57736,
  "mitre": 62791,
  "mixture_med": 58568,
  "mms": 58904,
  "mobile": 59322,
  "mobile_2": 62171,
  "mobile_3": 62170,
  "mobile_alert": 62163,
  "mobile_arrow_down": 62157,
  "mobile_arrow_right": 62162,
  "mobile_arrow_up_right": 62137,
  "mobile_block": 62181,
  "mobile_camera": 62159,
  "mobile_camera_front": 62153,
  "mobile_camera_rear": 62152,
  "mobile_cancel": 62186,
  "mobile_cast": 62156,
  "mobile_charge": 62179,
  "mobile_chat": 62158,
  "mobile_check": 59428,
  "mobile_code": 62178,
  "mobile_dots": 62160,
  "mobile_friendly": 57856,
  "mobile_gear": 62169,
  "mobile_hand": 62243,
  "mobile_hand_left": 62227,
  "mobile_hand_left_off": 62226,
  "mobile_hand_off": 62228,
  "mobile_info": 62172,
  "mobile_landscape": 60734,
  "mobile_layout": 62143,
  "mobile_lock_landscape": 62168,
  "mobile_lock_portrait": 62142,
  "mobile_loupe": 62242,
  "mobile_menu": 62161,
  "mobile_off": 57857,
  "mobile_question": 62177,
  "mobile_rotate": 62165,
  "mobile_rotate_lock": 62166,
  "mobile_screen_share": 57575,
  "mobile_screensaver": 62241,
  "mobile_sensor_hi": 62191,
  "mobile_sensor_lo": 62190,
  "mobile_share": 62175,
  "mobile_share_stack": 62174,
  "mobile_sound": 62184,
  "mobile_sound_2": 62232,
  "mobile_sound_off": 62185,
  "mobile_speaker": 62240,
  "mobile_text": 62187,
  "mobile_text_2": 62182,
  "mobile_theft": 62121,
  "mobile_ticket": 62180,
  "mobile_vibrate": 62155,
  "mobile_wrench": 62128,
  "mobiledata_off": 61492,
  "mode": 61591,
  "mode_comment": 57939,
  "mode_cool": 61798,
  "mode_cool_off": 61799,
  "mode_dual": 62807,
  "mode_edit": 57940,
  "mode_edit_outline": 61493,
  "mode_fan": 61800,
  "mode_fan_off": 60439,
  "mode_heat": 61802,
  "mode_heat_cool": 61803,
  "mode_heat_off": 61805,
  "mode_night": 61494,
  "mode_of_travel": 59342,
  "mode_off_on": 61807,
  "mode_standby": 61495,
  "model_training": 61647,
  "modeling": 62378,
  "monetization_on": 57955,
  "money": 58749,
  "money_bag": 62446,
  "money_off": 57948,
  "money_off_csred": 61496,
  "money_range": 62021,
  "monitor": 61275,
  "monitor_heart": 60066,
  "monitor_weight": 61497,
  "monitor_weight_gain": 63199,
  "monitor_weight_loss": 63198,
  "monitoring": 61840,
  "monochrome_photos": 58371,
  "monorail": 62579,
  "mood": 59378,
  "mood_bad": 59379,
  "moon_stars": 62287,
  "mop": 57997,
  "moped": 60200,
  "moped_package": 62091,
  "more": 58905,
  "more_down": 61846,
  "more_horiz": 58835,
  "more_time": 59997,
  "more_up": 61847,
  "more_vert": 58836,
  "mosque": 60082,
  "motion_blur": 61648,
  "motion_mode": 63554,
  "motion_photos_auto": 61498,
  "motion_photos_off": 59840,
  "motion_photos_on": 59841,
  "motion_photos_pause": 61991,
  "motion_photos_paused": 59842,
  "motion_play": 62475,
  "motion_sensor_active": 59282,
  "motion_sensor_alert": 59268,
  "motion_sensor_idle": 59267,
  "motion_sensor_urgent": 59278,
  "motorcycle": 59675,
  "mountain_flag": 62946,
  "mountain_steam": 62082,
  "mouse": 58147,
  "mouse_lock": 62608,
  "mouse_lock_off": 62607,
  "move": 59200,
  "move_down": 60257,
  "move_group": 63253,
  "move_item": 61951,
  "move_location": 59201,
  "move_selection_down": 63252,
  "move_selection_left": 63251,
  "move_selection_right": 63250,
  "move_selection_up": 63249,
  "move_to_inbox": 57704,
  "move_up": 60260,
  "moved_location": 58772,
  "movie": 57388,
  "movie_creation": 58372,
  "movie_edit": 63552,
  "movie_filter": 58426,
  "movie_info": 57389,
  "movie_off": 62617,
  "movie_speaker": 62115,
  "moving": 58625,
  "moving_beds": 59197,
  "moving_ministry": 59198,
  "mp": 59843,
  "multicooker": 58003,
  "multiline_chart": 59103,
  "multimodal_hand_eye": 62491,
  "multiple_airports": 61355,
  "multiple_stop": 61881,
  "museum": 59958,
  "music_cast": 60186,
  "music_history": 62145,
  "music_note": 58373,
  "music_note_add": 62353,
  "music_off": 58432,
  "music_video": 57443,
  "my_location": 58716,
  "mystery": 62945,
  "nat": 61276,
  "nature": 58374,
  "nature_people": 58375,
  "navigate_before": 58376,
  "navigate_next": 58377,
  "navigation": 58717,
  "near_me": 58729,
  "near_me_disabled": 61935,
  "nearby": 59063,
  "nearby_error": 61499,
  "nearby_off": 61500,
  "nephrology": 57613,
  "nest_audio": 60351,
  "nest_cam_floodlight": 63671,
  "nest_cam_indoor": 61726,
  "nest_cam_iq": 61727,
  "nest_cam_iq_outdoor": 61728,
  "nest_cam_magnet_mount": 63672,
  "nest_cam_outdoor": 61729,
  "nest_cam_stand": 63673,
  "nest_cam_wall_mount": 63674,
  "nest_cam_wired_stand": 60438,
  "nest_clock_farsight_analog": 63675,
  "nest_clock_farsight_digital": 63676,
  "nest_connect": 61730,
  "nest_detect": 61731,
  "nest_display": 61732,
  "nest_display_max": 61733,
  "nest_doorbell_visitor": 63677,
  "nest_eco_leaf": 63678,
  "nest_farsight_cool": 62077,
  "nest_farsight_dual": 62076,
  "nest_farsight_eco": 62075,
  "nest_farsight_heat": 62074,
  "nest_farsight_seasonal": 62073,
  "nest_farsight_weather": 63679,
  "nest_found_savings": 63680,
  "nest_heat_link_e": 61734,
  "nest_heat_link_gen_3": 61735,
  "nest_hello_doorbell": 59436,
  "nest_mini": 59273,
  "nest_multi_room": 63682,
  "nest_protect": 59022,
  "nest_remote_comfort_sensor": 61738,
  "nest_secure_alarm": 61739,
  "nest_sunblock": 63683,
  "nest_tag": 61740,
  "nest_thermostat": 59023,
  "nest_thermostat_e_eu": 61741,
  "nest_thermostat_gen_3": 61742,
  "nest_thermostat_sensor": 61743,
  "nest_thermostat_sensor_eu": 61744,
  "nest_thermostat_zirconium_eu": 61745,
  "nest_true_radiant": 63684,
  "nest_wake_on_approach": 63685,
  "nest_wake_on_press": 63686,
  "nest_wifi_point": 59455,
  "nest_wifi_pro": 62827,
  "nest_wifi_pro_2": 62826,
  "nest_wifi_router": 59457,
  "network_cell": 57785,
  "network_check": 58944,
  "network_intel_node": 62321,
  "network_intelligence": 61356,
  "network_intelligence_history": 62966,
  "network_intelligence_update": 62965,
  "network_locked": 58906,
  "network_manage": 63403,
  "network_node": 62830,
  "network_ping": 60362,
  "network_wifi": 57786,
  "network_wifi_1_bar": 60388,
  "network_wifi_1_bar_locked": 62863,
  "network_wifi_2_bar": 60374,
  "network_wifi_2_bar_locked": 62862,
  "network_wifi_3_bar": 60385,
  "network_wifi_3_bar_locked": 62861,
  "network_wifi_locked": 62770,
  "neurology": 57614,
  "new_label": 58889,
  "new_releases": 57393,
  "new_window": 63248,
  "news": 57394,
  "newsmode": 61357,
  "newspaper": 60289,
  "newsstand": 59844,
  "next_plan": 61277,
  "next_week": 57706,
  "nfc": 57787,
  "nfc_off": 62313,
  "night_shelter": 61937,
  "night_sight_auto": 61911,
  "night_sight_auto_off": 61945,
  "night_sight_max": 63171,
  "nightlife": 60002,
  "nightlight": 61501,
  "nightlight_round": 61278,
  "nights_stay": 59974,
  "no_accounts": 61502,
  "no_adult_content": 63742,
  "no_backpack": 62007,
  "no_cell": 61860,
  "no_crash": 60400,
  "no_drinks": 61861,
  "no_encryption": 58945,
  "no_encryption_gmailerrorred": 61503,
  "no_flash": 61862,
  "no_food": 61863,
  "no_luggage": 62011,
  "no_meals": 61910,
  "no_meals_ouline": 61993,
  "no_meeting_room": 60238,
  "no_photography": 61864,
  "no_sim": 57548,
  "no_sound": 59152,
  "no_stroller": 61871,
  "no_transfer": 61909,
  "noise_aware": 60396,
  "noise_control_off": 60403,
  "noise_control_on": 63656,
  "nordic_walking": 58638,
  "north": 61920,
  "north_east": 61921,
  "north_west": 61922,
  "not_accessible": 61694,
  "not_accessible_forward": 62794,
  "not_interested": 57395,
  "not_listed_location": 58741,
  "not_started": 61649,
  "note": 57455,
  "note_add": 59548,
  "note_alt": 61504,
  "note_stack": 62818,
  "note_stack_add": 62819,
  "notes": 57964,
  "notification_add": 58265,
  "notification_important": 57348,
  "notification_multiple": 59074,
  "notification_settings": 62311,
  "notification_sound": 62291,
  "notifications": 59380,
  "notifications_active": 59383,
  "notifications_none": 59381,
  "notifications_off": 59382,
  "notifications_paused": 59384,
  "notifications_unread": 62718,
  "numbers": 60103,
  "nutrition": 57616,
  "ods": 59112,
  "odt": 59113,
  "offline_bolt": 59698,
  "offline_pin": 59658,
  "offline_pin_off": 62672,
  "offline_share": 59845,
  "oil_barrel": 60437,
  "okonomiyaki": 62081,
  "on_device_training": 60413,
  "on_hub_device": 59075,
  "oncology": 57620,
  "ondemand_video": 58938,
  "online_prediction": 61675,
  "onsen": 63224,
  "opacity": 59676,
  "open_in_browser": 59549,
  "open_in_full": 61902,
  "open_in_new": 59550,
  "open_in_new_down": 63247,
  "open_in_new_off": 58614,
  "open_jam": 61358,
  "open_run": 62647,
  "open_with": 59551,
  "ophthalmology": 57621,
  "oral_disease": 57622,
  "orbit": 62502,
  "order_approve": 63506,
  "order_play": 63505,
  "orders": 60180,
  "orthopedics": 63639,
  "other_admission": 58491,
  "other_houses": 58764,
  "outbound": 57802,
  "outbox": 61279,
  "outbox_alt": 60183,
  "outdoor_garden": 57861,
  "outdoor_grill": 59975,
  "outgoing_mail": 61650,
  "outlet": 61908,
  "outlined_flag": 57710,
  "outpatient": 57624,
  "outpatient_med": 57625,
  "output": 60350,
  "output_circle": 63246,
  "oven": 59847,
  "oven_gen": 59459,
  "overview": 58535,
  "overview_key": 63444,
  "owl": 62388,
  "oxygen_saturation": 58590,
  "p2p": 62762,
  "pace": 63160,
  "pacemaker": 58966,
  "package": 58511,
  "package_2": 62825,
  "padding": 59848,
  "padel": 62119,
  "page_control": 59185,
  "page_footer": 62339,
  "page_header": 62340,
  "page_info": 62996,
  "page_menu_ios": 61179,
  "pageless": 62729,
  "pages": 59385,
  "pageview": 59552,
  "paid": 61505,
  "palette": 58378,
  "pallet": 63594,
  "pan_tool": 59685,
  "pan_tool_alt": 60345,
  "pan_zoom": 63061,
  "panorama": 58379,
  "panorama_fish_eye": 58380,
  "panorama_horizontal": 58381,
  "panorama_horizontal_select": 61280,
  "panorama_photosphere": 59849,
  "panorama_photosphere_select": 59850,
  "panorama_vertical": 58382,
  "panorama_vertical_select": 61281,
  "panorama_wide_angle": 58383,
  "panorama_wide_angle_select": 61282,
  "paragliding": 58639,
  "parent_child_dining": 61997,
  "park": 60003,
  "parking_meter": 62090,
  "parking_sign": 62089,
  "parking_valet": 62088,
  "partly_cloudy_day": 61810,
  "partly_cloudy_night": 61812,
  "partner_exchange": 63481,
  "partner_heart": 61230,
  "partner_reports": 61359,
  "party_mode": 59386,
  "passkey": 63615,
  "password": 61506,
  "password_2": 62633,
  "password_2_off": 62632,
  "patient_list": 58963,
  "pattern": 61507,
  "pause": 57396,
  "pause_circle": 57762,
  "pause_circle_filled": 57397,
  "pause_circle_outline": 57398,
  "pause_presentation": 57578,
  "payment": 59553,
  "payment_arrow_down": 62144,
  "payment_card": 62113,
  "payments": 61283,
  "pedal_bike": 60201,
  "pediatrics": 57629,
  "pen_size_1": 63317,
  "pen_size_2": 63316,
  "pen_size_3": 63315,
  "pen_size_4": 63314,
  "pen_size_5": 63313,
  "pending": 61284,
  "pending_actions": 61883,
  "pentagon": 60240,
  "people": 59387,
  "people_alt": 59937,
  "people_outline": 59388,
  "percent": 60248,
  "percent_discount": 62020,
  "pergola": 57859,
  "perm_camera_mic": 59554,
  "perm_contact_calendar": 59555,
  "perm_data_setting": 59556,
  "perm_device_information": 59557,
  "perm_identity": 59558,
  "perm_media": 59559,
  "perm_phone_msg": 59560,
  "perm_scan_wifi": 59561,
  "person": 59389,
  "person_2": 63716,
  "person_3": 63717,
  "person_4": 63718,
  "person_add": 59390,
  "person_add_alt": 59981,
  "person_add_alt_1": 61285,
  "person_add_disabled": 59851,
  "person_alert": 62823,
  "person_apron": 62883,
  "person_book": 62952,
  "person_cancel": 62822,
  "person_celebrate": 63486,
  "person_check": 62821,
  "person_edit": 62714,
  "person_heart": 62096,
  "person_off": 58640,
  "person_outline": 59391,
  "person_pin": 58714,
  "person_pin_circle": 58730,
  "person_play": 63485,
  "person_raised_hand": 62874,
  "person_remove": 61286,
  "person_remove_alt_1": 61287,
  "person_search": 61702,
  "person_shield": 58244,
  "personal_bag": 60174,
  "personal_bag_off": 60175,
  "personal_bag_question": 60176,
  "personal_injury": 59098,
  "personal_places": 59139,
  "personal_video": 58939,
  "pest_control": 61690,
  "pest_control_rodent": 61693,
  "pet_supplies": 61361,
  "pets": 59677,
  "phishing": 60119,
  "phone": 57549,
  "phone_android": 58148,
  "phone_bluetooth_speaker": 58907,
  "phone_callback": 58953,
  "phone_disabled": 59852,
  "phone_enabled": 59853,
  "phone_forwarded": 58908,
  "phone_in_talk": 58909,
  "phone_iphone": 58149,
  "phone_locked": 58910,
  "phone_missed": 58911,
  "phone_paused": 58912,
  "phonelink": 58150,
  "phonelink_erase": 57563,
  "phonelink_lock": 57564,
  "phonelink_off": 58151,
  "phonelink_ring": 57565,
  "phonelink_setup": 57566,
  "photo": 58384,
  "photo_album": 58385,
  "photo_auto_merge": 62768,
  "photo_camera": 58386,
  "photo_camera_back": 61288,
  "photo_camera_front": 61289,
  "photo_filter": 58427,
  "photo_frame": 61657,
  "photo_library": 58387,
  "photo_prints": 61362,
  "photo_size_select_actual": 58418,
  "photo_size_select_large": 58419,
  "photo_size_select_small": 58420,
  "php": 60303,
  "physical_therapy": 57630,
  "piano": 58657,
  "piano_off": 58656,
  "pickleball": 62118,
  "picture_as_pdf": 58389,
  "picture_in_picture": 59562,
  "picture_in_picture_alt": 59665,
  "picture_in_picture_center": 62800,
  "picture_in_picture_large": 62799,
  "picture_in_picture_medium": 62798,
  "picture_in_picture_mobile": 62743,
  "picture_in_picture_off": 62767,
  "picture_in_picture_small": 62797,
  "pie_chart": 59076,
  "pie_chart_outline": 61508,
  "pie_chart_outlined": 59077,
  "pill": 57631,
  "pill_off": 63497,
  "pin": 61509,
  "pin_drop": 58718,
  "pin_end": 59239,
  "pin_invoke": 59235,
  "pinboard": 62379,
  "pinboard_unread": 62380,
  "pinch": 60216,
  "pinch_zoom_in": 61946,
  "pinch_zoom_out": 61947,
  "pip": 63053,
  "pip_exit": 63245,
  "pivot_table_chart": 59854,
  "pix": 60067,
  "place": 58719,
  "place_item": 61936,
  "plagiarism": 59994,
  "plane_contrails": 62124,
  "planet": 62343,
  "planner_banner_ad_pt": 59026,
  "planner_review": 59028,
  "play_arrow": 57399,
  "play_circle": 57796,
  "play_circle_filled": 57400,
  "play_circle_outline": 57401,
  "play_disabled": 61290,
  "play_for_work": 59654,
  "play_lesson": 61511,
  "play_pause": 61751,
  "playground": 62094,
  "playground_2": 62095,
  "playing_cards": 62940,
  "playlist_add": 57403,
  "playlist_add_check": 57445,
  "playlist_add_check_circle": 59366,
  "playlist_add_circle": 59365,
  "playlist_play": 57439,
  "playlist_remove": 60288,
  "plug_connect": 62298,
  "plumbing": 61703,
  "plus_one": 59392,
  "podcasts": 61512,
  "podiatry": 57632,
  "podium": 63483,
  "point_of_sale": 61822,
  "point_scan": 63244,
  "poker_chip": 62619,
  "policy": 59927,
  "policy_alert": 62471,
  "poll": 59393,
  "polyline": 60347,
  "polymer": 59563,
  "pool": 60232,
  "portable_wifi_off": 57550,
  "portrait": 58390,
  "position_bottom_left": 63243,
  "position_bottom_right": 63242,
  "position_top_right": 63241,
  "post": 59141,
  "post_add": 59936,
  "potted_plant": 63658,
  "power": 58940,
  "power_input": 58166,
  "power_off": 58950,
  "power_settings_circle": 62488,
  "power_settings_new": 59564,
  "prayer_times": 63544,
  "precision_manufacturing": 61513,
  "pregnancy": 62961,
  "pregnant_woman": 59678,
  "preliminary": 59352,
  "prescriptions": 57633,
  "present_to_all": 57567,
  "preview": 61893,
  "preview_off": 63407,
  "price_change": 61514,
  "price_check": 61515,
  "print": 59565,
  "print_add": 63394,
  "print_connect": 63393,
  "print_disabled": 59855,
  "print_error": 63392,
  "print_lock": 63057,
  "priority": 57759,
  "priority_high": 58949,
  "privacy": 61768,
  "privacy_tip": 61660,
  "private_connectivity": 59204,
  "problem": 57634,
  "procedure": 58961,
  "process_chart": 63573,
  "production_quantity_limits": 57809,
  "productivity": 58006,
  "progress_activity": 59856,
  "prompt_suggestion": 62710,
  "propane": 60436,
  "propane_tank": 60435,
  "psychiatry": 57635,
  "psychology": 59978,
  "psychology_alt": 63722,
  "public": 59403,
  "public_off": 61898,
  "publish": 57941,
  "published_with_changes": 62002,
  "pulmonology": 57636,
  "pulse_alert": 62721,
  "punch_clock": 60072,
  "push_pin": 61709,
  "qr_code": 61291,
  "qr_code_2": 57354,
  "qr_code_2_add": 63064,
  "qr_code_scanner": 61958,
  "query_builder": 59566,
  "query_stats": 58620,
  "question_answer": 59567,
  "question_exchange": 63475,
  "question_mark": 60299,
  "queue": 57404,
  "queue_music": 57405,
  "queue_play_next": 57446,
  "quick_phrases": 59345,
  "quick_reference": 58478,
  "quick_reference_all": 63489,
  "quick_reorder": 60181,
  "quickreply": 61292,
  "quiz": 61516,
  "r_mobiledata": 61517,
  "radar": 61518,
  "radio": 57406,
  "radio_button_checked": 59447,
  "radio_button_partial": 62816,
  "radio_button_unchecked": 59446,
  "radiology": 57637,
  "railway_alert": 59857,
  "railway_alert_2": 62561,
  "rainy": 61814,
  "rainy_heavy": 63007,
  "rainy_light": 63006,
  "rainy_snow": 63005,
  "ramen_dining": 60004,
  "ramp_left": 60316,
  "ramp_right": 60310,
  "range_hood": 57834,
  "rate_review": 58720,
  "raven": 62805,
  "raw_off": 61519,
  "raw_on": 61520,
  "read_more": 61293,
  "readiness_score": 63197,
  "real_estate_agent": 59194,
  "rear_camera": 63170,
  "rebase": 63557,
  "rebase_edit": 63558,
  "receipt": 59568,
  "receipt_long": 61294,
  "receipt_long_off": 62474,
  "recent_actors": 57407,
  "recent_patient": 63496,
  "recenter": 62656,
  "recommend": 59858,
  "record_voice_over": 59679,
  "rectangle": 60244,
  "recycling": 59232,
  "redeem": 59569,
  "redo": 57690,
  "reduce_capacity": 61980,
  "refresh": 58837,
  "regular_expression": 63312,
  "relax": 63196,
  "release_alert": 63060,
  "remember_me": 61521,
  "reminder": 59029,
  "remote_gen": 59454,
  "remove": 57691,
  "remove_circle": 57692,
  "remove_circle_outline": 57693,
  "remove_done": 59859,
  "remove_from_queue": 57447,
  "remove_moderator": 59860,
  "remove_red_eye": 58391,
  "remove_road": 60412,
  "remove_selection": 59861,
  "remove_shopping_cart": 59688,
  "reopen_window": 63240,
  "reorder": 59646,
  "repartition": 63720,
  "repeat": 57408,
  "repeat_on": 59862,
  "repeat_one": 57409,
  "repeat_one_on": 59863,
  "replace_audio": 62545,
  "replace_image": 62544,
  "replace_video": 62543,
  "replay": 57410,
  "replay_10": 57433,
  "replay_30": 57434,
  "replay_5": 57435,
  "replay_circle_filled": 59864,
  "reply": 57694,
  "reply_all": 57695,
  "report": 57696,
  "report_gmailerrorred": 61522,
  "report_off": 57712,
  "report_problem": 59570,
  "request_page": 61996,
  "request_quote": 61878,
  "reset_brightness": 62594,
  "reset_exposure": 62054,
  "reset_focus": 62593,
  "reset_image": 63524,
  "reset_iso": 62592,
  "reset_settings": 62591,
  "reset_shadow": 62590,
  "reset_shutter_speed": 62589,
  "reset_tv": 59865,
  "reset_white_balance": 62588,
  "reset_wrench": 62828,
  "resize": 63239,
  "respiratory_rate": 57639,
  "responsive_layout": 59866,
  "rest_area": 61994,
  "restart_alt": 61523,
  "restaurant": 58732,
  "restaurant_menu": 58721,
  "restore": 59571,
  "restore_from_trash": 59704,
  "restore_page": 59689,
  "resume": 63440,
  "reviews": 61524,
  "rewarded_ads": 61366,
  "rheumatology": 57640,
  "rib_cage": 63640,
  "rice_bowl": 61941,
  "right_click": 63238,
  "right_panel_close": 63237,
  "right_panel_open": 63236,
  "ring_volume": 57553,
  "ripples": 59867,
  "road": 62578,
  "robot": 63618,
  "robot_2": 62928,
  "rocket": 60325,
  "rocket_launch": 60315,
  "roller_shades": 60434,
  "roller_shades_closed": 60433,
  "roller_skating": 60365,
  "roofing": 61953,
  "room": 59572,
  "room_preferences": 61880,
  "room_service": 60233,
  "rotate_90_degrees_ccw": 58392,
  "rotate_90_degrees_cw": 60075,
  "rotate_auto": 62487,
  "rotate_left": 58393,
  "rotate_right": 58394,
  "roundabout_left": 60313,
  "roundabout_right": 60323,
  "rounded_corner": 59680,
  "route": 60109,
  "router": 58152,
  "router_off": 62196,
  "routine": 57868,
  "rowing": 59681,
  "rss_feed": 57573,
  "rsvp": 61525,
  "rtt": 59821,
  "rubric": 60199,
  "rule": 61890,
  "rule_folder": 61897,
  "rule_settings": 63052,
  "run_circle": 61295,
  "running_with_errors": 58653,
  "rv_hookup": 58946,
  "safety_check": 60399,
  "safety_check_off": 62877,
  "safety_divider": 57804,
  "sailing": 58626,
  "salinity": 63606,
  "sanitizer": 61981,
  "satellite": 58722,
  "satellite_alt": 60218,
  "sauna": 63223,
  "save": 57697,
  "save_alt": 57713,
  "save_as": 60256,
  "save_clock": 62360,
  "saved_search": 59921,
  "savings": 58091,
  "scale": 60255,
  "scan": 63310,
  "scan_delete": 63311,
  "scanner": 58153,
  "scatter_plot": 57960,
  "scene": 58023,
  "schedule": 59573,
  "schedule_send": 59914,
  "schema": 58621,
  "school": 59404,
  "science": 59979,
  "science_off": 62786,
  "scooter": 62577,
  "score": 57961,
  "scoreboard": 60368,
  "screen_lock_landscape": 57790,
  "screen_lock_portrait": 57791,
  "screen_lock_rotation": 57792,
  "screen_record": 63097,
  "screen_rotation": 57793,
  "screen_rotation_alt": 60398,
  "screen_rotation_up": 63096,
  "screen_search_desktop": 61296,
  "screen_share": 57570,
  "screenshot": 61526,
  "screenshot_frame": 63095,
  "screenshot_frame_2": 62324,
  "screenshot_keyboard": 63443,
  "screenshot_monitor": 60424,
  "screenshot_region": 63442,
  "screenshot_tablet": 63127,
  "script": 62559,
  "scrollable_header": 59868,
  "scuba_diving": 60366,
  "sd": 59869,
  "sd_card": 58915,
  "sd_card_alert": 61527,
  "sd_storage": 57794,
  "sdk": 59168,
  "search": 59574,
  "search_activity": 62437,
  "search_check": 63488,
  "search_check_2": 62569,
  "search_gear": 61178,
  "search_hands_free": 59030,
  "search_insights": 62652,
  "search_off": 60022,
  "seat_cool_left": 62257,
  "seat_cool_right": 62256,
  "seat_heat_left": 62255,
  "seat_heat_right": 62254,
  "seat_vent_left": 62253,
  "seat_vent_right": 62252,
  "security": 58154,
  "security_key": 62723,
  "security_update": 61528,
  "security_update_good": 61529,
  "security_update_warning": 61530,
  "segment": 59723,
  "select": 63309,
  "select_all": 57698,
  "select_check_box": 61950,
  "select_to_speak": 63439,
  "select_window": 59130,
  "select_window_2": 62664,
  "select_window_off": 58630,
  "self_care": 63597,
  "self_improvement": 60024,
  "sell": 61531,
  "send": 57699,
  "send_and_archive": 59916,
  "send_money": 59575,
  "send_time_extension": 60123,
  "send_to_mobile": 61532,
  "sensor_door": 61877,
  "sensor_occupied": 60432,
  "sensor_window": 61876,
  "sensors": 58654,
  "sensors_krx": 62806,
  "sensors_krx_off": 62741,
  "sensors_off": 58655,
  "sentiment_calm": 63143,
  "sentiment_content": 63142,
  "sentiment_dissatisfied": 59409,
  "sentiment_excited": 63141,
  "sentiment_extremely_dissatisfied": 61844,
  "sentiment_frustrated": 63140,
  "sentiment_neutral": 59410,
  "sentiment_sad": 63139,
  "sentiment_satisfied": 59411,
  "sentiment_satisfied_alt": 57581,
  "sentiment_stressed": 63138,
  "sentiment_very_dissatisfied": 59412,
  "sentiment_very_satisfied": 59413,
  "sentiment_worried": 63137,
  "serif": 62636,
  "server_person": 62397,
  "service_toolbox": 59159,
  "set_meal": 61930,
  "settings": 59576,
  "settings_accessibility": 61533,
  "settings_account_box": 63541,
  "settings_alert": 61763,
  "settings_applications": 59577,
  "settings_b_roll": 63013,
  "settings_backup_restore": 59578,
  "settings_bluetooth": 59579,
  "settings_brightness": 59581,
  "settings_cell": 59580,
  "settings_cinematic_blur": 63012,
  "settings_ethernet": 59582,
  "settings_heart": 62754,
  "settings_input_antenna": 59583,
  "settings_input_component": 59584,
  "settings_input_composite": 59585,
  "settings_input_hdmi": 59586,
  "settings_input_svideo": 59587,
  "settings_motion_mode": 63539,
  "settings_night_sight": 63538,
  "settings_overscan": 59588,
  "settings_panorama": 63537,
  "settings_phone": 59589,
  "settings_photo_camera": 63540,
  "settings_power": 59590,
  "settings_remote": 59591,
  "settings_seating": 61229,
  "settings_slow_motion": 63011,
  "settings_suggest": 61534,
  "settings_system_daydream": 57795,
  "settings_timelapse": 63010,
  "settings_video_camera": 63009,
  "settings_voice": 59592,
  "settop_component": 58028,
  "severe_cold": 60371,
  "shadow": 59871,
  "shadow_add": 62852,
  "shadow_minus": 62851,
  "shape_line": 63699,
  "shapes": 58882,
  "share": 59405,
  "share_eta": 58871,
  "share_location": 61535,
  "share_off": 63179,
  "share_reviews": 63652,
  "share_windows": 62995,
  "shaved_ice": 61989,
  "sheets_rtl": 63523,
  "shelf_auto_hide": 63235,
  "shelf_position": 63234,
  "shelves": 63598,
  "shield": 59872,
  "shield_lock": 63110,
  "shield_locked": 62866,
  "shield_moon": 60073,
  "shield_person": 63056,
  "shield_question": 62761,
  "shield_toggle": 62125,
  "shield_watch": 62223,
  "shield_with_heart": 59279,
  "shield_with_house": 59277,
  "shift": 58866,
  "shift_lock": 63406,
  "shift_lock_off": 62595,
  "shop": 59593,
  "shop_2": 57758,
  "shop_two": 59594,
  "shopping_bag": 61900,
  "shopping_bag_speed": 62362,
  "shopping_basket": 59595,
  "shopping_cart": 59596,
  "shopping_cart_checkout": 60296,
  "shopping_cart_off": 62711,
  "shoppingmode": 61367,
  "short_stay": 58576,
  "short_text": 57953,
  "shortcut": 61536,
  "show_chart": 59105,
  "shower": 61537,
  "shuffle": 57411,
  "shuffle_on": 59873,
  "shutter_speed": 58429,
  "shutter_speed_add": 62846,
  "shutter_speed_minus": 62845,
  "sick": 61984,
  "side_navigation": 59874,
  "sign_language": 60389,
  "signal_cellular_0_bar": 61608,
  "signal_cellular_1_bar": 61609,
  "signal_cellular_2_bar": 61610,
  "signal_cellular_3_bar": 61611,
  "signal_cellular_4_bar": 57800,
  "signal_cellular_add": 63401,
  "signal_cellular_alt": 57858,
  "signal_cellular_alt_1_bar": 60383,
  "signal_cellular_alt_2_bar": 60387,
  "signal_cellular_connected_no_internet_0_bar": 61612,
  "signal_cellular_connected_no_internet_1_bar": 61613,
  "signal_cellular_connected_no_internet_2_bar": 61614,
  "signal_cellular_connected_no_internet_3_bar": 61615,
  "signal_cellular_connected_no_internet_4_bar": 57805,
  "signal_cellular_no_sim": 57806,
  "signal_cellular_nodata": 61538,
  "signal_cellular_null": 57807,
  "signal_cellular_off": 57808,
  "signal_cellular_pause": 62887,
  "signal_disconnected": 62009,
  "signal_wifi_0_bar": 61616,
  "signal_wifi_1_bar": 61617,
  "signal_wifi_1_bar_lock": 61618,
  "signal_wifi_2_bar": 61619,
  "signal_wifi_2_bar_lock": 61620,
  "signal_wifi_3_bar": 61621,
  "signal_wifi_3_bar_lock": 61622,
  "signal_wifi_4_bar": 57816,
  "signal_wifi_4_bar_lock": 57817,
  "signal_wifi_bad": 61539,
  "signal_wifi_connected_no_internet_0": 61682,
  "signal_wifi_connected_no_internet_1": 61678,
  "signal_wifi_connected_no_internet_2": 61681,
  "signal_wifi_connected_no_internet_3": 61677,
  "signal_wifi_connected_no_internet_4": 61540,
  "signal_wifi_off": 57818,
  "signal_wifi_statusbar_1_bar": 61670,
  "signal_wifi_statusbar_2_bar": 61680,
  "signal_wifi_statusbar_3_bar": 61674,
  "signal_wifi_statusbar_4_bar": 61541,
  "signal_wifi_statusbar_connected_no_internet": 61688,
  "signal_wifi_statusbar_connected_no_internet_1": 61673,
  "signal_wifi_statusbar_connected_no_internet_2": 61687,
  "signal_wifi_statusbar_connected_no_internet_3": 61672,
  "signal_wifi_statusbar_connected_no_internet_4": 61542,
  "signal_wifi_statusbar_not_connected": 61679,
  "signal_wifi_statusbar_null": 61543,
  "signature": 63308,
  "signpost": 60305,
  "sim_card": 58155,
  "sim_card_alert": 58916,
  "sim_card_download": 61544,
  "simulation": 62433,
  "single_bed": 59976,
  "sip": 61545,
  "siren": 62375,
  "siren_check": 62374,
  "siren_open": 62373,
  "siren_question": 62372,
  "skateboarding": 58641,
  "skeleton": 63641,
  "skillet": 62787,
  "skillet_cooktop": 62788,
  "skip_next": 57412,
  "skip_previous": 57413,
  "skull": 63642,
  "skull_list": 62320,
  "slab_serif": 62635,
  "sledding": 58642,
  "sleep_score": 63159,
  "slide_library": 63522,
  "sliders": 59875,
  "slideshow": 58395,
  "slow_motion_video": 57448,
  "smart_button": 61889,
  "smart_card_reader": 62629,
  "smart_card_reader_off": 62630,
  "smart_display": 61546,
  "smart_outlet": 59460,
  "smart_screen": 61547,
  "smart_toy": 61548,
  "smartphone": 58156,
  "smb_share": 63307,
  "smoke_free": 60234,
  "smoking_rooms": 60235,
  "sms": 58917,
  "sms_failed": 58918,
  "snippet_folder": 61895,
  "snooze": 57414,
  "snowboarding": 58643,
  "snowing": 59407,
  "snowing_heavy": 63004,
  "snowmobile": 58627,
  "snowshoeing": 58644,
  "soap": 61874,
  "soba": 61238,
  "social_distance": 57803,
  "social_leaderboard": 63136,
  "solar_power": 60431,
  "solo_dining": 61237,
  "sort": 57700,
  "sort_by_alpha": 57427,
  "sos": 60407,
  "sound_detection_dog_barking": 61769,
  "sound_detection_glass_break": 61770,
  "sound_detection_loud_sound": 61771,
  "sound_sampler": 63156,
  "soup_kitchen": 59347,
  "source": 61892,
  "source_environment": 58663,
  "source_notes": 57645,
  "south": 61923,
  "south_america": 59364,
  "south_east": 61924,
  "south_west": 61925,
  "spa": 60236,
  "space_bar": 57942,
  "space_dashboard": 58987,
  "spatial_audio": 60395,
  "spatial_audio_off": 60392,
  "spatial_speaker": 62671,
  "spatial_tracking": 60394,
  "speaker": 58157,
  "speaker_group": 58158,
  "speaker_notes": 59597,
  "speaker_notes_off": 59690,
  "speaker_phone": 57554,
  "special_character": 63306,
  "specific_gravity": 63602,
  "speech_to_text": 63655,
  "speed": 59876,
  "speed_0_25": 62676,
  "speed_0_2x": 62616,
  "speed_0_5": 62690,
  "speed_0_5x": 62615,
  "speed_0_75": 62675,
  "speed_0_7x": 62614,
  "speed_1_2": 62689,
  "speed_1_25": 62674,
  "speed_1_2x": 62613,
  "speed_1_5": 62688,
  "speed_1_5x": 62612,
  "speed_1_75": 62673,
  "speed_1_7x": 62611,
  "speed_2x": 62699,
  "speed_camera": 62576,
  "spellcheck": 59598,
  "split_scene": 62399,
  "split_scene_down": 62207,
  "split_scene_left": 62206,
  "split_scene_right": 62205,
  "split_scene_up": 62204,
  "splitscreen": 61549,
  "splitscreen_add": 62717,
  "splitscreen_bottom": 63094,
  "splitscreen_landscape": 62553,
  "splitscreen_left": 63093,
  "splitscreen_portrait": 62552,
  "splitscreen_right": 63092,
  "splitscreen_top": 63091,
  "splitscreen_vertical_add": 62716,
  "spo2": 63195,
  "spoke": 59815,
  "sports": 59952,
  "sports_and_outdoors": 61368,
  "sports_bar": 61939,
  "sports_baseball": 59985,
  "sports_basketball": 59942,
  "sports_cricket": 59943,
  "sports_esports": 59944,
  "sports_football": 59945,
  "sports_golf": 59946,
  "sports_gymnastics": 60356,
  "sports_handball": 59955,
  "sports_hockey": 59947,
  "sports_kabaddi": 59956,
  "sports_martial_arts": 60137,
  "sports_mma": 59948,
  "sports_motorsports": 59949,
  "sports_rugby": 59950,
  "sports_score": 61550,
  "sports_soccer": 59951,
  "sports_tennis": 59954,
  "sports_volleyball": 59953,
  "sprinkler": 58010,
  "sprint": 63519,
  "square": 60214,
  "square_dot": 62387,
  "square_foot": 59977,
  "ssid_chart": 60262,
  "stack": 62985,
  "stack_group": 62297,
  "stack_hexagon": 62492,
  "stack_off": 62984,
  "stack_star": 62983,
  "stacked_bar_chart": 59878,
  "stacked_email": 59079,
  "stacked_inbox": 59081,
  "stacked_line_chart": 61995,
  "stacks": 62720,
  "stadia_controller": 61749,
  "stadium": 60304,
  "stairs": 61865,
  "stairs_2": 62572,
  "star": 59448,
  "star_border": 59450,
  "star_border_purple500": 61593,
  "star_half": 59449,
  "star_outline": 61551,
  "star_purple500": 61594,
  "star_rate": 61676,
  "star_rate_half": 60485,
  "star_shine": 62237,
  "stars": 59600,
  "stars_2": 62236,
  "start": 57481,
  "stat_0": 59031,
  "stat_1": 59032,
  "stat_2": 59033,
  "stat_3": 59034,
  "stat_minus_1": 59035,
  "stat_minus_2": 59036,
  "stat_minus_3": 59037,
  "stay_current_landscape": 57555,
  "stay_current_portrait": 57556,
  "stay_primary_landscape": 57557,
  "stay_primary_portrait": 57558,
  "steering_wheel_heat": 62251,
  "step": 63230,
  "step_into": 63233,
  "step_out": 63232,
  "step_over": 63231,
  "steppers": 59879,
  "steps": 63194,
  "stethoscope": 63493,
  "stethoscope_arrow": 63495,
  "stethoscope_check": 63494,
  "sticky_note": 59880,
  "sticky_note_2": 61948,
  "stock_media": 62832,
  "stockpot": 62789,
  "stop": 57415,
  "stop_circle": 61297,
  "stop_screen_share": 57571,
  "storage": 57819,
  "store": 59601,
  "store_mall_directory": 58723,
  "storefront": 59922,
  "storm": 61552,
  "straight": 60309,
  "straighten": 58396,
  "strategy": 62943,
  "stream": 59881,
  "streetview": 58734,
  "stress_management": 63193,
  "strikethrough_s": 57943,
  "stroke_full": 63305,
  "stroke_partial": 63304,
  "stroller": 61870,
  "style": 58397,
  "styler": 57971,
  "stylus": 62980,
  "stylus_brush": 62310,
  "stylus_fountain_pen": 62309,
  "stylus_highlighter": 62308,
  "stylus_laser_pointer": 63303,
  "stylus_note": 62979,
  "stylus_pen": 62307,
  "stylus_pencil": 62306,
  "subdirectory_arrow_left": 58841,
  "subdirectory_arrow_right": 58842,
  "subheader": 59882,
  "subject": 59602,
  "subscript": 61713,
  "subscriptions": 57444,
  "subtitles": 57416,
  "subtitles_gear": 62293,
  "subtitles_off": 61298,
  "subway": 58735,
  "subway_walk": 62087,
  "summarize": 61553,
  "sunny": 59418,
  "sunny_snowing": 59417,
  "superscript": 61714,
  "supervised_user_circle": 59705,
  "supervised_user_circle_off": 62990,
  "supervisor_account": 59603,
  "support": 61299,
  "support_agent": 61666,
  "surfing": 58645,
  "surgical": 57649,
  "surround_sound": 57417,
  "swap_calls": 57559,
  "swap_driving_apps": 59038,
  "swap_driving_apps_wheel": 59039,
  "swap_horiz": 59604,
  "swap_horizontal_circle": 59699,
  "swap_vert": 59605,
  "swap_vertical_circle": 59606,
  "sweep": 59052,
  "swipe": 59884,
  "swipe_down": 60243,
  "swipe_down_alt": 60208,
  "swipe_left": 60249,
  "swipe_left_alt": 60211,
  "swipe_right": 60242,
  "swipe_right_alt": 60246,
  "swipe_up": 60206,
  "swipe_up_alt": 60213,
  "swipe_vertical": 60241,
  "switch": 57844,
  "switch_access": 63229,
  "switch_access_2": 62726,
  "switch_access_3": 62285,
  "switch_access_shortcut": 59361,
  "switch_access_shortcut_add": 59362,
  "switch_account": 59885,
  "switch_camera": 58398,
  "switch_left": 61905,
  "switch_right": 61906,
  "switch_video": 58399,
  "switches": 59187,
  "sword_rose": 62942,
  "swords": 63625,
  "symptoms": 57650,
  "synagogue": 60080,
  "sync": 58919,
  "sync_alt": 59928,
  "sync_arrow_down": 62332,
  "sync_arrow_up": 62331,
  "sync_desktop": 62490,
  "sync_disabled": 58920,
  "sync_lock": 60142,
  "sync_problem": 58921,
  "sync_saved_locally": 63520,
  "sync_saved_locally_off": 62052,
  "syringe": 57651,
  "system_security_update": 61554,
  "system_security_update_good": 61555,
  "system_security_update_warning": 61556,
  "system_update": 58922,
  "system_update_alt": 59607,
  "tab": 59608,
  "tab_close": 63301,
  "tab_close_inactive": 62416,
  "tab_close_right": 63302,
  "tab_duplicate": 63300,
  "tab_group": 63299,
  "tab_inactive": 62523,
  "tab_move": 63298,
  "tab_new_right": 63297,
  "tab_recent": 63296,
  "tab_search": 62194,
  "tab_unselected": 59609,
  "table": 61841,
  "table_bar": 60114,
  "table_chart": 57957,
  "table_chart_view": 63215,
  "table_convert": 62407,
  "table_edit": 62406,
  "table_eye": 62566,
  "table_lamp": 57842,
  "table_large": 62105,
  "table_restaurant": 60102,
  "table_rows": 61697,
  "table_rows_narrow": 63295,
  "table_sign": 61228,
  "table_view": 61886,
  "tablet": 58159,
  "tablet_android": 58160,
  "tablet_camera": 62541,
  "tablet_mac": 58161,
  "tabs": 59886,
  "tactic": 62820,
  "tag": 59887,
  "tag_faces": 58400,
  "takeout_dining": 60020,
  "takeout_dining_2": 61236,
  "tamper_detection_off": 59438,
  "tamper_detection_on": 63688,
  "tap_and_play": 58923,
  "tapas": 61929,
  "target": 59161,
  "task": 61557,
  "task_alt": 58086,
  "tatami_seat": 61235,
  "taunt": 63135,
  "taxi_alert": 61300,
  "team_dashboard": 57363,
  "temp_preferences_eco": 63690,
  "temple_buddhist": 60083,
  "temple_hindu": 60079,
  "tenancy": 61667,
  "terminal": 60302,
  "terrain": 58724,
  "text_ad": 59176,
  "text_compare": 62405,
  "text_decrease": 60125,
  "text_fields": 57954,
  "text_fields_alt": 59889,
  "text_format": 57701,
  "text_increase": 60130,
  "text_rotate_up": 59706,
  "text_rotate_vertical": 59707,
  "text_rotation_angledown": 59708,
  "text_rotation_angleup": 59709,
  "text_rotation_down": 59710,
  "text_rotation_none": 59711,
  "text_select_end": 63294,
  "text_select_jump_to_beginning": 63293,
  "text_select_jump_to_end": 63292,
  "text_select_move_back_character": 63291,
  "text_select_move_back_word": 63290,
  "text_select_move_down": 63289,
  "text_select_move_forward_character": 63288,
  "text_select_move_forward_word": 63287,
  "text_select_move_up": 63286,
  "text_select_start": 63285,
  "text_snippet": 61894,
  "text_to_speech": 61884,
  "text_up": 62622,
  "textsms": 57560,
  "texture": 58401,
  "texture_add": 62844,
  "texture_minus": 62843,
  "theater_comedy": 60006,
  "theaters": 59610,
  "thermometer": 59462,
  "thermometer_add": 62850,
  "thermometer_gain": 63192,
  "thermometer_loss": 63191,
  "thermometer_minus": 62849,
  "thermostat": 61558,
  "thermostat_arrow_down": 62330,
  "thermostat_arrow_up": 62329,
  "thermostat_auto": 61559,
  "thermostat_carbon": 61816,
  "things_to_do": 60202,
  "thread_unread": 62713,
  "threat_intelligence": 60141,
  "thumb_down": 59611,
  "thumb_down_alt": 59414,
  "thumb_down_off_alt": 59890,
  "thumb_up": 59612,
  "thumb_up_alt": 59415,
  "thumb_up_off_alt": 59891,
  "thumbnail_bar": 63284,
  "thumbs_up_double": 61180,
  "thumbs_up_down": 59613,
  "thunderstorm": 60379,
  "tibia": 63643,
  "tibia_alt": 63644,
  "tile_large": 62403,
  "tile_medium": 62402,
  "tile_small": 62401,
  "time_auto": 61668,
  "time_to_leave": 58924,
  "timelapse": 58402,
  "timeline": 59682,
  "timer": 58405,
  "timer_1": 62127,
  "timer_10": 58403,
  "timer_10_alt_1": 61375,
  "timer_10_select": 61562,
  "timer_2": 62126,
  "timer_3": 58404,
  "timer_3_alt_1": 61376,
  "timer_3_select": 61563,
  "timer_5": 62641,
  "timer_5_shutter": 62642,
  "timer_arrow_down": 62328,
  "timer_arrow_up": 62327,
  "timer_off": 58406,
  "timer_pause": 62651,
  "timer_play": 62650,
  "tips_and_updates": 59290,
  "tire_repair": 60360,
  "title": 57956,
  "titlecase": 62601,
  "toast": 61377,
  "toc": 59614,
  "today": 59615,
  "toggle_off": 59893,
  "toggle_on": 59894,
  "token": 59941,
  "toll": 59616,
  "tonality": 58407,
  "tonality_2": 62132,
  "toolbar": 59895,
  "tools_flat_head": 63691,
  "tools_installation_kit": 58027,
  "tools_ladder": 58059,
  "tools_level": 59259,
  "tools_phillips": 63692,
  "tools_pliers_wire_stripper": 58026,
  "tools_power_drill": 57833,
  "tooltip": 59896,
  "tooltip_2": 62445,
  "top_panel_close": 63283,
  "top_panel_open": 63282,
  "topic": 61896,
  "tornado": 57753,
  "total_dissolved_solids": 63607,
  "touch_app": 59667,
  "touch_double": 62347,
  "touch_long": 62346,
  "touch_triple": 62345,
  "touchpad_mouse": 63111,
  "touchpad_mouse_off": 62694,
  "tour": 61301,
  "toys": 58162,
  "toys_and_games": 61378,
  "toys_fan": 63623,
  "track_changes": 59617,
  "trackpad_input": 62663,
  "trackpad_input_2": 62473,
  "trackpad_input_3": 62472,
  "traffic": 58725,
  "traffic_jam": 62575,
  "trail_length": 60254,
  "trail_length_medium": 60259,
  "trail_length_short": 60269,
  "train": 58736,
  "tram": 58737,
  "transcribe": 63724,
  "transfer_within_a_station": 58738,
  "transform": 58408,
  "transgender": 58765,
  "transit_enterexit": 58745,
  "transit_ticket": 62449,
  "transition_chop": 62734,
  "transition_dissolve": 62733,
  "transition_fade": 62732,
  "transition_push": 62731,
  "transition_slide": 62730,
  "translate": 59618,
  "translate_indic": 62051,
  "transportation": 57885,
  "travel": 59082,
  "travel_explore": 58075,
  "travel_luggage_and_bags": 61379,
  "trending_down": 59619,
  "trending_flat": 59620,
  "trending_up": 59621,
  "trip": 59131,
  "trip_origin": 58747,
  "trolley": 63595,
  "trolley_cable_car": 62574,
  "trophy": 59162,
  "troubleshoot": 57810,
  "try": 61564,
  "tsunami": 60376,
  "tsv": 59094,
  "tty": 61866,
  "tune": 58409,
  "tungsten": 61565,
  "turn_left": 60326,
  "turn_right": 60331,
  "turn_sharp_left": 60327,
  "turn_sharp_right": 60330,
  "turn_slight_left": 60324,
  "turn_slight_right": 60314,
  "turned_in": 59622,
  "turned_in_not": 59623,
  "tv": 58163,
  "tv_displays": 62444,
  "tv_gen": 59440,
  "tv_guide": 57820,
  "tv_next": 62443,
  "tv_off": 58951,
  "tv_options_edit_channels": 57821,
  "tv_options_input_settings": 57822,
  "tv_remote": 62937,
  "tv_signin": 59163,
  "tv_with_assistant": 59269,
  "two_pager": 62751,
  "two_pager_store": 62404,
  "two_wheeler": 59897,
  "type_specimen": 63728,
  "u_turn_left": 60321,
  "u_turn_right": 60322,
  "udon": 61234,
  "ulna_radius": 63645,
  "ulna_radius_alt": 63646,
  "umbrella": 61869,
  "unarchive": 57705,
  "undo": 57702,
  "unfold_less": 58838,
  "unfold_less_double": 63695,
  "unfold_more": 58839,
  "unfold_more_double": 63696,
  "ungroup": 63281,
  "universal_currency": 59898,
  "universal_currency_alt": 59188,
  "universal_local": 59899,
  "unknown_2": 59042,
  "unknown_5": 59045,
  "unknown_7": 59047,
  "unknown_document": 63492,
  "unknown_med": 60093,
  "unlicense": 60165,
  "unpaved_road": 62573,
  "unpublished": 62006,
  "unsubscribe": 57579,
  "upcoming": 61566,
  "update": 59683,
  "update_disabled": 57461,
  "upgrade": 61691,
  "upi_pay": 62415,
  "upload": 61595,
  "upload_2": 62753,
  "upload_file": 59900,
  "uppercase": 62600,
  "urology": 57655,
  "usb": 57824,
  "usb_off": 58618,
  "user_attributes": 59144,
  "vaccines": 57656,
  "vacuum": 61381,
  "valve": 57892,
  "vape_free": 60358,
  "vaping_rooms": 60367,
  "variable_add": 62750,
  "variable_insert": 62749,
  "variable_remove": 62748,
  "variables": 63569,
  "ventilator": 57657,
  "verified": 61302,
  "verified_off": 62222,
  "verified_user": 59624,
  "vertical_align_bottom": 57944,
  "vertical_align_center": 57945,
  "vertical_align_top": 57946,
  "vertical_distribute": 57462,
  "vertical_shades": 60430,
  "vertical_shades_closed": 60429,
  "vertical_split": 59721,
  "vibration": 58925,
  "video_call": 57456,
  "video_camera_back": 61567,
  "video_camera_back_add": 62476,
  "video_camera_front": 61568,
  "video_camera_front_off": 63547,
  "video_chat": 63648,
  "video_file": 60295,
  "video_label": 57457,
  "video_library": 57418,
  "video_search": 61382,
  "video_settings": 60021,
  "video_stable": 61569,
  "videocam": 57419,
  "videocam_alert": 62352,
  "videocam_off": 57420,
  "videogame_asset": 58168,
  "videogame_asset_off": 58624,
  "view_agenda": 59625,
  "view_apps": 62326,
  "view_array": 59626,
  "view_carousel": 59627,
  "view_column": 59628,
  "view_column_2": 63559,
  "view_comfy": 58410,
  "view_comfy_alt": 60275,
  "view_compact": 58411,
  "view_compact_alt": 60276,
  "view_cozy": 60277,
  "view_day": 59629,
  "view_headline": 59630,
  "view_in_ar": 59902,
  "view_in_ar_off": 63003,
  "view_kanban": 60287,
  "view_list": 59631,
  "view_module": 59632,
  "view_object_track": 62514,
  "view_quilt": 59633,
  "view_real_size": 62658,
  "view_sidebar": 61716,
  "view_stream": 59634,
  "view_timeline": 60293,
  "view_week": 59635,
  "vignette": 58421,
  "vignette_2": 62131,
  "villa": 58758,
  "visibility": 59636,
  "visibility_lock": 63059,
  "visibility_off": 59637,
  "vital_signs": 58960,
  "vo2_max": 62634,
  "voice_chat": 58926,
  "voice_over_off": 59722,
  "voice_selection": 62858,
  "voice_selection_off": 62508,
  "voicemail": 57561,
  "voicemail_2": 62290,
  "volcano": 60378,
  "volume_down": 57421,
  "volume_down_alt": 59292,
  "volume_mute": 57422,
  "volume_off": 57423,
  "volume_up": 57424,
  "volunteer_activism": 60016,
  "voting_chip": 63570,
  "vpn_key": 57562,
  "vpn_key_alert": 63180,
  "vpn_key_off": 60282,
  "vpn_lock": 58927,
  "vpn_lock_2": 62288,
  "vr180_create2d": 61386,
  "vr180_create2d_off": 62833,
  "vrpano": 61570,
  "wall_art": 61387,
  "wall_lamp": 58036,
  "wallet": 63743,
  "wallpaper": 57788,
  "wallpaper_slideshow": 63090,
  "wand_shine": 62239,
  "wand_stars": 62238,
  "ward": 57660,
  "warehouse": 60344,
  "warning": 57346,
  "warning_amber": 61571,
  "warning_off": 63405,
  "wash": 61873,
  "washoku": 62080,
  "watch": 58164,
  "watch_arrow": 62154,
  "watch_button_press": 63146,
  "watch_check": 62568,
  "watch_later": 59684,
  "watch_off": 60131,
  "watch_screentime": 63150,
  "watch_vibration": 62567,
  "watch_wake": 63145,
  "water": 61572,
  "water_bottle": 63133,
  "water_bottle_large": 63134,
  "water_damage": 61955,
  "water_do": 63600,
  "water_drop": 59288,
  "water_ec": 63605,
  "water_full": 63190,
  "water_heater": 57988,
  "water_lock": 63149,
  "water_loss": 63189,
  "water_lux": 63604,
  "water_medium": 63188,
  "water_orp": 63608,
  "water_ph": 63610,
  "water_pump": 62936,
  "water_voc": 63611,
  "waterfall_chart": 59904,
  "waves": 57718,
  "waving_hand": 59238,
  "wb_auto": 58412,
  "wb_cloudy": 58413,
  "wb_incandescent": 58414,
  "wb_iridescent": 58422,
  "wb_shade": 59905,
  "wb_sunny": 58416,
  "wb_twighlight": 59906,
  "wb_twilight": 57798,
  "wc": 58941,
  "weather_hail": 63103,
  "weather_mix": 62987,
  "weather_snowy": 58061,
  "web": 57425,
  "web_asset": 57449,
  "web_asset_off": 58615,
  "web_stories": 58773,
  "web_traffic": 59907,
  "webhook": 60306,
  "weekend": 57707,
  "weight": 57661,
  "west": 61926,
  "whatshot": 59406,
  "wheelchair_pickup": 61867,
  "where_to_vote": 57719,
  "widget_medium": 62394,
  "widget_small": 62393,
  "widget_width": 62392,
  "widgets": 57789,
  "width_full": 63733,
  "width_normal": 63734,
  "width_wide": 63735,
  "wifi": 58942,
  "wifi_1_bar": 58570,
  "wifi_2_bar": 58585,
  "wifi_add": 63400,
  "wifi_calling": 61303,
  "wifi_calling_1": 61671,
  "wifi_calling_2": 61686,
  "wifi_calling_3": 61573,
  "wifi_calling_bar_1": 62540,
  "wifi_calling_bar_2": 62539,
  "wifi_calling_bar_3": 62538,
  "wifi_channel": 60266,
  "wifi_find": 60209,
  "wifi_home": 63089,
  "wifi_lock": 57825,
  "wifi_notification": 63088,
  "wifi_off": 58952,
  "wifi_password": 60267,
  "wifi_protected_setup": 61692,
  "wifi_proxy": 63399,
  "wifi_tethering": 57826,
  "wifi_tethering_error": 60121,
  "wifi_tethering_off": 61575,
  "wind_power": 60428,
  "window": 61576,
  "window_closed": 59262,
  "window_open": 59276,
  "window_sensor": 58043,
  "windshield_defrost_auto": 62024,
  "windshield_defrost_front": 62250,
  "windshield_defrost_rear": 62249,
  "windshield_heat_front": 62248,
  "wine_bar": 61928,
  "woman": 57662,
  "woman_2": 63719,
  "work": 59641,
  "work_alert": 62967,
  "work_history": 60425,
  "work_off": 59714,
  "work_outline": 59715,
  "work_update": 62968,
  "workspace_premium": 59311,
  "workspaces": 57760,
  "workspaces_filled": 59917,
  "workspaces_outline": 59919,
  "wounds_injuries": 57663,
  "wrap_text": 57947,
  "wrist": 63132,
  "wrong_location": 61304,
  "wysiwyg": 61891,
  "yakitori": 61233,
  "yard": 61577,
  "yoshoku": 62079,
  "your_trips": 60203,
  "youtube_activity": 63578,
  "youtube_searched_for": 59642,
  "zone_person_alert": 59265,
  "zone_person_idle": 59258,
  "zone_person_urgent": 59272,
  "zoom_in": 59647,
  "zoom_in_map": 60205,
  "zoom_out": 59648,
  "zoom_out_map": 58731
}
;
},809,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.getFont = getFont;
  var _androidWeightsRegular = require(_dependencyMap[0]);
  var regular = _interopDefault(_androidWeightsRegular);
  function getFont(weight) {
    const platformWeight = typeof weight === 'object' ? weight.android : null;
    if (!platformWeight) return regular.default;
    return platformWeight;
  }
},810,[811]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _expoGoogleFontsMaterialSymbols400Regular = require(_dependencyMap[0]);
  const weight = {
    name: 'MaterialSymbols_400Regular',
    font: _expoGoogleFontsMaterialSymbols400Regular.MaterialSymbols_400Regular
  };
  var _default = weight;
},811,[812]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "MaterialSymbols_400Regular", {
    enumerable: true,
    get: function () {
      return MaterialSymbols_400Regular;
    }
  });
  // This file is generated by @expo-google-fonts/generator
  // If you want to modify it, go to packages/generator/templates

  const MaterialSymbols_400Regular = require(_dependencyMap[0]);
},812,[813]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  module.exports = "/assets/__node_modules/.pnpm/@expo-google-fonts+material-symbols@0.4.51/node_modules/@expo-google-fonts/material-symbols/400Regular/MaterialSymbols_400Regular.6b4f0c2d698edccb36b0f132059c0205.ttf";
},813,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.SymbolView = SymbolView;
  var _reactJsxRuntime = require(_dependencyMap[0]);
  var _expoFont = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  require(_dependencyMap[3]);
  require(_dependencyMap[4]);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _android = require(_dependencyMap[7]);
  var _utils = require(_dependencyMap[8]);
  // trying to mirror iOS implementation
  const DEFAULT_SYMBOL_COLOR = '#7d9bd4';
  function SymbolView({
    name: nameProp,
    fallback,
    type,
    scale,
    weight,
    colors,
    size: sizeProp,
    tintColor,
    resizeMode,
    animationSpec,
    style: styleProp,
    ...viewProps
  }) {
    const font = (0, _react.useMemo)(() => (0, _utils.getFont)(weight), [weight]);
    const name = typeof nameProp === 'object' ? nameProp['web'] : null;
    const [loaded, setLoaded] = (0, _react.useState)(false);
    (0, _react.useEffect)(() => {
      (0, _expoFont.loadAsync)({
        [font.name]: {
          uri: font.font
        }
      }).then(() => setLoaded(true)).catch(() => {
        /* noop */});
    }, []);
    if (!name) {
      return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_reactJsxRuntime.Fragment, {
        children: fallback
      });
    }
    const size = sizeProp ?? 24;
    const style = [{
      width: size,
      height: size
    }, styleProp];
    if (!loaded) {
      return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        collapsable: false,
        ...viewProps,
        style: style
      });
    }
    return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
      collapsable: false,
      ...viewProps,
      style: style,
      children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        "aria-hidden": true,
        style: {
          fontFamily: font.name,
          color: tintColor ?? DEFAULT_SYMBOL_COLOR,
          fontSize: size,
          lineHeight: size
        },
        children: (0, _android.androidSymbolToString)(name)
      })
    });
  }
},814,[6,826,12,104,15,188,109,808,810]);