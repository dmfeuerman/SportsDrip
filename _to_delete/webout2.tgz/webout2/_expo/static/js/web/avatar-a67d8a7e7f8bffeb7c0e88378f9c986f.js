__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return LockerScreen;
    }
  });
  var _expoVectorIcons = require(_dependencyMap[0]);
  var _libMotion = require(_dependencyMap[1]);
  var _expoRouter = require(_dependencyMap[2]);
  var _react = require(_dependencyMap[3]);
  require(_dependencyMap[4]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[5]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[6]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[7]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[8]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[9]);
  var _reactNativeSafeAreaContext = require(_dependencyMap[10]);
  var _componentsAvatarDisplay = require(_dependencyMap[11]);
  var AvatarDisplay = _interopDefault(_componentsAvatarDisplay);
  var _componentsAvatarAvatarBackdrop = require(_dependencyMap[12]);
  var _componentsCartButton = require(_dependencyMap[13]);
  var CartButton = _interopDefault(_componentsCartButton);
  var _componentsFavoriteTeamsSheet = require(_dependencyMap[14]);
  var FavoriteTeamsSheet = _interopDefault(_componentsFavoriteTeamsSheet);
  var _componentsPlayerProfileSheet = require(_dependencyMap[15]);
  var PlayerProfileSheet = _interopDefault(_componentsPlayerProfileSheet);
  var _componentsTeamChips = require(_dependencyMap[16]);
  var TeamChips = _interopDefault(_componentsTeamChips);
  var _componentsAvatarItemIcon = require(_dependencyMap[17]);
  var ItemIcon = _interopDefault(_componentsAvatarItemIcon);
  var _componentsTokenBalance = require(_dependencyMap[18]);
  var TokenBalance = _interopDefault(_componentsTokenBalance);
  var _componentsUi = require(_dependencyMap[19]);
  var _contextAppContext = require(_dependencyMap[20]);
  var _hooksUseCatalog = require(_dependencyMap[21]);
  var _hooksUseColors = require(_dependencyMap[22]);
  var _libSettings = require(_dependencyMap[23]);
  var _typesCatalog = require(_dependencyMap[24]);
  var _constantsMoves = require(_dependencyMap[25]);
  var _constantsAchievements = require(_dependencyMap[26]);
  var _reactJsxRuntime = require(_dependencyMap[27]);
  const ACHIEVEMENT_COUNT = _constantsAchievements.ACHIEVEMENTS.length;
  /**
   * Locker: your character, live, with what it's wearing. All editing happens
   * in the character creator (/customize), which commits a whole look at once.
   */
  function LockerScreen() {
    const c = (0, _hooksUseColors.useColors)();
    const insets = (0, _reactNativeSafeAreaContext.useSafeAreaInsets)();
    const {
      profile,
      balance,
      inventory,
      trophies,
      error,
      clearError,
      bets,
      loadout,
      equip,
      background
    } = (0, _contextAppContext.useApp)();
    const achievements = (0, _react.useMemo)(() => trophies.filter(t => t.kind === "achievement"), [trophies]);
    const leagueTrophies = (0, _react.useMemo)(() => trophies.filter(t_0 => t_0.kind !== "achievement"), [trophies]);
    const {
      byId
    } = (0, _hooksUseCatalog.useCatalog)();
    const focused = (0, _expoRouter.useIsFocused)();
    // Stage: the backdrop zooms with the camera; tapping the character cycles through the loadout.
    const cam = (0, _componentsAvatarAvatarBackdrop.useBackdropCam)();
    const [stageMove, setStageMove] = (0, _react.useState)(null);
    const nextMove = (0, _react.useRef)(0);
    const [editTeams, setEditTeams] = (0, _react.useState)(false);
    // "Edit my profile → Favorite Teams" lands here with ?editTeams=1.
    const params = (0, _expoRouter.useLocalSearchParams)();
    (0, _react.useEffect)(() => {
      if (params.editTeams !== "1") return;
      setEditTeams(true);
      _expoRouter.router.setParams({
        editTeams: undefined
      });
    }, [params.editTeams]);
    const [showProfile, setShowProfile] = (0, _react.useState)(false);
    const favoriteTeams = profile?.favoriteTeams ?? [];
    const activePunishment = profile?.punishment && profile.punishment.expiresAt > Date.now() ? profile.punishment : null;
    const saved = profile?.equipped;
    // Wardrobe taps show on the character at once; each entry clears when the
    // profile snapshot catches up (or the call fails).
    const [pending, setPending] = (0, _react.useState)({});
    const equipped = (0, _react.useMemo)(() => {
      const out = {
        ...(saved ?? {})
      };
      for (const [slot, id] of Object.entries(pending)) {
        if (id) out[slot] = id;else delete out[slot];
      }
      return out;
    }, [saved, pending]);
    (0, _react.useEffect)(() => {
      setPending(p => {
        const next = {
          ...p
        };
        let changed = false;
        for (const [slot_0, id_0] of Object.entries(p)) {
          if ((saved?.[slot_0] ?? null) === id_0) {
            delete next[slot_0];
            changed = true;
          }
        }
        return changed ? next : p;
      });
    }, [saved]);
    const wear = (0, _react.useCallback)(async (slot_1, itemId) => {
      const next_0 = equipped[slot_1] === itemId ? null : itemId;
      _libMotion.haptic.light();
      setPending(p_0 => ({
        ...p_0,
        [slot_1]: next_0
      }));
      const ok = await equip(slot_1, next_0);
      if (!ok) setPending(p_1 => {
        const {
          [slot_1]: _drop,
          ...rest
        } = p_1;
        return rest;
      });
    }, [equip, equipped]);
    const owned = (0, _react.useMemo)(() => inventory.map(id_1 => byId.get(id_1)).filter(i => !!i), [inventory, byId]);
    const settled = bets.filter(b => b.status === "won" || b.status === "lost");
    const wins = settled.filter(b_0 => b_0.status === "won").length;
    const open = category => _expoRouter.router.push(category ? {
      pathname: "/customize",
      params: {
        category
      }
    } : "/customize");
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
      style: [styles.fill, {
        backgroundColor: c.background
      }],
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.header, {
          paddingTop: 36,
          borderBottomColor: c.border
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: {
            flex: 1
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            accessibilityRole: "header",
            style: [styles.title, {
              color: c.foreground
            }],
            numberOfLines: 1,
            children: "Locker"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.handle, {
              color: c.mutedForeground
            }],
            numberOfLines: 1,
            children: [profile?.displayName ?? "Player", profile?.username ? ` · @${profile.username}` : ""]
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TokenBalance.default, {
          tokens: balance
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(CartButton.default, {
          from: "locker"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
          style: [styles.iconBtn, {
            backgroundColor: c.secondary,
            borderColor: c.border
          }],
          onPress: _libSettings.openWalkthrough,
          accessibilityRole: "button",
          accessibilityLabel: "App walkthrough and info",
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "help-circle-outline",
            size: 17,
            color: c.foreground
          })
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
          style: [styles.iconBtn, {
            backgroundColor: c.secondary,
            borderColor: c.border
          }],
          onPress: () => _expoRouter.router.push("/settings"),
          accessibilityRole: "button",
          accessibilityLabel: "Settings",
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "cog-outline",
            size: 17,
            color: c.foreground
          })
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ErrorBanner, {
        message: error,
        onDismiss: clearError
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        contentContainerStyle: [styles.content, {
          paddingBottom: 100
        }],
        showsVerticalScrollIndicator: false,
        children: [activePunishment ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
          style: {
            gap: 4,
            borderColor: c.negative
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.teamsHead,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "emoticon-sad-outline",
              size: 18,
              color: c.negative
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.quickTitle, {
                color: c.foreground,
                flex: 1
              }],
              children: ["Last-Place Punishment \xB7 ", activePunishment.leagueName]
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.quickSub, {
              color: c.mutedForeground
            }],
            children: ["Equipped until ", new Date(activePunishment.expiresAt).toLocaleDateString(), "."]
          })]
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.stage, {
            backgroundColor: c.card,
            borderColor: c.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [styles.floor, {
              backgroundColor: c.secondary
            }]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.stageInner,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarAvatarBackdrop.ZoomingBackdrop, {
              id: background,
              cam: cam
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarDisplay.default, {
              avatar: profile?.avatar,
              equipped: equipped,
              catalog: byId,
              size: "lg",
              active: focused,
              backdropCam: cam,
              move: stageMove,
              onTap: () => {
                const loadout_0 = (0, _constantsMoves.loadoutOf)(profile?.moves);
                if (!loadout_0.length) return;
                const id_2 = loadout_0[nextMove.current++ % loadout_0.length];
                setStageMove(m => ({
                  id: id_2,
                  n: (m?.n ?? 0) + 1
                }));
              }
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.stageBar, {
              borderTopColor: c.border
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              label: "Scene",
              icon: "image-filter-hdr",
              size: "sm",
              variant: "secondary",
              onPress: () => _expoRouter.router.push({
                pathname: "/shop",
                params: {
                  tab: "backgrounds"
                }
              })
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              label: "Drip Shop",
              icon: "shopping-outline",
              size: "sm",
              onPress: () => _expoRouter.router.push("/shop")
            })]
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.quickRow,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
            onPress: () => _expoRouter.router.push("/bets"),
            style: styles.quickCard,
            accessibilityLabel: "My bets",
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.teamsHead,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "ticket-confirmation-outline",
                size: 20,
                color: c.accent
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.quickTitle, {
                  color: c.foreground,
                  flex: 1
                }],
                children: "My Bets"
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "chevron-right",
                size: 18,
                color: c.mutedForeground
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.quickBig, {
                color: c.foreground
              }],
              children: [wins, "\u2013", settled.length - wins]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.quickSub, {
                color: c.mutedForeground
              }],
              children: settled.length ? `${Math.round(wins / settled.length * 100)}% hit rate` : "No results yet"
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
            onPress: () => _expoRouter.router.push("/trophies"),
            style: styles.quickCard,
            accessibilityLabel: "Trophy shelf",
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.teamsHead,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "trophy",
                size: 20,
                color: c.primary
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.quickTitle, {
                  color: c.foreground,
                  flex: 1
                }],
                children: "Trophy Shelf"
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "chevron-right",
                size: 18,
                color: c.mutedForeground
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.quickBig, {
                color: c.foreground
              }],
              children: trophies.length
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.quickSub, {
                color: c.mutedForeground
              }],
              children: [achievements.length, "/", ACHIEVEMENT_COUNT, " achievements", leagueTrophies.length ? ` · ${leagueTrophies.length} league` : ""]
            })]
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
          style: {
            gap: 10
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.teamsHead,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "human-handsup",
              size: 18,
              color: c.primary
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.quickTitle, {
                color: c.foreground,
                flex: 1
              }],
              children: "Moves"
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              label: "Edit",
              size: "sm",
              variant: "secondary",
              icon: "music-note",
              onPress: () => _expoRouter.router.push("/moves")
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
            onPress: () => _expoRouter.router.push("/moves"),
            accessibilityLabel: "Moves: your dance button",
            style: styles.moves,
            children: Array.from({
              length: _constantsMoves.MAX_LOADOUT
            }, (_, i_0) => {
              const m_0 = loadout[i_0] ? _constantsMoves.MOVES_BY_ID.get(loadout[i_0]) : undefined;
              return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: [styles.moveSlot, {
                  backgroundColor: m_0 ? c.secondary : "transparent",
                  borderColor: c.border,
                  borderStyle: m_0 ? "solid" : "dashed"
                }],
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                  name: m_0?.icon ?? "plus",
                  size: 18,
                  color: m_0 ? c.rarity(m_0.rarity) : c.subtleForeground
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.moveName, {
                    color: m_0 ? c.foreground : c.subtleForeground
                  }],
                  numberOfLines: 1,
                  children: m_0?.name ?? "Empty"
                })]
              }, i_0);
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.teamsHead,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.quickSub, {
                color: c.mutedForeground,
                flex: 1
              }],
              children: "Tap the dance button on your character to pick one."
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              label: "Get More",
              size: "sm",
              variant: "ghost",
              icon: "cart-outline",
              onPress: () => _expoRouter.router.push({
                pathname: "/shop",
                params: {
                  tab: "moves"
                }
              })
            })]
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
          style: {
            gap: 10
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.teamsHead,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "heart-outline",
              size: 18,
              color: c.primary
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.quickTitle, {
                color: c.foreground,
                flex: 1
              }],
              children: "Favorite Teams"
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              label: favoriteTeams.length ? "Edit" : "Add",
              size: "sm",
              variant: "secondary",
              icon: "pencil-outline",
              onPress: () => setEditTeams(true)
            })]
          }), favoriteTeams.length ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TeamChips.default, {
            teams: favoriteTeams,
            max: 5
          }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.quickSub, {
              color: c.mutedForeground
            }],
            children: "Pick up to 5 \u2014 they show on your profile and in league standings."
          }), profile?.uid ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: "View My Profile",
            size: "sm",
            variant: "ghost",
            icon: "card-account-details-outline",
            onPress: () => setShowProfile(true)
          }) : null]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.section, {
            color: c.foreground
          }],
          children: "Wearing"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: styles.slots,
          children: _typesCatalog.SLOT_ORDER.map(slot_2 => {
            const item = equipped[slot_2] ? byId.get(equipped[slot_2]) : undefined;
            return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
              onPress: () => open(slot_2),
              accessibilityRole: "button",
              accessibilityLabel: `${_typesCatalog.SLOT_LABELS[slot_2]}: ${item?.name ?? "nothing"}. Change`,
              style: ({
                pressed
              }) => [styles.slot, {
                backgroundColor: c.card,
                borderColor: c.border,
                opacity: pressed ? 0.85 : 1
              }],
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
                style: [styles.slotArt, {
                  backgroundColor: c.secondary
                }],
                children: item ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ItemIcon.default, {
                  item: item,
                  size: 44
                }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                  name: _typesCatalog.SLOT_ICONS[slot_2],
                  size: 20,
                  color: c.subtleForeground
                })
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.slotLabel, {
                  color: c.mutedForeground
                }],
                children: _typesCatalog.SLOT_LABELS[slot_2].toUpperCase()
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.slotValue, {
                  color: item ? c.foreground : c.subtleForeground
                }],
                numberOfLines: 1,
                children: item?.name ?? "—"
              })]
            }, slot_2);
          })
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.wardrobeHead,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.section, {
              color: c.foreground
            }],
            children: ["Wardrobe \xB7 ", owned.length]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.quickSub, {
              color: c.mutedForeground
            }],
            children: "Tap to Wear \xB7 Hold to Customize"
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: styles.wardrobe,
          children: owned.map(item_0 => {
            const on = equipped[item_0.slot] === item_0.id;
            return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
              onPress: () => void wear(item_0.slot, item_0.id),
              onLongPress: () => open(item_0.slot),
              accessibilityRole: "button",
              accessibilityLabel: `${item_0.name}${on ? ", wearing" : ""}`,
              accessibilityHint: on ? "Takes it off" : "Puts it on",
              style: [styles.wItem, {
                backgroundColor: c.card,
                borderColor: on ? c.primary : c.border,
                borderWidth: on ? 2 : 1
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ItemIcon.default, {
                item: item_0,
                size: 52
              })
            }, item_0.id);
          })
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FavoriteTeamsSheet.default, {
        visible: editTeams,
        initial: favoriteTeams,
        initialReminders: !!profile?.teamReminders,
        uid: profile?.uid,
        onClose: () => setEditTeams(false)
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PlayerProfileSheet.default, {
        uid: showProfile ? profile?.uid ?? null : null,
        onClose: () => setShowProfile(false),
        seed: profile ? {
          displayName: profile.displayName,
          username: profile.username,
          avatar: profile.avatar,
          equipped: profile.equipped,
          moves: profile.moves,
          favoriteTeams
        } : undefined
      })]
    });
  }
  const styles = StyleSheet.default.create({
    fill: {
      flex: 1
    },
    header: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      borderBottomWidth: 1,
      paddingHorizontal: 16,
      paddingBottom: 12
    },
    title: {
      fontSize: 22,
      fontFamily: "Inter_900Black"
    },
    handle: {
      fontSize: 12,
      fontFamily: "Inter_400Regular",
      marginTop: 1
    },
    iconBtn: {
      width: 34,
      height: 34,
      borderRadius: 17,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center"
    },
    content: {
      padding: 16,
      gap: 14
    },
    stage: {
      borderRadius: 20,
      borderWidth: 1,
      overflow: "hidden"
    },
    floor: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: 52,
      height: 90
    },
    stageInner: {
      height: 400,
      overflow: "hidden"
    },
    stageBar: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "flex-end",
      gap: 8,
      paddingHorizontal: 14,
      paddingVertical: 10,
      borderTopWidth: StyleSheet.default.hairlineWidth
    },
    quickRow: {
      flexDirection: "row",
      gap: 8
    },
    quickCard: {
      flex: 1,
      gap: 4,
      padding: 12
    },
    quickTitle: {
      fontSize: 14,
      fontFamily: "Inter_700Bold"
    },
    quickBig: {
      fontSize: 22,
      fontFamily: "Inter_900Black",
      marginTop: 2
    },
    quickSub: {
      fontSize: 11,
      fontFamily: "Inter_400Regular"
    },
    teamsHead: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    moves: {
      flexDirection: "row",
      gap: 6
    },
    moveSlot: {
      flex: 1,
      alignItems: "center",
      gap: 4,
      paddingVertical: 10,
      paddingHorizontal: 4,
      borderRadius: 12,
      borderWidth: 1
    },
    moveName: {
      fontSize: 11,
      fontFamily: "Inter_600SemiBold"
    },
    section: {
      fontSize: 16,
      fontFamily: "Inter_700Bold",
      marginTop: 4
    },
    slots: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 8
    },
    slot: {
      width: "31.5%",
      flexGrow: 1,
      borderRadius: 14,
      borderWidth: 1,
      padding: 10,
      gap: 4
    },
    slotArt: {
      height: 52,
      borderRadius: 10,
      alignItems: "center",
      justifyContent: "center"
    },
    slotLabel: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.5
    },
    slotValue: {
      fontSize: 12,
      fontFamily: "Inter_600SemiBold"
    },
    wardrobe: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 8
    },
    wardrobeHead: {
      flexDirection: "row",
      alignItems: "flex-end",
      justifyContent: "space-between",
      gap: 8
    },
    wItem: {
      width: 66,
      height: 66,
      borderRadius: 14,
      alignItems: "center",
      justifyContent: "center"
    },
    privacy: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 6,
      paddingVertical: 12,
      marginTop: 4
    },
    privacyText: {
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    }
  });
},750,[818,820,817,12,104,133,28,188,109,827,271,828,829,830,831,832,833,834,835,836,837,838,819,816,839,840,841,6]);