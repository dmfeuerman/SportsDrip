__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return FeedScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  require(_dependencyMap[1]);
  var _reactNativeWebDistExportsFlatList = require(_dependencyMap[2]);
  var FlatList = _interopDefault(_reactNativeWebDistExportsFlatList);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[3]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsView = require(_dependencyMap[4]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsCrewFeed = require(_dependencyMap[5]);
  var _componentsUi = require(_dependencyMap[6]);
  var _hooksUseColors = require(_dependencyMap[7]);
  var _reactJsxRuntime = require(_dependencyMap[8]);
  /** Everything your league-mates did, across every league you're in. */
  function FeedScreen() {
    const $ = (0, _reactCompilerRuntime.c)(12);
    const c = (0, _hooksUseColors.useColors)();
    const bottom = (0, _componentsUi.useBottomPad)();
    const items = (0, _componentsCrewFeed.useCrewFeed)(30);
    let t0;
    if ($[0] !== c.background) {
      t0 = [styles.fill, {
        backgroundColor: c.background
      }];
      $[0] = c.background;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
        back: true,
        title: "Your Crew",
        subtitle: "Wins, rivalries and milestones from your leagues"
      });
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    let t2;
    if ($[3] !== bottom) {
      t2 = {
        padding: 16,
        paddingBottom: bottom
      };
      $[3] = bottom;
      $[4] = t2;
    } else {
      t2 = $[4];
    }
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsCrewFeed.CrewFeedEmpty, {});
      $[5] = t3;
    } else {
      t3 = $[5];
    }
    let t4;
    if ($[6] !== items || $[7] !== t2) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FlatList.default, {
        data: items,
        keyExtractor: _temp,
        contentContainerStyle: t2,
        ListEmptyComponent: t3,
        renderItem: _temp2
      });
      $[6] = items;
      $[7] = t2;
      $[8] = t4;
    } else {
      t4 = $[8];
    }
    let t5;
    if ($[9] !== t0 || $[10] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t0,
        children: [t1, t4]
      });
      $[9] = t0;
      $[10] = t4;
      $[11] = t5;
    } else {
      t5 = $[11];
    }
    return t5;
  }
  function _temp2(t0) {
    const {
      item
    } = t0;
    return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Card, {
      style: {
        padding: 0,
        marginBottom: 8,
        overflow: "hidden"
      },
      children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsCrewFeed.CrewRow, {
        item: item,
        last: true
      })
    });
  }
  function _temp(it) {
    return `${it.leagueId}_${it.id}`;
  }
  const styles = StyleSheet.default.create({
    fill: {
      flex: 1
    }
  });
},762,[815,12,107,28,109,893,836,819,6]);