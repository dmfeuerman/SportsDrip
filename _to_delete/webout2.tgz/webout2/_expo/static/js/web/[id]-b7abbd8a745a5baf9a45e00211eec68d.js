__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      if (k === 'default') return;
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return LeagueDetailScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _componentsPreseasonCard = require(_dependencyMap[2]);
  var PreseasonCard = _interopDefault(_componentsPreseasonCard);
  var _hooksUseOptimisticReaction = require(_dependencyMap[3]);
  var _libMotion = require(_dependencyMap[4]);
  var _expoLinearGradient = require(_dependencyMap[5]);
  var _expoRouter = require(_dependencyMap[6]);
  var _react = require(_dependencyMap[7]);
  var _reactNativeWebDistExportsKeyboardAvoidingView = require(_dependencyMap[8]);
  var KeyboardAvoidingView = _interopDefault(_reactNativeWebDistExportsKeyboardAvoidingView);
  require(_dependencyMap[9]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[10]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsShare = require(_dependencyMap[11]);
  var Share = _interopDefault(_reactNativeWebDistExportsShare);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[12]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[13]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsTextInput = require(_dependencyMap[14]);
  var TextInput = _interopDefault(_reactNativeWebDistExportsTextInput);
  var _reactNativeWebDistExportsView = require(_dependencyMap[15]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[16]);
  var _componentsBetBreakdownModal = require(_dependencyMap[17]);
  var BetBreakdownModal = _interopDefault(_componentsBetBreakdownModal);
  var _componentsChatReplyThread = require(_dependencyMap[18]);
  var _libChatText = require(_dependencyMap[19]);
  var _componentsChatWinLossReplyModal = require(_dependencyMap[20]);
  var WinLossReplyModal = _interopDefault(_componentsChatWinLossReplyModal);
  var _componentsKeyboardAwareScrollViewCompat = require(_dependencyMap[21]);
  var _componentsNumericInput = require(_dependencyMap[22]);
  var NumericInput = _interopDefault(_componentsNumericInput);
  var _componentsLoanCard = require(_dependencyMap[23]);
  var LoanCard = _interopDefault(_componentsLoanCard);
  var _componentsFxShimmer = require(_dependencyMap[24]);
  var Shimmer = _interopDefault(_componentsFxShimmer);
  var _componentsMemberAvatar = require(_dependencyMap[25]);
  var MemberAvatar = _interopDefault(_componentsMemberAvatar);
  var _componentsPlayerProfileSheet = require(_dependencyMap[26]);
  var PlayerProfileSheet = _interopDefault(_componentsPlayerProfileSheet);
  var _componentsChatBetChatCard = require(_dependencyMap[27]);
  var BetChatCard = _interopDefault(_componentsChatBetChatCard);
  var _componentsBracketFill = require(_dependencyMap[28]);
  var BracketFill = _interopDefault(_componentsBracketFill);
  var _componentsCoopGoalCard = require(_dependencyMap[29]);
  var CoopGoalCard = _interopDefault(_componentsCoopGoalCard);
  var _componentsChatTauntCard = require(_dependencyMap[30]);
  var TauntCard = _interopDefault(_componentsChatTauntCard);
  var _componentsGameQuickView = require(_dependencyMap[31]);
  var GameQuickView = _interopDefault(_componentsGameQuickView);
  var _componentsTeamChips = require(_dependencyMap[32]);
  var TeamChips = _interopDefault(_componentsTeamChips);
  var _contextChatContext = require(_dependencyMap[33]);
  var _componentsUi = require(_dependencyMap[34]);
  var _libApi = require(_dependencyMap[35]);
  var api = _interopNamespace(_libApi);
  var _constantsLeagueTypes = require(_dependencyMap[36]);
  var _contextAppContext = require(_dependencyMap[37]);
  var _contextToastContext = require(_dependencyMap[38]);
  var _contextLeagueContext = require(_dependencyMap[39]);
  var _hooksUseCatalog = require(_dependencyMap[40]);
  var _hooksUseColors = require(_dependencyMap[41]);
  var _hooksUseFriends = require(_dependencyMap[42]);
  var _hooksUseGames = require(_dependencyMap[43]);
  var _hooksUsePublicProfiles = require(_dependencyMap[44]);
  var _componentsInviteQR = require(_dependencyMap[45]);
  var InviteQR = _interopDefault(_componentsInviteQR);
  var _libAnalytics = require(_dependencyMap[46]);
  var _libInvites = require(_dependencyMap[47]);
  var _libLoanMath = require(_dependencyMap[48]);
  var _libMarkets = require(_dependencyMap[49]);
  var _libOdds = require(_dependencyMap[50]);
  var _libSettings = require(_dependencyMap[51]);
  var _reactJsxRuntime = require(_dependencyMap[52]);
  function ago(at, now) {
    const m = Math.max(0, Math.round((now - at) / 60_000));
    if (m < 1) return "just now";
    if (m < 60) return `${m}m ago`;
    const h = Math.round(m / 60);
    if (h < 24) return `${h}h ago`;
    return `${Math.round(h / 24)}d ago`;
  }
  function LeagueDetailScreen() {
    const $ = (0, _reactCompilerRuntime.c)(123);
    const c = (0, _hooksUseColors.useColors)();
    const fmt = (0, _libSettings.useOddsFormat)();
    const bottom = (0, _componentsUi.useBottomPad)(false);
    const params = (0, _expoRouter.useLocalSearchParams)();
    const {
      leagues,
      getLeague,
      uid,
      error,
      clearError
    } = (0, _contextLeagueContext.useLeague)();
    let t0;
    if ($[0] !== getLeague || $[1] !== params.id) {
      t0 = getLeague(params.id);
      $[0] = getLeague;
      $[1] = params.id;
      $[2] = t0;
    } else {
      t0 = $[2];
    }
    const league = t0;
    const detail = (0, _contextLeagueContext.useLeagueDetail)(league);
    const [tab, setTab] = (0, _react.useState)(params.tab ?? "standings");
    const seenAt = (0, _libSettings.useChatSeen)(league?.id);
    let t1;
    bb0: {
      if (!league || tab === "feed") {
        t1 = 0;
        break bb0;
      }
      let t2;
      if ($[3] !== detail.messages || $[4] !== seenAt || $[5] !== uid) {
        let t3;
        if ($[7] !== seenAt || $[8] !== uid) {
          t3 = m => m.uid !== uid && m.at > seenAt;
          $[7] = seenAt;
          $[8] = uid;
          $[9] = t3;
        } else {
          t3 = $[9];
        }
        t2 = detail.messages.filter(t3);
        $[3] = detail.messages;
        $[4] = seenAt;
        $[5] = uid;
        $[6] = t2;
      } else {
        t2 = $[6];
      }
      t1 = t2.length;
    }
    const unreadFeed = t1;
    let t2;
    let t3;
    if ($[10] !== detail.messages || $[11] !== league || $[12] !== tab) {
      t2 = () => {
        if (tab === "feed" && league) {
          const latest = detail.messages[0]?.at ?? Date.now();
          (0, _libSettings.markChatSeen)(league.id, Math.max(Date.now(), latest));
        }
      };
      t3 = [tab, league, detail.messages];
      $[10] = detail.messages;
      $[11] = league;
      $[12] = tab;
      $[13] = t2;
      $[14] = t3;
    } else {
      t2 = $[13];
      t3 = $[14];
    }
    (0, _react.useEffect)(t2, t3);
    if (!league) {
      let t4;
      if ($[15] !== c.background) {
        t4 = [styles.container, {
          backgroundColor: c.background
        }];
        $[15] = c.background;
        $[16] = t4;
      } else {
        t4 = $[16];
      }
      let t5;
      if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
          back: true,
          title: "League"
        });
        $[17] = t5;
      } else {
        t5 = $[17];
      }
      let t6;
      if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: {
            padding: 16
          },
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
            icon: "trophy-broken",
            title: "League Not Found",
            body: "You may have left it, or it's still loading.",
            action: "All Leagues",
            onAction: _temp
          })
        });
        $[18] = t6;
      } else {
        t6 = $[18];
      }
      let t7;
      if ($[19] !== t4) {
        t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: t4,
          children: [t5, t6]
        });
        $[19] = t4;
        $[20] = t7;
      } else {
        t7 = $[20];
      }
      return t7;
    }
    let t4;
    if ($[21] !== detail.standings || $[22] !== uid) {
      t4 = detail.standings.find(s => s.uid === uid) ?? null;
      $[21] = detail.standings;
      $[22] = uid;
      $[23] = t4;
    } else {
      t4 = $[23];
    }
    const me = t4;
    const myMember = uid ? league.members[uid] : undefined;
    const myTokens = myMember?.leagueTokens ?? 0;
    const ended = league.status === "ended";
    let t5;
    if ($[24] !== detail.now || $[25] !== league) {
      t5 = (0, _constantsLeagueTypes.isLeagueClosed)(league, detail.now);
      $[24] = detail.now;
      $[25] = league;
      $[26] = t5;
    } else {
      t5 = $[26];
    }
    const closed = t5;
    const daysLeft = Math.max(0, Math.ceil((league.endsAt - detail.now) / 86400000));
    let t6;
    if ($[27] !== closed || $[28] !== detail.loans || $[29] !== detail.now || $[30] !== league.stimulus || $[31] !== league.stimulusEnabled || $[32] !== uid) {
      t6 = closed ? 0 : detail.loans.filter(l => l.kind === "peer" && (l.status === "requested" || l.status === "countered") && l.borrowerId !== uid).length + (league.stimulusEnabled && league.stimulus && league.stimulus.expiresAt > detail.now && uid && !league.stimulus.votes.includes(uid) ? 1 : 0);
      $[27] = closed;
      $[28] = detail.loans;
      $[29] = detail.now;
      $[30] = league.stimulus;
      $[31] = league.stimulusEnabled;
      $[32] = uid;
      $[33] = t6;
    } else {
      t6 = $[33];
    }
    const pendingRequests = t6;
    const chatOpen = tab === "feed";
    let t7;
    if ($[34] !== detail.now || $[35] !== league) {
      t7 = (0, _constantsLeagueTypes.isLeagueStarted)(league, detail.now);
      $[34] = detail.now;
      $[35] = league;
      $[36] = t7;
    } else {
      t7 = $[36];
    }
    const started = t7;
    let t8;
    if ($[37] !== league) {
      t8 = new Date((0, _constantsLeagueTypes.leagueStartsAt)(league)).toLocaleString(undefined, {
        weekday: "short",
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit"
      });
      $[37] = league;
      $[38] = t8;
    } else {
      t8 = $[38];
    }
    const startLabel = t8;
    let t9;
    if ($[39] !== closed || $[40] !== league || $[41] !== started) {
      t9 = () => {
        if (closed || started) {
          return;
        }
        (0, _libAnalytics.trackEvent)("share_card_tapped", {
          surface: "league_invite",
          league_id: league.id
        });
        Share.default.share({
          message: (0, _libInvites.inviteMessage)(league),
          url: (0, _libInvites.inviteLink)(league.code),
          title: `Join ${league.name} on SportDrip`
        }).catch(_temp2);
      };
      $[39] = closed;
      $[40] = league;
      $[41] = started;
      $[42] = t9;
    } else {
      t9 = $[42];
    }
    const invite = t9;
    let t10;
    if ($[43] !== c.background) {
      t10 = [styles.container, {
        backgroundColor: c.background
      }];
      $[43] = c.background;
      $[44] = t10;
    } else {
      t10 = $[44];
    }
    const t11 = chatOpen ? `League chat · ${league.memberIds.length} member${league.memberIds.length === 1 ? "" : "s"}` : closed ? "Closed \xB7 read-only" : !started ? `Starts ${startLabel} · code ${league.code}` : `${daysLeft} day${daysLeft === 1 ? "" : "s"} left`;
    let t12;
    if ($[45] !== closed || $[46] !== invite || $[47] !== started) {
      t12 = closed ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
        label: "Closed",
        tone: "neutral",
        icon: "lock-outline"
      }) : started ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
        label: "Roster Locked",
        tone: "neutral",
        icon: "account-lock-outline"
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.IconButton, {
        icon: "account-plus-outline",
        label: "Invite",
        onPress: invite
      });
      $[45] = closed;
      $[46] = invite;
      $[47] = started;
      $[48] = t12;
    } else {
      t12 = $[48];
    }
    let t13;
    if ($[49] !== c.league || $[50] !== chatOpen || $[51] !== league.id || $[52] !== leagues) {
      t13 = !chatOpen && leagues.length > 1 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.FilterPills, {
        value: league.id,
        onChange: _temp3,
        inset: 0,
        options: leagues.map(l_0 => ({
          value: l_0.id,
          label: l_0.name,
          icon: "trophy-outline",
          color: c.league
        }))
      });
      $[49] = c.league;
      $[50] = chatOpen;
      $[51] = league.id;
      $[52] = leagues;
      $[53] = t13;
    } else {
      t13 = $[53];
    }
    let t14;
    if ($[54] !== c.foreground || $[55] !== c.mutedForeground || $[56] !== c.negative || $[57] !== c.positive || $[58] !== c.primary || $[59] !== chatOpen || $[60] !== detail.standings.length || $[61] !== league.mode || $[62] !== me || $[63] !== myMember || $[64] !== myTokens) {
      t14 = !chatOpen && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.hero,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.StatTile, {
          label: "Rank",
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.heroRank, {
              color: me?.rank === 1 ? c.primary : c.foreground
            }],
            children: ["#", me?.rank ?? "\u2013", /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.heroOf, {
                color: c.mutedForeground
              }],
              children: [" /", detail.standings.length]
            })]
          })
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.StatTile, {
          label: league.mode === "pickem" || league.mode === "bracket" ? "Points" : league.mode === "survivor" ? "Status" : league.mode === "matchups" ? "H2H record" : "Net worth",
          children: league.mode === "matchups" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.heroRank, {
              color: c.foreground
            }],
            children: [myMember?.h2h?.w ?? 0, "\u2013", myMember?.h2h?.l ?? 0, myMember?.h2h?.t ? `–${myMember.h2h.t}` : ""]
          }) : league.mode === "pickem" || league.mode === "bracket" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.heroRank, {
              color: c.foreground
            }],
            children: [myMember?.pickPoints ?? 0, " pts"]
          }) : league.mode === "survivor" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.heroRank, {
              color: myMember?.eliminated ? c.negative : c.positive
            }],
            children: myMember?.eliminated ? "Out" : "Alive"
          }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
            value: me?.netWorth ?? myTokens,
            currency: "league",
            size: "sm"
          })
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.StatTile, {
          label: me && me.debt > 0 ? "You owe" : "Tokens",
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
            value: me && me.debt > 0 ? me.debt : myTokens,
            currency: "league",
            size: "sm",
            tone: me && me.debt > 0 ? "debt" : undefined
          })
        })]
      });
      $[54] = c.foreground;
      $[55] = c.mutedForeground;
      $[56] = c.negative;
      $[57] = c.positive;
      $[58] = c.primary;
      $[59] = chatOpen;
      $[60] = detail.standings.length;
      $[61] = league.mode;
      $[62] = me;
      $[63] = myMember;
      $[64] = myTokens;
      $[65] = t14;
    } else {
      t14 = $[65];
    }
    let t15;
    let t16;
    if ($[66] === Symbol.for("react.memo_cache_sentinel")) {
      t15 = {
        value: "standings",
        label: "Table"
      };
      t16 = {
        value: "bets",
        label: "Bets"
      };
      $[66] = t15;
      $[67] = t16;
    } else {
      t15 = $[66];
      t16 = $[67];
    }
    const t17 = pendingRequests || undefined;
    let t18;
    if ($[68] !== t17) {
      t18 = {
        value: "bank",
        label: "Loans",
        badge: t17
      };
      $[68] = t17;
      $[69] = t18;
    } else {
      t18 = $[69];
    }
    const t19 = unreadFeed || undefined;
    let t20;
    if ($[70] !== t19) {
      t20 = {
        value: "feed",
        label: "Chat",
        badge: t19
      };
      $[70] = t19;
      $[71] = t20;
    } else {
      t20 = $[71];
    }
    let t21;
    if ($[72] === Symbol.for("react.memo_cache_sentinel")) {
      t21 = {
        value: "info",
        label: "Info"
      };
      $[72] = t21;
    } else {
      t21 = $[72];
    }
    let t22;
    if ($[73] !== t18 || $[74] !== t20) {
      t22 = [t15, t16, t18, t20, t21];
      $[73] = t18;
      $[74] = t20;
      $[75] = t22;
    } else {
      t22 = $[75];
    }
    let t23;
    if ($[76] !== t22 || $[77] !== tab) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.TabStrip, {
        value: tab,
        onChange: setTab,
        options: t22
      });
      $[76] = t22;
      $[77] = tab;
      $[78] = t23;
    } else {
      t23 = $[78];
    }
    let t24;
    if ($[79] !== league.name || $[80] !== t11 || $[81] !== t12 || $[82] !== t13 || $[83] !== t14 || $[84] !== t23) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.ScreenHeader, {
        back: true,
        title: league.name,
        subtitle: t11,
        right: t12,
        children: [t13, t14, t23]
      });
      $[79] = league.name;
      $[80] = t11;
      $[81] = t12;
      $[82] = t13;
      $[83] = t14;
      $[84] = t23;
      $[85] = t24;
    } else {
      t24 = $[85];
    }
    let t25;
    if ($[86] !== clearError || $[87] !== error) {
      t25 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ErrorBanner, {
        message: error,
        onDismiss: clearError
      });
      $[86] = clearError;
      $[87] = error;
      $[88] = t25;
    } else {
      t25 = $[88];
    }
    let t26;
    if ($[89] !== bottom || $[90] !== c.background || $[91] !== c.border || $[92] !== c.foreground || $[93] !== c.mutedForeground || $[94] !== closed || $[95] !== detail.activity || $[96] !== detail.audit || $[97] !== detail.bets || $[98] !== detail.loans || $[99] !== detail.matchups || $[100] !== detail.messages || $[101] !== detail.now || $[102] !== detail.parlays || $[103] !== detail.picks || $[104] !== detail.reports || $[105] !== detail.standings || $[106] !== ended || $[107] !== fmt || $[108] !== invite || $[109] !== league || $[110] !== me || $[111] !== myTokens || $[112] !== params.created || $[113] !== startLabel || $[114] !== started || $[115] !== tab || $[116] !== uid) {
      t26 = tab === "feed" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FeedTab, {
        league: league,
        activity: detail.activity,
        messages: detail.messages,
        bets: detail.bets,
        uid: uid,
        now: detail.now,
        closed: closed,
        fmt: fmt,
        bottomPad: bottom
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsKeyboardAwareScrollViewCompat.KeyboardAwareScrollViewCompat, {
          contentContainerStyle: [styles.body, {
            paddingBottom: bottom + (closed ? 0 : 72)
          }],
          showsVerticalScrollIndicator: false,
          bottomOffset: closed ? 16 : 88,
          children: [closed && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
            style: styles.closedBanner,
            accessibilityLabel: "This league is closed. You can view its history, but nothing can be changed.",
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "lock-outline",
              size: 18,
              color: c.mutedForeground
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1,
                gap: 2
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.cardTitle, {
                  color: c.foreground
                }],
                children: "League Closed"
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.muted, {
                  color: c.mutedForeground
                }],
                children: [ended ? "The season is over." : "The season is over \u2014 final results are being tallied.", " Standings, bets, loans and the feed are view-only."]
              })]
            })]
          }), ended && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
            label: "Your Season Wrapped",
            icon: "gift-outline",
            tone: "league",
            onPress: () => _expoRouter.router.push({
              pathname: "/wrapped/[id]",
              params: {
                id: league.id
              }
            })
          }), !closed && !started && tab === "standings" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PreseasonCard.default, {
            league: league,
            uid: uid,
            onInvite: invite
          }), !closed && !started && params.created && league.memberIds.length === 1 && tab === "standings" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
            tone: "league",
            style: {
              gap: 8
            },
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.cardTitle, {
                color: c.foreground
              }],
              children: "League Created"
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.muted, {
                color: c.mutedForeground
              }],
              children: ["Share code ", league.code, " or invite friends below. Everyone starts with ", league.startingLeagueTokens.toLocaleString(), " tokens."]
            })]
          }), tab === "standings" && !closed && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(CoopGoalCard.default, {
            league: league,
            uid: uid
          }), tab === "standings" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(StandingsTab, {
            league: league,
            standings: detail.standings,
            bets: detail.bets,
            matchups: detail.matchups,
            reports: detail.reports,
            uid: uid,
            closed: closed,
            onInvite: invite
          }), tab === "bets" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BetsTab, {
            league: league,
            bets: detail.bets,
            parlays: detail.parlays,
            picks: detail.picks,
            uid: uid,
            leagueId: closed ? undefined : league.id,
            now: detail.now,
            fmt: fmt
          }), tab === "bank" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BankTab, {
            league: league,
            loans: detail.loans,
            uid: uid,
            me: me,
            tokens: myTokens,
            now: detail.now,
            closed: closed
          }), tab === "info" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(InfoTab, {
            league: league,
            betsCount: detail.bets.length,
            audit: detail.audit,
            uid: uid,
            closed: closed,
            onInvite: invite
          })]
        }), !closed && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [styles.dock, {
            backgroundColor: c.background,
            borderTopColor: c.border,
            paddingBottom: bottom - 12
          }],
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: started ? `Bet with ${myTokens.toLocaleString()} league tokens` : `Betting opens ${startLabel}`,
            icon: started ? "ticket-outline" : "lock-clock",
            variant: "league",
            size: "lg",
            disabled: !started,
            onPress: () => _expoRouter.router.navigate({
              pathname: "/(tabs)/games",
              params: {
                wallet: league.id
              }
            })
          })
        })]
      });
      $[89] = bottom;
      $[90] = c.background;
      $[91] = c.border;
      $[92] = c.foreground;
      $[93] = c.mutedForeground;
      $[94] = closed;
      $[95] = detail.activity;
      $[96] = detail.audit;
      $[97] = detail.bets;
      $[98] = detail.loans;
      $[99] = detail.matchups;
      $[100] = detail.messages;
      $[101] = detail.now;
      $[102] = detail.parlays;
      $[103] = detail.picks;
      $[104] = detail.reports;
      $[105] = detail.standings;
      $[106] = ended;
      $[107] = fmt;
      $[108] = invite;
      $[109] = league;
      $[110] = me;
      $[111] = myTokens;
      $[112] = params.created;
      $[113] = startLabel;
      $[114] = started;
      $[115] = tab;
      $[116] = uid;
      $[117] = t26;
    } else {
      t26 = $[117];
    }
    let t27;
    if ($[118] !== t10 || $[119] !== t24 || $[120] !== t25 || $[121] !== t26) {
      t27 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t10,
        children: [t24, t25, t26]
      });
      $[118] = t10;
      $[119] = t24;
      $[120] = t25;
      $[121] = t26;
      $[122] = t27;
    } else {
      t27 = $[122];
    }
    return t27;
  }
  function _temp3(id) {
    return _expoRouter.router.setParams({
      id
    });
  }
  function _temp2() {}
  function _temp() {
    return _expoRouter.router.navigate("/(tabs)/leagues");
  }
  const FEED_ICON = {
    created: "flag-outline",
    joined: "account-plus-outline",
    left: "account-minus-outline",
    bet_placed: "ticket-outline",
    bet_tailed: "account-multiple-plus",
    bet_faded: "account-switch",
    bet_won: "arrow-up-bold",
    bet_lost: "arrow-down-bold",
    bet_push: "minus",
    bet_voided: "undo-variant",
    bank_loan: "bank-outline",
    loan_request: "hand-coin-outline",
    loan_funded: "handshake-outline",
    repayment: "cash-refund",
    settings: "cog-outline",
    stimulus: "cash-plus",
    ended: "trophy"
  };

  // ── Standings ──────────────────────────────────────────────────────────────

  const GOLD = "#F5C542";
  const SILVER = "#C9D1CC";
  const BRONZE = "#C4703B";
  function StandingsTab(t0) {
    const $ = (0, _reactCompilerRuntime.c)(53);
    const {
      league,
      standings,
      bets,
      matchups,
      reports,
      uid,
      closed,
      onInvite
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const {
      byId
    } = (0, _hooksUseCatalog.useCatalog)();
    const {
      profile: myProfile
    } = (0, _contextAppContext.useApp)();
    let t1;
    if ($[0] !== standings) {
      t1 = standings.map(_temp4);
      $[0] = standings;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    const fetched = (0, _hooksUsePublicProfiles.usePublicProfiles)(t1);
    const [subView, setSubView] = (0, _react.useState)("table");
    let t2;
    bb0: {
      if (!myProfile || !fetched[myProfile.uid]) {
        t2 = fetched;
        break bb0;
      }
      const t3 = fetched[myProfile.uid];
      let t4;
      if ($[2] !== myProfile.favoriteTeams) {
        t4 = myProfile.favoriteTeams ?? [];
        $[2] = myProfile.favoriteTeams;
        $[3] = t4;
      } else {
        t4 = $[3];
      }
      let t5;
      if ($[4] !== t3 || $[5] !== t4) {
        t5 = {
          ...t3,
          favoriteTeams: t4
        };
        $[4] = t3;
        $[5] = t4;
        $[6] = t5;
      } else {
        t5 = $[6];
      }
      let t6;
      if ($[7] !== fetched || $[8] !== myProfile.uid || $[9] !== t5) {
        t6 = {
          ...fetched,
          [myProfile.uid]: t5
        };
        $[7] = fetched;
        $[8] = myProfile.uid;
        $[9] = t5;
        $[10] = t6;
      } else {
        t6 = $[10];
      }
      t2 = t6;
    }
    const profiles = t2;
    const prizes = (0, _libLoanMath.prizeSplit)(league.pot, league.prizeDistribution, standings.length);
    const ended = league.status === "ended";
    const mine = league.results?.find(r => r.memberId === uid);
    const [openUid, setOpenUid] = (0, _react.useState)(null);
    const info = s_0 => {
      const m = league.members[s_0.uid];
      const r_0 = league.results?.find(x => x.memberId === s_0.uid);
      return {
        m,
        r: r_0,
        name: m?.displayName ?? r_0?.memberName ?? "Player",
        color: m?.avatarColor ?? r_0?.memberColor ?? c.mutedForeground,
        you: s_0.uid === uid,
        prize: prizes[standings.indexOf(s_0)] ?? 0
      };
    };
    let t3;
    if ($[11] !== bets || $[12] !== league.members) {
      const map = new Map();
      for (const [id, m_0] of Object.entries(league.members)) {
        map.set(id, {
          uid: id,
          name: m_0.displayName,
          won: 0,
          lost: 0,
          pending: 0,
          net: 0
        });
      }
      for (const b of bets) {
        if (!b.lockWeek && !b.lock) {
          continue;
        }
        const row = map.get(b.uid) ?? {
          uid: b.uid,
          name: b.displayName,
          won: 0,
          lost: 0,
          pending: 0,
          net: 0
        };
        if (b.status === "won") {
          row.won = row.won + 1;
          row.net = row.net + (b.potentialPayout - b.stake);
        } else {
          if (b.status === "lost") {
            row.lost = row.lost + 1;
            row.net = row.net - b.stake;
          } else {
            if (b.status === "pending") {
              row.pending = row.pending + 1;
            }
          }
        }
        map.set(b.uid, row);
      }
      t3 = [...map.values()].sort(_temp5);
      $[11] = bets;
      $[12] = league.members;
      $[13] = t3;
    } else {
      t3 = $[13];
    }
    const lockBoard = t3;
    const leader = standings[0]?.rank === 1 ? standings[0] : undefined;
    const rest = leader ? standings.slice(1) : standings;
    const opened = openUid ? standings.find(s_1 => s_1.uid === openUid) : undefined;
    const openedInfo = opened ? info(opened) : undefined;
    const latestReport = reports[0];
    const latestMatchup = matchups[0];
    let t4;
    if ($[14] !== latestMatchup) {
      t4 = latestMatchup ? [latestMatchup.week] : [];
      $[14] = latestMatchup;
      $[15] = t4;
    } else {
      t4 = $[15];
    }
    const matchupsNew = (0, _libSettings.useUnseenCount)(`league.${league.id}.matchups`, t4, subView === "matchups");
    const T0 = View.default;
    let t5;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
      t5 = {
        gap: 10
      };
      $[16] = t5;
    } else {
      t5 = $[16];
    }
    let t6;
    if ($[17] !== c || $[18] !== latestReport || $[19] !== league.id) {
      t6 = latestReport && latestReport.cards.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        tone: "league",
        onPress: () => _expoRouter.router.push({
          pathname: "/league/[id]/recap",
          params: {
            id: league.id,
            week: latestReport.week
          }
        }),
        style: {
          flexDirection: "row",
          alignItems: "center",
          gap: 10
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "newspaper-variant-outline",
          size: 22,
          color: c.league
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: {
            flex: 1,
            gap: 2
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.cardTitle, {
              color: c.foreground
            }],
            children: ["Tuesday League Report \xB7 ", latestReport.week]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.muted, {
              color: c.mutedForeground
            }],
            numberOfLines: 1,
            children: [latestReport.cards[0]?.headline || latestReport.cards[0]?.title, " \u2014 tap to view & share story cards"]
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "chevron-right",
          size: 20,
          color: c.league
        })]
      });
      $[17] = c;
      $[18] = latestReport;
      $[19] = league.id;
      $[20] = t6;
    } else {
      t6 = $[20];
    }
    let t7;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
      t7 = {
        value: "table",
        label: "Standings"
      };
      $[21] = t7;
    } else {
      t7 = $[21];
    }
    const t8 = league.mode === "matchups" ? "Matchups" : "H2H Matchups";
    const t9 = matchupsNew || undefined;
    let t10;
    if ($[22] !== t8 || $[23] !== t9) {
      t10 = {
        value: "matchups",
        label: t8,
        badge: t9
      };
      $[22] = t8;
      $[23] = t9;
      $[24] = t10;
    } else {
      t10 = $[24];
    }
    let t11;
    if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
      t11 = {
        value: "locks",
        label: "Locks \uD83D\uDD12"
      };
      $[25] = t11;
    } else {
      t11 = $[25];
    }
    let t12;
    if ($[26] !== t10) {
      t12 = [t7, t10, t11];
      $[26] = t10;
      $[27] = t12;
    } else {
      t12 = $[27];
    }
    let t13;
    if ($[28] !== subView || $[29] !== t12) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SegmentedControl, {
        value: subView,
        onChange: setSubView,
        options: t12
      });
      $[28] = subView;
      $[29] = t12;
      $[30] = t13;
    } else {
      t13 = $[30];
    }
    const t14 = subView === "matchups" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(MatchupsSection, {
      league: league,
      matchups: matchups,
      uid: uid
    }) : subView === "locks" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
      style: {
        gap: 8
      },
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.cardTitle, {
          color: c.foreground
        }],
        children: "Lock of the Week Leaderboard"
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.muted, {
          color: c.mutedForeground
        }],
        children: "One pick per week can be locked for the weekly Lock leaderboard."
      }), lockBoard.map((row_0, idx) => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.inline, {
          paddingVertical: 6,
          borderTopWidth: idx > 0 ? StyleSheet.default.hairlineWidth : 0,
          borderTopColor: c.border
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.rankNum, {
            color: idx === 0 ? GOLD : c.mutedForeground
          }],
          children: idx + 1
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.memberName, {
            color: c.foreground,
            flex: 1
          }],
          numberOfLines: 1,
          children: row_0.uid === uid ? "You" : row_0.name
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
          label: `${row_0.won}–${row_0.lost}${row_0.pending ? ` (${row_0.pending} open)` : ""}`,
          tone: row_0.won > row_0.lost ? "positive" : row_0.lost > row_0.won ? "negative" : "neutral"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
          value: row_0.net,
          currency: "league",
          size: "sm",
          signed: true,
          tone: row_0.net > 0 ? "positive" : row_0.net < 0 ? "negative" : "neutral"
        })]
      }, row_0.uid))]
    }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
      children: [ended && mine && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        tone: mine.prizeTokens > 0 ? "money" : undefined,
        style: {
          gap: 6
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.cardTitle, {
            color: c.foreground
          }],
          children: mine.rank === 1 ? "Champion." : `You finished #${mine.rank} of ${league.results.length}`
        }), mine.prizeTokens > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.inline,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
            value: mine.prizeTokens,
            signed: true,
            tone: "positive"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.muted, {
              color: c.mutedForeground
            }],
            children: mine.paid ? "paid to your credits" : "paying out\u2026"
          })]
        }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.muted, {
            color: c.mutedForeground
          }],
          children: ["No prize this season. Net worth ", (mine.netWorth ?? mine.leagueTokens).toLocaleString(), "."]
        })]
      }), leader && (() => {
        const L = info(leader);
        const p = profiles[leader.uid];
        return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
          accessibilityRole: "button",
          accessibilityLabel: `First place, ${L.you ? "you" : L.name}, net worth ${leader.netWorth.toLocaleString()}. Open profile`,
          onPress: () => setOpenUid(leader.uid),
          style: t15 => {
            const {
              pressed
            } = t15;
            return [styles.champ, {
              backgroundColor: c.card,
              borderColor: c.alpha(GOLD, 0.7),
              shadowColor: GOLD,
              transform: [{
                scale: pressed ? 0.985 : 1
              }]
            }];
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoLinearGradient.LinearGradient, {
            colors: [c.alpha(GOLD, 0.26), c.alpha(GOLD, 0.06), "transparent"],
            start: {
              x: 0,
              y: 0
            },
            end: {
              x: 1,
              y: 1
            },
            style: StyleSheet.default.absoluteFill,
            pointerEvents: "none"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Shimmer.default, {
            color: GOLD,
            intensity: 0.22,
            every: 3400,
            sweep: 1300
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.champTop,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: [styles.champBadge, {
                backgroundColor: GOLD
              }],
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "crown",
                size: 13,
                color: "#2A1E00"
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: styles.champBadgeText,
                children: closed ? "CHAMPION" : "1ST PLACE"
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: {
                flex: 1
              }
            }), L.prize > 0 && !closed ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
              label: `${L.prize.toLocaleString()} pot share`,
              tone: "money",
              icon: "trophy"
            }) : null, L.r && L.r.prizeTokens > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
              label: `won ${L.r.prizeTokens.toLocaleString()}`,
              tone: "money",
              icon: "trophy"
            }) : null]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.champMain,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(MemberAvatar.default, {
              profile: p,
              name: L.name,
              color: L.color,
              catalog: byId,
              size: 78,
              ring: GOLD
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1,
                gap: 4
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: styles.inline,
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.champName, {
                    color: c.foreground
                  }],
                  numberOfLines: 1,
                  children: L.name
                }), L.you && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
                  label: "YOU",
                  tone: "league"
                })]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TeamChips.default, {
                teams: p?.favoriteTeams,
                compact: true,
                max: 3
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.memberSub, {
                  color: c.mutedForeground
                }],
                numberOfLines: 1,
                children: [L.m ? `${L.m.betsWon}–${L.m.betsLost} record` : "", L.m?.h2h?.w != null ? ` · H2H ${L.m.h2h.w}–${L.m.h2h.l ?? 0}` : "", leader.debt > 0 ? ` · owes ${leader.debt.toLocaleString()}` : "", leader.receivable > 0 ? ` · owed ${leader.receivable.toLocaleString()}` : ""]
              })]
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.champStats, {
              borderTopColor: c.alpha(GOLD, 0.25)
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1.4
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.champK, {
                  color: c.subtleForeground
                }],
                children: league.mode === "pickem" || league.mode === "bracket" ? "PICK POINTS" : league.mode === "survivor" ? "SURVIVOR" : league.mode === "matchups" ? "H2H RECORD" : "NET WORTH"
              }), league.mode === "matchups" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.champV, {
                  color: c.foreground
                }],
                children: [L.m?.h2h?.w ?? 0, "\u2013", L.m?.h2h?.l ?? 0, L.m?.h2h?.t ? `–${L.m.h2h.t}` : ""]
              }) : league.mode === "pickem" || league.mode === "bracket" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.champV, {
                  color: c.foreground
                }],
                children: [L.m?.pickPoints ?? 0, " pts"]
              }) : league.mode === "survivor" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.champV, {
                  color: L.m?.eliminated ? c.negative : c.positive
                }],
                children: L.m?.eliminated ? `Out (${L.m.eliminatedWeek ?? "eliminated"})` : "Alive"
              }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
                value: leader.netWorth,
                currency: "league",
                size: "lg"
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.champK, {
                  color: c.subtleForeground
                }],
                children: "LEAD"
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.champV, {
                  color: c.foreground
                }],
                children: standings[1] ? `+${Math.max(0, leader.netWorth - standings[1].netWorth).toLocaleString()}` : "\u2014"
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "chevron-right",
              size: 22,
              color: c.mutedForeground
            })]
          })]
        });
      })(), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.muted, {
          color: c.mutedForeground
        }],
        children: [league.mode === "matchups" ? `Ranked by head-to-head record (2 pts a win, 1 a tie), net worth breaks ties. New matchups ${_constantsLeagueTypes.MATCHUP_CADENCES.find(m_1 => m_1.value === (league.matchupCadence ?? "weekly"))?.desc.replace(/^New opponent /, "") ?? ""}.` : "Ranked by net worth \u2014 tokens, plus what you're owed, minus what you owe (ties broken by lower debt).", " ", "Tap anyone for their stats and rivalry record."]
      }), rest.map(s_2 => {
        const R = info(s_2);
        const p_0 = profiles[s_2.uid];
        const rankColor = s_2.rank === 1 ? GOLD : s_2.rank === 2 ? SILVER : s_2.rank === 3 ? BRONZE : c.mutedForeground;
        return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
          accessibilityRole: "button",
          accessibilityLabel: `Rank ${s_2.rank}, ${R.you ? "you" : R.name}, net worth ${s_2.netWorth.toLocaleString()}${s_2.debt ? `, owes ${s_2.debt.toLocaleString()}` : ""}. Open profile`,
          onPress: () => setOpenUid(s_2.uid),
          style: t16 => {
            const {
              pressed: pressed_0
            } = t16;
            return [styles.member, {
              backgroundColor: R.you ? c.leagueSoft : c.card,
              borderColor: R.you ? c.alpha(c.league, 0.5) : c.border,
              opacity: pressed_0 ? 0.85 : 1
            }];
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.RoundBadge, {
            label: s_2.rank,
            color: rankColor,
            size: 28,
            filled: s_2.rank <= 3
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(MemberAvatar.default, {
            profile: p_0,
            name: R.name,
            color: R.color,
            catalog: byId,
            size: 40
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: {
              flex: 1,
              gap: 3
            },
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.inline,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.memberName, {
                  color: c.foreground
                }],
                numberOfLines: 1,
                children: R.name
              }), R.you && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
                label: "YOU",
                tone: "league"
              }), R.m?.achievementCount ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
                label: `⭐${R.m.achievementCount}`,
                tone: "warning"
              }) : null, p_0?.ladder?.tier ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
                label: p_0.ladder.tier,
                tone: "accent",
                icon: "stairs-up"
              }) : null, league.mode === "survivor" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
                label: R.m?.eliminated ? `Out ${R.m.eliminatedWeek ?? ""}`.trim() : "Alive",
                tone: R.m?.eliminated ? "negative" : "positive"
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TeamChips.default, {
              teams: p_0?.favoriteTeams,
              compact: true,
              max: 3
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.memberSub, {
                color: c.mutedForeground
              }],
              numberOfLines: 2,
              children: [league.mode === "pickem" || league.mode === "bracket" ? `${R.m?.pickPoints ?? 0} pick pts · ` : "", league.mode === "matchups" ? `H2H ${R.m?.h2h?.w ?? 0}–${R.m?.h2h?.l ?? 0}${R.m?.h2h?.t ? `–${R.m.h2h.t}` : ""} · ` : "", s_2.tokens.toLocaleString(), " tokens", s_2.debt > 0 ? ` · owes ${s_2.debt.toLocaleString()}` : "", s_2.receivable > 0 ? ` · owed ${s_2.receivable.toLocaleString()}` : "", R.m ? ` · ${R.m.betsWon}–${R.m.betsLost}` : ""]
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: {
              alignItems: "flex-end",
              gap: 2
            },
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
              value: s_2.netWorth,
              currency: "league",
              size: "sm"
            }), R.prize > 0 && !closed ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
              label: `${R.prize.toLocaleString()} pot share`,
              tone: "money",
              icon: "trophy"
            }) : null, R.r && R.r.prizeTokens > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.memberSub, {
                color: c.primary
              }],
              children: ["won ", R.r.prizeTokens.toLocaleString()]
            }) : null]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "chevron-right",
            size: 18,
            color: c.subtleForeground
          })]
        }, s_2.uid);
      }), !closed && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(InvitePanel, {
        league: league,
        onShare: onInvite
      })]
    });
    let t17;
    if ($[31] !== setOpenUid) {
      t17 = () => setOpenUid(null);
      $[31] = setOpenUid;
      $[32] = t17;
    } else {
      t17 = $[32];
    }
    let t18;
    if ($[33] !== openUid || $[34] !== openedInfo || $[35] !== profiles) {
      t18 = openedInfo && openUid ? {
        displayName: openedInfo.name,
        username: profiles[openUid]?.username,
        avatar: profiles[openUid]?.avatar,
        equipped: profiles[openUid]?.equipped,
        favoriteTeams: profiles[openUid]?.favoriteTeams
      } : undefined;
      $[33] = openUid;
      $[34] = openedInfo;
      $[35] = profiles;
      $[36] = t18;
    } else {
      t18 = $[36];
    }
    let t19;
    if ($[37] !== opened || $[38] !== standings.length) {
      t19 = opened ? {
        rank: opened.rank,
        of: standings.length,
        netWorth: opened.netWorth,
        tokens: opened.tokens,
        debt: opened.debt,
        receivable: opened.receivable
      } : undefined;
      $[37] = opened;
      $[38] = standings.length;
      $[39] = t19;
    } else {
      t19 = $[39];
    }
    let t20;
    if ($[40] !== league.id || $[41] !== openUid || $[42] !== t17 || $[43] !== t18 || $[44] !== t19) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PlayerProfileSheet.default, {
        uid: openUid,
        leagueId: league.id,
        onClose: t17,
        seed: t18,
        standing: t19
      });
      $[40] = league.id;
      $[41] = openUid;
      $[42] = t17;
      $[43] = t18;
      $[44] = t19;
      $[45] = t20;
    } else {
      t20 = $[45];
    }
    let t21;
    if ($[46] !== T0 || $[47] !== t13 || $[48] !== t14 || $[49] !== t20 || $[50] !== t5 || $[51] !== t6) {
      t21 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T0, {
        style: t5,
        children: [t6, t13, t14, t20]
      });
      $[46] = T0;
      $[47] = t13;
      $[48] = t14;
      $[49] = t20;
      $[50] = t5;
      $[51] = t6;
      $[52] = t21;
    } else {
      t21 = $[52];
    }
    return t21;
  }
  function _temp5(a, b_0) {
    return b_0.won - a.won || b_0.net - a.net;
  }
  function _temp4(s) {
    return s.uid;
  }
  function MatchupsSection({
    league,
    matchups,
    uid
  }) {
    const c = (0, _hooksUseColors.useColors)();
    const {
      profile
    } = (0, _contextAppContext.useApp)();
    const {
      show
    } = (0, _contextToastContext.useToast)();
    const [sentTaunt, setSentTaunt] = (0, _react.useState)({});
    const danceMove = profile?.moves?.[0] ?? "cheer";
    const sendDance = async (matchupId, receiverUid) => {
      _libMotion.haptic.tick();
      try {
        await api.sendTaunt({
          scope: "league",
          leagueId: league.id,
          matchupId,
          receiverUid,
          moveId: danceMove
        });
        setSentTaunt(m => ({
          ...m,
          [`${matchupId}_${receiverUid}`]: true
        }));
      } catch (e) {
        show({
          kind: "warning",
          title: "Couldn't send",
          body: api.friendlyError(e)
        });
      }
    };
    const nameOf = (id, fallback) => {
      if (!id) return "BYE";
      if (id === uid) return "You";
      return league.members[id]?.displayName ?? fallback ?? "Player";
    };
    const stars = id_0 => {
      const n = id_0 ? league.members[id_0]?.achievementCount : 0;
      return n ? ` ⭐${n} ` : "";
    };
    if (matchups.length === 0) {
      return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
        icon: "sword-cross",
        title: "No Matchups Yet",
        body: `${_constantsLeagueTypes.MATCHUP_CADENCES.find(m_0 => m_0.value === (league.matchupCadence ?? "weekly"))?.desc ?? "New opponent every Monday"} at 9am ET: members are paired head-to-head on net profit for the round. The top seeds meet in a playoff in the final round.`
      });
    }
    return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
      style: {
        gap: 10
      },
      children: matchups.map(w => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: {
          gap: 8
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.inline,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.cardTitle, {
              color: c.foreground,
              flex: 1
            }],
            children: w.isPlayoff ? `🏆 Playoff Bracket · ${w.week}` : `${(0, _constantsLeagueTypes.periodNoun)(league.matchupCadence)} ${w.weekNumber ?? ""} · ${w.week.replace(/-([ab])$/, (_, h) => h === "a" ? " (Mon–Wed)" : " (Thu–Sun)")}`
          }), w.isPlayoff && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
            label: "PLAYOFFS",
            tone: "money",
            icon: "trophy"
          })]
        }), w.pairs.map((p, i) => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.inline, {
            paddingVertical: 8,
            borderTopWidth: i > 0 ? StyleSheet.default.hairlineWidth : 0,
            borderTopColor: c.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: {
              flex: 1,
              gap: 2
            },
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.memberName, {
                color: p.winnerUid === p.aUid ? c.positive : c.foreground
              }],
              children: [nameOf(p.aUid, p.aName), " ", p.winnerUid === p.aUid ? "✓" : "", stars(p.aUid)]
            }), p.aDelta !== null ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
              value: p.aDelta,
              currency: "league",
              size: "sm",
              signed: true,
              tone: p.aDelta >= 0 ? "positive" : "negative"
            }) : null]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.muted, {
              color: c.subtleForeground
            }],
            children: p.bracket === "playoff" ? "PLAYOFF" : "vs"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: {
              flex: 1,
              alignItems: "flex-end",
              gap: 2
            },
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.memberName, {
                color: p.winnerUid === p.bUid ? c.positive : c.foreground
              }],
              children: [stars(p.bUid), p.winnerUid === p.bUid ? "✓ " : "", nameOf(p.bUid, p.bName)]
            }), p.bDelta !== null && p.bUid ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
              value: p.bDelta,
              currency: "league",
              size: "sm",
              signed: true,
              tone: p.bDelta >= 0 ? "positive" : "negative"
            }) : null]
          }), uid && p.winnerUid === uid && p.bUid ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
            label: sentTaunt[`${w.week}_${p.aUid === uid ? p.bUid : p.aUid}`] ? "Sent" : "Send a dance",
            icon: "human-handsup",
            chevron: false,
            tone: "league",
            disabled: !!sentTaunt[`${w.week}_${p.aUid === uid ? p.bUid : p.aUid}`],
            onPress: () => void sendDance(w.week, p.aUid === uid ? p.bUid : p.aUid)
          }) : null]
        }, i))]
      }, w.week))
    });
  }
  function InvitePanel(t0) {
    const $ = (0, _reactCompilerRuntime.c)(20);
    const {
      league,
      onShare
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const {
      profile
    } = (0, _contextAppContext.useApp)();
    const {
      inviteFriend
    } = (0, _contextLeagueContext.useLeague)();
    const {
      friends
    } = (0, _hooksUseFriends.useFriends)(profile?.uid ?? null);
    let t1;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = {};
      $[0] = t1;
    } else {
      t1 = $[0];
    }
    const [sent, setSent] = (0, _react.useState)(t1);
    let t2;
    let t3;
    if ($[1] !== c || $[2] !== friends || $[3] !== inviteFriend || $[4] !== league || $[5] !== onShare || $[6] !== sent) {
      t3 = Symbol.for("react.early_return_sentinel");
      bb0: {
        let t4;
        if ($[9] !== league) {
          t4 = f => !league.memberIds.includes(f.uid);
          $[9] = league;
          $[10] = t4;
        } else {
          t4 = $[10];
        }
        const candidates = friends.filter(t4).slice(0, 8);
        if ((0, _constantsLeagueTypes.isLeagueClosed)(league) || (0, _constantsLeagueTypes.isLeagueStarted)(league)) {
          t3 = null;
          break bb0;
        }
        let t5;
        if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
          t5 = {
            gap: 10
          };
          $[11] = t5;
        } else {
          t5 = $[11];
        }
        let t6;
        if ($[12] !== c.foreground) {
          t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.cardTitle, {
              color: c.foreground,
              flex: 1
            }],
            children: "Invite Friends"
          });
          $[12] = c.foreground;
          $[13] = t6;
        } else {
          t6 = $[13];
        }
        let t7;
        if ($[14] !== league.code || $[15] !== onShare) {
          t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            size: "sm",
            variant: "secondary",
            icon: "share-variant",
            label: league.code,
            onPress: onShare
          });
          $[14] = league.code;
          $[15] = onShare;
          $[16] = t7;
        } else {
          t7 = $[16];
        }
        let t8;
        if ($[17] !== t6 || $[18] !== t7) {
          t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.inline,
            children: [t6, t7]
          });
          $[17] = t6;
          $[18] = t7;
          $[19] = t8;
        } else {
          t8 = $[19];
        }
        t2 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
          style: t5,
          children: [t8, candidates.length === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.muted, {
              color: c.mutedForeground
            }],
            children: ["Share the code \u2014 anyone with it can join", league.buyIn > 0 ? ` for ${league.buyIn.toLocaleString()} credits` : "", "."]
          }) : candidates.map(f_0 => {
            const st = sent[f_0.uid];
            return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.inline,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.memberName, {
                  color: c.foreground,
                  flex: 1
                }],
                numberOfLines: 1,
                children: [f_0.displayName, " ", /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                  style: {
                    color: c.mutedForeground
                  },
                  children: ["@", f_0.username]
                })]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
                size: "sm",
                label: st === "sent" ? "Invited" : "Invite",
                variant: st === "sent" ? "secondary" : "primary",
                loading: st === "busy",
                disabled: st === "sent",
                onPress: async () => {
                  setSent(p => ({
                    ...p,
                    [f_0.uid]: "busy"
                  }));
                  const e = await inviteFriend(league.id, f_0.uid);
                  setSent(p_0 => ({
                    ...p_0,
                    [f_0.uid]: e ? "" : "sent"
                  }));
                }
              })]
            }, f_0.uid);
          })]
        });
      }
      $[1] = c;
      $[2] = friends;
      $[3] = inviteFriend;
      $[4] = league;
      $[5] = onShare;
      $[6] = sent;
      $[7] = t2;
      $[8] = t3;
    } else {
      t2 = $[7];
      t3 = $[8];
    }
    if (t3 !== Symbol.for("react.early_return_sentinel")) {
      return t3;
    }
    return t2;
  }

  // ── Bets, Parlays & Pick'em / Survivor ──────────────────────────────────────

  function BetsTab(t0) {
    const $ = (0, _reactCompilerRuntime.c)(105);
    const {
      league,
      bets,
      parlays,
      picks,
      uid,
      leagueId,
      now,
      fmt
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const {
      myLeagueBets,
      reactToItem,
      reportResult,
      voidLeagueBet
    } = (0, _contextLeagueContext.useLeague)();
    const {
      betComments
    } = (0, _contextChatContext.useChat)();
    const [quickGame, setQuickGame] = (0, _react.useState)(null);
    const [follow, setFollow] = (0, _react.useState)(null);
    const [voidTarget, setVoidTarget] = (0, _react.useState)(null);
    const [voidBusy, setVoidBusy] = (0, _react.useState)(false);
    let t1;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = {};
      $[0] = t1;
    } else {
      t1 = $[0];
    }
    const [reportedIds, setReportedIds] = (0, _react.useState)(t1);
    const [breakdown, setBreakdown] = (0, _react.useState)(null);
    const [replyTarget, setReplyTarget] = (0, _react.useState)(null);
    const [profileUid, setProfileUid] = (0, _react.useState)(null);
    const isCreator = league.creatorId === uid;
    let T0;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    if ($[1] !== betComments || $[2] !== bets || $[3] !== c || $[4] !== fmt || $[5] !== isCreator || $[6] !== league || $[7] !== leagueId || $[8] !== myLeagueBets || $[9] !== now || $[10] !== parlays || $[11] !== picks || $[12] !== reactToItem || $[13] !== reportResult || $[14] !== reportedIds || $[15] !== uid) {
      const open = bets.filter(_temp6);
      const settled = bets.filter(_temp7);
      let out;
      if ($[22] !== leagueId || $[23] !== myLeagueBets) {
        out = {};
        for (const mine of (leagueId ? myLeagueBets[leagueId] : undefined) ?? []) {
          if (mine.tailOf) {
            out[mine.tailOf] = "tail";
          }
          if (mine.fadeOf) {
            out[mine.fadeOf] = "fade";
          }
        }
        $[22] = leagueId;
        $[23] = myLeagueBets;
        $[24] = out;
      } else {
        out = $[24];
      }
      const followed = out;
      let t7;
      if ($[25] !== leagueId) {
        t7 = (b_1, kind) => {
          if (!leagueId) {
            return;
          }
          _libMotion.haptic.tick();
          setFollow({
            betId: b_1.id,
            kind,
            leagueId,
            name: b_1.displayName,
            side: kind === "tail" ? b_1.side : b_1.side === "home" ? "away" : "home",
            stake: 0,
            sourceTeamAbbr: b_1.teamAbbr
          });
          setQuickGame(b_1.gameId);
        };
        $[25] = leagueId;
        $[26] = t7;
      } else {
        t7 = $[26];
      }
      const startFollow = t7;
      let t8;
      if ($[27] !== league.id || $[28] !== league.name) {
        t8 = b_2 => {
          if (b_2.status === "pending") {
            setFollow(null);
            setQuickGame(b_2.gameId);
            return;
          }
          _libMotion.haptic.tick();
          setBreakdown({
            id: b_2.id,
            gameId: b_2.gameId,
            sport: b_2.sport,
            teamName: b_2.teamName,
            teamAbbr: b_2.teamAbbr,
            teamColor: b_2.teamColor,
            opponentAbbr: b_2.opponentAbbr,
            side: b_2.side,
            market: b_2.market ?? "ml",
            selection: b_2.selection ?? null,
            line: b_2.line ?? null,
            label: b_2.label ?? null,
            lock: Boolean(b_2.lockWeek || b_2.lock),
            odds: b_2.odds,
            stake: b_2.stake,
            payout: b_2.potentialPayout,
            status: b_2.status,
            finalHomeScore: b_2.finalHomeScore ?? null,
            finalAwayScore: b_2.finalAwayScore ?? null,
            wallet: "league",
            leagueId: league.id,
            leagueName: league.name,
            ownerUid: b_2.uid,
            ownerName: b_2.displayName,
            placedAtMs: b_2.placedAt
          });
        };
        $[27] = league.id;
        $[28] = league.name;
        $[29] = t8;
      } else {
        t8 = $[29];
      }
      const openBetInfo = t8;
      let t9;
      if ($[30] !== betComments || $[31] !== c || $[32] !== fmt || $[33] !== followed || $[34] !== isCreator || $[35] !== league.id || $[36] !== leagueId || $[37] !== now || $[38] !== openBetInfo || $[39] !== reactToItem || $[40] !== reportResult || $[41] !== reportedIds || $[42] !== startFollow || $[43] !== uid) {
        t9 = b_3 => {
          const label = b_3.status === "pending" ? "Open" : b_3.status === "won" ? "Won" : b_3.status === "lost" ? "Lost" : b_3.status === "push" ? "Push" : "Void";
          const mine_0 = b_3.uid === uid;
          const upcoming = b_3.startsAt == null || b_3.startsAt > now;
          const canFollow = !!leagueId && !!uid && !mine_0 && b_3.status === "pending" && upcoming;
          const already = uid && b_3.followers?.[uid] || followed[b_3.id];
          const tails = b_3.tails ?? 0;
          const fades = b_3.fades ?? 0;
          const quote = {
            id: b_3.id,
            kind: "bet_result",
            authorUid: b_3.uid,
            authorName: b_3.displayName,
            text: `${b_3.label ?? b_3.teamAbbr} v ${b_3.opponentAbbr} · ${label.toUpperCase()} (${(0, _libOdds.formatOdds)(b_3.odds, fmt)})`,
            betStatus: b_3.status,
            teamAbbr: b_3.teamAbbr,
            opponentAbbr: b_3.opponentAbbr,
            odds: b_3.odds,
            stake: b_3.stake,
            payout: b_3.potentialPayout,
            currency: "league"
          };
          const comments = betComments[b_3.id] ?? [];
          return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [styles.betRow, {
              backgroundColor: c.card,
              borderColor: c.border,
              borderLeftColor: b_3.teamColor
            }],
            children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1,
                gap: 6
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
                onPress: () => openBetInfo(b_3),
                style: styles.betTop,
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                  style: {
                    flex: 1,
                    gap: 2
                  },
                  children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                    style: styles.inline,
                    children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                      onPress: () => setProfileUid(b_3.uid),
                      hitSlop: 6,
                      children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                        style: [styles.memberName, {
                          color: c.primary
                        }],
                        children: mine_0 ? "You" : b_3.displayName
                      })
                    }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                      style: [styles.memberName, {
                        color: c.foreground,
                        flexShrink: 1
                      }],
                      numberOfLines: 1,
                      children: ["\xB7 ", b_3.label ?? b_3.teamAbbr, " ", /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                        style: {
                          color: c.mutedForeground
                        },
                        children: ["v ", b_3.opponentAbbr]
                      })]
                    }), b_3.lockWeek || b_3.lock ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
                      label: "LOCK",
                      tone: "accent",
                      icon: "lock"
                    }) : null]
                  }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: [styles.memberSub, {
                      color: c.mutedForeground
                    }],
                    children: b_3.uid === uid ? `${b_3.stake.toLocaleString()} at ${(0, _libOdds.formatOdds)(b_3.odds, fmt)} → ${b_3.potentialPayout.toLocaleString()}` : `at ${(0, _libOdds.formatOdds)(b_3.odds, fmt)}`
                  }), b_3.followOfName ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: [styles.memberSub, {
                      color: c.subtleForeground
                    }],
                    numberOfLines: 1,
                    children: b_3.tailOf ? `Tailing ${b_3.followOfName}` : `Fading ${b_3.followOfName}`
                  }) : null, tails + fades > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: [styles.memberSub, {
                      color: c.league
                    }],
                    children: [tails ? `${tails} tail${tails === 1 ? "" : "s"}` : null, fades ? `${fades} fade${fades === 1 ? "" : "s"}` : null].filter(Boolean).join(" \xB7 ")
                  }) : null]
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
                  label: label,
                  tone: b_3.status === "won" ? "positive" : b_3.status === "lost" ? "negative" : b_3.status === "pending" ? "league" : "neutral"
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                  name: b_3.status === "pending" ? "chevron-right" : "information-outline",
                  size: 18,
                  color: c.subtleForeground
                })]
              }), canFollow ? already ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
                style: styles.followRow,
                children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
                  label: already === "tail" ? "You tailed this" : "You faded this",
                  tone: "league",
                  icon: already === "tail" ? "account-multiple-plus" : "account-switch"
                })
              }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: styles.followRow,
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
                  accessibilityLabel: `Tail ${b_3.displayName}: back ${b_3.teamAbbr}`,
                  onPress: () => startFollow(b_3, "tail"),
                  hitSlop: 6,
                  style: t10 => {
                    const {
                      pressed
                    } = t10;
                    return [styles.followBtn, {
                      backgroundColor: c.leagueSoft,
                      borderColor: c.alpha(c.league, 0.55),
                      opacity: pressed ? 0.75 : 1
                    }];
                  },
                  children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                    name: "account-multiple-plus",
                    size: 14,
                    color: c.league
                  }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                    style: [styles.followText, {
                      color: c.foreground
                    }],
                    children: ["Tail ", b_3.teamAbbr]
                  })]
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
                  accessibilityLabel: `Fade ${b_3.displayName}: back ${b_3.opponentAbbr} instead`,
                  onPress: () => startFollow(b_3, "fade"),
                  hitSlop: 6,
                  style: t11 => {
                    const {
                      pressed: pressed_0
                    } = t11;
                    return [styles.followBtn, {
                      backgroundColor: c.secondary,
                      borderColor: c.border,
                      opacity: pressed_0 ? 0.75 : 1
                    }];
                  },
                  children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                    name: "account-switch",
                    size: 14,
                    color: c.mutedForeground
                  }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                    style: [styles.followText, {
                      color: c.foreground
                    }],
                    children: ["Fade \u2192 ", b_3.opponentAbbr]
                  })]
                })]
              }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: styles.inline,
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(ReactionBar, {
                  reactions: b_3.reactions,
                  reactors: b_3.reactors,
                  uid: uid,
                  onToggle: emoji => leagueId ? reactToItem(leagueId, "bet", b_3.id, emoji) : false
                }), isCreator && leagueId && b_3.status === "pending" && upcoming && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
                  onPress: () => setVoidTarget(b_3),
                  style: [styles.miniAction, {
                    borderColor: c.border,
                    backgroundColor: c.secondary
                  }],
                  children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                    name: "undo-variant",
                    size: 12,
                    color: c.negative
                  }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: [styles.miniActionText, {
                      color: c.negative
                    }],
                    children: "Void"
                  })]
                }), b_3.status !== "pending" && b_3.status !== "cancelled" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
                  disabled: !!reportedIds[b_3.id] || !!b_3.disputed,
                  onPress: async () => {
                    await reportResult(league.id, b_3.id, "Result disputed by member");
                    setReportedIds(p => ({
                      ...p,
                      [b_3.id]: true
                    }));
                  },
                  style: [styles.miniAction, {
                    borderColor: c.border,
                    backgroundColor: c.secondary
                  }],
                  children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                    name: "flag-outline",
                    size: 12,
                    color: c.mutedForeground
                  }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: [styles.miniActionText, {
                      color: c.mutedForeground
                    }],
                    children: reportedIds[b_3.id] || b_3.disputed ? "Reported" : "Report result"
                  })]
                })]
              }), b_3.status !== "pending" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsChatReplyThread.WinLossReplyThread, {
                parentQuote: quote,
                replies: comments,
                myUid: uid,
                onPressReply: () => setReplyTarget(quote),
                onPressAuthor: authorId => setProfileUid(authorId)
              })]
            })
          }, b_3.id);
        };
        $[30] = betComments;
        $[31] = c;
        $[32] = fmt;
        $[33] = followed;
        $[34] = isCreator;
        $[35] = league.id;
        $[36] = leagueId;
        $[37] = now;
        $[38] = openBetInfo;
        $[39] = reactToItem;
        $[40] = reportResult;
        $[41] = reportedIds;
        $[42] = startFollow;
        $[43] = uid;
        $[44] = t9;
      } else {
        t9 = $[44];
      }
      const row = t9;
      T0 = View.default;
      if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
          gap: 10
        };
        $[45] = t2;
      } else {
        t2 = $[45];
      }
      if ($[46] !== league || $[47] !== leagueId || $[48] !== picks || $[49] !== uid) {
        t3 = (league.mode === "pickem" || league.mode === "survivor") && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ModePicksCard, {
          league: league,
          picks: picks,
          uid: uid,
          closed: !leagueId
        });
        $[46] = league;
        $[47] = leagueId;
        $[48] = picks;
        $[49] = uid;
        $[50] = t3;
      } else {
        t3 = $[50];
      }
      if ($[51] !== league || $[52] !== uid) {
        t4 = league.mode === "bracket" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BracketFill.default, {
          league: league,
          uid: uid
        });
        $[51] = league;
        $[52] = uid;
        $[53] = t4;
      } else {
        t4 = $[53];
      }
      const t10 = !leagueId;
      if ($[54] !== fmt || $[55] !== league || $[56] !== parlays || $[57] !== t10 || $[58] !== uid) {
        t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ParlaysSection, {
          league: league,
          parlays: parlays,
          uid: uid,
          closed: t10,
          fmt: fmt
        });
        $[54] = fmt;
        $[55] = league;
        $[56] = parlays;
        $[57] = t10;
        $[58] = uid;
        $[59] = t5;
      } else {
        t5 = $[59];
      }
      t6 = bets.length === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
        icon: "ticket-outline",
        title: "No League Bets Yet",
        body: "Bets placed with this league's tokens show up here \u2014 everyone's, so you can see who's swinging big.",
        action: leagueId ? "Make the first pick" : undefined,
        onAction: leagueId ? () => _expoRouter.router.navigate({
          pathname: "/(tabs)/games",
          params: {
            wallet: leagueId
          }
        }) : undefined
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [open.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
          title: `Open (${open.length})`
        }), open.map(row), settled.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
          title: "Settled Results (Tap for Breakdown)"
        }), settled.map(row)]
      });
      $[1] = betComments;
      $[2] = bets;
      $[3] = c;
      $[4] = fmt;
      $[5] = isCreator;
      $[6] = league;
      $[7] = leagueId;
      $[8] = myLeagueBets;
      $[9] = now;
      $[10] = parlays;
      $[11] = picks;
      $[12] = reactToItem;
      $[13] = reportResult;
      $[14] = reportedIds;
      $[15] = uid;
      $[16] = T0;
      $[17] = t2;
      $[18] = t3;
      $[19] = t4;
      $[20] = t5;
      $[21] = t6;
    } else {
      T0 = $[16];
      t2 = $[17];
      t3 = $[18];
      t4 = $[19];
      t5 = $[20];
      t6 = $[21];
    }
    const t7 = !!voidTarget;
    let t8;
    if ($[60] !== voidTarget) {
      t8 = voidTarget ? `Refund ${voidTarget.stake.toLocaleString()} tokens to ${voidTarget.displayName}? This action is logged in the Commissioner Audit Log.` : "";
      $[60] = voidTarget;
      $[61] = t8;
    } else {
      t8 = $[61];
    }
    let t9;
    if ($[62] === Symbol.for("react.memo_cache_sentinel")) {
      t9 = () => setVoidTarget(null);
      $[62] = t9;
    } else {
      t9 = $[62];
    }
    let t10;
    if ($[63] !== league.id || $[64] !== voidLeagueBet || $[65] !== voidTarget) {
      t10 = async () => {
        if (!voidTarget) {
          return;
        }
        setVoidBusy(true);
        await voidLeagueBet(league.id, voidTarget.id, "Voided by commissioner");
        setVoidBusy(false);
        setVoidTarget(null);
      };
      $[63] = league.id;
      $[64] = voidLeagueBet;
      $[65] = voidTarget;
      $[66] = t10;
    } else {
      t10 = $[66];
    }
    let t11;
    if ($[67] !== t10 || $[68] !== t7 || $[69] !== t8 || $[70] !== voidBusy) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ConfirmDialog, {
        visible: t7,
        title: "Void this league bet?",
        body: t8,
        confirmLabel: "Void & refund",
        destructive: true,
        busy: voidBusy,
        onCancel: t9,
        onConfirm: t10
      });
      $[67] = t10;
      $[68] = t7;
      $[69] = t8;
      $[70] = voidBusy;
      $[71] = t11;
    } else {
      t11 = $[71];
    }
    let t12;
    let t13;
    if ($[72] === Symbol.for("react.memo_cache_sentinel")) {
      t12 = () => setBreakdown(null);
      t13 = gId => setQuickGame(gId);
      $[72] = t12;
      $[73] = t13;
    } else {
      t12 = $[72];
      t13 = $[73];
    }
    let t14;
    if ($[74] !== fmt) {
      t14 = item => setReplyTarget({
        id: item.id,
        kind: "bet_result",
        authorUid: item.ownerUid ?? "",
        authorName: item.ownerName ?? "Player",
        text: `${item.label ?? item.teamAbbr} v ${item.opponentAbbr} · ${item.status.toUpperCase()} (${(0, _libOdds.formatOdds)(item.odds, fmt)})`,
        betStatus: item.status,
        teamAbbr: item.teamAbbr,
        opponentAbbr: item.opponentAbbr,
        odds: item.odds,
        stake: item.stake,
        payout: item.payout,
        currency: "league"
      });
      $[74] = fmt;
      $[75] = t14;
    } else {
      t14 = $[75];
    }
    let t15;
    if ($[76] !== breakdown || $[77] !== t14) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BetBreakdownModal.default, {
        item: breakdown,
        onClose: t12,
        onOpenGame: t13,
        onReply: t14
      });
      $[76] = breakdown;
      $[77] = t14;
      $[78] = t15;
    } else {
      t15 = $[78];
    }
    let t16;
    let t17;
    if ($[79] === Symbol.for("react.memo_cache_sentinel")) {
      t16 = () => setReplyTarget(null);
      t17 = authorId_0 => {
        setReplyTarget(null);
        setProfileUid(authorId_0);
      };
      $[79] = t16;
      $[80] = t17;
    } else {
      t16 = $[79];
      t17 = $[80];
    }
    let t18;
    if ($[81] !== league.id || $[82] !== replyTarget) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(WinLossReplyModal.default, {
        target: replyTarget,
        leagueId: league.id,
        onClose: t16,
        onOpenProfile: t17
      });
      $[81] = league.id;
      $[82] = replyTarget;
      $[83] = t18;
    } else {
      t18 = $[83];
    }
    let t19;
    if ($[84] === Symbol.for("react.memo_cache_sentinel")) {
      t19 = () => setProfileUid(null);
      $[84] = t19;
    } else {
      t19 = $[84];
    }
    let t20;
    if ($[85] !== league.id || $[86] !== profileUid) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PlayerProfileSheet.default, {
        uid: profileUid,
        leagueId: league.id,
        onClose: t19
      });
      $[85] = league.id;
      $[86] = profileUid;
      $[87] = t20;
    } else {
      t20 = $[87];
    }
    let t21;
    if ($[88] === Symbol.for("react.memo_cache_sentinel")) {
      t21 = () => {
        setQuickGame(null);
        setFollow(null);
      };
      $[88] = t21;
    } else {
      t21 = $[88];
    }
    let t22;
    if ($[89] !== follow || $[90] !== leagueId || $[91] !== quickGame) {
      t22 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(GameQuickView.default, {
        gameId: quickGame,
        onClose: t21,
        defaultWallet: leagueId,
        follow: follow
      });
      $[89] = follow;
      $[90] = leagueId;
      $[91] = quickGame;
      $[92] = t22;
    } else {
      t22 = $[92];
    }
    let t23;
    if ($[93] !== T0 || $[94] !== t11 || $[95] !== t15 || $[96] !== t18 || $[97] !== t2 || $[98] !== t20 || $[99] !== t22 || $[100] !== t3 || $[101] !== t4 || $[102] !== t5 || $[103] !== t6) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T0, {
        style: t2,
        children: [t3, t4, t5, t6, t11, t15, t18, t20, t22]
      });
      $[93] = T0;
      $[94] = t11;
      $[95] = t15;
      $[96] = t18;
      $[97] = t2;
      $[98] = t20;
      $[99] = t22;
      $[100] = t3;
      $[101] = t4;
      $[102] = t5;
      $[103] = t6;
      $[104] = t23;
    } else {
      t23 = $[104];
    }
    return t23;
  }
  function _temp7(b_0) {
    return b_0.status !== "pending";
  }
  function _temp6(b) {
    return b.status === "pending";
  }
  function ModePicksCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(32);
    const {
      league,
      picks,
      uid,
      closed
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const {
      makePick
    } = (0, _contextLeagueContext.useLeague)();
    const {
      upcoming
    } = (0, _hooksUseGames.useGames)();
    let t1;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = (0, _libMarkets.weekKey)();
      $[0] = t1;
    } else {
      t1 = $[0];
    }
    const wk = t1;
    let t2;
    if ($[1] !== league.allowedSports || $[2] !== league.endsAt) {
      t2 = g => league.allowedSports.includes(g.sport) && g.startsAt < league.endsAt;
      $[1] = league.allowedSports;
      $[2] = league.endsAt;
      $[3] = t2;
    } else {
      t2 = $[3];
    }
    const allowedUpcoming = upcoming.filter(t2).slice(0, 6);
    let t3;
    if ($[4] !== uid) {
      t3 = p => p.uid === uid && p.week === wk;
      $[4] = uid;
      $[5] = t3;
    } else {
      t3 = $[5];
    }
    const myPicksThisWeek = picks.filter(t3);
    const [busyGame, setBusyGame] = (0, _react.useState)(null);
    const myMem = uid ? league.members[uid] : undefined;
    const isSurvivorOut = !!myMem?.eliminated;
    const T0 = _componentsUi.Card;
    let t4;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
      t4 = {
        gap: 8
      };
      $[6] = t4;
    } else {
      t4 = $[6];
    }
    const t5 = league.mode === "survivor" ? "skull-outline" : "checkbox-marked-circle-outline";
    let t6;
    if ($[7] !== c.league || $[8] !== t5) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: t5,
        size: 18,
        color: c.league
      });
      $[7] = c.league;
      $[8] = t5;
      $[9] = t6;
    } else {
      t6 = $[9];
    }
    let t7;
    if ($[10] !== c.foreground) {
      t7 = [styles.cardTitle, {
        color: c.foreground,
        flex: 1
      }];
      $[10] = c.foreground;
      $[11] = t7;
    } else {
      t7 = $[11];
    }
    const t8 = league.mode === "survivor" ? `Survivor Pick · ${wk}` : `Weekly Pick'em · ${wk}`;
    let t9;
    if ($[12] !== t7 || $[13] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t7,
        children: t8
      });
      $[12] = t7;
      $[13] = t8;
      $[14] = t9;
    } else {
      t9 = $[14];
    }
    const t10 = `${myPicksThisWeek.length} picked`;
    let t11;
    if ($[15] !== t10) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
        label: t10,
        tone: "league"
      });
      $[15] = t10;
      $[16] = t11;
    } else {
      t11 = $[16];
    }
    let t12;
    if ($[17] !== t11 || $[18] !== t6 || $[19] !== t9) {
      t12 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.inline,
        children: [t6, t9, t11]
      });
      $[17] = t11;
      $[18] = t6;
      $[19] = t9;
      $[20] = t12;
    } else {
      t12 = $[20];
    }
    let t13;
    if ($[21] !== c.mutedForeground) {
      t13 = [styles.muted, {
        color: c.mutedForeground
      }];
      $[21] = c.mutedForeground;
      $[22] = t13;
    } else {
      t13 = $[22];
    }
    const t14 = league.mode === "survivor" ? isSurvivorOut ? `You were eliminated in ${myMem?.eliminatedWeek ?? "an earlier week"}.` : "Pick one team to win straight-up this week. Lose and you're eliminated." : "Pick winners straight-up across this week's slate \u2014 1 point per win.";
    let t15;
    if ($[23] !== t13 || $[24] !== t14) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t13,
        children: t14
      });
      $[23] = t13;
      $[24] = t14;
      $[25] = t15;
    } else {
      t15 = $[25];
    }
    const t16 = !closed && !isSurvivorOut && allowedUpcoming.map(g_0 => {
      const current = myPicksThisWeek.find(p_0 => p_0.gameId === g_0.id);
      return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.inline, {
          paddingVertical: 4
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.memberSub, {
            color: c.foreground,
            flex: 1
          }],
          numberOfLines: 1,
          children: [g_0.awayTeam.abbreviation, " @ ", g_0.homeTeam.abbreviation]
        }), ["away", "home"].map(side => {
          const team = side === "home" ? g_0.homeTeam : g_0.awayTeam;
          const picked = current?.side === side;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            size: "sm",
            variant: picked ? "league" : "secondary",
            label: team.abbreviation,
            loading: busyGame === `${g_0.id}_${side}`,
            onPress: async () => {
              setBusyGame(`${g_0.id}_${side}`);
              await makePick(league.id, g_0.id, side);
              setBusyGame(null);
            }
          }, side);
        })]
      }, g_0.id);
    });
    let t17;
    if ($[26] !== T0 || $[27] !== t12 || $[28] !== t15 || $[29] !== t16 || $[30] !== t4) {
      t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T0, {
        style: t4,
        children: [t12, t15, t16]
      });
      $[26] = T0;
      $[27] = t12;
      $[28] = t15;
      $[29] = t16;
      $[30] = t4;
      $[31] = t17;
    } else {
      t17 = $[31];
    }
    return t17;
  }
  function ParlaysSection(t0) {
    const $ = (0, _reactCompilerRuntime.c)(70);
    const {
      league,
      parlays,
      uid,
      closed,
      fmt
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const {
      createGroupParlay,
      addParlayLeg,
      rideParlay,
      lockParlay
    } = (0, _contextLeagueContext.useLeague)();
    const {
      upcoming
    } = (0, _hooksUseGames.useGames)();
    const [creating, setCreating] = (0, _react.useState)(false);
    const [stake, setStake] = (0, _react.useState)("250");
    const [busy, setBusy] = (0, _react.useState)(null);
    let t1;
    if ($[0] !== league || $[1] !== upcoming) {
      let t2;
      if ($[3] !== league) {
        t2 = g => league.allowedSports.includes(g.sport) && g.startsAt < league.endsAt && (g.homeTeam.odds ?? 0) > 1;
        $[3] = league;
        $[4] = t2;
      } else {
        t2 = $[4];
      }
      t1 = upcoming.find(t2);
      $[0] = league;
      $[1] = upcoming;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    const candidateGame = t1;
    let t2;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
      t2 = {
        gap: 8
      };
      $[5] = t2;
    } else {
      t2 = $[5];
    }
    let t3;
    if ($[6] !== c.league) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "cards-playing-outline",
        size: 18,
        color: c.league
      });
      $[6] = c.league;
      $[7] = t3;
    } else {
      t3 = $[7];
    }
    let t4;
    if ($[8] !== c.foreground) {
      t4 = [styles.cardTitle, {
        color: c.foreground,
        flex: 1
      }];
      $[8] = c.foreground;
      $[9] = t4;
    } else {
      t4 = $[9];
    }
    let t5;
    if ($[10] !== parlays.length || $[11] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: t4,
        children: ["Group Parlays (", parlays.length, ")"]
      });
      $[10] = parlays.length;
      $[11] = t4;
      $[12] = t5;
    } else {
      t5 = $[12];
    }
    let t6;
    if ($[13] !== candidateGame || $[14] !== closed || $[15] !== creating) {
      t6 = !closed && candidateGame && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        size: "sm",
        variant: "secondary",
        icon: creating ? "close" : "plus",
        label: creating ? "Cancel" : "Start parlay",
        onPress: () => setCreating(_temp8)
      });
      $[13] = candidateGame;
      $[14] = closed;
      $[15] = creating;
      $[16] = t6;
    } else {
      t6 = $[16];
    }
    let t7;
    if ($[17] !== t3 || $[18] !== t5 || $[19] !== t6) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.inline,
        children: [t3, t5, t6]
      });
      $[17] = t3;
      $[18] = t5;
      $[19] = t6;
      $[20] = t7;
    } else {
      t7 = $[20];
    }
    let t8;
    if ($[21] !== c.mutedForeground) {
      t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.muted, {
          color: c.mutedForeground
        }],
        children: "Build a 2\u20134 leg ticket together. Friends can add legs or ride the ticket before kickoff."
      });
      $[21] = c.mutedForeground;
      $[22] = t8;
    } else {
      t8 = $[22];
    }
    let t9;
    if ($[23] !== busy || $[24] !== c.border || $[25] !== c.foreground || $[26] !== c.secondary || $[27] !== c.subtleForeground || $[28] !== candidateGame || $[29] !== createGroupParlay || $[30] !== creating || $[31] !== league || $[32] !== stake) {
      t9 = creating && candidateGame && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: {
          gap: 8
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(NumericInput.default, {
          style: [styles.field, {
            color: c.foreground,
            borderColor: c.border,
            backgroundColor: c.secondary
          }],
          value: stake,
          onChangeText: t => setStake(t.replace(/[^0-9]/g, "")),
          keyboardType: "number-pad",
          placeholder: "Entry stake per rider",
          placeholderTextColor: c.subtleForeground
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: styles.inline,
          children: ["away", "home"].map(side => {
            const t_0 = side === "home" ? candidateGame.homeTeam : candidateGame.awayTeam;
            return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              size: "sm",
              variant: "league",
              label: `1st leg: ${t_0.abbreviation} ML`,
              loading: busy === `new_${side}`,
              onPress: async () => {
                setBusy(`new_${side}`);
                await createGroupParlay({
                  idempotencyKey: (0, _libApi.newIdempotencyKey)(),
                  leagueId: league.id,
                  stake: Number.parseInt(stake, 10) || 250,
                  leg: {
                    gameId: candidateGame.id,
                    side,
                    market: "ml",
                    selection: side
                  }
                });
                setBusy(null);
                setCreating(false);
              }
            }, side);
          })
        })]
      });
      $[23] = busy;
      $[24] = c.border;
      $[25] = c.foreground;
      $[26] = c.secondary;
      $[27] = c.subtleForeground;
      $[28] = candidateGame;
      $[29] = createGroupParlay;
      $[30] = creating;
      $[31] = league;
      $[32] = stake;
      $[33] = t9;
    } else {
      t9 = $[33];
    }
    let t10;
    if ($[34] !== addParlayLeg || $[35] !== busy || $[36] !== c.border || $[37] !== c.foreground || $[38] !== c.mutedForeground || $[39] !== c.negative || $[40] !== c.secondary || $[41] !== closed || $[42] !== fmt || $[43] !== league || $[44] !== lockParlay || $[45] !== parlays || $[46] !== rideParlay || $[47] !== uid || $[48] !== upcoming) {
      let t11;
      if ($[50] !== addParlayLeg || $[51] !== busy || $[52] !== c.border || $[53] !== c.foreground || $[54] !== c.mutedForeground || $[55] !== c.negative || $[56] !== c.secondary || $[57] !== closed || $[58] !== fmt || $[59] !== league || $[60] !== lockParlay || $[61] !== rideParlay || $[62] !== uid || $[63] !== upcoming) {
        t11 = p => {
          const riders = Object.values(p.riders ?? {});
          const defaultStake = riders[0]?.stake ?? 250;
          const imRiding = !!(uid && p.riders?.[uid]);
          const nextGame = upcoming.find(g_0 => league.allowedSports.includes(g_0.sport) && !p.legs.some(l => l.gameId === g_0.id) && (g_0.homeTeam.odds ?? 0) > 1);
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.parlayBox, {
              borderColor: c.border,
              backgroundColor: c.secondary
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.inline,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.memberName, {
                  color: c.foreground,
                  flex: 1
                }],
                children: [p.legs.length, "-leg parlay \xB7 ", (0, _libOdds.formatOdds)(p.combinedOdds, fmt)]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
                label: p.status.toUpperCase(),
                tone: p.status === "won" ? "positive" : p.status === "lost" ? "negative" : "league"
              })]
            }), p.legs.map((l_0, i) => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.memberSub, {
                color: c.foreground
              }],
              children: ["\u2022 ", l_0.label, " (", (0, _libOdds.formatOdds)(l_0.odds, fmt), ") \u2014 by ", l_0.name]
            }, `${l_0.gameId}_${i}`)), p.bustedByName ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.memberSub, {
                color: c.negative
              }],
              children: ["\uD83D\uDC80 Busted by ", p.bustedByName, p.bustedLeg ? ` (${p.bustedLeg})` : ""]
            }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.memberSub, {
                color: c.mutedForeground
              }],
              children: [riders.length, " rider", riders.length === 1 ? "" : "s", " (", riders.map(r => r.uid === uid ? `${r.name} · ${r.stake.toLocaleString()}` : r.name).join(", "), ")"]
            }), !closed && p.status === "open" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.inline,
              children: [nextGame && p.legs.length < 4 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
                size: "sm",
                variant: "secondary",
                label: `+ ${nextGame.homeTeam.abbreviation} ML`,
                loading: busy === `leg_${p.id}`,
                onPress: async () => {
                  setBusy(`leg_${p.id}`);
                  await addParlayLeg({
                    leagueId: league.id,
                    parlayId: p.id,
                    gameId: nextGame.id,
                    side: "home",
                    market: "ml",
                    selection: "home"
                  });
                  setBusy(null);
                }
              }), !imRiding && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
                size: "sm",
                variant: "league",
                label: `Ride (${defaultStake.toLocaleString()})`,
                loading: busy === `ride_${p.id}`,
                onPress: async () => {
                  setBusy(`ride_${p.id}`);
                  await rideParlay(league.id, p.id, defaultStake);
                  setBusy(null);
                }
              }), p.creatorUid === uid && p.legs.length >= 2 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
                size: "sm",
                variant: "primary",
                label: "Lock Ticket",
                loading: busy === `lock_${p.id}`,
                onPress: async () => {
                  setBusy(`lock_${p.id}`);
                  await lockParlay(league.id, p.id);
                  setBusy(null);
                }
              })]
            })]
          }, p.id);
        };
        $[50] = addParlayLeg;
        $[51] = busy;
        $[52] = c.border;
        $[53] = c.foreground;
        $[54] = c.mutedForeground;
        $[55] = c.negative;
        $[56] = c.secondary;
        $[57] = closed;
        $[58] = fmt;
        $[59] = league;
        $[60] = lockParlay;
        $[61] = rideParlay;
        $[62] = uid;
        $[63] = upcoming;
        $[64] = t11;
      } else {
        t11 = $[64];
      }
      t10 = parlays.map(t11);
      $[34] = addParlayLeg;
      $[35] = busy;
      $[36] = c.border;
      $[37] = c.foreground;
      $[38] = c.mutedForeground;
      $[39] = c.negative;
      $[40] = c.secondary;
      $[41] = closed;
      $[42] = fmt;
      $[43] = league;
      $[44] = lockParlay;
      $[45] = parlays;
      $[46] = rideParlay;
      $[47] = uid;
      $[48] = upcoming;
      $[49] = t10;
    } else {
      t10 = $[49];
    }
    let t11;
    if ($[65] !== t10 || $[66] !== t7 || $[67] !== t8 || $[68] !== t9) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: t2,
        children: [t7, t8, t9, t10]
      });
      $[65] = t10;
      $[66] = t7;
      $[67] = t8;
      $[68] = t9;
      $[69] = t11;
    } else {
      t11 = $[69];
    }
    return t11;
  }
  function _temp8(v) {
    return !v;
  }
  function ReactionBar(t0) {
    const $ = (0, _reactCompilerRuntime.c)(6);
    const {
      reactions,
      reactors,
      uid,
      onToggle
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const optimistic = (0, _hooksUseOptimisticReaction.useOptimisticReaction)(reactors, uid, reactions);
    let t1;
    if ($[0] !== c || $[1] !== onToggle || $[2] !== optimistic) {
      t1 = _constantsLeagueTypes.REACTION_EMOJIS.map(emoji => {
        const count = optimistic.counts[emoji] ?? 0;
        const mine = optimistic.mine === emoji;
        return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
          accessibilityRole: "button",
          onPress: () => void optimistic.toggle(emoji, e => onToggle(e)),
          style: [styles.reactionChip, {
            backgroundColor: mine ? c.leagueSoft : c.secondary,
            borderColor: mine ? c.league : c.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: {
              fontSize: 11
            },
            children: emoji
          }), count > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.reactionCount, {
              color: mine ? c.league : c.mutedForeground
            }],
            children: count
          }) : null]
        }, emoji);
      });
      $[0] = c;
      $[1] = onToggle;
      $[2] = optimistic;
      $[3] = t1;
    } else {
      t1 = $[3];
    }
    let t2;
    if ($[4] !== t1) {
      t2 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.reactionRow,
        children: t1
      });
      $[4] = t1;
      $[5] = t2;
    } else {
      t2 = $[5];
    }
    return t2;
  }

  // ── Bank & peer loans ──────────────────────────────────────────────────────

  function BankTab({
    league,
    loans,
    uid,
    me,
    tokens,
    now,
    closed
  }) {
    const c = (0, _hooksUseColors.useColors)();
    const {
      takeBankLoan,
      repayLoan,
      updateBankSettings
    } = (0, _contextLeagueContext.useLeague)();
    const isCreator = league.creatorId === uid;
    const [opening, setOpening] = (0, _react.useState)(false);
    const ended = league.status === "ended";
    const asOf = ended ? league.endedAt ?? league.endsAt : Math.min(now, league.endsAt);
    const mine = loans.filter(l => l.borrowerId === uid && (l.status === "active" || l.status === "repaid"));
    const activeMine = mine.filter(l_0 => l_0.status === "active");
    const lent = loans.filter(l_1 => l_1.lenderId === uid && (l_1.status === "active" || l_1.status === "repaid"));
    const totals = activeMine.reduce((t, l_2) => {
      const s = (0, _libLoanMath.loanSnapshot)(l_2, asOf);
      return {
        owed: t.owed + s.totalOwed,
        charged: t.charged + s.interestCharged,
        paid: t.paid + s.interestPaid,
        principal: t.principal + s.principalOutstanding
      };
    }, {
      owed: 0,
      charged: 0,
      paid: 0,
      principal: 0
    });
    const cap = Math.floor(league.startingLeagueTokens * _constantsLeagueTypes.BANK_PRINCIPAL_CAP_MULTIPLIER);
    const bankPrincipal = activeMine.filter(l_3 => l_3.kind === "bank").reduce((s_0, l_4) => s_0 + l_4.principalOutstanding, 0);
    const room = Math.max(0, cap - bankPrincipal);
    const [amount, setAmount] = (0, _react.useState)("");
    const [busy, setBusy] = (0, _react.useState)(false);
    const [err, setErr] = (0, _react.useState)(null);
    const borrow = Number.parseInt(amount, 10) || 0;
    const fee = (0, _libLoanMath.flatInterest)(borrow, league.bankInterestRate);
    const activeEdges = loans.filter(l_5 => l_5.status === "active");
    const lenderBoard = (0, _react.useMemo)(() => {
      const map = new Map();
      for (const l_6 of loans) {
        if (l_6.kind !== "peer" || !l_6.lenderId) continue;
        if (l_6.status !== "active" && l_6.status !== "repaid") continue;
        const cur = map.get(l_6.lenderId) ?? {
          id: l_6.lenderId,
          name: l_6.lenderName ?? "Lender",
          interestEarned: 0,
          lentCount: 0
        };
        cur.interestEarned += l_6.interestPaid ?? 0;
        cur.lentCount += 1;
        map.set(l_6.lenderId, cur);
      }
      return [...map.values()].sort((a, b) => b.interestEarned - a.interestEarned || b.lentCount - a.lentCount);
    }, [loans]);
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
      style: {
        gap: 12
      },
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: {
          gap: 10
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.cardTitle, {
            color: c.foreground
          }],
          children: "Your Finances"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.hero,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.StatTile, {
            label: "Tokens",
            children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
              value: tokens,
              currency: "league",
              size: "sm",
              animate: true
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.StatTile, {
            label: "Owed",
            children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
              value: totals.owed,
              currency: "league",
              size: "sm",
              tone: totals.owed ? "debt" : "neutral"
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.StatTile, {
            label: "Net Worth",
            children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
              value: me?.netWorth ?? tokens,
              currency: "league",
              size: "sm"
            })
          })]
        }), tokens === 0 && activeMine.length === 0 && !closed && uid && !league.members[uid]?.resetUsed ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
          label: `Fresh start: reset to ${Math.floor(league.startingLeagueTokens * 0.25).toLocaleString()} (once per league)`,
          icon: "restart",
          chevron: false,
          tone: "league",
          disabled: busy,
          onPress: async () => {
            setBusy(true);
            setErr(null);
            try {
              await api.requestReset({
                leagueId: league.id
              });
            } catch (e) {
              setErr(api.friendlyError(e));
            } finally {
              setBusy(false);
            }
          }
        }) : null, activeMine.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.muted, {
            color: c.mutedForeground
          }],
          children: [totals.principal.toLocaleString(), " principal outstanding \xB7 ", totals.charged.toLocaleString(), " flat interest, ", totals.paid.toLocaleString(), " of it paid."]
        })]
      }), (activeEdges.length > 0 || lenderBoard.length > 0) && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: {
          gap: 8
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.inline,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "graph-outline",
            size: 18,
            color: c.league
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.cardTitle, {
              color: c.foreground,
              flex: 1
            }],
            children: "Who owes who & Loan Sharks"
          })]
        }), activeEdges.map(l_7 => {
          const snap = (0, _libLoanMath.loanSnapshot)(l_7, asOf);
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.inline,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.memberSub, {
                color: c.foreground,
                flex: 1
              }],
              numberOfLines: 1,
              children: [l_7.borrowerId === uid ? "You" : l_7.borrowerName, " \u2192 ", l_7.kind === "bank" ? "League Bank" : l_7.lenderId === uid ? "You" : l_7.lenderName]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
              value: snap.totalOwed,
              currency: "league",
              size: "sm",
              tone: "debt"
            })]
          }, l_7.id);
        }), lenderBoard.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: {
            gap: 4,
            marginTop: 4
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.champK, {
              color: c.subtleForeground
            }],
            children: "TOP PEER LENDERS (INTEREST EARNED)"
          }), lenderBoard.map((row, idx) => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.inline,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.memberSub, {
                color: c.foreground,
                flex: 1
              }],
              children: [idx === 0 ? "🦈 " : "", row.id === uid ? "You" : row.name, " (", row.lentCount, " loan", row.lentCount === 1 ? "" : "s", ")"]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
              value: row.interestEarned,
              currency: "league",
              size: "sm",
              signed: true,
              tone: "positive"
            })]
          }, row.id))]
        })]
      }), league.stimulusEnabled && !closed ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(StimulusCard, {
        league: league,
        uid: uid,
        now: now
      }) : null, !closed && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PeerMarket, {
        league: league,
        loans: loans,
        uid: uid,
        tokens: tokens
      }), league.bankLoanEnabled && !closed ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: {
          gap: 10
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.inline,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "bank-outline",
            size: 18,
            color: c.league
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.cardTitle, {
              color: c.foreground,
              flex: 1
            }],
            children: "League Bank"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
            label: `${league.bankInterestRate}% flat`,
            tone: "league"
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.muted, {
            color: c.mutedForeground
          }],
          children: ["A one-time ", league.bankInterestRate, "% fee on what you borrow \u2014 it never grows. You can borrow ", room.toLocaleString(), " more (limit ", cap.toLocaleString(), " in principal). Debt counts against your net worth."]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.input, {
            borderColor: borrow > room ? c.negative : c.border,
            backgroundColor: c.secondary
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "shield-star",
            size: 18,
            color: c.league
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(NumericInput.default, {
            style: [styles.inputText, {
              color: c.foreground
            }],
            value: amount,
            onChangeText: t_0 => setAmount(t_0.replace(/[^0-9]/g, "")),
            keyboardType: "number-pad",
            placeholder: "Amount to borrow",
            placeholderTextColor: c.subtleForeground,
            accessibilityLabel: "Amount to borrow"
          })]
        }), borrow > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.muted, {
            color: c.mutedForeground
          }],
          children: ["You'll repay ", (borrow + fee).toLocaleString(), " in total (", fee.toLocaleString(), " interest), however long it takes."]
        }), err ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.muted, {
            color: c.negative
          }],
          children: err
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: borrow > 0 ? `Borrow ${borrow.toLocaleString()}` : "Borrow",
          variant: "league",
          loading: busy,
          disabled: borrow < 10 || borrow > room,
          onPress: async () => {
            setBusy(true);
            setErr(null);
            const e_0 = await takeBankLoan(league.id, borrow);
            setBusy(false);
            if (e_0) setErr(e_0);else {
              _libMotion.haptic.success();
              setAmount("");
            }
          }
        })]
      }) : !closed ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: {
          gap: 10
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.inline,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "bank-off-outline",
            size: 18,
            color: c.mutedForeground
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.cardTitle, {
              color: c.foreground,
              flex: 1
            }],
            children: "League Bank Is Closed"
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.muted, {
            color: c.mutedForeground
          }],
          children: isCreator ? "Open it so members can borrow league tokens for a flat fee." : "Only the league creator can open the bank. You can still borrow from friends above."
        }), err ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.muted, {
            color: c.negative
          }],
          children: err
        }) : null, isCreator && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: `Open the bank · ${league.bankInterestRate || 10}% flat`,
          icon: "bank-outline",
          variant: "league",
          loading: opening,
          onPress: async () => {
            setOpening(true);
            setErr(null);
            const e_1 = await updateBankSettings(league.id, true, league.bankInterestRate || 10, league.bankInterestIntervalHours || 24);
            setOpening(false);
            if (e_1) setErr(e_1);
          }
        })]
      }) : null, mine.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
        title: "What You Owe"
      }), mine.map(l_8 => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(LoanCard.default, {
        loan: l_8,
        now: asOf,
        viewer: "borrower",
        tokens: tokens,
        onRepay: closed ? undefined : amt => repayLoan(league.id, l_8.id, amt)
      }, l_8.id)), lent.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
        title: "What you're owed"
      }), lent.map(l_9 => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(LoanCard.default, {
        loan: l_9,
        now: asOf,
        viewer: "lender",
        tokens: tokens
      }, l_9.id))]
    });
  }

  /** Bank stimulus: ask the bank to top everyone up; a majority yes pays out. */
  function StimulusCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(40);
    const {
      league,
      uid,
      now
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const {
      stimulus
    } = (0, _contextLeagueContext.useLeague)();
    const [busy, setBusy] = (0, _react.useState)(null);
    const [err, setErr] = (0, _react.useState)(null);
    const open = league.stimulus && league.stimulus.expiresAt > now ? league.stimulus : null;
    const needed = Math.floor(league.memberIds.length / 2) + 1;
    let t1;
    if ($[0] !== open || $[1] !== uid) {
      t1 = open && uid && open.votes.includes(uid);
      $[0] = open;
      $[1] = uid;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    const iVoted = !!t1;
    const cooldownLeft = league.lastStimulusAt ? league.lastStimulusAt + 604800000 - now : 0;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
      t2 = async (key, fn) => {
        setBusy(key);
        setErr(null);
        const e = await fn();
        setBusy(null);
        if (e) {
          setErr(e);
        } else {
          _libMotion.haptic.success();
        }
      };
      $[3] = t2;
    } else {
      t2 = $[3];
    }
    const act = t2;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
      t3 = {
        gap: 10
      };
      $[4] = t3;
    } else {
      t3 = $[4];
    }
    let t4;
    if ($[5] !== c.positive) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "cash-plus",
        size: 18,
        color: c.positive
      });
      $[5] = c.positive;
      $[6] = t4;
    } else {
      t4 = $[6];
    }
    let t5;
    if ($[7] !== c.foreground) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.cardTitle, {
          color: c.foreground,
          flex: 1
        }],
        children: "Stimulus Vote"
      });
      $[7] = c.foreground;
      $[8] = t5;
    } else {
      t5 = $[8];
    }
    let t6;
    if ($[9] !== needed || $[10] !== open) {
      t6 = open ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
        label: `${open.votes.length}/${needed} yes`,
        tone: "positive"
      }) : null;
      $[9] = needed;
      $[10] = open;
      $[11] = t6;
    } else {
      t6 = $[11];
    }
    let t7;
    if ($[12] !== t4 || $[13] !== t5 || $[14] !== t6) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.inline,
        children: [t4, t5, t6]
      });
      $[12] = t4;
      $[13] = t5;
      $[14] = t6;
      $[15] = t7;
    } else {
      t7 = $[15];
    }
    let t8;
    if ($[16] !== busy || $[17] !== c.mutedForeground || $[18] !== cooldownLeft || $[19] !== iVoted || $[20] !== league.creatorId || $[21] !== league.id || $[22] !== league.memberIds.length || $[23] !== league.startingLeagueTokens || $[24] !== needed || $[25] !== open || $[26] !== stimulus || $[27] !== uid) {
      t8 = open ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.muted, {
            color: c.mutedForeground
          }],
          children: [open.uid === uid ? "You" : open.name, " asked the bank to give every member ", open.amount.toLocaleString(), " tokens (", open.pct, "% of the starting stack). It pays out the moment ", needed, " of ", league.memberIds.length, " members say yes \xB7 closes", " ", new Date(open.expiresAt).toLocaleString(undefined, {
            weekday: "short",
            hour: "numeric",
            minute: "2-digit"
          }), "."]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.inline,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: iVoted ? "You voted yes \xB7 undo" : `Vote yes (+${open.amount.toLocaleString()})`,
            variant: iVoted ? "secondary" : "primary",
            icon: iVoted ? "undo" : "thumb-up-outline",
            size: "sm",
            loading: busy === "vote",
            onPress: () => act("vote", () => stimulus({
              leagueId: league.id,
              action: "vote",
              requestId: open.id,
              approve: !iVoted
            }))
          }), open.uid === uid || league.creatorId === uid ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: "Withdraw",
            variant: "ghost",
            size: "sm",
            loading: busy === "cancel",
            onPress: () => act("cancel", () => stimulus({
              leagueId: league.id,
              action: "cancel",
              requestId: open.id
            }))
          }) : null]
        })]
      }) : cooldownLeft > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.muted, {
          color: c.mutedForeground
        }],
        children: ["The last stimulus paid out recently. You can ask again in ", Math.ceil(cooldownLeft / 86400000), " day", Math.ceil(cooldownLeft / 86400000) === 1 ? "" : "s", "."]
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.muted, {
            color: c.mutedForeground
          }],
          children: ["Stacks running low? Ask the bank to give everyone the same top-up. It's free money, not a loan, and needs ", needed, " of", " ", league.memberIds.length, " members to agree."]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: styles.inline,
          children: _constantsLeagueTypes.STIMULUS_PCTS.map(pct => {
            const amt = Math.round(league.startingLeagueTokens * pct / 100);
            return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              label: `${pct}% · ${amt.toLocaleString()}`,
              variant: "secondary",
              size: "sm",
              loading: busy === `req${pct}`,
              onPress: () => act(`req${pct}`, () => stimulus({
                leagueId: league.id,
                action: "request",
                pct
              }))
            }, pct);
          })
        })]
      });
      $[16] = busy;
      $[17] = c.mutedForeground;
      $[18] = cooldownLeft;
      $[19] = iVoted;
      $[20] = league.creatorId;
      $[21] = league.id;
      $[22] = league.memberIds.length;
      $[23] = league.startingLeagueTokens;
      $[24] = needed;
      $[25] = open;
      $[26] = stimulus;
      $[27] = uid;
      $[28] = t8;
    } else {
      t8 = $[28];
    }
    let t9;
    if ($[29] !== c.subtleForeground || $[30] !== league.stimulusTotal) {
      t9 = league.stimulusTotal ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.memberSub, {
          color: c.subtleForeground
        }],
        children: ["Paid out so far: ", league.stimulusTotal.toLocaleString(), " tokens per member."]
      }) : null;
      $[29] = c.subtleForeground;
      $[30] = league.stimulusTotal;
      $[31] = t9;
    } else {
      t9 = $[31];
    }
    let t10;
    if ($[32] !== c.negative || $[33] !== err) {
      t10 = err ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.memberSub, {
          color: c.negative
        }],
        children: err
      }) : null;
      $[32] = c.negative;
      $[33] = err;
      $[34] = t10;
    } else {
      t10 = $[34];
    }
    let t11;
    if ($[35] !== t10 || $[36] !== t7 || $[37] !== t8 || $[38] !== t9) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: t3,
        children: [t7, t8, t9, t10]
      });
      $[35] = t10;
      $[36] = t7;
      $[37] = t8;
      $[38] = t9;
      $[39] = t11;
    } else {
      t11 = $[39];
    }
    return t11;
  }
  function PeerMarket(t0) {
    const $ = (0, _reactCompilerRuntime.c)(28);
    const {
      league,
      loans,
      uid,
      tokens
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const {
      requestLoan,
      peerLoanAction
    } = (0, _contextLeagueContext.useLeague)();
    const open = loans.filter(_temp9);
    const max = Math.floor(league.startingLeagueTokens * _constantsLeagueTypes.PEER_LOAN_MAX_PCT);
    const [show, setShow] = (0, _react.useState)(false);
    const [amount, setAmount] = (0, _react.useState)("");
    const [rate, setRate] = (0, _react.useState)("");
    const [msg, setMsg] = (0, _react.useState)("");
    const [busy, setBusy] = (0, _react.useState)(null);
    const [err, setErr] = (0, _react.useState)(null);
    const [counterFor, setCounterFor] = (0, _react.useState)(null);
    const [counterRate, setCounterRate] = (0, _react.useState)("");
    let t1;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = async (key, fn) => {
        setBusy(key);
        setErr(null);
        const e = await fn();
        setBusy(null);
        if (e) {
          setErr(e);
        }
        return e;
      };
      $[0] = t1;
    } else {
      t1 = $[0];
    }
    const act = t1;
    const amt = Number.parseInt(amount, 10) || 0;
    const r = Number.parseFloat(rate) || 0;
    let t2;
    if ($[1] !== league) {
      t2 = _constantsLeagueTypes.PEER_LOAN_REQUESTS_ENABLED && !(0, _constantsLeagueTypes.isLeagueClosed)(league);
      $[1] = league;
      $[2] = t2;
    } else {
      t2 = $[2];
    }
    const canRequest = t2;
    if (!canRequest && open.length === 0) {
      return null;
    }
    const T0 = View.default;
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
      t3 = {
        gap: 10
      };
      $[3] = t3;
    } else {
      t3 = $[3];
    }
    let t4;
    if ($[4] !== c || $[5] !== canRequest || $[6] !== show) {
      t4 = canRequest ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
          title: "Loans From Friends"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.muted, {
            color: c.mutedForeground
          }],
          children: "Name your amount and a flat return. A friend funds it from their own tokens, or counters. Borrow 100 at 10% and they get back 110 \u2014 never more."
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: show ? "Cancel" : "Ask friends for a loan",
          icon: show ? "close" : "hand-coin-outline",
          variant: show ? "secondary" : "league",
          onPress: () => setShow(_temp0)
        })]
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SectionHeader, {
        title: "Open Loan Requests"
      });
      $[4] = c;
      $[5] = canRequest;
      $[6] = show;
      $[7] = t4;
    } else {
      t4 = $[7];
    }
    const t5 = canRequest && show && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
      style: {
        gap: 8
      },
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(NumericInput.default, {
        style: [styles.field, {
          color: c.foreground,
          borderColor: c.border,
          backgroundColor: c.secondary
        }],
        value: amount,
        onChangeText: t => setAmount(t.replace(/[^0-9]/g, "")),
        keyboardType: "number-pad",
        placeholder: `Amount (max ${max.toLocaleString()})`,
        placeholderTextColor: c.subtleForeground,
        accessibilityLabel: "Loan amount"
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(NumericInput.default, {
        style: [styles.field, {
          color: c.foreground,
          borderColor: c.border,
          backgroundColor: c.secondary
        }],
        value: rate,
        onChangeText: setRate,
        keyboardType: "decimal-pad",
        placeholder: `Flat return % (bank charges ${league.bankInterestRate}%)`,
        placeholderTextColor: c.subtleForeground,
        accessibilityLabel: "Interest rate"
      }), amt > 0 && r > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.muted, {
          color: c.mutedForeground
        }],
        children: ["You'll repay ", (amt + (0, _libLoanMath.flatInterest)(amt, r)).toLocaleString(), " in total (", (0, _libLoanMath.flatInterest)(amt, r).toLocaleString(), " interest)."]
      }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TextInput.default, {
        style: [styles.field, {
          color: c.foreground,
          borderColor: c.border,
          backgroundColor: c.secondary
        }],
        value: msg,
        onChangeText: setMsg,
        placeholder: "Note (optional)",
        placeholderTextColor: c.subtleForeground,
        maxLength: 80
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        label: "Post Request",
        variant: "league",
        loading: busy === "req",
        disabled: amt < 10 || amt > max || !(r > 0 && r <= 50),
        onPress: async () => {
          const e_0 = await act("req", () => requestLoan(league.id, amt, r, msg));
          if (!e_0) {
            setShow(false);
            setAmount("");
            setRate("");
            setMsg("");
          }
        }
      })]
    });
    let t6;
    if ($[8] !== c || $[9] !== err) {
      t6 = err ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.muted, {
          color: c.negative
        }],
        children: err
      }) : null;
      $[8] = c;
      $[9] = err;
      $[10] = t6;
    } else {
      t6 = $[10];
    }
    let t7;
    if ($[11] !== busy || $[12] !== c || $[13] !== counterFor || $[14] !== counterRate || $[15] !== league.bankInterestRate || $[16] !== league.id || $[17] !== peerLoanAction || $[18] !== tokens || $[19] !== uid) {
      t7 = l_0 => {
        const mineReq = l_0.borrowerId === uid;
        const countered = l_0.status === "countered";
        const declined = !!(uid && l_0.declinedBy?.includes(uid));
        const baseRate = l_0.proposedRate ?? league.bankInterestRate ?? 0;
        const shownRate = countered && l_0.counterRate ? l_0.counterRate : baseRate;
        const shownInterest = (0, _libLoanMath.flatInterest)(l_0.principal, shownRate);
        return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
          style: {
            gap: 8
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.inline,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.memberName, {
                color: c.foreground,
                flex: 1
              }],
              children: [mineReq ? "Your request" : `${l_0.borrowerName} wants`, " \xB7 ", l_0.principal.toLocaleString()]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
              label: `+${shownInterest.toLocaleString()} (${shownRate}% flat)`,
              tone: "league"
            })]
          }), l_0.message ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.muted, {
              color: c.mutedForeground
            }],
            children: ["\"", l_0.message, "\""]
          }) : null, countered && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.memberSub, {
              color: c.accent
            }],
            children: [l_0.counterByName, " countered at ", l_0.counterRate, "% flat (+", shownInterest.toLocaleString(), " interest)"]
          }), mineReq ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.inline,
            children: [countered && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
                size: "sm",
                label: `Accept ${l_0.counterRate}%`,
                variant: "league",
                loading: busy === `acc${l_0.id}`,
                onPress: () => act(`acc${l_0.id}`, () => peerLoanAction(league.id, l_0.id, "accept_counter"))
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
                size: "sm",
                label: "Decline",
                variant: "secondary",
                loading: busy === `rj${l_0.id}`,
                onPress: () => act(`rj${l_0.id}`, () => peerLoanAction(league.id, l_0.id, "reject_counter"))
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              size: "sm",
              label: "Withdraw",
              variant: "ghost",
              loading: busy === `can${l_0.id}`,
              onPress: () => act(`can${l_0.id}`, () => peerLoanAction(league.id, l_0.id, "cancel"))
            })]
          }) : countered || declined ? null : counterFor === l_0.id ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.inline,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(NumericInput.default, {
              style: [styles.field, {
                flex: 1,
                color: c.foreground,
                borderColor: c.border,
                backgroundColor: c.secondary
              }],
              value: counterRate,
              onChangeText: setCounterRate,
              keyboardType: "decimal-pad",
              placeholder: "Your rate %",
              placeholderTextColor: c.subtleForeground,
              autoFocus: true
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              size: "sm",
              label: "Send",
              loading: busy === `ctr${l_0.id}`,
              disabled: !(Number.parseFloat(counterRate) > 0),
              onPress: async () => {
                const e_1 = await act(`ctr${l_0.id}`, () => peerLoanAction(league.id, l_0.id, "counter", Number.parseFloat(counterRate)));
                if (!e_1) {
                  setCounterFor(null);
                }
              }
            })]
          }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.inline,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              size: "sm",
              label: `Lend ${l_0.principal.toLocaleString()}`,
              variant: "league",
              disabled: tokens < l_0.principal,
              loading: busy === `fund${l_0.id}`,
              onPress: () => act(`fund${l_0.id}`, () => peerLoanAction(league.id, l_0.id, "fund"))
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              size: "sm",
              label: "Counter",
              variant: "secondary",
              onPress: () => {
                setCounterFor(l_0.id);
                setCounterRate("");
              }
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              size: "sm",
              label: "Pass",
              variant: "ghost",
              loading: busy === `dec${l_0.id}`,
              onPress: () => act(`dec${l_0.id}`, () => peerLoanAction(league.id, l_0.id, "decline"))
            })]
          }), !mineReq && tokens < l_0.principal && !countered ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.memberSub, {
              color: c.subtleForeground
            }],
            children: ["You'd need ", l_0.principal.toLocaleString(), " tokens to fund this."]
          }) : null]
        }, l_0.id);
      };
      $[11] = busy;
      $[12] = c;
      $[13] = counterFor;
      $[14] = counterRate;
      $[15] = league.bankInterestRate;
      $[16] = league.id;
      $[17] = peerLoanAction;
      $[18] = tokens;
      $[19] = uid;
      $[20] = t7;
    } else {
      t7 = $[20];
    }
    const t8 = open.map(t7);
    let t9;
    if ($[21] !== T0 || $[22] !== t3 || $[23] !== t4 || $[24] !== t5 || $[25] !== t6 || $[26] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T0, {
        style: t3,
        children: [t4, t5, t6, t8]
      });
      $[21] = T0;
      $[22] = t3;
      $[23] = t4;
      $[24] = t5;
      $[25] = t6;
      $[26] = t8;
      $[27] = t9;
    } else {
      t9 = $[27];
    }
    return t9;
  }

  // ── Unified Chat & Activity Feed (Newest at Bottom + Fixed Bottom Input) ───
  function _temp0(v) {
    return !v;
  }
  function _temp9(l) {
    return l.kind === "peer" && (l.status === "requested" || l.status === "countered");
  }
  function FeedTab(t0) {
    const $ = (0, _reactCompilerRuntime.c)(55);
    const {
      league,
      activity,
      messages,
      bets,
      uid,
      now,
      closed,
      fmt,
      bottomPad
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const {
      sendMessage,
      reactToItem
    } = (0, _contextLeagueContext.useLeague)();
    const {
      leagueReplyQuotes,
      recordLeagueMessageQuote,
      setActiveChatId
    } = (0, _contextChatContext.useChat)();
    const [text, setText] = (0, _react.useState)("");
    const [sending, setSending] = (0, _react.useState)(false);
    const [replyQuote, setReplyQuote] = (0, _react.useState)(null);
    const [sendErr, setSendErr] = (0, _react.useState)(null);
    const [profileUid, setProfileUid] = (0, _react.useState)(null);
    const [quickGame, setQuickGame] = (0, _react.useState)(null);
    const [follow, setFollow] = (0, _react.useState)(null);
    const scrollRef = (0, _react.useRef)(null);
    let t1;
    let t2;
    if ($[0] !== league.id || $[1] !== setActiveChatId) {
      t1 = () => {
        setActiveChatId(league.id);
        return () => setActiveChatId(null);
      };
      t2 = [league.id, setActiveChatId];
      $[0] = league.id;
      $[1] = setActiveChatId;
      $[2] = t1;
      $[3] = t2;
    } else {
      t1 = $[2];
      t2 = $[3];
    }
    (0, _react.useEffect)(t1, t2);
    let t3;
    if ($[4] !== activity || $[5] !== messages) {
      const merged = [...messages.map(_temp1), ...activity.map(_temp10)];
      t3 = merged.sort(_temp11);
      $[4] = activity;
      $[5] = messages;
      $[6] = t3;
    } else {
      t3 = $[6];
    }
    const items = t3;
    let map;
    if ($[7] !== bets) {
      map = new Map();
      for (const b of bets) {
        map.set(b.id, b);
      }
      $[7] = bets;
      $[8] = map;
    } else {
      map = $[8];
    }
    const betById = map;
    let t4;
    if ($[9] !== league.id || $[10] !== recordLeagueMessageQuote || $[11] !== replyQuote || $[12] !== sendMessage || $[13] !== sending || $[14] !== text) {
      t4 = async () => {
        const body = text.trim();
        if (!body || sending) {
          return;
        }
        setSending(true);
        _libMotion.haptic.light();
        setSendErr(null);
        const quote = replyQuote ? Object.fromEntries(Object.entries(replyQuote).filter(_temp12)) : null;
        const err = await sendMessage(league.id, body, quote);
        setSending(false);
        if (err) {
          setSendErr(err);
        } else {
          if (replyQuote) {
            recordLeagueMessageQuote(`msg_${Date.now()}`, replyQuote);
          }
          setText("");
          setReplyQuote(null);
          setTimeout(() => scrollRef.current?.scrollToEnd({
            animated: true
          }), 80);
        }
      };
      $[9] = league.id;
      $[10] = recordLeagueMessageQuote;
      $[11] = replyQuote;
      $[12] = sendMessage;
      $[13] = sending;
      $[14] = text;
      $[15] = t4;
    } else {
      t4 = $[15];
    }
    const handleSend = t4;
    let t5;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
      t5 = {
        flex: 1
      };
      $[16] = t5;
    } else {
      t5 = $[16];
    }
    let t6;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
      t6 = [styles.body, {
        flexGrow: 1,
        justifyContent: "flex-end",
        paddingBottom: 16
      }];
      $[17] = t6;
    } else {
      t6 = $[17];
    }
    let t7;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
      t7 = () => scrollRef.current?.scrollToEnd({
        animated: false
      });
      $[18] = t7;
    } else {
      t7 = $[18];
    }
    let t8;
    if ($[19] !== betById || $[20] !== c || $[21] !== closed || $[22] !== fmt || $[23] !== items || $[24] !== league.id || $[25] !== leagueReplyQuotes || $[26] !== now || $[27] !== reactToItem || $[28] !== uid) {
      t8 = items.length === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Card, {
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.muted, {
            color: c.mutedForeground
          }],
          children: "Nothing yet \u2014 drop a message below or place the first league bet."
        })
      }) : items.map(item => {
        if (item.kind === "msg") {
          const m_0 = item.m;
          const mine = m_0.uid === uid;
          const attached = m_0.betId ? betById.get(m_0.betId) : undefined;
          const quote_0 = m_0.replyTo ?? leagueReplyQuotes[m_0.id] ?? null;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: {
              gap: 2
            },
            children: [quote_0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsChatReplyThread.QuotedParent, {
              quote: quote_0,
              isMine: mine
            }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
              style: {
                gap: 6,
                borderColor: mine ? c.alpha(c.league, 0.45) : c.border
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: styles.inline,
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                  onPress: () => setProfileUid(m_0.uid),
                  hitSlop: 6,
                  style: {
                    flex: 1
                  },
                  children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: [styles.memberName, {
                      color: mine ? c.league : c.primary
                    }],
                    children: mine ? "You" : m_0.name
                  })
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.feedTime, {
                    color: c.subtleForeground
                  }],
                  children: ago(m_0.at, now)
                }), !closed && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                  hitSlop: 8,
                  onPress: () => {
                    _libMotion.haptic.tick();
                    setReplyQuote({
                      id: m_0.id,
                      kind: m_0.kind === "bet" ? "bet_result" : "message",
                      authorUid: m_0.uid,
                      authorName: m_0.name,
                      text: (0, _libChatText.chatText)(m_0.text)
                    });
                  },
                  children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                    style: {
                      fontSize: 11,
                      fontFamily: "Inter_700Bold",
                      color: "#007AFF"
                    },
                    children: "Reply"
                  })
                })]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.feedText, {
                  color: c.foreground
                }],
                children: (0, _libChatText.chatText)(m_0.text)
              }), m_0.kind === "taunt" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TauntCard.default, {
                taunt: m_0
              }) : m_0.kind === "bet" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BetChatCard.default, {
                message: m_0,
                uid: uid,
                leagueId: league.id,
                now: now,
                onTail: (gameId, intent) => {
                  if (closed) {
                    return;
                  }
                  setFollow(intent);
                  setQuickGame(gameId);
                }
              }) : attached && !attached.hidden ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
                style: [styles.parlayBox, {
                  borderColor: c.border,
                  backgroundColor: c.secondary
                }],
                children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                  style: [styles.memberSub, {
                    color: c.foreground
                  }],
                  children: ["\uD83C\uDF9F ", attached.label ?? attached.teamAbbr, " @ ", (0, _libOdds.formatOdds)(attached.odds, fmt)]
                })
              }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ReactionBar, {
                reactions: m_0.reactions,
                reactors: m_0.reactors,
                uid: uid,
                onToggle: emoji => closed ? false : reactToItem(league.id, "message", m_0.id, emoji)
              })]
            })]
          }, `msg_${m_0.id}`);
        }
        const a_0 = item.a;
        const isWinAct = a_0.type === "bet_won";
        const isLossAct = a_0.type === "bet_lost";
        return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.feedRow, {
            backgroundColor: c.card,
            borderRadius: 12,
            borderWidth: 1,
            borderColor: c.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: FEED_ICON[a_0.type] ?? "circle-small",
            size: 18,
            color: isWinAct ? c.positive : isLossAct ? c.negative : c.mutedForeground
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
            disabled: !a_0.uid,
            onPress: () => a_0.uid && setProfileUid(a_0.uid),
            style: {
              flex: 1
            },
            children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.feedText, {
                color: c.foreground
              }],
              children: a_0.text
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.feedTime, {
              color: c.subtleForeground
            }],
            children: ago(a_0.at, now)
          }), !closed && (isWinAct || isLossAct || a_0.type === "bet_placed") && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
            hitSlop: 8,
            onPress: () => {
              _libMotion.haptic.tick();
              setReplyQuote({
                id: a_0.id,
                kind: "bet_result",
                authorUid: a_0.uid ?? "",
                authorName: a_0.name ?? "Player",
                text: a_0.text,
                betStatus: isWinAct ? "won" : isLossAct ? "lost" : "pending"
              });
            },
            children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: {
                fontSize: 11,
                fontFamily: "Inter_700Bold",
                color: "#007AFF"
              },
              children: "Reply"
            })
          })]
        }, `act_${a_0.id}`);
      });
      $[19] = betById;
      $[20] = c;
      $[21] = closed;
      $[22] = fmt;
      $[23] = items;
      $[24] = league.id;
      $[25] = leagueReplyQuotes;
      $[26] = now;
      $[27] = reactToItem;
      $[28] = uid;
      $[29] = t8;
    } else {
      t8 = $[29];
    }
    let t9;
    if ($[30] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ScrollView.default, {
        ref: scrollRef,
        contentContainerStyle: t6,
        showsVerticalScrollIndicator: false,
        keyboardShouldPersistTaps: "handled",
        onContentSizeChange: t7,
        children: t8
      });
      $[30] = t8;
      $[31] = t9;
    } else {
      t9 = $[31];
    }
    let t10;
    if ($[32] !== bottomPad || $[33] !== c || $[34] !== closed || $[35] !== handleSend || $[36] !== replyQuote || $[37] !== sendErr || $[38] !== sending || $[39] !== text) {
      t10 = !closed && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: {
          backgroundColor: c.card,
          borderTopWidth: StyleSheet.default.hairlineWidth,
          borderTopColor: c.border,
          paddingBottom: Math.max(10, bottomPad - 12)
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsChatReplyThread.ReplyComposerBar, {
          quote: replyQuote,
          onCancel: () => setReplyQuote(null)
        }), sendErr ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          accessibilityRole: "alert",
          style: {
            color: c.negative,
            fontSize: 12,
            fontFamily: "Inter_500Medium",
            paddingHorizontal: 14,
            paddingTop: 8
          },
          children: sendErr
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.inline, {
            paddingHorizontal: 14,
            paddingTop: 10
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(TextInput.default, {
            style: [styles.field, {
              flex: 1,
              color: c.foreground,
              borderColor: c.border,
              backgroundColor: c.secondary,
              borderRadius: 20
            }],
            value: text,
            onChangeText: setText,
            placeholder: replyQuote ? `Reply to ${replyQuote.authorName}…` : "Talk smack or call your shot\u2026",
            placeholderTextColor: c.subtleForeground,
            maxLength: 400,
            returnKeyType: "send",
            onSubmitEditing: handleSend
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            size: "sm",
            variant: "league",
            icon: "send",
            label: "Send",
            loading: sending,
            disabled: !text.trim(),
            onPress: handleSend
          })]
        })]
      });
      $[32] = bottomPad;
      $[33] = c;
      $[34] = closed;
      $[35] = handleSend;
      $[36] = replyQuote;
      $[37] = sendErr;
      $[38] = sending;
      $[39] = text;
      $[40] = t10;
    } else {
      t10 = $[40];
    }
    let t11;
    if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
      t11 = () => setProfileUid(null);
      $[41] = t11;
    } else {
      t11 = $[41];
    }
    let t12;
    if ($[42] !== league.id || $[43] !== profileUid) {
      t12 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PlayerProfileSheet.default, {
        uid: profileUid,
        leagueId: league.id,
        onClose: t11
      });
      $[42] = league.id;
      $[43] = profileUid;
      $[44] = t12;
    } else {
      t12 = $[44];
    }
    let t13;
    if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
      t13 = () => {
        setQuickGame(null);
        setFollow(null);
      };
      $[45] = t13;
    } else {
      t13 = $[45];
    }
    let t14;
    if ($[46] !== follow || $[47] !== league.id || $[48] !== quickGame) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(GameQuickView.default, {
        gameId: quickGame,
        onClose: t13,
        defaultWallet: league.id,
        follow: follow
      });
      $[46] = follow;
      $[47] = league.id;
      $[48] = quickGame;
      $[49] = t14;
    } else {
      t14 = $[49];
    }
    let t15;
    if ($[50] !== t10 || $[51] !== t12 || $[52] !== t14 || $[53] !== t9) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(KeyboardAvoidingView.default, {
        style: t5,
        behavior: "height",
        children: [t9, t10, t12, t14]
      });
      $[50] = t10;
      $[51] = t12;
      $[52] = t14;
      $[53] = t9;
      $[54] = t15;
    } else {
      t15 = $[54];
    }
    return t15;
  }

  // ── Info & settings ────────────────────────────────────────────────────────
  function _temp12(t0) {
    const [, v] = t0;
    return v !== undefined;
  }
  function _temp11(x, y) {
    return x.at - y.at;
  }
  function _temp10(a) {
    return {
      kind: "act",
      at: a.at,
      a
    };
  }
  function _temp1(m) {
    return {
      kind: "msg",
      at: m.at,
      m
    };
  }
  function InfoTab(t0) {
    const $ = (0, _reactCompilerRuntime.c)(178);
    const {
      league,
      betsCount,
      audit,
      uid,
      closed,
      onInvite
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const {
      updateBankSettings,
      updateLeagueSettings,
      voteEndLeague,
      endLeague,
      leaveLeague
    } = (0, _contextLeagueContext.useLeague)();
    const isCreator = league.creatorId === uid;
    let t1;
    if ($[0] !== league.prizeDistribution) {
      t1 = _constantsLeagueTypes.PRIZE_PRESETS.find(p => p.value === league.prizeDistribution.preset);
      $[0] = league.prizeDistribution;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    const preset = t1;
    const [enabled, setEnabled] = (0, _react.useState)(league.bankLoanEnabled);
    const [rate, setRate] = (0, _react.useState)(String(league.bankInterestRate));
    const [saving, setSaving] = (0, _react.useState)(false);
    const [saved, setSaved] = (0, _react.useState)(null);
    const [confirm, setConfirm] = (0, _react.useState)(null);
    const [busy, setBusy] = (0, _react.useState)(false);
    const [dlgErr, setDlgErr] = (0, _react.useState)(null);
    const [voteBusy, setVoteBusy] = (0, _react.useState)(false);
    const [editMode, setEditMode] = (0, _react.useState)(league.mode ?? "bankroll");
    const [editMatchups, setEditMatchups] = (0, _react.useState)(league.matchupsEnabled !== false);
    const [editCadence, setEditCadence] = (0, _react.useState)(league.matchupCadence ?? "weekly");
    const [stimOn, setStimOn] = (0, _react.useState)(!!league.stimulusEnabled);
    const [stimBusy, setStimBusy] = (0, _react.useState)(false);
    const [editRulesBusy, setEditRulesBusy] = (0, _react.useState)(false);
    const [editRulesMsg, setEditRulesMsg] = (0, _react.useState)(null);
    const t2 = league.pot;
    const t3 = league.prizeDistribution;
    const t4 = Math.max(3, league.memberIds.length);
    let t5;
    if ($[2] !== league.pot || $[3] !== league.prizeDistribution || $[4] !== t4) {
      t5 = (0, _libLoanMath.prizeSplit)(t2, t3, t4);
      $[2] = league.pot;
      $[3] = league.prizeDistribution;
      $[4] = t4;
      $[5] = t5;
    } else {
      t5 = $[5];
    }
    const shares = t5;
    let t6;
    if ($[6] !== league.endVotes) {
      t6 = league.endVotes ?? [];
      $[6] = league.endVotes;
      $[7] = t6;
    } else {
      t6 = $[7];
    }
    const votes = t6;
    const neededVotes = Math.floor(league.memberIds.length / 2) + 1;
    let t7;
    if ($[8] !== uid || $[9] !== votes) {
      t7 = uid && votes.includes(uid);
      $[8] = uid;
      $[9] = votes;
      $[10] = t7;
    } else {
      t7 = $[10];
    }
    const iVoted = !!t7;
    const t8 = closed ? "Closed" : "Active";
    let t9;
    if ($[11] !== t8) {
      t9 = ["Status", t8];
      $[11] = t8;
      $[12] = t9;
    } else {
      t9 = $[12];
    }
    let t10;
    if ($[13] !== league.mode) {
      t10 = _constantsLeagueTypes.LEAGUE_MODES.find(m => m.value === (league.mode ?? "bankroll"))?.label ?? "Bankroll";
      $[13] = league.mode;
      $[14] = t10;
    } else {
      t10 = $[14];
    }
    let t11;
    if ($[15] !== t10) {
      t11 = ["Format", t10];
      $[15] = t10;
      $[16] = t11;
    } else {
      t11 = $[16];
    }
    let t12;
    if ($[17] !== closed || $[18] !== league) {
      t12 = closed || (0, _constantsLeagueTypes.isLeagueStarted)(league) ? [] : [["Invite code", league.code]];
      $[17] = closed;
      $[18] = league;
      $[19] = t12;
    } else {
      t12 = $[19];
    }
    const t13 = (0, _constantsLeagueTypes.isLeagueStarted)(league) ? "Started" : "Starts";
    let t14;
    if ($[20] !== league) {
      t14 = new Date((0, _constantsLeagueTypes.leagueStartsAt)(league)).toLocaleDateString(undefined, {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit"
      });
      $[20] = league;
      $[21] = t14;
    } else {
      t14 = $[21];
    }
    let t15;
    if ($[22] !== t13 || $[23] !== t14) {
      t15 = [t13, t14];
      $[22] = t13;
      $[23] = t14;
      $[24] = t15;
    } else {
      t15 = $[24];
    }
    let t16;
    if ($[25] !== league.startingLeagueTokens) {
      t16 = league.startingLeagueTokens.toLocaleString();
      $[25] = league.startingLeagueTokens;
      $[26] = t16;
    } else {
      t16 = $[26];
    }
    let t17;
    if ($[27] !== t16) {
      t17 = ["Starting tokens", t16];
      $[27] = t16;
      $[28] = t17;
    } else {
      t17 = $[28];
    }
    let t18;
    if ($[29] !== league.buyIn) {
      t18 = league.buyIn > 0 ? `${league.buyIn.toLocaleString()} credits` : "Free";
      $[29] = league.buyIn;
      $[30] = t18;
    } else {
      t18 = $[30];
    }
    let t19;
    if ($[31] !== t18) {
      t19 = ["Buy-in", t18];
      $[31] = t18;
      $[32] = t19;
    } else {
      t19 = $[32];
    }
    let t20;
    if ($[33] !== league.pot) {
      t20 = league.pot.toLocaleString();
      $[33] = league.pot;
      $[34] = t20;
    } else {
      t20 = $[34];
    }
    const t21 = `${t20} credits`;
    let t22;
    if ($[35] !== t21) {
      t22 = ["Prize pot", t21];
      $[35] = t21;
      $[36] = t22;
    } else {
      t22 = $[36];
    }
    const t23 = preset?.label ?? "Custom";
    let t24;
    if ($[37] !== t23) {
      t24 = ["Prize split", t23];
      $[37] = t23;
      $[38] = t24;
    } else {
      t24 = $[38];
    }
    let t25;
    if ($[39] !== league.allowedSports) {
      t25 = league.allowedSports.join(", ");
      $[39] = league.allowedSports;
      $[40] = t25;
    } else {
      t25 = $[40];
    }
    let t26;
    if ($[41] !== t25) {
      t26 = ["Sports", t25];
      $[41] = t25;
      $[42] = t26;
    } else {
      t26 = $[42];
    }
    const t27 = league.duration === "Full Season" ? "Full season (follows the sports' calendars)" : league.duration ?? `${league.durationWeeks ?? "\u2013"} weeks`;
    let t28;
    if ($[43] !== t27) {
      t28 = ["Length", t27];
      $[43] = t27;
      $[44] = t28;
    } else {
      t28 = $[44];
    }
    const t29 = closed ? "Ended" : "Ends";
    let t30;
    if ($[45] !== league.endedAt || $[46] !== league.endsAt) {
      t30 = new Date(league.endedAt ?? league.endsAt).toLocaleDateString(undefined, {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit"
      });
      $[45] = league.endedAt;
      $[46] = league.endsAt;
      $[47] = t30;
    } else {
      t30 = $[47];
    }
    let t31;
    if ($[48] !== t29 || $[49] !== t30) {
      t31 = [t29, t30];
      $[48] = t29;
      $[49] = t30;
      $[50] = t31;
    } else {
      t31 = $[50];
    }
    let t32;
    if ($[51] !== league.matchupCadence || $[52] !== league.matchupsEnabled || $[53] !== league.mode) {
      t32 = league.mode === "matchups" || league.matchupsEnabled ? (0, _constantsLeagueTypes.cadenceLabel)(league.matchupCadence) : "Off";
      $[51] = league.matchupCadence;
      $[52] = league.matchupsEnabled;
      $[53] = league.mode;
      $[54] = t32;
    } else {
      t32 = $[54];
    }
    let t33;
    if ($[55] !== t32) {
      t33 = ["Matchups", t32];
      $[55] = t32;
      $[56] = t33;
    } else {
      t33 = $[56];
    }
    const t34 = league.bankLoanEnabled ? `${league.bankInterestRate}% flat` : "Closed";
    let t35;
    if ($[57] !== t34) {
      t35 = ["Bank", t34];
      $[57] = t34;
      $[58] = t35;
    } else {
      t35 = $[58];
    }
    const t36 = league.stimulusEnabled ? "On" : "Off";
    let t37;
    if ($[59] !== t36) {
      t37 = ["Stimulus votes", t36];
      $[59] = t36;
      $[60] = t37;
    } else {
      t37 = $[60];
    }
    let t38;
    if ($[61] !== t11 || $[62] !== t12 || $[63] !== t15 || $[64] !== t17 || $[65] !== t19 || $[66] !== t22 || $[67] !== t24 || $[68] !== t26 || $[69] !== t28 || $[70] !== t31 || $[71] !== t33 || $[72] !== t35 || $[73] !== t37 || $[74] !== t9) {
      t38 = [t9, t11, ...t12, t15, t17, t19, t22, t24, t26, t28, t31, t33, t35, t37];
      $[61] = t11;
      $[62] = t12;
      $[63] = t15;
      $[64] = t17;
      $[65] = t19;
      $[66] = t22;
      $[67] = t24;
      $[68] = t26;
      $[69] = t28;
      $[70] = t31;
      $[71] = t33;
      $[72] = t35;
      $[73] = t37;
      $[74] = t9;
      $[75] = t38;
    } else {
      t38 = $[75];
    }
    const rows = t38;
    let t39;
    if ($[76] === Symbol.for("react.memo_cache_sentinel")) {
      t39 = {
        gap: 12
      };
      $[76] = t39;
    } else {
      t39 = $[76];
    }
    let t40;
    if ($[77] !== c || $[78] !== closed || $[79] !== league || $[80] !== onInvite) {
      t40 = !closed && !(0, _constantsLeagueTypes.isLeagueStarted)(league) && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: styles.qrCard,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(InviteQR.default, {
          value: (0, _libInvites.inviteLink)(league.code),
          size: 168,
          accessibilityLabel: `QR code to join ${league.name}, code ${league.code}`
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: {
            flex: 1,
            gap: 6
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.cardTitle, {
              color: c.foreground
            }],
            children: "Scan to Join"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.muted, {
              color: c.mutedForeground
            }],
            children: ["Point a phone camera at this to open ", league.name, " in SportDrip", league.buyIn > 0 ? ` (${league.buyIn.toLocaleString()}-credit buy-in)` : "", "."]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.qrCode, {
              color: c.foreground
            }],
            selectable: true,
            children: league.code
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            size: "sm",
            variant: "secondary",
            icon: "share-variant",
            label: "Share Link",
            onPress: onInvite
          })]
        })]
      });
      $[77] = c;
      $[78] = closed;
      $[79] = league;
      $[80] = onInvite;
      $[81] = t40;
    } else {
      t40 = $[81];
    }
    let t41;
    if ($[82] !== league) {
      t41 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsPreseasonCard.PredictionsCard, {
        league: league
      });
      $[82] = league;
      $[83] = t41;
    } else {
      t41 = $[83];
    }
    let t42;
    if ($[84] === Symbol.for("react.memo_cache_sentinel")) {
      t42 = {
        padding: 0
      };
      $[84] = t42;
    } else {
      t42 = $[84];
    }
    let t43;
    if ($[85] !== c || $[86] !== rows) {
      t43 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Card, {
        style: t42,
        children: rows.map((t44, i) => {
          const [k, v] = t44;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.infoRow, i < rows.length - 1 && {
              borderBottomWidth: StyleSheet.default.hairlineWidth,
              borderBottomColor: c.border
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.muted, {
                color: c.mutedForeground
              }],
              children: k
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.memberName, {
                color: c.foreground,
                flexShrink: 1,
                textAlign: "right"
              }],
              children: v
            })]
          }, k);
        })
      });
      $[85] = c;
      $[86] = rows;
      $[87] = t43;
    } else {
      t43 = $[87];
    }
    let t44;
    if ($[88] !== c || $[89] !== league.pot || $[90] !== shares) {
      t44 = league.pot > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: {
          gap: 6
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.cardTitle, {
            color: c.foreground
          }],
          children: "Payouts"
        }), shares.map((s, i_0) => s > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.inline,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.muted, {
              color: c.mutedForeground,
              flex: 1
            }],
            children: [["1st", "2nd", "3rd"][i_0], " place"]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
            value: s,
            size: "sm"
          })]
        }, i_0) : null), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.memberSub, {
            color: c.subtleForeground
          }],
          children: "Paid in credits when the season ends. Tied net worths split their shared positions equally."
        })]
      });
      $[88] = c;
      $[89] = league.pot;
      $[90] = shares;
      $[91] = t44;
    } else {
      t44 = $[91];
    }
    let t45;
    if ($[92] !== betsCount || $[93] !== c || $[94] !== closed || $[95] !== editCadence || $[96] !== editMatchups || $[97] !== editMode || $[98] !== editRulesBusy || $[99] !== editRulesMsg || $[100] !== isCreator || $[101] !== league.id || $[102] !== updateLeagueSettings) {
      t45 = isCreator && !closed && betsCount === 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: {
          gap: 10
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.cardTitle, {
            color: c.foreground
          }],
          children: "Pre-season rules (before 1st bet)"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SegmentedControl, {
          value: editMode,
          onChange: setEditMode,
          options: _constantsLeagueTypes.LEAGUE_MODES.map(_temp13)
        }), editMode !== "matchups" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.inline,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.muted, {
              color: c.foreground,
              flex: 1
            }],
            children: "H2H Matchups"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Switch, {
            value: editMatchups,
            onValueChange: setEditMatchups,
            trackColor: {
              false: c.border,
              true: c.league
            }
          })]
        }) : null, editMode === "matchups" || editMatchups ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.SegmentedControl, {
          value: editCadence,
          onChange: setEditCadence,
          options: _constantsLeagueTypes.MATCHUP_CADENCES.map(_temp14)
        }) : null, editRulesMsg ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.memberSub, {
            color: editRulesMsg === "Saved" ? c.positive : c.negative
          }],
          children: editRulesMsg
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: "Save Rules",
          variant: "secondary",
          loading: editRulesBusy,
          onPress: async () => {
            setEditRulesBusy(true);
            const e = await updateLeagueSettings({
              leagueId: league.id,
              mode: editMode,
              matchupsEnabled: editMode === "matchups" || editMatchups,
              matchupCadence: editCadence
            });
            setEditRulesBusy(false);
            setEditRulesMsg(e ?? "Saved");
          }
        })]
      });
      $[92] = betsCount;
      $[93] = c;
      $[94] = closed;
      $[95] = editCadence;
      $[96] = editMatchups;
      $[97] = editMode;
      $[98] = editRulesBusy;
      $[99] = editRulesMsg;
      $[100] = isCreator;
      $[101] = league.id;
      $[102] = updateLeagueSettings;
      $[103] = t45;
    } else {
      t45 = $[103];
    }
    let t46;
    if ($[104] !== c || $[105] !== closed || $[106] !== enabled || $[107] !== isCreator || $[108] !== league.bankInterestIntervalHours || $[109] !== league.bankInterestRate || $[110] !== league.id || $[111] !== rate || $[112] !== saved || $[113] !== saving || $[114] !== updateBankSettings) {
      t46 = isCreator && !closed && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: {
          gap: 10
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.inline,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.cardTitle, {
              color: c.foreground,
              flex: 1
            }],
            children: "Bank Settings"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Switch, {
            value: enabled,
            onValueChange: setEnabled,
            trackColor: {
              false: c.border,
              true: c.league
            },
            accessibilityLabel: "Bank open"
          })]
        }), enabled && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(NumericInput.default, {
          style: [styles.field, {
            color: c.foreground,
            borderColor: c.border,
            backgroundColor: c.secondary
          }],
          value: rate,
          onChangeText: setRate,
          keyboardType: "decimal-pad",
          placeholder: "Flat rate % (0.5\u201350)",
          placeholderTextColor: c.subtleForeground,
          accessibilityLabel: "Bank rate"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.memberSub, {
            color: c.subtleForeground
          }],
          children: "Changes apply to new loans. Existing loans keep the terms they were taken at."
        }), saved ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.memberSub, {
            color: saved === "Saved" ? c.positive : c.negative
          }],
          children: saved
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: "Save Bank Settings",
          variant: "secondary",
          loading: saving,
          disabled: enabled && !(Number.parseFloat(rate) >= 0.5 && Number.parseFloat(rate) <= 50),
          onPress: async () => {
            setSaving(true);
            const e_0 = await updateBankSettings(league.id, enabled, Number.parseFloat(rate) || league.bankInterestRate, league.bankInterestIntervalHours);
            setSaving(false);
            setSaved(e_0 ?? "Saved");
          }
        })]
      });
      $[104] = c;
      $[105] = closed;
      $[106] = enabled;
      $[107] = isCreator;
      $[108] = league.bankInterestIntervalHours;
      $[109] = league.bankInterestRate;
      $[110] = league.id;
      $[111] = rate;
      $[112] = saved;
      $[113] = saving;
      $[114] = updateBankSettings;
      $[115] = t46;
    } else {
      t46 = $[115];
    }
    let t47;
    if ($[116] !== c || $[117] !== closed || $[118] !== isCreator || $[119] !== league.id || $[120] !== stimBusy || $[121] !== stimOn || $[122] !== updateLeagueSettings) {
      t47 = isCreator && !closed && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: {
          gap: 8
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.inline,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "cash-plus",
            size: 18,
            color: c.positive
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.cardTitle, {
              color: c.foreground,
              flex: 1
            }],
            children: "Stimulus Votes"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Switch, {
            value: stimOn,
            disabled: stimBusy,
            accessibilityLabel: "Stimulus votes",
            trackColor: {
              false: c.border,
              true: c.positive
            },
            onValueChange: async v_0 => {
              setStimOn(v_0);
              setStimBusy(true);
              const e_1 = await updateLeagueSettings({
                leagueId: league.id,
                stimulusEnabled: v_0
              });
              setStimBusy(false);
              if (e_1) {
                setStimOn(!v_0);
              }
            }
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.memberSub, {
            color: c.subtleForeground
          }],
          children: "Lets any member ask the bank to give everyone 10\u201350% of the starting stack. A majority yes pays all members the same amount (at most once a week). You can switch this on or off any time."
        })]
      });
      $[116] = c;
      $[117] = closed;
      $[118] = isCreator;
      $[119] = league.id;
      $[120] = stimBusy;
      $[121] = stimOn;
      $[122] = updateLeagueSettings;
      $[123] = t47;
    } else {
      t47 = $[123];
    }
    let t48;
    if ($[124] !== c || $[125] !== closed || $[126] !== iVoted || $[127] !== league.id || $[128] !== league.memberIds.length || $[129] !== neededVotes || $[130] !== voteBusy || $[131] !== voteEndLeague || $[132] !== votes) {
      t48 = !closed && league.memberIds.length >= 2 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: {
          gap: 8
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.inline,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "vote-outline",
            size: 18,
            color: c.league
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.cardTitle, {
              color: c.foreground,
              flex: 1
            }],
            children: "Early-end majority vote"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
            label: `${votes.length}/${neededVotes} votes`,
            tone: "league"
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.muted, {
            color: c.mutedForeground
          }],
          children: ["Ending a multi-member league early requires a majority vote (", neededVotes, " of ", league.memberIds.length, " members) so no single person can freeze standings mid-slate."]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: iVoted ? "Withdraw my vote to end" : "Vote to end season now",
          variant: iVoted ? "secondary" : "league",
          loading: voteBusy,
          onPress: async () => {
            setVoteBusy(true);
            await voteEndLeague(league.id, !iVoted);
            setVoteBusy(false);
          }
        })]
      });
      $[124] = c;
      $[125] = closed;
      $[126] = iVoted;
      $[127] = league.id;
      $[128] = league.memberIds.length;
      $[129] = neededVotes;
      $[130] = voteBusy;
      $[131] = voteEndLeague;
      $[132] = votes;
      $[133] = t48;
    } else {
      t48 = $[133];
    }
    let t49;
    if ($[134] !== audit || $[135] !== c) {
      t49 = audit.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: {
          gap: 8
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.inline,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "shield-check-outline",
            size: 18,
            color: c.mutedForeground
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.cardTitle, {
              color: c.foreground,
              flex: 1
            }],
            children: "Commissioner Audit Log"
          })]
        }), audit.map(a => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.inline,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.memberSub, {
              color: c.foreground,
              flex: 1
            }],
            children: [a.name, ": ", a.action, a.reason ? ` (${a.reason})` : ""]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.feedTime, {
              color: c.subtleForeground
            }],
            children: new Date(a.at).toLocaleDateString(undefined, {
              month: "short",
              day: "numeric"
            })
          })]
        }, a.id))]
      });
      $[134] = audit;
      $[135] = c;
      $[136] = t49;
    } else {
      t49 = $[136];
    }
    let t50;
    if ($[137] !== closed || $[138] !== isCreator || $[139] !== league.memberIds.length) {
      t50 = !closed && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: {
          gap: 8
        },
        children: [isCreator && league.memberIds.length < 2 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: "End season now & pay out",
          icon: "flag-checkered",
          variant: "secondary",
          onPress: () => {
            setDlgErr(null);
            setConfirm("end");
          }
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: "Leave League",
          icon: "exit-to-app",
          variant: "destructive",
          onPress: () => {
            setDlgErr(null);
            setConfirm("leave");
          }
        })]
      });
      $[137] = closed;
      $[138] = isCreator;
      $[139] = league.memberIds.length;
      $[140] = t50;
    } else {
      t50 = $[140];
    }
    const t51 = !closed && confirm === "end";
    let t52;
    if ($[141] !== league.pot) {
      t52 = league.pot.toLocaleString();
      $[141] = league.pot;
      $[142] = t52;
    } else {
      t52 = $[142];
    }
    const t53 = `Standings lock at current net worth. Open league bets are voided and refunded, and the ${t52}-credit pot pays out immediately. This can't be undone.`;
    let t54;
    if ($[143] === Symbol.for("react.memo_cache_sentinel")) {
      t54 = () => setConfirm(null);
      $[143] = t54;
    } else {
      t54 = $[143];
    }
    let t55;
    if ($[144] !== endLeague || $[145] !== league.id) {
      t55 = async () => {
        setBusy(true);
        const e_2 = await endLeague(league.id);
        setBusy(false);
        if (e_2) {
          setDlgErr(e_2);
        } else {
          setConfirm(null);
        }
      };
      $[144] = endLeague;
      $[145] = league.id;
      $[146] = t55;
    } else {
      t55 = $[146];
    }
    let t56;
    if ($[147] !== busy || $[148] !== dlgErr || $[149] !== t51 || $[150] !== t53 || $[151] !== t55) {
      t56 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ConfirmDialog, {
        visible: t51,
        title: "End the season now?",
        body: t53,
        confirmLabel: "End & pay out",
        busy: busy,
        error: dlgErr,
        onCancel: t54,
        onConfirm: t55
      });
      $[147] = busy;
      $[148] = dlgErr;
      $[149] = t51;
      $[150] = t53;
      $[151] = t55;
      $[152] = t56;
    } else {
      t56 = $[152];
    }
    const t57 = !closed && confirm === "leave";
    let t58;
    if ($[153] !== league.buyIn) {
      t58 = league.buyIn > 0 ? ` Your ${league.buyIn.toLocaleString()}-credit buy-in stays in the pot.` : "";
      $[153] = league.buyIn;
      $[154] = t58;
    } else {
      t58 = $[154];
    }
    const t59 = `You'll drop out of the standings and can't rejoin.${t58} You have to settle any loans and wait for open bets first.`;
    let t60;
    if ($[155] === Symbol.for("react.memo_cache_sentinel")) {
      t60 = () => setConfirm(null);
      $[155] = t60;
    } else {
      t60 = $[155];
    }
    let t61;
    if ($[156] !== league.id || $[157] !== leaveLeague) {
      t61 = async () => {
        setBusy(true);
        const e_3 = await leaveLeague(league.id);
        setBusy(false);
        if (e_3) {
          setDlgErr(e_3);
        } else {
          setConfirm(null);
          _expoRouter.router.navigate("/(tabs)/leagues");
        }
      };
      $[156] = league.id;
      $[157] = leaveLeague;
      $[158] = t61;
    } else {
      t61 = $[158];
    }
    let t62;
    if ($[159] !== busy || $[160] !== dlgErr || $[161] !== t57 || $[162] !== t59 || $[163] !== t61) {
      t62 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ConfirmDialog, {
        visible: t57,
        title: "Leave this league?",
        body: t59,
        confirmLabel: "Leave",
        destructive: true,
        busy: busy,
        error: dlgErr,
        onCancel: t60,
        onConfirm: t61
      });
      $[159] = busy;
      $[160] = dlgErr;
      $[161] = t57;
      $[162] = t59;
      $[163] = t61;
      $[164] = t62;
    } else {
      t62 = $[164];
    }
    let t63;
    if ($[165] !== t40 || $[166] !== t41 || $[167] !== t43 || $[168] !== t44 || $[169] !== t45 || $[170] !== t46 || $[171] !== t47 || $[172] !== t48 || $[173] !== t49 || $[174] !== t50 || $[175] !== t56 || $[176] !== t62) {
      t63 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t39,
        children: [t40, t41, t43, t44, t45, t46, t47, t48, t49, t50, t56, t62]
      });
      $[165] = t40;
      $[166] = t41;
      $[167] = t43;
      $[168] = t44;
      $[169] = t45;
      $[170] = t46;
      $[171] = t47;
      $[172] = t48;
      $[173] = t49;
      $[174] = t50;
      $[175] = t56;
      $[176] = t62;
      $[177] = t63;
    } else {
      t63 = $[177];
    }
    return t63;
  }
  function _temp14(m_1) {
    return {
      value: m_1.value,
      label: m_1.label
    };
  }
  function _temp13(m_0) {
    return {
      value: m_0.value,
      label: m_0.label
    };
  }
  const styles = StyleSheet.default.create({
    container: {
      flex: 1
    },
    body: {
      padding: 16,
      gap: 12
    },
    switch: {
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderRadius: 999,
      borderWidth: 1,
      maxWidth: 170
    },
    switchText: {
      fontSize: 12,
      fontFamily: "Inter_600SemiBold"
    },
    hero: {
      flexDirection: "row",
      gap: 8
    },
    heroRank: {
      fontSize: 18,
      fontFamily: "Inter_700Bold",
      fontVariant: ["tabular-nums"]
    },
    heroOf: {
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    },
    cardTitle: {
      fontSize: 15,
      fontFamily: "Inter_700Bold"
    },
    muted: {
      fontSize: 13,
      lineHeight: 19,
      fontFamily: "Inter_400Regular"
    },
    inline: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      flexWrap: "wrap"
    },
    member: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      padding: 10,
      borderRadius: 14,
      borderWidth: 1
    },
    rankNum: {
      width: 22,
      textAlign: "center",
      fontSize: 16,
      fontFamily: "Inter_700Bold",
      fontVariant: ["tabular-nums"]
    },
    memberName: {
      fontSize: 14,
      fontFamily: "Inter_600SemiBold"
    },
    memberSub: {
      fontSize: 12,
      fontFamily: "Inter_400Regular"
    },
    betRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      padding: 12,
      borderRadius: 12,
      borderWidth: 1,
      borderLeftWidth: 4
    },
    betTop: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10
    },
    followRow: {
      flexDirection: "row",
      gap: 8,
      flexWrap: "wrap"
    },
    followBtn: {
      flexDirection: "row",
      alignItems: "center",
      gap: 5,
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 999,
      borderWidth: 1
    },
    followText: {
      fontSize: 12,
      fontFamily: "Inter_700Bold"
    },
    reactionRow: {
      flexDirection: "row",
      gap: 5,
      flexWrap: "wrap"
    },
    reactionChip: {
      flexDirection: "row",
      alignItems: "center",
      gap: 3,
      paddingHorizontal: 7,
      paddingVertical: 3,
      borderRadius: 999,
      borderWidth: 1
    },
    reactionCount: {
      fontSize: 11,
      fontFamily: "Inter_700Bold"
    },
    miniAction: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
      paddingHorizontal: 8,
      paddingVertical: 3,
      borderRadius: 999,
      borderWidth: 1
    },
    miniActionText: {
      fontSize: 11,
      fontFamily: "Inter_600SemiBold"
    },
    parlayBox: {
      borderRadius: 12,
      borderWidth: 1,
      padding: 10,
      gap: 6
    },
    qrCard: {
      flexDirection: "row",
      alignItems: "center",
      gap: 14,
      flexWrap: "wrap"
    },
    qrCode: {
      fontSize: 20,
      fontFamily: "Inter_800ExtraBold",
      letterSpacing: 4
    },
    feedRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      paddingHorizontal: 14,
      paddingVertical: 11
    },
    feedText: {
      flex: 1,
      fontSize: 13,
      lineHeight: 18,
      fontFamily: "Inter_400Regular"
    },
    feedTime: {
      fontSize: 11,
      fontFamily: "Inter_500Medium"
    },
    input: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      borderWidth: 1,
      borderRadius: 12,
      paddingHorizontal: 12,
      paddingVertical: 10
    },
    inputText: {
      flex: 1,
      fontSize: 18,
      fontFamily: "Inter_700Bold",
      fontVariant: ["tabular-nums"]
    },
    field: {
      borderWidth: 1,
      borderRadius: 12,
      paddingHorizontal: 12,
      paddingVertical: 10,
      fontSize: 15,
      fontFamily: "Inter_500Medium"
    },
    infoRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 12,
      paddingHorizontal: 14,
      paddingVertical: 12
    },
    closedBanner: {
      flexDirection: "row",
      alignItems: "flex-start",
      gap: 10
    },
    champ: {
      borderWidth: 1.5,
      borderRadius: 22,
      padding: 16,
      gap: 14,
      overflow: "hidden",
      shadowOpacity: 0.28,
      shadowRadius: 18,
      shadowOffset: {
        width: 0,
        height: 8
      },
      elevation: 6
    },
    champTop: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    champBadge: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
      paddingHorizontal: 9,
      paddingVertical: 4,
      borderRadius: 999
    },
    champBadgeText: {
      fontSize: 11,
      fontFamily: "Inter_800ExtraBold",
      letterSpacing: 0.8,
      color: "#2A1E00"
    },
    champMain: {
      flexDirection: "row",
      alignItems: "center",
      gap: 14
    },
    champName: {
      fontSize: 22,
      fontFamily: "Inter_900Black",
      letterSpacing: -0.4,
      flexShrink: 1
    },
    champStats: {
      flexDirection: "row",
      alignItems: "flex-end",
      gap: 12,
      borderTopWidth: StyleSheet.default.hairlineWidth,
      paddingTop: 12
    },
    champK: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.6,
      marginBottom: 2
    },
    champV: {
      fontSize: 18,
      fontFamily: "Inter_800ExtraBold",
      fontVariant: ["tabular-nums"]
    },
    dock: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: 0,
      paddingHorizontal: 16,
      paddingTop: 10,
      borderTopWidth: StyleSheet.default.hairlineWidth
    }
  });
},766,[815,818,1223,1257,820,871,817,12,237,104,133,226,28,188,255,109,827,890,1258,1259,1260,1224,914,1225,872,1261,832,1262,1226,1227,1263,851,833,822,836,863,855,837,859,858,838,819,846,860,1222,1228,897,1193,915,864,870,816,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return PreseasonCard;
    }
  });
  exports.usePredictions = usePredictions;
  exports.PredictionsCard = PredictionsCard;
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _firebaseFirestore = require(_dependencyMap[2]);
  var _react = require(_dependencyMap[3]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsTextInput = require(_dependencyMap[6]);
  var TextInput = _interopDefault(_reactNativeWebDistExportsTextInput);
  var _reactNativeWebDistExportsView = require(_dependencyMap[7]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsUi = require(_dependencyMap[8]);
  var _constantsLeagueTypes = require(_dependencyMap[9]);
  var _hooksUseColors = require(_dependencyMap[10]);
  var _hooksUseNow = require(_dependencyMap[11]);
  var _libDemo = require(_dependencyMap[12]);
  var _libFirebase = require(_dependencyMap[13]);
  var _libMotion = require(_dependencyMap[14]);
  var _reactJsxRuntime = require(_dependencyMap[15]);
  /** Members' Bold Predictions (leagues/{id}/predictions). */
  function usePredictions(leagueId) {
    const $ = (0, _reactCompilerRuntime.c)(4);
    let t0;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t0 = [];
      $[0] = t0;
    } else {
      t0 = $[0];
    }
    const [list, setList] = (0, _react.useState)(t0);
    let t1;
    let t2;
    if ($[1] !== leagueId) {
      t1 = () => {
        if (_libDemo.DEMO || !leagueId) {
          return;
        }
        const db = (0, _libFirebase.getDb)();
        if (!db) {
          return;
        }
        return (0, _firebaseFirestore.onSnapshot)((0, _firebaseFirestore.collection)(db, "leagues", leagueId, "predictions"), s => setList(s.docs.map(_temp).sort(_temp2)), _temp3);
      };
      t2 = [leagueId];
      $[1] = leagueId;
      $[2] = t1;
      $[3] = t2;
    } else {
      t1 = $[2];
      t2 = $[3];
    }
    (0, _react.useEffect)(t1, t2);
    return list;
  }

  /** The squad goal shown before kickoff: more people make a better table. */
  function _temp3() {}
  function _temp2(a, b) {
    return a.at - b.at;
  }
  function _temp(d) {
    return d.data();
  }
  const SQUAD_GOAL = 4;
  function countdown(ms) {
    const m = Math.max(0, Math.floor(ms / 60_000));
    const d = Math.floor(m / 1440);
    const h = Math.floor(m % 1440 / 60);
    return d > 0 ? `${d}d ${h}h ${m % 60}m` : h > 0 ? `${h}h ${m % 60}m` : `${m}m`;
  }

  /**
   * Pre-season: a live countdown to kickoff, a squad goal with the invite
   * button, and Bold Predictions everyone posts before it starts.
   */
  function PreseasonCard({
    league,
    uid,
    onInvite
  }) {
    const c = (0, _hooksUseColors.useColors)();
    const now = (0, _hooksUseNow.useNow)(30_000);
    const start = (0, _constantsLeagueTypes.leagueStartsAt)(league);
    const predictions = usePredictions(league.id);
    const mine = predictions.find(p => p.uid === uid);
    const [draft, setDraft] = (0, _react.useState)("");
    const [editing, setEditing] = (0, _react.useState)(false);
    const [saving, setSaving] = (0, _react.useState)(false);
    const [err, setErr] = (0, _react.useState)(null);
    if ((0, _constantsLeagueTypes.isLeagueStarted)(league, now)) return null;
    const members = league.memberIds.length;
    const need = Math.max(0, SQUAD_GOAL - members);
    const myName = uid ? league.members?.[uid]?.displayName : undefined;
    const save = async () => {
      const text = draft.trim();
      if (!text || !uid || !myName) return;
      const db = (0, _libFirebase.getDb)();
      if (!db) return;
      setSaving(true);
      setErr(null);
      try {
        await (0, _firebaseFirestore.setDoc)((0, _firebaseFirestore.doc)(db, "leagues", league.id, "predictions", uid), {
          uid,
          name: myName,
          text,
          at: Date.now()
        });
        _libMotion.haptic.success();
        setEditing(false);
        setDraft("");
      } catch {
        setErr("Couldn't save. Predictions lock when the league starts.");
      } finally {
        setSaving(false);
      }
    };
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
      tone: "league",
      style: {
        gap: 12
      },
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.row,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "timer-outline",
          size: 18,
          color: c.league
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.kicker, {
            color: c.league
          }],
          children: "PRE-SEASON"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.clock, {
            color: c.foreground
          }],
          children: countdown(start - now)
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.sub, {
          color: c.mutedForeground
        }],
        children: ["Kicks off ", new Date(start).toLocaleString(undefined, {
          weekday: "short",
          month: "short",
          day: "numeric",
          hour: "numeric",
          minute: "2-digit"
        }), ". The roster locks then \u2014 get everyone in now."]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: {
          gap: 6
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.row,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.label, {
              color: c.foreground,
              flex: 1
            }],
            children: [members, " in", need > 0 ? ` · ${need} more for a full table` : " · full table"]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            size: "sm",
            variant: "league",
            icon: "account-plus-outline",
            label: "Invite",
            onPress: onInvite
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [styles.track, {
            backgroundColor: c.alpha(c.league, 0.18)
          }],
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [styles.fill, {
              width: `${Math.min(1, members / SQUAD_GOAL) * 100}%`,
              backgroundColor: c.league
            }]
          })
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [styles.divider, {
          backgroundColor: c.border
        }]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.row,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "crystal-ball",
          size: 18,
          color: c.accent
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.label, {
            color: c.foreground,
            flex: 1
          }],
          children: "Bold Predictions"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.sub, {
            color: c.mutedForeground
          }],
          children: [predictions.length, "/", members]
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.sub, {
          color: c.mutedForeground
        }],
        children: "Call your shot before kickoff. They lock at the start and stay on the league page all season."
      }), predictions.map(p_0 => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.pred, {
          backgroundColor: c.secondary,
          borderColor: c.border
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.predName, {
            color: p_0.uid === uid ? c.accent : c.foreground
          }],
          children: p_0.uid === uid ? "You" : p_0.name
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.predText, {
            color: c.foreground
          }],
          children: ["\u201C", p_0.text, "\u201D"]
        })]
      }, p_0.uid)), uid && (!mine || editing) ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: {
          gap: 8
        },
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(TextInput.default, {
          value: draft,
          onChangeText: setDraft,
          placeholder: mine ? mine.text : "e.g. I finish first and Jake goes bankrupt by week 3",
          placeholderTextColor: c.subtleForeground,
          maxLength: 140,
          multiline: true,
          style: [styles.input, {
            color: c.foreground,
            backgroundColor: c.background,
            borderColor: c.border
          }]
        }), err ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.sub, {
            color: c.negative
          }],
          children: err
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          size: "sm",
          label: mine ? "Update Prediction" : "Lock In Prediction",
          icon: "crystal-ball",
          onPress: () => void save(),
          loading: saving,
          disabled: !draft.trim()
        })]
      }) : uid ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        size: "sm",
        variant: "ghost",
        label: "Edit My Prediction",
        icon: "pencil-outline",
        onPress: () => {
          setDraft(mine?.text ?? "");
          setEditing(true);
        }
      }) : null]
    });
  }

  /** After kickoff: the predictions, read-only (shown on the league's Info tab). */
  function PredictionsCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(23);
    const {
      league
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const predictions = usePredictions(league.id);
    if (!predictions.length || !(0, _constantsLeagueTypes.isLeagueStarted)(league)) {
      return null;
    }
    let t1;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = {
        gap: 8
      };
      $[0] = t1;
    } else {
      t1 = $[0];
    }
    let t2;
    if ($[1] !== c.accent) {
      t2 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "crystal-ball",
        size: 18,
        color: c.accent
      });
      $[1] = c.accent;
      $[2] = t2;
    } else {
      t2 = $[2];
    }
    let t3;
    if ($[3] !== c.foreground) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.label, {
          color: c.foreground,
          flex: 1
        }],
        children: "Bold Predictions"
      });
      $[3] = c.foreground;
      $[4] = t3;
    } else {
      t3 = $[4];
    }
    let t4;
    if ($[5] !== c.mutedForeground) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "lock-outline",
        size: 14,
        color: c.mutedForeground
      });
      $[5] = c.mutedForeground;
      $[6] = t4;
    } else {
      t4 = $[6];
    }
    let t5;
    if ($[7] !== t2 || $[8] !== t3 || $[9] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.row,
        children: [t2, t3, t4]
      });
      $[7] = t2;
      $[8] = t3;
      $[9] = t4;
      $[10] = t5;
    } else {
      t5 = $[10];
    }
    let t6;
    if ($[11] !== c.border || $[12] !== c.foreground || $[13] !== c.secondary || $[14] !== predictions) {
      let t7;
      if ($[16] !== c.border || $[17] !== c.foreground || $[18] !== c.secondary) {
        t7 = p => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.pred, {
            backgroundColor: c.secondary,
            borderColor: c.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.predName, {
              color: c.foreground
            }],
            children: p.name
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.predText, {
              color: c.foreground
            }],
            children: ["\u201C", p.text, "\u201D"]
          })]
        }, p.uid);
        $[16] = c.border;
        $[17] = c.foreground;
        $[18] = c.secondary;
        $[19] = t7;
      } else {
        t7 = $[19];
      }
      t6 = predictions.map(t7);
      $[11] = c.border;
      $[12] = c.foreground;
      $[13] = c.secondary;
      $[14] = predictions;
      $[15] = t6;
    } else {
      t6 = $[15];
    }
    let t7;
    if ($[20] !== t5 || $[21] !== t6) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: t1,
        children: [t5, t6]
      });
      $[20] = t5;
      $[21] = t6;
      $[22] = t7;
    } else {
      t7 = $[22];
    }
    return t7;
  }
  const styles = StyleSheet.default.create({
    row: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    kicker: {
      flex: 1,
      fontSize: 11,
      letterSpacing: 1.4,
      fontFamily: "Inter_900Black"
    },
    clock: {
      fontSize: 18,
      fontFamily: "Inter_900Black",
      fontVariant: ["tabular-nums"]
    },
    sub: {
      fontSize: 12,
      fontFamily: "Inter_500Medium",
      lineHeight: 17
    },
    label: {
      fontSize: 14,
      fontFamily: "Inter_700Bold"
    },
    track: {
      height: 8,
      borderRadius: 4,
      overflow: "hidden"
    },
    fill: {
      height: 8,
      borderRadius: 4
    },
    divider: {
      height: StyleSheet.default.hairlineWidth
    },
    pred: {
      borderRadius: 12,
      borderWidth: 1,
      padding: 10,
      gap: 2
    },
    predName: {
      fontSize: 11,
      letterSpacing: 0.4,
      fontFamily: "Inter_800ExtraBold"
    },
    predText: {
      fontSize: 13,
      fontFamily: "Inter_500Medium"
    },
    input: {
      borderWidth: 1,
      borderRadius: 12,
      padding: 10,
      minHeight: 60,
      fontSize: 14,
      fontFamily: "Inter_500Medium",
      textAlignVertical: "top"
    }
  });
},1223,[815,818,905,12,28,188,255,109,836,855,819,844,902,906,820,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.KeyboardAwareScrollViewCompat = KeyboardAwareScrollViewCompat;
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _reactNativeKeyboardController = require(_dependencyMap[1]);
  require(_dependencyMap[2]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[3]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactJsxRuntime = require(_dependencyMap[4]);
  function KeyboardAwareScrollViewCompat(t0) {
    const $ = (0, _reactCompilerRuntime.c)(12);
    let children;
    let props;
    let t1;
    if ($[0] !== t0) {
      ({
        children,
        keyboardShouldPersistTaps: t1,
        ...props
      } = t0);
      $[0] = t0;
      $[1] = children;
      $[2] = props;
      $[3] = t1;
    } else {
      children = $[1];
      props = $[2];
      t1 = $[3];
    }
    const keyboardShouldPersistTaps = t1 === undefined ? "handled" : t1;
    {
      let t2;
      if ($[4] !== children || $[5] !== keyboardShouldPersistTaps || $[6] !== props) {
        t2 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ScrollView.default, {
          keyboardShouldPersistTaps: keyboardShouldPersistTaps,
          ...props,
          children: children
        });
        $[4] = children;
        $[5] = keyboardShouldPersistTaps;
        $[6] = props;
        $[7] = t2;
      } else {
        t2 = $[7];
      }
      return t2;
    }
    let t2;
    if ($[8] !== children || $[9] !== keyboardShouldPersistTaps || $[10] !== props) {
      t2 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_reactNativeKeyboardController.KeyboardAwareScrollView, {
        keyboardShouldPersistTaps: keyboardShouldPersistTaps,
        ...props,
        children: children
      });
      $[8] = children;
      $[9] = keyboardShouldPersistTaps;
      $[10] = props;
      $[11] = t2;
    } else {
      t2 = $[11];
    }
    return t2;
  }
},1224,[815,1189,104,133,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return LoanCard;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[3]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[4]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[5]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsNumericInput = require(_dependencyMap[6]);
  var NumericInput = _interopDefault(_componentsNumericInput);
  var _componentsUi = require(_dependencyMap[7]);
  var _hooksUseColors = require(_dependencyMap[8]);
  var _libLoanMath = require(_dependencyMap[9]);
  var _reactJsxRuntime = require(_dependencyMap[10]);
  /**
   * One loan, fully itemised: original principal, what's been repaid, interest
   * charged and paid, and the total owed now — one flat fee, all computed
   * by the same loanMath the server settles with. The repay form previews the
   * split (interest first, then principal) before anything is sent.
   */
  function LoanCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(94);
    const {
      loan,
      now,
      viewer,
      tokens,
      onRepay
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const snap = (0, _libLoanMath.loanSnapshot)(loan, now);
    const [open, setOpen] = (0, _react.useState)(false);
    const [amount, setAmount] = (0, _react.useState)("");
    const [busy, setBusy] = (0, _react.useState)(false);
    const [err, setErr] = (0, _react.useState)(null);
    let t1;
    if ($[0] !== amount) {
      t1 = Number.parseInt(amount, 10) || 0;
      $[0] = amount;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    const pay = Math.min(t1, tokens);
    let t2;
    if ($[2] !== loan || $[3] !== now || $[4] !== pay) {
      t2 = pay > 0 ? (0, _libLoanMath.applyRepayment)(loan, pay, now) : null;
      $[2] = loan;
      $[3] = now;
      $[4] = pay;
      $[5] = t2;
    } else {
      t2 = $[5];
    }
    const preview = t2;
    const repaid = loan.status === "repaid";
    const counterparty = loan.kind === "bank" ? "League Bank" : viewer === "lender" ? loan.borrowerName : loan.lenderName ?? "\u2014";
    let t3;
    if ($[6] !== onRepay || $[7] !== pay || $[8] !== setAmount || $[9] !== setOpen) {
      t3 = async function submit() {
        if (!onRepay || pay <= 0) {
          return;
        }
        setBusy(true);
        setErr(null);
        const e = await onRepay(pay);
        setBusy(false);
        if (e) {
          setErr(e);
        } else {
          setAmount("");
          setOpen(false);
        }
      };
      $[6] = onRepay;
      $[7] = pay;
      $[8] = setAmount;
      $[9] = setOpen;
      $[10] = t3;
    } else {
      t3 = $[10];
    }
    const submit = t3;
    const t4 = viewer === "lender" ? c.leagueSoft : c.debtSoft;
    let t5;
    if ($[11] !== t4) {
      t5 = [styles.icon, {
        backgroundColor: t4
      }];
      $[11] = t4;
      $[12] = t5;
    } else {
      t5 = $[12];
    }
    const t6 = loan.kind === "bank" ? "bank-outline" : "handshake-outline";
    const t7 = viewer === "lender" ? c.league : c.debt;
    let t8;
    if ($[13] !== t6 || $[14] !== t7) {
      t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: t6,
        size: 18,
        color: t7
      });
      $[13] = t6;
      $[14] = t7;
      $[15] = t8;
    } else {
      t8 = $[15];
    }
    let t9;
    if ($[16] !== t5 || $[17] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t5,
        children: t8
      });
      $[16] = t5;
      $[17] = t8;
      $[18] = t9;
    } else {
      t9 = $[18];
    }
    let t10;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
      t10 = {
        flex: 1
      };
      $[19] = t10;
    } else {
      t10 = $[19];
    }
    let t11;
    if ($[20] !== c.foreground) {
      t11 = [styles.title, {
        color: c.foreground
      }];
      $[20] = c.foreground;
      $[21] = t11;
    } else {
      t11 = $[21];
    }
    const t12 = viewer === "lender" ? `${loan.borrowerName} owes you` : `From ${counterparty}`;
    let t13;
    if ($[22] !== t11 || $[23] !== t12) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t11,
        numberOfLines: 1,
        children: t12
      });
      $[22] = t11;
      $[23] = t12;
      $[24] = t13;
    } else {
      t13 = $[24];
    }
    let t14;
    if ($[25] !== c.mutedForeground) {
      t14 = [styles.sub, {
        color: c.mutedForeground
      }];
      $[25] = c.mutedForeground;
      $[26] = t14;
    } else {
      t14 = $[26];
    }
    let t15;
    if ($[27] !== repaid) {
      t15 = repaid ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
        label: "Paid Off",
        tone: "positive",
        icon: "check"
      }) : null;
      $[27] = repaid;
      $[28] = t15;
    } else {
      t15 = $[28];
    }
    let t16;
    if ($[29] !== c.subtleForeground) {
      t16 = [styles.k, {
        color: c.subtleForeground
      }];
      $[29] = c.subtleForeground;
      $[30] = t16;
    } else {
      t16 = $[30];
    }
    const t17 = repaid ? "SETTLED" : viewer === "lender" ? "OWED TO YOU" : "TOTAL OWED";
    let t18;
    if ($[31] !== t16 || $[32] !== t17) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t16,
        children: t17
      });
      $[31] = t16;
      $[32] = t17;
      $[33] = t18;
    } else {
      t18 = $[33];
    }
    const T0 = View.default;
    let t19;
    if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
      t19 = {
        alignItems: "flex-end"
      };
      $[34] = t19;
    } else {
      t19 = $[34];
    }
    let t20;
    if ($[35] !== c.subtleForeground) {
      t20 = [styles.k, {
        color: c.subtleForeground
      }];
      $[35] = c.subtleForeground;
      $[36] = t20;
    } else {
      t20 = $[36];
    }
    const t21 = viewer === "lender" ? "RECEIVED" : "REPAID";
    let t22;
    if ($[37] !== t20 || $[38] !== t21) {
      t22 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t20,
        children: t21
      });
      $[37] = t20;
      $[38] = t21;
      $[39] = t22;
    } else {
      t22 = $[39];
    }
    const T1 = Text.default;
    let t23;
    if ($[40] !== c.foreground) {
      t23 = [styles.v, {
        color: c.foreground
      }];
      $[40] = c.foreground;
      $[41] = t23;
    } else {
      t23 = $[41];
    }
    const t24 = snap.totalRepaid.toLocaleString();
    const t25 = " / ";
    const t26 = snap.totalRepayable.toLocaleString();
    let t27;
    if ($[42] !== T1 || $[43] !== t23 || $[44] !== t24 || $[45] !== t26) {
      t27 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T1, {
        style: t23,
        children: [t24, t25, t26]
      });
      $[42] = T1;
      $[43] = t23;
      $[44] = t24;
      $[45] = t26;
      $[46] = t27;
    } else {
      t27 = $[46];
    }
    let t28;
    if ($[47] !== T0 || $[48] !== t19 || $[49] !== t22 || $[50] !== t27) {
      t28 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T0, {
        style: t19,
        children: [t22, t27]
      });
      $[47] = T0;
      $[48] = t19;
      $[49] = t22;
      $[50] = t27;
      $[51] = t28;
    } else {
      t28 = $[51];
    }
    let t29;
    if ($[52] !== c.border) {
      t29 = [styles.grid, {
        borderTopColor: c.border
      }];
      $[52] = c.border;
      $[53] = t29;
    } else {
      t29 = $[53];
    }
    let t30;
    if ($[54] !== snap.principal) {
      t30 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Cell, {
        label: "Original Principal",
        value: snap.principal
      });
      $[54] = snap.principal;
      $[55] = t30;
    } else {
      t30 = $[55];
    }
    let t31;
    if ($[56] !== snap.principalOutstanding) {
      t31 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Cell, {
        label: "Principal Left",
        value: snap.principalOutstanding
      });
      $[56] = snap.principalOutstanding;
      $[57] = t31;
    } else {
      t31 = $[57];
    }
    const t32 = `Interest (${loan.ratePct}%)`;
    let t33;
    if ($[58] !== snap.interestCharged || $[59] !== t32) {
      t33 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Cell, {
        label: t32,
        value: snap.interestCharged
      });
      $[58] = snap.interestCharged;
      $[59] = t32;
      $[60] = t33;
    } else {
      t33 = $[60];
    }
    let t34;
    if ($[61] !== snap.interestPaid) {
      t34 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Cell, {
        label: "Interest Paid",
        value: snap.interestPaid
      });
      $[61] = snap.interestPaid;
      $[62] = t34;
    } else {
      t34 = $[62];
    }
    let t35;
    if ($[63] !== t29 || $[64] !== t30 || $[65] !== t31 || $[66] !== t33 || $[67] !== t34) {
      t35 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t29,
        children: [t30, t31, t33, t34]
      });
      $[63] = t29;
      $[64] = t30;
      $[65] = t31;
      $[66] = t33;
      $[67] = t34;
      $[68] = t35;
    } else {
      t35 = $[68];
    }
    let t36;
    if ($[69] !== amount || $[70] !== busy || $[71] !== c.border || $[72] !== c.foreground || $[73] !== c.league || $[74] !== c.mutedForeground || $[75] !== c.negative || $[76] !== c.secondary || $[77] !== c.subtleForeground || $[78] !== c.warning || $[79] !== err || $[80] !== now || $[81] !== onRepay || $[82] !== open || $[83] !== pay || $[84] !== preview || $[85] !== repaid || $[86] !== setAmount || $[87] !== setOpen || $[88] !== snap.interestOutstanding || $[89] !== snap.totalOwed || $[90] !== submit || $[91] !== tokens || $[92] !== viewer) {
      t36 = viewer === "borrower" && !repaid && onRepay && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_reactJsxRuntime.Fragment, {
        children: !open ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: "Repay",
          icon: "cash-refund",
          variant: "secondary",
          onPress: () => setOpen(true)
        }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: {
            gap: 8
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.input, {
              borderColor: c.border,
              backgroundColor: c.secondary
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "shield-star",
              size: 18,
              color: c.league
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(NumericInput.default, {
              style: [styles.inputText, {
                color: c.foreground
              }],
              value: amount,
              onChangeText: t => setAmount(t.replace(/[^0-9]/g, "")),
              keyboardType: "number-pad",
              placeholder: `Up to ${Math.min(snap.totalOwed, tokens).toLocaleString()}`,
              placeholderTextColor: c.subtleForeground,
              accessibilityLabel: "Repayment amount",
              autoFocus: true
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.quick,
            children: [snap.interestOutstanding > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              size: "sm",
              variant: "secondary",
              label: "Interest Only",
              onPress: () => setAmount(String(Math.min(snap.interestOutstanding, tokens)))
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              size: "sm",
              variant: "secondary",
              label: "Pay It Off",
              onPress: () => setAmount(String(Math.min(snap.totalOwed, tokens)))
            })]
          }), preview && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.sub, {
              color: c.mutedForeground
            }],
            children: [preview.toInterest.toLocaleString(), " to interest, ", preview.toPrincipal.toLocaleString(), " to principal.", " ", preview.settled ? "This closes the loan." : `You'll still owe ${(0, _libLoanMath.loanSnapshot)(preview.loan, now).totalOwed.toLocaleString()}.`]
          }), pay > 0 && pay >= tokens && tokens < snap.totalOwed ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.sub, {
              color: c.warning
            }],
            children: "That's every league token you have."
          }) : null, err ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.sub, {
              color: c.negative
            }],
            children: err
          }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.quick,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              label: "Cancel",
              variant: "ghost",
              style: {
                flex: 1
              },
              onPress: () => setOpen(false)
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
              label: pay > 0 ? `Repay ${pay.toLocaleString()}` : "Repay",
              style: {
                flex: 1
              },
              variant: "league",
              onPress: submit,
              loading: busy,
              disabled: pay <= 0
            })]
          })]
        })
      });
      $[69] = amount;
      $[70] = busy;
      $[71] = c.border;
      $[72] = c.foreground;
      $[73] = c.league;
      $[74] = c.mutedForeground;
      $[75] = c.negative;
      $[76] = c.secondary;
      $[77] = c.subtleForeground;
      $[78] = c.warning;
      $[79] = err;
      $[80] = now;
      $[81] = onRepay;
      $[82] = open;
      $[83] = pay;
      $[84] = preview;
      $[85] = repaid;
      $[86] = setAmount;
      $[87] = setOpen;
      $[88] = snap.interestOutstanding;
      $[89] = snap.totalOwed;
      $[90] = submit;
      $[91] = tokens;
      $[92] = viewer;
      $[93] = t36;
    } else {
      t36 = $[93];
    }
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
      tone: repaid ? undefined : viewer === "lender" ? "league" : "debt",
      style: styles.card,
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.head,
        children: [t9, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: t10,
          children: [t13, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: t14,
            children: [loan.ratePct, "% flat \xB7 repays ", snap.totalRepayable.toLocaleString(), " total"]
          })]
        }), t15]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.owedRow,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          children: [t18, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
            value: snap.totalOwed,
            currency: "league",
            size: "lg",
            tone: repaid ? "neutral" : viewer === "lender" ? "league" : "debt"
          })]
        }), t28]
      }), t35, t36]
    });
  }
  function Cell(t0) {
    const $ = (0, _reactCompilerRuntime.c)(17);
    const {
      label,
      value
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    let t1;
    if ($[0] !== c.subtleForeground) {
      t1 = [styles.k, {
        color: c.subtleForeground
      }];
      $[0] = c.subtleForeground;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    let t2;
    if ($[2] !== label) {
      t2 = label.toUpperCase();
      $[2] = label;
      $[3] = t2;
    } else {
      t2 = $[3];
    }
    let t3;
    if ($[4] !== t1 || $[5] !== t2) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t1,
        children: t2
      });
      $[4] = t1;
      $[5] = t2;
      $[6] = t3;
    } else {
      t3 = $[6];
    }
    let t4;
    if ($[7] !== c.foreground) {
      t4 = [styles.v, {
        color: c.foreground
      }];
      $[7] = c.foreground;
      $[8] = t4;
    } else {
      t4 = $[8];
    }
    let t5;
    if ($[9] !== value) {
      t5 = value.toLocaleString();
      $[9] = value;
      $[10] = t5;
    } else {
      t5 = $[10];
    }
    let t6;
    if ($[11] !== t4 || $[12] !== t5) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t4,
        children: t5
      });
      $[11] = t4;
      $[12] = t5;
      $[13] = t6;
    } else {
      t6 = $[13];
    }
    let t7;
    if ($[14] !== t3 || $[15] !== t6) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.cell,
        children: [t3, t6]
      });
      $[14] = t3;
      $[15] = t6;
      $[16] = t7;
    } else {
      t7 = $[16];
    }
    return t7;
  }
  const styles = StyleSheet.default.create({
    card: {
      gap: 12
    },
    head: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10
    },
    icon: {
      width: 36,
      height: 36,
      borderRadius: 18,
      alignItems: "center",
      justifyContent: "center"
    },
    title: {
      fontSize: 15,
      fontFamily: "Inter_700Bold"
    },
    sub: {
      fontSize: 12,
      lineHeight: 17,
      fontFamily: "Inter_400Regular"
    },
    owedRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "flex-end"
    },
    k: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.5
    },
    v: {
      fontSize: 15,
      fontFamily: "Inter_700Bold",
      fontVariant: ["tabular-nums"]
    },
    grid: {
      flexDirection: "row",
      flexWrap: "wrap",
      borderTopWidth: StyleSheet.default.hairlineWidth,
      paddingTop: 10,
      rowGap: 10
    },
    cell: {
      width: "50%",
      gap: 2
    },
    input: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      borderWidth: 1,
      borderRadius: 12,
      paddingHorizontal: 12,
      paddingVertical: 10
    },
    inputText: {
      flex: 1,
      fontSize: 18,
      fontFamily: "Inter_700Bold",
      fontVariant: ["tabular-nums"]
    },
    quick: {
      flexDirection: "row",
      gap: 8
    }
  });
},1225,[815,818,12,28,188,109,914,836,819,915,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      if (k === 'default') return;
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return BracketFill;
    }
  });
  var _firebaseFirestore = require(_dependencyMap[0]);
  var _react = require(_dependencyMap[1]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[2]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[3]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[4]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[5]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[6]);
  var _componentsUi = require(_dependencyMap[7]);
  var _constantsTheme = require(_dependencyMap[8]);
  var theme = _interopDefault(_constantsTheme);
  var _hooksUseColors = require(_dependencyMap[9]);
  var _libApi = require(_dependencyMap[10]);
  var api = _interopNamespace(_libApi);
  var _libFirebase = require(_dependencyMap[11]);
  var _libMotion = require(_dependencyMap[12]);
  var _reactJsxRuntime = require(_dependencyMap[13]);
  const COL_W = 132;

  /** Mirrors functions/src/lib/bracket.ts slotOptions. */
  function options(t, picks, s) {
    if (s.round === 1) return [...(s.teams ?? [])];
    return (s.feeds ?? []).map(f => picks[f]).filter(x => !!x);
  }

  /** Pick a downstream winner and clear later picks that no longer follow. */
  function cascade(t, picks) {
    const out = {};
    for (const s of [...t.slots].sort((a, b) => a.round - b.round)) {
      const p = picks[s.id];
      if (p && options(t, out, s).includes(p)) out[s.id] = p;
    }
    return out;
  }

  /** Bracket fill: one column per round, pinch to zoom (iOS) and pan in both directions. */
  function BracketFill({
    league,
    uid
  }) {
    const c = (0, _hooksUseColors.useColors)();
    const [tpl, setTpl] = (0, _react.useState)(null);
    const [picks, setPicks] = (0, _react.useState)({});
    const [points, setPoints] = (0, _react.useState)(0);
    const [busy, setBusy] = (0, _react.useState)(false);
    const [msg, setMsg] = (0, _react.useState)(null);
    (0, _react.useEffect)(() => {
      const db = (0, _libFirebase.getDb)();
      if (!db || !league.bracketTemplateId) return;
      return (0, _firebaseFirestore.onSnapshot)((0, _firebaseFirestore.doc)(db, "bracketTemplates", league.bracketTemplateId), s => setTpl(s.exists() ? s.data() : null), () => {});
    }, [league.bracketTemplateId]);
    (0, _react.useEffect)(() => {
      const db_0 = (0, _libFirebase.getDb)();
      if (!db_0 || !uid) return;
      return (0, _firebaseFirestore.onSnapshot)((0, _firebaseFirestore.doc)(db_0, "leagues", league.id, "brackets", uid), s_0 => {
        if (!s_0.exists()) return;
        setPicks(s_0.get("picks") ?? {});
        setPoints(s_0.get("points") ?? 0);
      }, () => {});
    }, [league.id, uid]);
    const rounds = (0, _react.useMemo)(() => {
      const m = new Map();
      for (const s_1 of tpl?.slots ?? []) m.set(s_1.round, [...(m.get(s_1.round) ?? []), s_1]);
      return [...m.entries()].sort((a, b) => a[0] - b[0]);
    }, [tpl]);
    if (!league.bracketTemplateId) {
      return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Card, {
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.sub, {
            color: c.mutedForeground
          }],
          children: "No tournament is attached to this league yet."
        })
      });
    }
    if (!tpl) return null;
    const locked = Date.now() >= tpl.locksAt;
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
      style: {
        gap: 8
      },
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.head,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.title, {
            color: c.foreground,
            flex: 1
          }],
          children: tpl.name
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
          label: locked ? `${points} pts` : "Open",
          tone: locked ? "league" : "accent"
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ScrollView.default, {
        horizontal: true,
        maximumZoomScale: 2.5,
        minimumZoomScale: 0.6,
        bouncesZoom: true,
        showsHorizontalScrollIndicator: false,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: styles.grid,
          children: rounds.map(([round, slots]) => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.col, {
              width: COL_W
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.round, {
                color: c.mutedForeground
              }],
              children: ["Round ", round]
            }), slots.map(s_2 => {
              const opts = options(tpl, picks, s_2);
              const result = tpl.results?.[s_2.id];
              return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
                style: [styles.slot, {
                  borderColor: c.border,
                  backgroundColor: c.secondary
                }],
                children: (opts.length ? opts : ["TBD", "TBD"]).map((team, i) => {
                  const on = picks[s_2.id] === team;
                  const tone = result ? result === team ? c.positive : on ? c.negative : c.mutedForeground : on ? c.primary : c.foreground;
                  return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
                    accessibilityRole: "button",
                    accessibilityState: {
                      selected: on,
                      disabled: locked || team === "TBD"
                    },
                    accessibilityLabel: `Round ${round}: pick ${team}`,
                    disabled: locked || team === "TBD",
                    onPress: () => {
                      _libMotion.haptic.tick();
                      setPicks(p => cascade(tpl, {
                        ...p,
                        [s_2.id]: team
                      }));
                    },
                    style: [styles.team, on && {
                      backgroundColor: c.alpha(c.primary, 0.18)
                    }],
                    children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                      style: [styles.teamText, {
                        color: tone
                      }],
                      children: team
                    })
                  }, `${team}_${i}`);
                })
              }, s_2.id);
            })]
          }, round))
        })
      }), !locked ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
        label: "Save Bracket",
        loading: busy,
        onPress: async () => {
          setBusy(true);
          setMsg(null);
          try {
            await api.submitBracket({
              leagueId: league.id,
              picks
            });
            _libMotion.haptic.success();
            setMsg("Saved.");
          } catch (e) {
            setMsg(api.friendlyError(e));
          } finally {
            setBusy(false);
          }
        }
      }) : null, msg ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.sub, {
          color: c.mutedForeground
        }],
        children: msg
      }) : null]
    });
  }
  const styles = StyleSheet.default.create({
    head: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    title: theme.default.type.bodyStrong,
    sub: theme.default.type.caption,
    round: theme.default.type.overline,
    grid: {
      flexDirection: "row",
      gap: 10,
      paddingVertical: 4
    },
    col: {
      gap: 10,
      justifyContent: "space-around"
    },
    slot: {
      borderWidth: 1,
      borderRadius: 10,
      overflow: "hidden"
    },
    team: {
      paddingVertical: 8,
      paddingHorizontal: 10
    },
    teamText: theme.default.type.captionStrong
  });
},1226,[905,12,133,28,188,109,827,836,874,819,863,906,820,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return CoopGoalCard;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _firebaseFirestore = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[3]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[4]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[5]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsUi = require(_dependencyMap[6]);
  var _constantsTheme = require(_dependencyMap[7]);
  var theme = _interopDefault(_constantsTheme);
  var _hooksUseColors = require(_dependencyMap[8]);
  var _libExperiments = require(_dependencyMap[9]);
  var _libFirebase = require(_dependencyMap[10]);
  var _libMarkets = require(_dependencyMap[11]);
  var _reactJsxRuntime = require(_dependencyMap[12]);
  /** Weekly co-op goal with per-member contribution. Experimental (coop_goals_v1, league unit). */
  function CoopGoalCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(35);
    const {
      league,
      uid
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const arm = (0, _libExperiments.useExperiment)(_libExperiments.EXPERIMENTS.coopGoals, uid, league.id);
    const [coop, setCoop] = (0, _react.useState)(null);
    let t1;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = (0, _libMarkets.weekKey)();
      $[0] = t1;
    } else {
      t1 = $[0];
    }
    const week = t1;
    let t2;
    let t3;
    if ($[1] !== arm || $[2] !== league.id) {
      t2 = () => {
        const db = (0, _libFirebase.getDb)();
        if (!db || arm === _libExperiments.CONTROL) {
          return;
        }
        return (0, _firebaseFirestore.onSnapshot)((0, _firebaseFirestore.doc)(db, "leagues", league.id, "coop", week), s => setCoop(s.exists() ? s.data() : null), _temp);
      };
      t3 = [league.id, week, arm];
      $[1] = arm;
      $[2] = league.id;
      $[3] = t2;
      $[4] = t3;
    } else {
      t2 = $[3];
      t3 = $[4];
    }
    (0, _react.useEffect)(t2, t3);
    if (arm === _libExperiments.CONTROL) {
      return null;
    }
    const target = coop?.target ?? Math.min(80, Math.max(20, 5 * league.memberIds.length));
    const progress = Math.min(target, coop?.progress ?? 0);
    let t4;
    if ($[5] !== c || $[6] !== coop?.completedAt || $[7] !== coop?.contributions || $[8] !== league.members || $[9] !== progress || $[10] !== target || $[11] !== uid) {
      const rows = Object.entries(coop?.contributions ?? {}).sort(_temp2);
      let t5;
      if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
          gap: 8
        };
        $[13] = t5;
      } else {
        t5 = $[13];
      }
      let t6;
      if ($[14] !== c.foreground) {
        t6 = [styles.title, {
          color: c.foreground
        }];
        $[14] = c.foreground;
        $[15] = t6;
      } else {
        t6 = $[15];
      }
      const t7 = coop?.completedAt ? "\uD83E\uDD1D League goal hit!" : "League goal this week";
      let t8;
      if ($[16] !== t6 || $[17] !== t7) {
        t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: t6,
          children: t7
        });
        $[16] = t6;
        $[17] = t7;
        $[18] = t8;
      } else {
        t8 = $[18];
      }
      let t9;
      if ($[19] !== c.mutedForeground) {
        t9 = [styles.sub, {
          color: c.mutedForeground
        }];
        $[19] = c.mutedForeground;
        $[20] = t9;
      } else {
        t9 = $[20];
      }
      let t10;
      if ($[21] !== progress || $[22] !== t9 || $[23] !== target) {
        t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: t9,
          children: [progress, "/", target, " correct picks together"]
        });
        $[21] = progress;
        $[22] = t9;
        $[23] = target;
        $[24] = t10;
      } else {
        t10 = $[24];
      }
      let t11;
      if ($[25] !== c.secondary) {
        t11 = [styles.track, {
          backgroundColor: c.secondary
        }];
        $[25] = c.secondary;
        $[26] = t11;
      } else {
        t11 = $[26];
      }
      let t12;
      if ($[27] !== c || $[28] !== target || $[29] !== uid) {
        t12 = t13 => {
          const [u, n] = t13;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: {
              width: `${n / target * 100}%`,
              backgroundColor: u === uid ? c.league : c.alpha(c.league, 0.45)
            }
          }, u);
        };
        $[27] = c;
        $[28] = target;
        $[29] = uid;
        $[30] = t12;
      } else {
        t12 = $[30];
      }
      let t13;
      if ($[31] !== c.mutedForeground || $[32] !== league.members || $[33] !== uid) {
        t13 = t14 => {
          const [u_0, n_0] = t14;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.sub, {
              color: c.mutedForeground
            }],
            children: [u_0 === uid ? "You" : league.members[u_0]?.displayName ?? "Player", " \xB7 ", n_0]
          }, u_0);
        };
        $[31] = c.mutedForeground;
        $[32] = league.members;
        $[33] = uid;
        $[34] = t13;
      } else {
        t13 = $[34];
      }
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
        style: t5,
        accessibilityLabel: `League goal: ${progress} of ${target} correct picks`,
        children: [t8, t10, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: t11,
          children: rows.map(t12)
        }), rows.slice(0, 5).map(t13)]
      });
      $[5] = c;
      $[6] = coop?.completedAt;
      $[7] = coop?.contributions;
      $[8] = league.members;
      $[9] = progress;
      $[10] = target;
      $[11] = uid;
      $[12] = t4;
    } else {
      t4 = $[12];
    }
    return t4;
  }
  function _temp2(a, b) {
    return b[1] - a[1];
  }
  function _temp() {}
  const styles = StyleSheet.default.create({
    title: theme.default.type.bodyStrong,
    sub: theme.default.type.caption,
    track: {
      height: 10,
      borderRadius: 5,
      overflow: "hidden",
      flexDirection: "row"
    }
  });
},1227,[815,905,12,28,188,109,836,874,819,898,906,864,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return InviteQR;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _qrcode = require(_dependencyMap[1]);
  require(_dependencyMap[2]);
  var _reactNativeWebDistExportsView = require(_dependencyMap[3]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _reactNativeSvg = require(_dependencyMap[4]);
  var Svg = _interopDefault(_reactNativeSvg);
  var _reactJsxRuntime = require(_dependencyMap[5]);
  /** Quiet zone in modules on every side; scanners need at least 4. */const QUIET = 4;
  /**
   * Fixed ink and paper rather than theme tokens: phone cameras expect dark
   * modules on a light ground, and an inverted code fails to scan in dark mode.
   */
  const INK = "#0B0F19";
  const PAPER = "#FFFFFF";

  /** A QR code for an invite link, drawn as one SVG path (no native module). */
  function InviteQR(t0) {
    const $ = (0, _reactCompilerRuntime.c)(19);
    const {
      value,
      size: t1,
      accessibilityLabel
    } = t0;
    const size = t1 === undefined ? 176 : t1;
    let n;
    let path;
    if ($[0] !== value) {
      const {
        modules
      } = (0, _qrcode.create)(value, {
        errorCorrectionLevel: "M"
      });
      n = modules.size;
      path = "";
      for (let y = 0; y < n; y++) {
        for (let x = 0; x < n; x++) {
          if (modules.get(y, x)) {
            path = path + `M${x + QUIET} ${y + QUIET}h1v1h-1z`;
          }
        }
      }
      $[0] = value;
      $[1] = n;
      $[2] = path;
    } else {
      n = $[1];
      path = $[2];
    }
    const t2 = n + 8;
    let t3;
    if ($[3] !== path || $[4] !== t2) {
      t3 = {
        d: path,
        extent: t2
      };
      $[3] = path;
      $[4] = t2;
      $[5] = t3;
    } else {
      t3 = $[5];
    }
    const {
      d,
      extent
    } = t3;
    const t4 = accessibilityLabel ?? "QR code";
    let t5;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
      t5 = {
        borderRadius: 12,
        overflow: "hidden"
      };
      $[6] = t5;
    } else {
      t5 = $[6];
    }
    const t6 = `0 0 ${extent} ${extent}`;
    let t7;
    if ($[7] !== extent) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_reactNativeSvg.Rect, {
        x: 0,
        y: 0,
        width: extent,
        height: extent,
        fill: PAPER
      });
      $[7] = extent;
      $[8] = t7;
    } else {
      t7 = $[8];
    }
    let t8;
    if ($[9] !== d) {
      t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_reactNativeSvg.Path, {
        d: d,
        fill: INK
      });
      $[9] = d;
      $[10] = t8;
    } else {
      t8 = $[10];
    }
    let t9;
    if ($[11] !== size || $[12] !== t6 || $[13] !== t7 || $[14] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Svg.default, {
        width: size,
        height: size,
        viewBox: t6,
        children: [t7, t8]
      });
      $[11] = size;
      $[12] = t6;
      $[13] = t7;
      $[14] = t8;
      $[15] = t9;
    } else {
      t9 = $[15];
    }
    let t10;
    if ($[16] !== t4 || $[17] !== t9) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        accessible: true,
        accessibilityRole: "image",
        accessibilityLabel: t4,
        style: t5,
        children: t9
      });
      $[16] = t4;
      $[17] = t9;
      $[18] = t10;
    } else {
      t10 = $[18];
    }
    return t10;
  }
},1228,[815,1229,12,109,907,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const canPromise = require(_dependencyMap[0]);
  const QRCode = require(_dependencyMap[1]);
  const CanvasRenderer = require(_dependencyMap[2]);
  const SvgRenderer = require(_dependencyMap[3]);
  function renderCanvas(renderFunc, canvas, text, opts, cb) {
    const args = [].slice.call(arguments, 1);
    const argsNum = args.length;
    const isLastArgCb = typeof args[argsNum - 1] === 'function';
    if (!isLastArgCb && !canPromise()) {
      throw new Error('Callback required as last argument');
    }
    if (isLastArgCb) {
      if (argsNum < 2) {
        throw new Error('Too few arguments provided');
      }
      if (argsNum === 2) {
        cb = text;
        text = canvas;
        canvas = opts = undefined;
      } else if (argsNum === 3) {
        if (canvas.getContext && typeof cb === 'undefined') {
          cb = opts;
          opts = undefined;
        } else {
          cb = opts;
          opts = text;
          text = canvas;
          canvas = undefined;
        }
      }
    } else {
      if (argsNum < 1) {
        throw new Error('Too few arguments provided');
      }
      if (argsNum === 1) {
        text = canvas;
        canvas = opts = undefined;
      } else if (argsNum === 2 && !canvas.getContext) {
        opts = text;
        text = canvas;
        canvas = undefined;
      }
      return new Promise(function (resolve, reject) {
        try {
          const data = QRCode.create(text, opts);
          resolve(renderFunc(data, canvas, opts));
        } catch (e) {
          reject(e);
        }
      });
    }
    try {
      const data = QRCode.create(text, opts);
      cb(null, renderFunc(data, canvas, opts));
    } catch (e) {
      cb(e);
    }
  }
  exports.create = QRCode.create;
  exports.toCanvas = renderCanvas.bind(null, CanvasRenderer.render);
  exports.toDataURL = renderCanvas.bind(null, CanvasRenderer.renderToDataURL);

  // only svg for now.
  exports.toString = renderCanvas.bind(null, function (data, _, opts) {
    return SvgRenderer.render(data, opts);
  });
},1229,[1230,1231,1254,1256]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  // can-promise has a crash in some versions of react native that dont have
  // standard global objects
  // https://github.com/soldair/node-qrcode/issues/157

  module.exports = function () {
    return typeof Promise === 'function' && Promise.prototype && Promise.prototype.then;
  };
},1230,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const Utils = require(_dependencyMap[0]);
  const ECLevel = require(_dependencyMap[1]);
  const BitBuffer = require(_dependencyMap[2]);
  const BitMatrix = require(_dependencyMap[3]);
  const AlignmentPattern = require(_dependencyMap[4]);
  const FinderPattern = require(_dependencyMap[5]);
  const MaskPattern = require(_dependencyMap[6]);
  const ECCode = require(_dependencyMap[7]);
  const ReedSolomonEncoder = require(_dependencyMap[8]);
  const Version = require(_dependencyMap[9]);
  const FormatInfo = require(_dependencyMap[10]);
  const Mode = require(_dependencyMap[11]);
  const Segments = require(_dependencyMap[12]);

  /**
   * QRCode for JavaScript
   *
   * modified by Ryan Day for nodejs support
   * Copyright (c) 2011 Ryan Day
   *
   * Licensed under the MIT license:
   *   http://www.opensource.org/licenses/mit-license.php
   *
  //---------------------------------------------------------------------
  // QRCode for JavaScript
  //
  // Copyright (c) 2009 Kazuhiko Arase
  //
  // URL: http://www.d-project.com/
  //
  // Licensed under the MIT license:
  //   http://www.opensource.org/licenses/mit-license.php
  //
  // The word "QR Code" is registered trademark of
  // DENSO WAVE INCORPORATED
  //   http://www.denso-wave.com/qrcode/faqpatent-e.html
  //
  //---------------------------------------------------------------------
  */

  /**
   * Add finder patterns bits to matrix
   *
   * @param  {BitMatrix} matrix  Modules matrix
   * @param  {Number}    version QR Code version
   */
  function setupFinderPattern(matrix, version) {
    const size = matrix.size;
    const pos = FinderPattern.getPositions(version);
    for (let i = 0; i < pos.length; i++) {
      const row = pos[i][0];
      const col = pos[i][1];
      for (let r = -1; r <= 7; r++) {
        if (row + r <= -1 || size <= row + r) continue;
        for (let c = -1; c <= 7; c++) {
          if (col + c <= -1 || size <= col + c) continue;
          if (r >= 0 && r <= 6 && (c === 0 || c === 6) || c >= 0 && c <= 6 && (r === 0 || r === 6) || r >= 2 && r <= 4 && c >= 2 && c <= 4) {
            matrix.set(row + r, col + c, true, true);
          } else {
            matrix.set(row + r, col + c, false, true);
          }
        }
      }
    }
  }

  /**
   * Add timing pattern bits to matrix
   *
   * Note: this function must be called before {@link setupAlignmentPattern}
   *
   * @param  {BitMatrix} matrix Modules matrix
   */
  function setupTimingPattern(matrix) {
    const size = matrix.size;
    for (let r = 8; r < size - 8; r++) {
      const value = r % 2 === 0;
      matrix.set(r, 6, value, true);
      matrix.set(6, r, value, true);
    }
  }

  /**
   * Add alignment patterns bits to matrix
   *
   * Note: this function must be called after {@link setupTimingPattern}
   *
   * @param  {BitMatrix} matrix  Modules matrix
   * @param  {Number}    version QR Code version
   */
  function setupAlignmentPattern(matrix, version) {
    const pos = AlignmentPattern.getPositions(version);
    for (let i = 0; i < pos.length; i++) {
      const row = pos[i][0];
      const col = pos[i][1];
      for (let r = -2; r <= 2; r++) {
        for (let c = -2; c <= 2; c++) {
          if (r === -2 || r === 2 || c === -2 || c === 2 || r === 0 && c === 0) {
            matrix.set(row + r, col + c, true, true);
          } else {
            matrix.set(row + r, col + c, false, true);
          }
        }
      }
    }
  }

  /**
   * Add version info bits to matrix
   *
   * @param  {BitMatrix} matrix  Modules matrix
   * @param  {Number}    version QR Code version
   */
  function setupVersionInfo(matrix, version) {
    const size = matrix.size;
    const bits = Version.getEncodedBits(version);
    let row, col, mod;
    for (let i = 0; i < 18; i++) {
      row = Math.floor(i / 3);
      col = i % 3 + size - 8 - 3;
      mod = (bits >> i & 1) === 1;
      matrix.set(row, col, mod, true);
      matrix.set(col, row, mod, true);
    }
  }

  /**
   * Add format info bits to matrix
   *
   * @param  {BitMatrix} matrix               Modules matrix
   * @param  {ErrorCorrectionLevel}    errorCorrectionLevel Error correction level
   * @param  {Number}    maskPattern          Mask pattern reference value
   */
  function setupFormatInfo(matrix, errorCorrectionLevel, maskPattern) {
    const size = matrix.size;
    const bits = FormatInfo.getEncodedBits(errorCorrectionLevel, maskPattern);
    let i, mod;
    for (i = 0; i < 15; i++) {
      mod = (bits >> i & 1) === 1;

      // vertical
      if (i < 6) {
        matrix.set(i, 8, mod, true);
      } else if (i < 8) {
        matrix.set(i + 1, 8, mod, true);
      } else {
        matrix.set(size - 15 + i, 8, mod, true);
      }

      // horizontal
      if (i < 8) {
        matrix.set(8, size - i - 1, mod, true);
      } else if (i < 9) {
        matrix.set(8, 15 - i - 1 + 1, mod, true);
      } else {
        matrix.set(8, 15 - i - 1, mod, true);
      }
    }

    // fixed module
    matrix.set(size - 8, 8, 1, true);
  }

  /**
   * Add encoded data bits to matrix
   *
   * @param  {BitMatrix}  matrix Modules matrix
   * @param  {Uint8Array} data   Data codewords
   */
  function setupData(matrix, data) {
    const size = matrix.size;
    let inc = -1;
    let row = size - 1;
    let bitIndex = 7;
    let byteIndex = 0;
    for (let col = size - 1; col > 0; col -= 2) {
      if (col === 6) col--;
      while (true) {
        for (let c = 0; c < 2; c++) {
          if (!matrix.isReserved(row, col - c)) {
            let dark = false;
            if (byteIndex < data.length) {
              dark = (data[byteIndex] >>> bitIndex & 1) === 1;
            }
            matrix.set(row, col - c, dark);
            bitIndex--;
            if (bitIndex === -1) {
              byteIndex++;
              bitIndex = 7;
            }
          }
        }
        row += inc;
        if (row < 0 || size <= row) {
          row -= inc;
          inc = -inc;
          break;
        }
      }
    }
  }

  /**
   * Create encoded codewords from data input
   *
   * @param  {Number}   version              QR Code version
   * @param  {ErrorCorrectionLevel}   errorCorrectionLevel Error correction level
   * @param  {ByteData} data                 Data input
   * @return {Uint8Array}                    Buffer containing encoded codewords
   */
  function createData(version, errorCorrectionLevel, segments) {
    // Prepare data buffer
    const buffer = new BitBuffer();
    segments.forEach(function (data) {
      // prefix data with mode indicator (4 bits)
      buffer.put(data.mode.bit, 4);

      // Prefix data with character count indicator.
      // The character count indicator is a string of bits that represents the
      // number of characters that are being encoded.
      // The character count indicator must be placed after the mode indicator
      // and must be a certain number of bits long, depending on the QR version
      // and data mode
      // @see {@link Mode.getCharCountIndicator}.
      buffer.put(data.getLength(), Mode.getCharCountIndicator(data.mode, version));

      // add binary data sequence to buffer
      data.write(buffer);
    });

    // Calculate required number of bits
    const totalCodewords = Utils.getSymbolTotalCodewords(version);
    const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);
    const dataTotalCodewordsBits = (totalCodewords - ecTotalCodewords) * 8;

    // Add a terminator.
    // If the bit string is shorter than the total number of required bits,
    // a terminator of up to four 0s must be added to the right side of the string.
    // If the bit string is more than four bits shorter than the required number of bits,
    // add four 0s to the end.
    if (buffer.getLengthInBits() + 4 <= dataTotalCodewordsBits) {
      buffer.put(0, 4);
    }

    // If the bit string is fewer than four bits shorter, add only the number of 0s that
    // are needed to reach the required number of bits.

    // After adding the terminator, if the number of bits in the string is not a multiple of 8,
    // pad the string on the right with 0s to make the string's length a multiple of 8.
    while (buffer.getLengthInBits() % 8 !== 0) {
      buffer.putBit(0);
    }

    // Add pad bytes if the string is still shorter than the total number of required bits.
    // Extend the buffer to fill the data capacity of the symbol corresponding to
    // the Version and Error Correction Level by adding the Pad Codewords 11101100 (0xEC)
    // and 00010001 (0x11) alternately.
    const remainingByte = (dataTotalCodewordsBits - buffer.getLengthInBits()) / 8;
    for (let i = 0; i < remainingByte; i++) {
      buffer.put(i % 2 ? 0x11 : 0xEC, 8);
    }
    return createCodewords(buffer, version, errorCorrectionLevel);
  }

  /**
   * Encode input data with Reed-Solomon and return codewords with
   * relative error correction bits
   *
   * @param  {BitBuffer} bitBuffer            Data to encode
   * @param  {Number}    version              QR Code version
   * @param  {ErrorCorrectionLevel} errorCorrectionLevel Error correction level
   * @return {Uint8Array}                     Buffer containing encoded codewords
   */
  function createCodewords(bitBuffer, version, errorCorrectionLevel) {
    // Total codewords for this QR code version (Data + Error correction)
    const totalCodewords = Utils.getSymbolTotalCodewords(version);

    // Total number of error correction codewords
    const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);

    // Total number of data codewords
    const dataTotalCodewords = totalCodewords - ecTotalCodewords;

    // Total number of blocks
    const ecTotalBlocks = ECCode.getBlocksCount(version, errorCorrectionLevel);

    // Calculate how many blocks each group should contain
    const blocksInGroup2 = totalCodewords % ecTotalBlocks;
    const blocksInGroup1 = ecTotalBlocks - blocksInGroup2;
    const totalCodewordsInGroup1 = Math.floor(totalCodewords / ecTotalBlocks);
    const dataCodewordsInGroup1 = Math.floor(dataTotalCodewords / ecTotalBlocks);
    const dataCodewordsInGroup2 = dataCodewordsInGroup1 + 1;

    // Number of EC codewords is the same for both groups
    const ecCount = totalCodewordsInGroup1 - dataCodewordsInGroup1;

    // Initialize a Reed-Solomon encoder with a generator polynomial of degree ecCount
    const rs = new ReedSolomonEncoder(ecCount);
    let offset = 0;
    const dcData = new Array(ecTotalBlocks);
    const ecData = new Array(ecTotalBlocks);
    let maxDataSize = 0;
    const buffer = new Uint8Array(bitBuffer.buffer);

    // Divide the buffer into the required number of blocks
    for (let b = 0; b < ecTotalBlocks; b++) {
      const dataSize = b < blocksInGroup1 ? dataCodewordsInGroup1 : dataCodewordsInGroup2;

      // extract a block of data from buffer
      dcData[b] = buffer.slice(offset, offset + dataSize);

      // Calculate EC codewords for this data block
      ecData[b] = rs.encode(dcData[b]);
      offset += dataSize;
      maxDataSize = Math.max(maxDataSize, dataSize);
    }

    // Create final data
    // Interleave the data and error correction codewords from each block
    const data = new Uint8Array(totalCodewords);
    let index = 0;
    let i, r;

    // Add data codewords
    for (i = 0; i < maxDataSize; i++) {
      for (r = 0; r < ecTotalBlocks; r++) {
        if (i < dcData[r].length) {
          data[index++] = dcData[r][i];
        }
      }
    }

    // Apped EC codewords
    for (i = 0; i < ecCount; i++) {
      for (r = 0; r < ecTotalBlocks; r++) {
        data[index++] = ecData[r][i];
      }
    }
    return data;
  }

  /**
   * Build QR Code symbol
   *
   * @param  {String} data                 Input string
   * @param  {Number} version              QR Code version
   * @param  {ErrorCorretionLevel} errorCorrectionLevel Error level
   * @param  {MaskPattern} maskPattern     Mask pattern
   * @return {Object}                      Object containing symbol data
   */
  function createSymbol(data, version, errorCorrectionLevel, maskPattern) {
    let segments;
    if (Array.isArray(data)) {
      segments = Segments.fromArray(data);
    } else if (typeof data === 'string') {
      let estimatedVersion = version;
      if (!estimatedVersion) {
        const rawSegments = Segments.rawSplit(data);

        // Estimate best version that can contain raw splitted segments
        estimatedVersion = Version.getBestVersionForData(rawSegments, errorCorrectionLevel);
      }

      // Build optimized segments
      // If estimated version is undefined, try with the highest version
      segments = Segments.fromString(data, estimatedVersion || 40);
    } else {
      throw new Error('Invalid data');
    }

    // Get the min version that can contain data
    const bestVersion = Version.getBestVersionForData(segments, errorCorrectionLevel);

    // If no version is found, data cannot be stored
    if (!bestVersion) {
      throw new Error('The amount of data is too big to be stored in a QR Code');
    }

    // If not specified, use min version as default
    if (!version) {
      version = bestVersion;

      // Check if the specified version can contain the data
    } else if (version < bestVersion) {
      throw new Error("\nThe chosen QR Code version cannot contain this amount of data.\nMinimum version required to store current data is: " + bestVersion + '.\n');
    }
    const dataBits = createData(version, errorCorrectionLevel, segments);

    // Allocate matrix buffer
    const moduleCount = Utils.getSymbolSize(version);
    const modules = new BitMatrix(moduleCount);

    // Add function modules
    setupFinderPattern(modules, version);
    setupTimingPattern(modules);
    setupAlignmentPattern(modules, version);

    // Add temporary dummy bits for format info just to set them as reserved.
    // This is needed to prevent these bits from being masked by {@link MaskPattern.applyMask}
    // since the masking operation must be performed only on the encoding region.
    // These blocks will be replaced with correct values later in code.
    setupFormatInfo(modules, errorCorrectionLevel, 0);
    if (version >= 7) {
      setupVersionInfo(modules, version);
    }

    // Add data codewords
    setupData(modules, dataBits);
    if (isNaN(maskPattern)) {
      // Find best mask pattern
      maskPattern = MaskPattern.getBestMask(modules, setupFormatInfo.bind(null, modules, errorCorrectionLevel));
    }

    // Apply mask pattern
    MaskPattern.applyMask(maskPattern, modules);

    // Replace format info bits with correct values
    setupFormatInfo(modules, errorCorrectionLevel, maskPattern);
    return {
      modules: modules,
      version: version,
      errorCorrectionLevel: errorCorrectionLevel,
      maskPattern: maskPattern,
      segments: segments
    };
  }

  /**
   * QR Code
   *
   * @param {String | Array} data                 Input data
   * @param {Object} options                      Optional configurations
   * @param {Number} options.version              QR Code version
   * @param {String} options.errorCorrectionLevel Error correction level
   * @param {Function} options.toSJISFunc         Helper func to convert utf8 to sjis
   */
  exports.create = function create(data, options) {
    if (typeof data === 'undefined' || data === '') {
      throw new Error('No input text');
    }
    let errorCorrectionLevel = ECLevel.M;
    let version;
    let mask;
    if (typeof options !== 'undefined') {
      // Use higher error correction level as default
      errorCorrectionLevel = ECLevel.from(options.errorCorrectionLevel, ECLevel.M);
      version = Version.from(options.version);
      mask = MaskPattern.from(options.maskPattern);
      if (options.toSJISFunc) {
        Utils.setToSJISFunction(options.toSJISFunc);
      }
    }
    return createSymbol(data, version, errorCorrectionLevel, mask);
  };
},1231,[1232,1233,1234,1235,1236,1237,1238,1239,1240,1243,1247,1244,1248]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  let toSJISFunction;
  const CODEWORDS_COUNT = [0,
  // Not used
  26, 44, 70, 100, 134, 172, 196, 242, 292, 346, 404, 466, 532, 581, 655, 733, 815, 901, 991, 1085, 1156, 1258, 1364, 1474, 1588, 1706, 1828, 1921, 2051, 2185, 2323, 2465, 2611, 2761, 2876, 3034, 3196, 3362, 3532, 3706];

  /**
   * Returns the QR Code size for the specified version
   *
   * @param  {Number} version QR Code version
   * @return {Number}         size of QR code
   */
  exports.getSymbolSize = function getSymbolSize(version) {
    if (!version) throw new Error('"version" cannot be null or undefined');
    if (version < 1 || version > 40) throw new Error('"version" should be in range from 1 to 40');
    return version * 4 + 17;
  };

  /**
   * Returns the total number of codewords used to store data and EC information.
   *
   * @param  {Number} version QR Code version
   * @return {Number}         Data length in bits
   */
  exports.getSymbolTotalCodewords = function getSymbolTotalCodewords(version) {
    return CODEWORDS_COUNT[version];
  };

  /**
   * Encode data with Bose-Chaudhuri-Hocquenghem
   *
   * @param  {Number} data Value to encode
   * @return {Number}      Encoded value
   */
  exports.getBCHDigit = function (data) {
    let digit = 0;
    while (data !== 0) {
      digit++;
      data >>>= 1;
    }
    return digit;
  };
  exports.setToSJISFunction = function setToSJISFunction(f) {
    if (typeof f !== 'function') {
      throw new Error('"toSJISFunc" is not a valid function.');
    }
    toSJISFunction = f;
  };
  exports.isKanjiModeEnabled = function () {
    return typeof toSJISFunction !== 'undefined';
  };
  exports.toSJIS = function toSJIS(kanji) {
    return toSJISFunction(kanji);
  };
},1232,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  exports.L = {
    bit: 1
  };
  exports.M = {
    bit: 0
  };
  exports.Q = {
    bit: 3
  };
  exports.H = {
    bit: 2
  };
  function fromString(string) {
    if (typeof string !== 'string') {
      throw new Error('Param is not a string');
    }
    const lcStr = string.toLowerCase();
    switch (lcStr) {
      case 'l':
      case 'low':
        return exports.L;
      case 'm':
      case 'medium':
        return exports.M;
      case 'q':
      case 'quartile':
        return exports.Q;
      case 'h':
      case 'high':
        return exports.H;
      default:
        throw new Error('Unknown EC Level: ' + string);
    }
  }
  exports.isValid = function isValid(level) {
    return level && typeof level.bit !== 'undefined' && level.bit >= 0 && level.bit < 4;
  };
  exports.from = function from(value, defaultValue) {
    if (exports.isValid(value)) {
      return value;
    }
    try {
      return fromString(value);
    } catch (e) {
      return defaultValue;
    }
  };
},1233,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  function BitBuffer() {
    this.buffer = [];
    this.length = 0;
  }
  BitBuffer.prototype = {
    get: function (index) {
      const bufIndex = Math.floor(index / 8);
      return (this.buffer[bufIndex] >>> 7 - index % 8 & 1) === 1;
    },
    put: function (num, length) {
      for (let i = 0; i < length; i++) {
        this.putBit((num >>> length - i - 1 & 1) === 1);
      }
    },
    getLengthInBits: function () {
      return this.length;
    },
    putBit: function (bit) {
      const bufIndex = Math.floor(this.length / 8);
      if (this.buffer.length <= bufIndex) {
        this.buffer.push(0);
      }
      if (bit) {
        this.buffer[bufIndex] |= 0x80 >>> this.length % 8;
      }
      this.length++;
    }
  };
  module.exports = BitBuffer;
},1234,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Helper class to handle QR Code symbol modules
   *
   * @param {Number} size Symbol size
   */
  function BitMatrix(size) {
    if (!size || size < 1) {
      throw new Error('BitMatrix size must be defined and greater than 0');
    }
    this.size = size;
    this.data = new Uint8Array(size * size);
    this.reservedBit = new Uint8Array(size * size);
  }

  /**
   * Set bit value at specified location
   * If reserved flag is set, this bit will be ignored during masking process
   *
   * @param {Number}  row
   * @param {Number}  col
   * @param {Boolean} value
   * @param {Boolean} reserved
   */
  BitMatrix.prototype.set = function (row, col, value, reserved) {
    const index = row * this.size + col;
    this.data[index] = value;
    if (reserved) this.reservedBit[index] = true;
  };

  /**
   * Returns bit value at specified location
   *
   * @param  {Number}  row
   * @param  {Number}  col
   * @return {Boolean}
   */
  BitMatrix.prototype.get = function (row, col) {
    return this.data[row * this.size + col];
  };

  /**
   * Applies xor operator at specified location
   * (used during masking process)
   *
   * @param {Number}  row
   * @param {Number}  col
   * @param {Boolean} value
   */
  BitMatrix.prototype.xor = function (row, col, value) {
    this.data[row * this.size + col] ^= value;
  };

  /**
   * Check if bit at specified location is reserved
   *
   * @param {Number}   row
   * @param {Number}   col
   * @return {Boolean}
   */
  BitMatrix.prototype.isReserved = function (row, col) {
    return this.reservedBit[row * this.size + col];
  };
  module.exports = BitMatrix;
},1235,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Alignment pattern are fixed reference pattern in defined positions
   * in a matrix symbology, which enables the decode software to re-synchronise
   * the coordinate mapping of the image modules in the event of moderate amounts
   * of distortion of the image.
   *
   * Alignment patterns are present only in QR Code symbols of version 2 or larger
   * and their number depends on the symbol version.
   */

  const getSymbolSize = require(_dependencyMap[0]).getSymbolSize;

  /**
   * Calculate the row/column coordinates of the center module of each alignment pattern
   * for the specified QR Code version.
   *
   * The alignment patterns are positioned symmetrically on either side of the diagonal
   * running from the top left corner of the symbol to the bottom right corner.
   *
   * Since positions are simmetrical only half of the coordinates are returned.
   * Each item of the array will represent in turn the x and y coordinate.
   * @see {@link getPositions}
   *
   * @param  {Number} version QR Code version
   * @return {Array}          Array of coordinate
   */
  exports.getRowColCoords = function getRowColCoords(version) {
    if (version === 1) return [];
    const posCount = Math.floor(version / 7) + 2;
    const size = getSymbolSize(version);
    const intervals = size === 145 ? 26 : Math.ceil((size - 13) / (2 * posCount - 2)) * 2;
    const positions = [size - 7]; // Last coord is always (size - 7)

    for (let i = 1; i < posCount - 1; i++) {
      positions[i] = positions[i - 1] - intervals;
    }
    positions.push(6); // First coord is always 6

    return positions.reverse();
  };

  /**
   * Returns an array containing the positions of each alignment pattern.
   * Each array's element represent the center point of the pattern as (x, y) coordinates
   *
   * Coordinates are calculated expanding the row/column coordinates returned by {@link getRowColCoords}
   * and filtering out the items that overlaps with finder pattern
   *
   * @example
   * For a Version 7 symbol {@link getRowColCoords} returns values 6, 22 and 38.
   * The alignment patterns, therefore, are to be centered on (row, column)
   * positions (6,22), (22,6), (22,22), (22,38), (38,22), (38,38).
   * Note that the coordinates (6,6), (6,38), (38,6) are occupied by finder patterns
   * and are not therefore used for alignment patterns.
   *
   * let pos = getPositions(7)
   * // [[6,22], [22,6], [22,22], [22,38], [38,22], [38,38]]
   *
   * @param  {Number} version QR Code version
   * @return {Array}          Array of coordinates
   */
  exports.getPositions = function getPositions(version) {
    const coords = [];
    const pos = exports.getRowColCoords(version);
    const posLength = pos.length;
    for (let i = 0; i < posLength; i++) {
      for (let j = 0; j < posLength; j++) {
        // Skip if position is occupied by finder patterns
        if (i === 0 && j === 0 ||
        // top-left
        i === 0 && j === posLength - 1 ||
        // bottom-left
        i === posLength - 1 && j === 0) {
          // top-right
          continue;
        }
        coords.push([pos[i], pos[j]]);
      }
    }
    return coords;
  };
},1236,[1232]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const getSymbolSize = require(_dependencyMap[0]).getSymbolSize;
  const FINDER_PATTERN_SIZE = 7;

  /**
   * Returns an array containing the positions of each finder pattern.
   * Each array's element represent the top-left point of the pattern as (x, y) coordinates
   *
   * @param  {Number} version QR Code version
   * @return {Array}          Array of coordinates
   */
  exports.getPositions = function getPositions(version) {
    const size = getSymbolSize(version);
    return [
    // top-left
    [0, 0],
    // top-right
    [size - FINDER_PATTERN_SIZE, 0],
    // bottom-left
    [0, size - FINDER_PATTERN_SIZE]];
  };
},1237,[1232]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Data mask pattern reference
   * @type {Object}
   */
  exports.Patterns = {
    PATTERN000: 0,
    PATTERN001: 1,
    PATTERN010: 2,
    PATTERN011: 3,
    PATTERN100: 4,
    PATTERN101: 5,
    PATTERN110: 6,
    PATTERN111: 7
  };

  /**
   * Weighted penalty scores for the undesirable features
   * @type {Object}
   */
  const PenaltyScores = {
    N1: 3,
    N2: 3,
    N3: 40,
    N4: 10
  };

  /**
   * Check if mask pattern value is valid
   *
   * @param  {Number}  mask    Mask pattern
   * @return {Boolean}         true if valid, false otherwise
   */
  exports.isValid = function isValid(mask) {
    return mask != null && mask !== '' && !isNaN(mask) && mask >= 0 && mask <= 7;
  };

  /**
   * Returns mask pattern from a value.
   * If value is not valid, returns undefined
   *
   * @param  {Number|String} value        Mask pattern value
   * @return {Number}                     Valid mask pattern or undefined
   */
  exports.from = function from(value) {
    return exports.isValid(value) ? parseInt(value, 10) : undefined;
  };

  /**
  * Find adjacent modules in row/column with the same color
  * and assign a penalty value.
  *
  * Points: N1 + i
  * i is the amount by which the number of adjacent modules of the same color exceeds 5
  */
  exports.getPenaltyN1 = function getPenaltyN1(data) {
    const size = data.size;
    let points = 0;
    let sameCountCol = 0;
    let sameCountRow = 0;
    let lastCol = null;
    let lastRow = null;
    for (let row = 0; row < size; row++) {
      sameCountCol = sameCountRow = 0;
      lastCol = lastRow = null;
      for (let col = 0; col < size; col++) {
        let module = data.get(row, col);
        if (module === lastCol) {
          sameCountCol++;
        } else {
          if (sameCountCol >= 5) points += PenaltyScores.N1 + (sameCountCol - 5);
          lastCol = module;
          sameCountCol = 1;
        }
        module = data.get(col, row);
        if (module === lastRow) {
          sameCountRow++;
        } else {
          if (sameCountRow >= 5) points += PenaltyScores.N1 + (sameCountRow - 5);
          lastRow = module;
          sameCountRow = 1;
        }
      }
      if (sameCountCol >= 5) points += PenaltyScores.N1 + (sameCountCol - 5);
      if (sameCountRow >= 5) points += PenaltyScores.N1 + (sameCountRow - 5);
    }
    return points;
  };

  /**
   * Find 2x2 blocks with the same color and assign a penalty value
   *
   * Points: N2 * (m - 1) * (n - 1)
   */
  exports.getPenaltyN2 = function getPenaltyN2(data) {
    const size = data.size;
    let points = 0;
    for (let row = 0; row < size - 1; row++) {
      for (let col = 0; col < size - 1; col++) {
        const last = data.get(row, col) + data.get(row, col + 1) + data.get(row + 1, col) + data.get(row + 1, col + 1);
        if (last === 4 || last === 0) points++;
      }
    }
    return points * PenaltyScores.N2;
  };

  /**
   * Find 1:1:3:1:1 ratio (dark:light:dark:light:dark) pattern in row/column,
   * preceded or followed by light area 4 modules wide
   *
   * Points: N3 * number of pattern found
   */
  exports.getPenaltyN3 = function getPenaltyN3(data) {
    const size = data.size;
    let points = 0;
    let bitsCol = 0;
    let bitsRow = 0;
    for (let row = 0; row < size; row++) {
      bitsCol = bitsRow = 0;
      for (let col = 0; col < size; col++) {
        bitsCol = bitsCol << 1 & 0x7FF | data.get(row, col);
        if (col >= 10 && (bitsCol === 0x5D0 || bitsCol === 0x05D)) points++;
        bitsRow = bitsRow << 1 & 0x7FF | data.get(col, row);
        if (col >= 10 && (bitsRow === 0x5D0 || bitsRow === 0x05D)) points++;
      }
    }
    return points * PenaltyScores.N3;
  };

  /**
   * Calculate proportion of dark modules in entire symbol
   *
   * Points: N4 * k
   *
   * k is the rating of the deviation of the proportion of dark modules
   * in the symbol from 50% in steps of 5%
   */
  exports.getPenaltyN4 = function getPenaltyN4(data) {
    let darkCount = 0;
    const modulesCount = data.data.length;
    for (let i = 0; i < modulesCount; i++) darkCount += data.data[i];
    const k = Math.abs(Math.ceil(darkCount * 100 / modulesCount / 5) - 10);
    return k * PenaltyScores.N4;
  };

  /**
   * Return mask value at given position
   *
   * @param  {Number} maskPattern Pattern reference value
   * @param  {Number} i           Row
   * @param  {Number} j           Column
   * @return {Boolean}            Mask value
   */
  function getMaskAt(maskPattern, i, j) {
    switch (maskPattern) {
      case exports.Patterns.PATTERN000:
        return (i + j) % 2 === 0;
      case exports.Patterns.PATTERN001:
        return i % 2 === 0;
      case exports.Patterns.PATTERN010:
        return j % 3 === 0;
      case exports.Patterns.PATTERN011:
        return (i + j) % 3 === 0;
      case exports.Patterns.PATTERN100:
        return (Math.floor(i / 2) + Math.floor(j / 3)) % 2 === 0;
      case exports.Patterns.PATTERN101:
        return i * j % 2 + i * j % 3 === 0;
      case exports.Patterns.PATTERN110:
        return (i * j % 2 + i * j % 3) % 2 === 0;
      case exports.Patterns.PATTERN111:
        return (i * j % 3 + (i + j) % 2) % 2 === 0;
      default:
        throw new Error('bad maskPattern:' + maskPattern);
    }
  }

  /**
   * Apply a mask pattern to a BitMatrix
   *
   * @param  {Number}    pattern Pattern reference number
   * @param  {BitMatrix} data    BitMatrix data
   */
  exports.applyMask = function applyMask(pattern, data) {
    const size = data.size;
    for (let col = 0; col < size; col++) {
      for (let row = 0; row < size; row++) {
        if (data.isReserved(row, col)) continue;
        data.xor(row, col, getMaskAt(pattern, row, col));
      }
    }
  };

  /**
   * Returns the best mask pattern for data
   *
   * @param  {BitMatrix} data
   * @return {Number} Mask pattern reference number
   */
  exports.getBestMask = function getBestMask(data, setupFormatFunc) {
    const numPatterns = Object.keys(exports.Patterns).length;
    let bestPattern = 0;
    let lowerPenalty = Infinity;
    for (let p = 0; p < numPatterns; p++) {
      setupFormatFunc(p);
      exports.applyMask(p, data);

      // Calculate penalty
      const penalty = exports.getPenaltyN1(data) + exports.getPenaltyN2(data) + exports.getPenaltyN3(data) + exports.getPenaltyN4(data);

      // Undo previously applied mask
      exports.applyMask(p, data);
      if (penalty < lowerPenalty) {
        lowerPenalty = penalty;
        bestPattern = p;
      }
    }
    return bestPattern;
  };
},1238,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const ECLevel = require(_dependencyMap[0]);
  const EC_BLOCKS_TABLE = [
  // L  M  Q  H
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 2, 2, 4, 1, 2, 4, 4, 2, 4, 4, 4, 2, 4, 6, 5, 2, 4, 6, 6, 2, 5, 8, 8, 4, 5, 8, 8, 4, 5, 8, 11, 4, 8, 10, 11, 4, 9, 12, 16, 4, 9, 16, 16, 6, 10, 12, 18, 6, 10, 17, 16, 6, 11, 16, 19, 6, 13, 18, 21, 7, 14, 21, 25, 8, 16, 20, 25, 8, 17, 23, 25, 9, 17, 23, 34, 9, 18, 25, 30, 10, 20, 27, 32, 12, 21, 29, 35, 12, 23, 34, 37, 12, 25, 34, 40, 13, 26, 35, 42, 14, 28, 38, 45, 15, 29, 40, 48, 16, 31, 43, 51, 17, 33, 45, 54, 18, 35, 48, 57, 19, 37, 51, 60, 19, 38, 53, 63, 20, 40, 56, 66, 21, 43, 59, 70, 22, 45, 62, 74, 24, 47, 65, 77, 25, 49, 68, 81];
  const EC_CODEWORDS_TABLE = [
  // L  M  Q  H
  7, 10, 13, 17, 10, 16, 22, 28, 15, 26, 36, 44, 20, 36, 52, 64, 26, 48, 72, 88, 36, 64, 96, 112, 40, 72, 108, 130, 48, 88, 132, 156, 60, 110, 160, 192, 72, 130, 192, 224, 80, 150, 224, 264, 96, 176, 260, 308, 104, 198, 288, 352, 120, 216, 320, 384, 132, 240, 360, 432, 144, 280, 408, 480, 168, 308, 448, 532, 180, 338, 504, 588, 196, 364, 546, 650, 224, 416, 600, 700, 224, 442, 644, 750, 252, 476, 690, 816, 270, 504, 750, 900, 300, 560, 810, 960, 312, 588, 870, 1050, 336, 644, 952, 1110, 360, 700, 1020, 1200, 390, 728, 1050, 1260, 420, 784, 1140, 1350, 450, 812, 1200, 1440, 480, 868, 1290, 1530, 510, 924, 1350, 1620, 540, 980, 1440, 1710, 570, 1036, 1530, 1800, 570, 1064, 1590, 1890, 600, 1120, 1680, 1980, 630, 1204, 1770, 2100, 660, 1260, 1860, 2220, 720, 1316, 1950, 2310, 750, 1372, 2040, 2430];

  /**
   * Returns the number of error correction block that the QR Code should contain
   * for the specified version and error correction level.
   *
   * @param  {Number} version              QR Code version
   * @param  {Number} errorCorrectionLevel Error correction level
   * @return {Number}                      Number of error correction blocks
   */
  exports.getBlocksCount = function getBlocksCount(version, errorCorrectionLevel) {
    switch (errorCorrectionLevel) {
      case ECLevel.L:
        return EC_BLOCKS_TABLE[(version - 1) * 4 + 0];
      case ECLevel.M:
        return EC_BLOCKS_TABLE[(version - 1) * 4 + 1];
      case ECLevel.Q:
        return EC_BLOCKS_TABLE[(version - 1) * 4 + 2];
      case ECLevel.H:
        return EC_BLOCKS_TABLE[(version - 1) * 4 + 3];
      default:
        return undefined;
    }
  };

  /**
   * Returns the number of error correction codewords to use for the specified
   * version and error correction level.
   *
   * @param  {Number} version              QR Code version
   * @param  {Number} errorCorrectionLevel Error correction level
   * @return {Number}                      Number of error correction codewords
   */
  exports.getTotalCodewordsCount = function getTotalCodewordsCount(version, errorCorrectionLevel) {
    switch (errorCorrectionLevel) {
      case ECLevel.L:
        return EC_CODEWORDS_TABLE[(version - 1) * 4 + 0];
      case ECLevel.M:
        return EC_CODEWORDS_TABLE[(version - 1) * 4 + 1];
      case ECLevel.Q:
        return EC_CODEWORDS_TABLE[(version - 1) * 4 + 2];
      case ECLevel.H:
        return EC_CODEWORDS_TABLE[(version - 1) * 4 + 3];
      default:
        return undefined;
    }
  };
},1239,[1233]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const Polynomial = require(_dependencyMap[0]);
  function ReedSolomonEncoder(degree) {
    this.genPoly = undefined;
    this.degree = degree;
    if (this.degree) this.initialize(this.degree);
  }

  /**
   * Initialize the encoder.
   * The input param should correspond to the number of error correction codewords.
   *
   * @param  {Number} degree
   */
  ReedSolomonEncoder.prototype.initialize = function initialize(degree) {
    // create an irreducible generator polynomial
    this.degree = degree;
    this.genPoly = Polynomial.generateECPolynomial(this.degree);
  };

  /**
   * Encodes a chunk of data
   *
   * @param  {Uint8Array} data Buffer containing input data
   * @return {Uint8Array}      Buffer containing encoded data
   */
  ReedSolomonEncoder.prototype.encode = function encode(data) {
    if (!this.genPoly) {
      throw new Error('Encoder not initialized');
    }

    // Calculate EC for this data block
    // extends data size to data+genPoly size
    const paddedData = new Uint8Array(data.length + this.degree);
    paddedData.set(data);

    // The error correction codewords are the remainder after dividing the data codewords
    // by a generator polynomial
    const remainder = Polynomial.mod(paddedData, this.genPoly);

    // return EC data blocks (last n byte, where n is the degree of genPoly)
    // If coefficients number in remainder are less than genPoly degree,
    // pad with 0s to the left to reach the needed number of coefficients
    const start = this.degree - remainder.length;
    if (start > 0) {
      const buff = new Uint8Array(this.degree);
      buff.set(remainder, start);
      return buff;
    }
    return remainder;
  };
  module.exports = ReedSolomonEncoder;
},1240,[1241]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const GF = require(_dependencyMap[0]);

  /**
   * Multiplies two polynomials inside Galois Field
   *
   * @param  {Uint8Array} p1 Polynomial
   * @param  {Uint8Array} p2 Polynomial
   * @return {Uint8Array}    Product of p1 and p2
   */
  exports.mul = function mul(p1, p2) {
    const coeff = new Uint8Array(p1.length + p2.length - 1);
    for (let i = 0; i < p1.length; i++) {
      for (let j = 0; j < p2.length; j++) {
        coeff[i + j] ^= GF.mul(p1[i], p2[j]);
      }
    }
    return coeff;
  };

  /**
   * Calculate the remainder of polynomials division
   *
   * @param  {Uint8Array} divident Polynomial
   * @param  {Uint8Array} divisor  Polynomial
   * @return {Uint8Array}          Remainder
   */
  exports.mod = function mod(divident, divisor) {
    let result = new Uint8Array(divident);
    while (result.length - divisor.length >= 0) {
      const coeff = result[0];
      for (let i = 0; i < divisor.length; i++) {
        result[i] ^= GF.mul(divisor[i], coeff);
      }

      // remove all zeros from buffer head
      let offset = 0;
      while (offset < result.length && result[offset] === 0) offset++;
      result = result.slice(offset);
    }
    return result;
  };

  /**
   * Generate an irreducible generator polynomial of specified degree
   * (used by Reed-Solomon encoder)
   *
   * @param  {Number} degree Degree of the generator polynomial
   * @return {Uint8Array}    Buffer containing polynomial coefficients
   */
  exports.generateECPolynomial = function generateECPolynomial(degree) {
    let poly = new Uint8Array([1]);
    for (let i = 0; i < degree; i++) {
      poly = exports.mul(poly, new Uint8Array([1, GF.exp(i)]));
    }
    return poly;
  };
},1241,[1242]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const EXP_TABLE = new Uint8Array(512);
  const LOG_TABLE = new Uint8Array(256)
  /**
   * Precompute the log and anti-log tables for faster computation later
   *
   * For each possible value in the galois field 2^8, we will pre-compute
   * the logarithm and anti-logarithm (exponential) of this value
   *
   * ref {@link https://en.wikiversity.org/wiki/Reed%E2%80%93Solomon_codes_for_coders#Introduction_to_mathematical_fields}
   */;
  (function initTables() {
    let x = 1;
    for (let i = 0; i < 255; i++) {
      EXP_TABLE[i] = x;
      LOG_TABLE[x] = i;
      x <<= 1; // multiply by 2

      // The QR code specification says to use byte-wise modulo 100011101 arithmetic.
      // This means that when a number is 256 or larger, it should be XORed with 0x11D.
      if (x & 0x100) {
        // similar to x >= 256, but a lot faster (because 0x100 == 256)
        x ^= 0x11D;
      }
    }

    // Optimization: double the size of the anti-log table so that we don't need to mod 255 to
    // stay inside the bounds (because we will mainly use this table for the multiplication of
    // two GF numbers, no more).
    // @see {@link mul}
    for (let i = 255; i < 512; i++) {
      EXP_TABLE[i] = EXP_TABLE[i - 255];
    }
  })();

  /**
   * Returns log value of n inside Galois Field
   *
   * @param  {Number} n
   * @return {Number}
   */
  exports.log = function log(n) {
    if (n < 1) throw new Error('log(' + n + ')');
    return LOG_TABLE[n];
  };

  /**
   * Returns anti-log value of n inside Galois Field
   *
   * @param  {Number} n
   * @return {Number}
   */
  exports.exp = function exp(n) {
    return EXP_TABLE[n];
  };

  /**
   * Multiplies two number inside Galois Field
   *
   * @param  {Number} x
   * @param  {Number} y
   * @return {Number}
   */
  exports.mul = function mul(x, y) {
    if (x === 0 || y === 0) return 0;

    // should be EXP_TABLE[(LOG_TABLE[x] + LOG_TABLE[y]) % 255] if EXP_TABLE wasn't oversized
    // @see {@link initTables}
    return EXP_TABLE[LOG_TABLE[x] + LOG_TABLE[y]];
  };
},1242,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const Utils = require(_dependencyMap[0]);
  const ECCode = require(_dependencyMap[1]);
  const ECLevel = require(_dependencyMap[2]);
  const Mode = require(_dependencyMap[3]);
  const VersionCheck = require(_dependencyMap[4]);

  // Generator polynomial used to encode version information
  const G18 = 7973;
  const G18_BCH = Utils.getBCHDigit(G18);
  function getBestVersionForDataLength(mode, length, errorCorrectionLevel) {
    for (let currentVersion = 1; currentVersion <= 40; currentVersion++) {
      if (length <= exports.getCapacity(currentVersion, errorCorrectionLevel, mode)) {
        return currentVersion;
      }
    }
    return undefined;
  }
  function getReservedBitsCount(mode, version) {
    // Character count indicator + mode indicator bits
    return Mode.getCharCountIndicator(mode, version) + 4;
  }
  function getTotalBitsFromDataArray(segments, version) {
    let totalBits = 0;
    segments.forEach(function (data) {
      const reservedBits = getReservedBitsCount(data.mode, version);
      totalBits += reservedBits + data.getBitsLength();
    });
    return totalBits;
  }
  function getBestVersionForMixedData(segments, errorCorrectionLevel) {
    for (let currentVersion = 1; currentVersion <= 40; currentVersion++) {
      const length = getTotalBitsFromDataArray(segments, currentVersion);
      if (length <= exports.getCapacity(currentVersion, errorCorrectionLevel, Mode.MIXED)) {
        return currentVersion;
      }
    }
    return undefined;
  }

  /**
   * Returns version number from a value.
   * If value is not a valid version, returns defaultValue
   *
   * @param  {Number|String} value        QR Code version
   * @param  {Number}        defaultValue Fallback value
   * @return {Number}                     QR Code version number
   */
  exports.from = function from(value, defaultValue) {
    if (VersionCheck.isValid(value)) {
      return parseInt(value, 10);
    }
    return defaultValue;
  };

  /**
   * Returns how much data can be stored with the specified QR code version
   * and error correction level
   *
   * @param  {Number} version              QR Code version (1-40)
   * @param  {Number} errorCorrectionLevel Error correction level
   * @param  {Mode}   mode                 Data mode
   * @return {Number}                      Quantity of storable data
   */
  exports.getCapacity = function getCapacity(version, errorCorrectionLevel, mode) {
    if (!VersionCheck.isValid(version)) {
      throw new Error('Invalid QR Code version');
    }

    // Use Byte mode as default
    if (typeof mode === 'undefined') mode = Mode.BYTE;

    // Total codewords for this QR code version (Data + Error correction)
    const totalCodewords = Utils.getSymbolTotalCodewords(version);

    // Total number of error correction codewords
    const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);

    // Total number of data codewords
    const dataTotalCodewordsBits = (totalCodewords - ecTotalCodewords) * 8;
    if (mode === Mode.MIXED) return dataTotalCodewordsBits;
    const usableBits = dataTotalCodewordsBits - getReservedBitsCount(mode, version);

    // Return max number of storable codewords
    switch (mode) {
      case Mode.NUMERIC:
        return Math.floor(usableBits / 10 * 3);
      case Mode.ALPHANUMERIC:
        return Math.floor(usableBits / 11 * 2);
      case Mode.KANJI:
        return Math.floor(usableBits / 13);
      case Mode.BYTE:
      default:
        return Math.floor(usableBits / 8);
    }
  };

  /**
   * Returns the minimum version needed to contain the amount of data
   *
   * @param  {Segment} data                    Segment of data
   * @param  {Number} [errorCorrectionLevel=H] Error correction level
   * @param  {Mode} mode                       Data mode
   * @return {Number}                          QR Code version
   */
  exports.getBestVersionForData = function getBestVersionForData(data, errorCorrectionLevel) {
    let seg;
    const ecl = ECLevel.from(errorCorrectionLevel, ECLevel.M);
    if (Array.isArray(data)) {
      if (data.length > 1) {
        return getBestVersionForMixedData(data, ecl);
      }
      if (data.length === 0) {
        return 1;
      }
      seg = data[0];
    } else {
      seg = data;
    }
    return getBestVersionForDataLength(seg.mode, seg.getLength(), ecl);
  };

  /**
   * Returns version information with relative error correction bits
   *
   * The version information is included in QR Code symbols of version 7 or larger.
   * It consists of an 18-bit sequence containing 6 data bits,
   * with 12 error correction bits calculated using the (18, 6) Golay code.
   *
   * @param  {Number} version QR Code version
   * @return {Number}         Encoded version info bits
   */
  exports.getEncodedBits = function getEncodedBits(version) {
    if (!VersionCheck.isValid(version) || version < 7) {
      throw new Error('Invalid QR Code version');
    }
    let d = version << 12;
    while (Utils.getBCHDigit(d) - G18_BCH >= 0) {
      d ^= G18 << Utils.getBCHDigit(d) - G18_BCH;
    }
    return version << 12 | d;
  };
},1243,[1232,1239,1233,1244,1245]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const VersionCheck = require(_dependencyMap[0]);
  const Regex = require(_dependencyMap[1]);

  /**
   * Numeric mode encodes data from the decimal digit set (0 - 9)
   * (byte values 30HEX to 39HEX).
   * Normally, 3 data characters are represented by 10 bits.
   *
   * @type {Object}
   */
  exports.NUMERIC = {
    id: 'Numeric',
    bit: 1,
    ccBits: [10, 12, 14]
  };

  /**
   * Alphanumeric mode encodes data from a set of 45 characters,
   * i.e. 10 numeric digits (0 - 9),
   *      26 alphabetic characters (A - Z),
   *   and 9 symbols (SP, $, %, *, +, -, ., /, :).
   * Normally, two input characters are represented by 11 bits.
   *
   * @type {Object}
   */
  exports.ALPHANUMERIC = {
    id: 'Alphanumeric',
    bit: 2,
    ccBits: [9, 11, 13]
  };

  /**
   * In byte mode, data is encoded at 8 bits per character.
   *
   * @type {Object}
   */
  exports.BYTE = {
    id: 'Byte',
    bit: 4,
    ccBits: [8, 16, 16]
  };

  /**
   * The Kanji mode efficiently encodes Kanji characters in accordance with
   * the Shift JIS system based on JIS X 0208.
   * The Shift JIS values are shifted from the JIS X 0208 values.
   * JIS X 0208 gives details of the shift coded representation.
   * Each two-byte character value is compacted to a 13-bit binary codeword.
   *
   * @type {Object}
   */
  exports.KANJI = {
    id: 'Kanji',
    bit: 8,
    ccBits: [8, 10, 12]
  };

  /**
   * Mixed mode will contain a sequences of data in a combination of any of
   * the modes described above
   *
   * @type {Object}
   */
  exports.MIXED = {
    bit: -1
  };

  /**
   * Returns the number of bits needed to store the data length
   * according to QR Code specifications.
   *
   * @param  {Mode}   mode    Data mode
   * @param  {Number} version QR Code version
   * @return {Number}         Number of bits
   */
  exports.getCharCountIndicator = function getCharCountIndicator(mode, version) {
    if (!mode.ccBits) throw new Error('Invalid mode: ' + mode);
    if (!VersionCheck.isValid(version)) {
      throw new Error('Invalid version: ' + version);
    }
    if (version >= 1 && version < 10) return mode.ccBits[0];else if (version < 27) return mode.ccBits[1];
    return mode.ccBits[2];
  };

  /**
   * Returns the most efficient mode to store the specified data
   *
   * @param  {String} dataStr Input data string
   * @return {Mode}           Best mode
   */
  exports.getBestModeForData = function getBestModeForData(dataStr) {
    if (Regex.testNumeric(dataStr)) return exports.NUMERIC;else if (Regex.testAlphanumeric(dataStr)) return exports.ALPHANUMERIC;else if (Regex.testKanji(dataStr)) return exports.KANJI;else return exports.BYTE;
  };

  /**
   * Return mode name as string
   *
   * @param {Mode} mode Mode object
   * @returns {String}  Mode name
   */
  exports.toString = function toString(mode) {
    if (mode && mode.id) return mode.id;
    throw new Error('Invalid mode');
  };

  /**
   * Check if input param is a valid mode object
   *
   * @param   {Mode}    mode Mode object
   * @returns {Boolean} True if valid mode, false otherwise
   */
  exports.isValid = function isValid(mode) {
    return mode && mode.bit && mode.ccBits;
  };

  /**
   * Get mode object from its name
   *
   * @param   {String} string Mode name
   * @returns {Mode}          Mode object
   */
  function fromString(string) {
    if (typeof string !== 'string') {
      throw new Error('Param is not a string');
    }
    const lcStr = string.toLowerCase();
    switch (lcStr) {
      case 'numeric':
        return exports.NUMERIC;
      case 'alphanumeric':
        return exports.ALPHANUMERIC;
      case 'kanji':
        return exports.KANJI;
      case 'byte':
        return exports.BYTE;
      default:
        throw new Error('Unknown mode: ' + string);
    }
  }

  /**
   * Returns mode from a value.
   * If value is not a valid mode, returns defaultValue
   *
   * @param  {Mode|String} value        Encoding mode
   * @param  {Mode}        defaultValue Fallback value
   * @return {Mode}                     Encoding mode
   */
  exports.from = function from(value, defaultValue) {
    if (exports.isValid(value)) {
      return value;
    }
    try {
      return fromString(value);
    } catch (e) {
      return defaultValue;
    }
  };
},1244,[1245,1246]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Check if QR Code version is valid
   *
   * @param  {Number}  version QR Code version
   * @return {Boolean}         true if valid version, false otherwise
   */
  exports.isValid = function isValid(version) {
    return !isNaN(version) && version >= 1 && version <= 40;
  };
},1245,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const numeric = '[0-9]+';
  const alphanumeric = '[A-Z $%*+\\-./:]+';
  let kanji = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";
  kanji = kanji.replace(/u/g, '\\u');
  const byte = '(?:(?![A-Z0-9 $%*+\\-./:]|' + kanji + ')(?:.|[\r\n]))+';
  exports.KANJI = new RegExp(kanji, 'g');
  exports.BYTE_KANJI = new RegExp('[^A-Z0-9 $%*+\\-./:]+', 'g');
  exports.BYTE = new RegExp(byte, 'g');
  exports.NUMERIC = new RegExp(numeric, 'g');
  exports.ALPHANUMERIC = new RegExp(alphanumeric, 'g');
  const TEST_KANJI = new RegExp('^' + kanji + '$');
  const TEST_NUMERIC = new RegExp("^[0-9]+$");
  const TEST_ALPHANUMERIC = new RegExp('^[A-Z0-9 $%*+\\-./:]+$');
  exports.testKanji = function testKanji(str) {
    return TEST_KANJI.test(str);
  };
  exports.testNumeric = function testNumeric(str) {
    return TEST_NUMERIC.test(str);
  };
  exports.testAlphanumeric = function testAlphanumeric(str) {
    return TEST_ALPHANUMERIC.test(str);
  };
},1246,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const Utils = require(_dependencyMap[0]);
  const G15 = 1335;
  const G15_MASK = 21522;
  const G15_BCH = Utils.getBCHDigit(G15);

  /**
   * Returns format information with relative error correction bits
   *
   * The format information is a 15-bit sequence containing 5 data bits,
   * with 10 error correction bits calculated using the (15, 5) BCH code.
   *
   * @param  {Number} errorCorrectionLevel Error correction level
   * @param  {Number} mask                 Mask pattern
   * @return {Number}                      Encoded format information bits
   */
  exports.getEncodedBits = function getEncodedBits(errorCorrectionLevel, mask) {
    const data = errorCorrectionLevel.bit << 3 | mask;
    let d = data << 10;
    while (Utils.getBCHDigit(d) - G15_BCH >= 0) {
      d ^= G15 << Utils.getBCHDigit(d) - G15_BCH;
    }

    // xor final data with mask pattern in order to ensure that
    // no combination of Error Correction Level and data mask pattern
    // will result in an all-zero data string
    return (data << 10 | d) ^ G15_MASK;
  };
},1247,[1232]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const Mode = require(_dependencyMap[0]);
  const NumericData = require(_dependencyMap[1]);
  const AlphanumericData = require(_dependencyMap[2]);
  const ByteData = require(_dependencyMap[3]);
  const KanjiData = require(_dependencyMap[4]);
  const Regex = require(_dependencyMap[5]);
  const Utils = require(_dependencyMap[6]);
  const dijkstra = require(_dependencyMap[7]);

  /**
   * Returns UTF8 byte length
   *
   * @param  {String} str Input string
   * @return {Number}     Number of byte
   */
  function getStringByteLength(str) {
    return unescape(encodeURIComponent(str)).length;
  }

  /**
   * Get a list of segments of the specified mode
   * from a string
   *
   * @param  {Mode}   mode Segment mode
   * @param  {String} str  String to process
   * @return {Array}       Array of object with segments data
   */
  function getSegments(regex, mode, str) {
    const segments = [];
    let result;
    while ((result = regex.exec(str)) !== null) {
      segments.push({
        data: result[0],
        index: result.index,
        mode: mode,
        length: result[0].length
      });
    }
    return segments;
  }

  /**
   * Extracts a series of segments with the appropriate
   * modes from a string
   *
   * @param  {String} dataStr Input string
   * @return {Array}          Array of object with segments data
   */
  function getSegmentsFromString(dataStr) {
    const numSegs = getSegments(Regex.NUMERIC, Mode.NUMERIC, dataStr);
    const alphaNumSegs = getSegments(Regex.ALPHANUMERIC, Mode.ALPHANUMERIC, dataStr);
    let byteSegs;
    let kanjiSegs;
    if (Utils.isKanjiModeEnabled()) {
      byteSegs = getSegments(Regex.BYTE, Mode.BYTE, dataStr);
      kanjiSegs = getSegments(Regex.KANJI, Mode.KANJI, dataStr);
    } else {
      byteSegs = getSegments(Regex.BYTE_KANJI, Mode.BYTE, dataStr);
      kanjiSegs = [];
    }
    const segs = numSegs.concat(alphaNumSegs, byteSegs, kanjiSegs);
    return segs.sort(function (s1, s2) {
      return s1.index - s2.index;
    }).map(function (obj) {
      return {
        data: obj.data,
        mode: obj.mode,
        length: obj.length
      };
    });
  }

  /**
   * Returns how many bits are needed to encode a string of
   * specified length with the specified mode
   *
   * @param  {Number} length String length
   * @param  {Mode} mode     Segment mode
   * @return {Number}        Bit length
   */
  function getSegmentBitsLength(length, mode) {
    switch (mode) {
      case Mode.NUMERIC:
        return NumericData.getBitsLength(length);
      case Mode.ALPHANUMERIC:
        return AlphanumericData.getBitsLength(length);
      case Mode.KANJI:
        return KanjiData.getBitsLength(length);
      case Mode.BYTE:
        return ByteData.getBitsLength(length);
    }
  }

  /**
   * Merges adjacent segments which have the same mode
   *
   * @param  {Array} segs Array of object with segments data
   * @return {Array}      Array of object with segments data
   */
  function mergeSegments(segs) {
    return segs.reduce(function (acc, curr) {
      const prevSeg = acc.length - 1 >= 0 ? acc[acc.length - 1] : null;
      if (prevSeg && prevSeg.mode === curr.mode) {
        acc[acc.length - 1].data += curr.data;
        return acc;
      }
      acc.push(curr);
      return acc;
    }, []);
  }

  /**
   * Generates a list of all possible nodes combination which
   * will be used to build a segments graph.
   *
   * Nodes are divided by groups. Each group will contain a list of all the modes
   * in which is possible to encode the given text.
   *
   * For example the text '12345' can be encoded as Numeric, Alphanumeric or Byte.
   * The group for '12345' will contain then 3 objects, one for each
   * possible encoding mode.
   *
   * Each node represents a possible segment.
   *
   * @param  {Array} segs Array of object with segments data
   * @return {Array}      Array of object with segments data
   */
  function buildNodes(segs) {
    const nodes = [];
    for (let i = 0; i < segs.length; i++) {
      const seg = segs[i];
      switch (seg.mode) {
        case Mode.NUMERIC:
          nodes.push([seg, {
            data: seg.data,
            mode: Mode.ALPHANUMERIC,
            length: seg.length
          }, {
            data: seg.data,
            mode: Mode.BYTE,
            length: seg.length
          }]);
          break;
        case Mode.ALPHANUMERIC:
          nodes.push([seg, {
            data: seg.data,
            mode: Mode.BYTE,
            length: seg.length
          }]);
          break;
        case Mode.KANJI:
          nodes.push([seg, {
            data: seg.data,
            mode: Mode.BYTE,
            length: getStringByteLength(seg.data)
          }]);
          break;
        case Mode.BYTE:
          nodes.push([{
            data: seg.data,
            mode: Mode.BYTE,
            length: getStringByteLength(seg.data)
          }]);
      }
    }
    return nodes;
  }

  /**
   * Builds a graph from a list of nodes.
   * All segments in each node group will be connected with all the segments of
   * the next group and so on.
   *
   * At each connection will be assigned a weight depending on the
   * segment's byte length.
   *
   * @param  {Array} nodes    Array of object with segments data
   * @param  {Number} version QR Code version
   * @return {Object}         Graph of all possible segments
   */
  function buildGraph(nodes, version) {
    const table = {};
    const graph = {
      start: {}
    };
    let prevNodeIds = ['start'];
    for (let i = 0; i < nodes.length; i++) {
      const nodeGroup = nodes[i];
      const currentNodeIds = [];
      for (let j = 0; j < nodeGroup.length; j++) {
        const node = nodeGroup[j];
        const key = '' + i + j;
        currentNodeIds.push(key);
        table[key] = {
          node: node,
          lastCount: 0
        };
        graph[key] = {};
        for (let n = 0; n < prevNodeIds.length; n++) {
          const prevNodeId = prevNodeIds[n];
          if (table[prevNodeId] && table[prevNodeId].node.mode === node.mode) {
            graph[prevNodeId][key] = getSegmentBitsLength(table[prevNodeId].lastCount + node.length, node.mode) - getSegmentBitsLength(table[prevNodeId].lastCount, node.mode);
            table[prevNodeId].lastCount += node.length;
          } else {
            if (table[prevNodeId]) table[prevNodeId].lastCount = node.length;
            graph[prevNodeId][key] = getSegmentBitsLength(node.length, node.mode) + 4 + Mode.getCharCountIndicator(node.mode, version); // switch cost
          }
        }
      }
      prevNodeIds = currentNodeIds;
    }
    for (let n = 0; n < prevNodeIds.length; n++) {
      graph[prevNodeIds[n]].end = 0;
    }
    return {
      map: graph,
      table: table
    };
  }

  /**
   * Builds a segment from a specified data and mode.
   * If a mode is not specified, the more suitable will be used.
   *
   * @param  {String} data             Input data
   * @param  {Mode | String} modesHint Data mode
   * @return {Segment}                 Segment
   */
  function buildSingleSegment(data, modesHint) {
    let mode;
    const bestMode = Mode.getBestModeForData(data);
    mode = Mode.from(modesHint, bestMode);

    // Make sure data can be encoded
    if (mode !== Mode.BYTE && mode.bit < bestMode.bit) {
      throw new Error('"' + data + '"' + ' cannot be encoded with mode ' + Mode.toString(mode) + '.\n Suggested mode is: ' + Mode.toString(bestMode));
    }

    // Use Mode.BYTE if Kanji support is disabled
    if (mode === Mode.KANJI && !Utils.isKanjiModeEnabled()) {
      mode = Mode.BYTE;
    }
    switch (mode) {
      case Mode.NUMERIC:
        return new NumericData(data);
      case Mode.ALPHANUMERIC:
        return new AlphanumericData(data);
      case Mode.KANJI:
        return new KanjiData(data);
      case Mode.BYTE:
        return new ByteData(data);
    }
  }

  /**
   * Builds a list of segments from an array.
   * Array can contain Strings or Objects with segment's info.
   *
   * For each item which is a string, will be generated a segment with the given
   * string and the more appropriate encoding mode.
   *
   * For each item which is an object, will be generated a segment with the given
   * data and mode.
   * Objects must contain at least the property "data".
   * If property "mode" is not present, the more suitable mode will be used.
   *
   * @param  {Array} array Array of objects with segments data
   * @return {Array}       Array of Segments
   */
  exports.fromArray = function fromArray(array) {
    return array.reduce(function (acc, seg) {
      if (typeof seg === 'string') {
        acc.push(buildSingleSegment(seg, null));
      } else if (seg.data) {
        acc.push(buildSingleSegment(seg.data, seg.mode));
      }
      return acc;
    }, []);
  };

  /**
   * Builds an optimized sequence of segments from a string,
   * which will produce the shortest possible bitstream.
   *
   * @param  {String} data    Input string
   * @param  {Number} version QR Code version
   * @return {Array}          Array of segments
   */
  exports.fromString = function fromString(data, version) {
    const segs = getSegmentsFromString(data, Utils.isKanjiModeEnabled());
    const nodes = buildNodes(segs);
    const graph = buildGraph(nodes, version);
    const path = dijkstra.find_path(graph.map, 'start', 'end');
    const optimizedSegs = [];
    for (let i = 1; i < path.length - 1; i++) {
      optimizedSegs.push(graph.table[path[i]].node);
    }
    return exports.fromArray(mergeSegments(optimizedSegs));
  };

  /**
   * Splits a string in various segments with the modes which
   * best represent their content.
   * The produced segments are far from being optimized.
   * The output of this function is only used to estimate a QR Code version
   * which may contain the data.
   *
   * @param  {string} data Input string
   * @return {Array}       Array of segments
   */
  exports.rawSplit = function rawSplit(data) {
    return exports.fromArray(getSegmentsFromString(data, Utils.isKanjiModeEnabled()));
  };
},1248,[1244,1249,1250,1251,1252,1246,1232,1253]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const Mode = require(_dependencyMap[0]);
  function NumericData(data) {
    this.mode = Mode.NUMERIC;
    this.data = data.toString();
  }
  NumericData.getBitsLength = function getBitsLength(length) {
    return 10 * Math.floor(length / 3) + (length % 3 ? length % 3 * 3 + 1 : 0);
  };
  NumericData.prototype.getLength = function getLength() {
    return this.data.length;
  };
  NumericData.prototype.getBitsLength = function getBitsLength() {
    return NumericData.getBitsLength(this.data.length);
  };
  NumericData.prototype.write = function write(bitBuffer) {
    let i, group, value;

    // The input data string is divided into groups of three digits,
    // and each group is converted to its 10-bit binary equivalent.
    for (i = 0; i + 3 <= this.data.length; i += 3) {
      group = this.data.substr(i, 3);
      value = parseInt(group, 10);
      bitBuffer.put(value, 10);
    }

    // If the number of input digits is not an exact multiple of three,
    // the final one or two digits are converted to 4 or 7 bits respectively.
    const remainingNum = this.data.length - i;
    if (remainingNum > 0) {
      group = this.data.substr(i);
      value = parseInt(group, 10);
      bitBuffer.put(value, remainingNum * 3 + 1);
    }
  };
  module.exports = NumericData;
},1249,[1244]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const Mode = require(_dependencyMap[0]);

  /**
   * Array of characters available in alphanumeric mode
   *
   * As per QR Code specification, to each character
   * is assigned a value from 0 to 44 which in this case coincides
   * with the array index
   *
   * @type {Array}
   */
  const ALPHA_NUM_CHARS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', ' ', '$', '%', '*', '+', '-', '.', '/', ':'];
  function AlphanumericData(data) {
    this.mode = Mode.ALPHANUMERIC;
    this.data = data;
  }
  AlphanumericData.getBitsLength = function getBitsLength(length) {
    return 11 * Math.floor(length / 2) + 6 * (length % 2);
  };
  AlphanumericData.prototype.getLength = function getLength() {
    return this.data.length;
  };
  AlphanumericData.prototype.getBitsLength = function getBitsLength() {
    return AlphanumericData.getBitsLength(this.data.length);
  };
  AlphanumericData.prototype.write = function write(bitBuffer) {
    let i;

    // Input data characters are divided into groups of two characters
    // and encoded as 11-bit binary codes.
    for (i = 0; i + 2 <= this.data.length; i += 2) {
      // The character value of the first character is multiplied by 45
      let value = ALPHA_NUM_CHARS.indexOf(this.data[i]) * 45;

      // The character value of the second digit is added to the product
      value += ALPHA_NUM_CHARS.indexOf(this.data[i + 1]);

      // The sum is then stored as 11-bit binary number
      bitBuffer.put(value, 11);
    }

    // If the number of input data characters is not a multiple of two,
    // the character value of the final character is encoded as a 6-bit binary number.
    if (this.data.length % 2) {
      bitBuffer.put(ALPHA_NUM_CHARS.indexOf(this.data[i]), 6);
    }
  };
  module.exports = AlphanumericData;
},1250,[1244]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const Mode = require(_dependencyMap[0]);
  function ByteData(data) {
    this.mode = Mode.BYTE;
    if (typeof data === 'string') {
      this.data = new TextEncoder().encode(data);
    } else {
      this.data = new Uint8Array(data);
    }
  }
  ByteData.getBitsLength = function getBitsLength(length) {
    return length * 8;
  };
  ByteData.prototype.getLength = function getLength() {
    return this.data.length;
  };
  ByteData.prototype.getBitsLength = function getBitsLength() {
    return ByteData.getBitsLength(this.data.length);
  };
  ByteData.prototype.write = function (bitBuffer) {
    for (let i = 0, l = this.data.length; i < l; i++) {
      bitBuffer.put(this.data[i], 8);
    }
  };
  module.exports = ByteData;
},1251,[1244]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const Mode = require(_dependencyMap[0]);
  const Utils = require(_dependencyMap[1]);
  function KanjiData(data) {
    this.mode = Mode.KANJI;
    this.data = data;
  }
  KanjiData.getBitsLength = function getBitsLength(length) {
    return length * 13;
  };
  KanjiData.prototype.getLength = function getLength() {
    return this.data.length;
  };
  KanjiData.prototype.getBitsLength = function getBitsLength() {
    return KanjiData.getBitsLength(this.data.length);
  };
  KanjiData.prototype.write = function (bitBuffer) {
    let i;

    // In the Shift JIS system, Kanji characters are represented by a two byte combination.
    // These byte values are shifted from the JIS X 0208 values.
    // JIS X 0208 gives details of the shift coded representation.
    for (i = 0; i < this.data.length; i++) {
      let value = Utils.toSJIS(this.data[i]);

      // For characters with Shift JIS values from 0x8140 to 0x9FFC:
      if (value >= 0x8140 && value <= 0x9FFC) {
        // Subtract 0x8140 from Shift JIS value
        value -= 0x8140;

        // For characters with Shift JIS values from 0xE040 to 0xEBBF
      } else if (value >= 0xE040 && value <= 0xEBBF) {
        // Subtract 0xC140 from Shift JIS value
        value -= 0xC140;
      } else {
        throw new Error('Invalid SJIS character: ' + this.data[i] + '\n' + 'Make sure your charset is UTF-8');
      }

      // Multiply most significant byte of result by 0xC0
      // and add least significant byte to product
      value = (value >>> 8 & 0xff) * 0xC0 + (value & 0xff);

      // Convert result to a 13-bit binary string
      bitBuffer.put(value, 13);
    }
  };
  module.exports = KanjiData;
},1252,[1244,1232]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  /******************************************************************************
   * Created 2008-08-19.
   *
   * Dijkstra path-finding functions. Adapted from the Dijkstar Python project.
   *
   * Copyright (C) 2008
   *   Wyatt Baldwin <self@wyattbaldwin.com>
   *   All rights reserved
   *
   * Licensed under the MIT license.
   *
   *   http://www.opensource.org/licenses/mit-license.php
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
   * THE SOFTWARE.
   *****************************************************************************/
  var dijkstra = {
    single_source_shortest_paths: function (graph, s, d) {
      // Predecessor map for each node that has been encountered.
      // node ID => predecessor node ID
      var predecessors = {};

      // Costs of shortest paths from s to all nodes encountered.
      // node ID => cost
      var costs = {};
      costs[s] = 0;

      // Costs of shortest paths from s to all nodes encountered; differs from
      // `costs` in that it provides easy access to the node that currently has
      // the known shortest path from s.
      // XXX: Do we actually need both `costs` and `open`?
      var open = dijkstra.PriorityQueue.make();
      open.push(s, 0);
      var closest, u, v, cost_of_s_to_u, adjacent_nodes, cost_of_e, cost_of_s_to_u_plus_cost_of_e, cost_of_s_to_v, first_visit;
      while (!open.empty()) {
        // In the nodes remaining in graph that have a known cost from s,
        // find the node, u, that currently has the shortest path from s.
        closest = open.pop();
        u = closest.value;
        cost_of_s_to_u = closest.cost;

        // Get nodes adjacent to u...
        adjacent_nodes = graph[u] || {};

        // ...and explore the edges that connect u to those nodes, updating
        // the cost of the shortest paths to any or all of those nodes as
        // necessary. v is the node across the current edge from u.
        for (v in adjacent_nodes) {
          if (adjacent_nodes.hasOwnProperty(v)) {
            // Get the cost of the edge running from u to v.
            cost_of_e = adjacent_nodes[v];

            // Cost of s to u plus the cost of u to v across e--this is *a*
            // cost from s to v that may or may not be less than the current
            // known cost to v.
            cost_of_s_to_u_plus_cost_of_e = cost_of_s_to_u + cost_of_e;

            // If we haven't visited v yet OR if the current known cost from s to
            // v is greater than the new cost we just found (cost of s to u plus
            // cost of u to v across e), update v's cost in the cost list and
            // update v's predecessor in the predecessor list (it's now u).
            cost_of_s_to_v = costs[v];
            first_visit = typeof costs[v] === 'undefined';
            if (first_visit || cost_of_s_to_v > cost_of_s_to_u_plus_cost_of_e) {
              costs[v] = cost_of_s_to_u_plus_cost_of_e;
              open.push(v, cost_of_s_to_u_plus_cost_of_e);
              predecessors[v] = u;
            }
          }
        }
      }
      if (typeof d !== 'undefined' && typeof costs[d] === 'undefined') {
        var msg = ['Could not find a path from ', s, ' to ', d, '.'].join('');
        throw new Error(msg);
      }
      return predecessors;
    },
    extract_shortest_path_from_predecessor_list: function (predecessors, d) {
      var nodes = [];
      var u = d;
      var predecessor;
      while (u) {
        nodes.push(u);
        predecessor = predecessors[u];
        u = predecessors[u];
      }
      nodes.reverse();
      return nodes;
    },
    find_path: function (graph, s, d) {
      var predecessors = dijkstra.single_source_shortest_paths(graph, s, d);
      return dijkstra.extract_shortest_path_from_predecessor_list(predecessors, d);
    },
    /**
     * A very naive priority queue implementation.
     */
    PriorityQueue: {
      make: function (opts) {
        var T = dijkstra.PriorityQueue,
          t = {},
          key;
        opts = opts || {};
        for (key in T) {
          if (T.hasOwnProperty(key)) {
            t[key] = T[key];
          }
        }
        t.queue = [];
        t.sorter = opts.sorter || T.default_sorter;
        return t;
      },
      default_sorter: function (a, b) {
        return a.cost - b.cost;
      },
      /**
       * Add a new item to the queue and ensure the highest priority element
       * is at the front of the queue.
       */
      push: function (value, cost) {
        var item = {
          value: value,
          cost: cost
        };
        this.queue.push(item);
        this.queue.sort(this.sorter);
      },
      /**
       * Return the highest priority element in the queue.
       */
      pop: function () {
        return this.queue.shift();
      },
      empty: function () {
        return this.queue.length === 0;
      }
    }
  };

  // node.js module exports
  if (typeof module !== 'undefined') {
    module.exports = dijkstra;
  }
},1253,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const Utils = require(_dependencyMap[0]);
  function clearCanvas(ctx, canvas, size) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!canvas.style) canvas.style = {};
    canvas.height = size;
    canvas.width = size;
    canvas.style.height = size + 'px';
    canvas.style.width = size + 'px';
  }
  function getCanvasElement() {
    try {
      return document.createElement('canvas');
    } catch (e) {
      throw new Error('You need to specify a canvas element');
    }
  }
  exports.render = function render(qrData, canvas, options) {
    let opts = options;
    let canvasEl = canvas;
    if (typeof opts === 'undefined' && (!canvas || !canvas.getContext)) {
      opts = canvas;
      canvas = undefined;
    }
    if (!canvas) {
      canvasEl = getCanvasElement();
    }
    opts = Utils.getOptions(opts);
    const size = Utils.getImageWidth(qrData.modules.size, opts);
    const ctx = canvasEl.getContext('2d');
    const image = ctx.createImageData(size, size);
    Utils.qrToImageData(image.data, qrData, opts);
    clearCanvas(ctx, canvasEl, size);
    ctx.putImageData(image, 0, 0);
    return canvasEl;
  };
  exports.renderToDataURL = function renderToDataURL(qrData, canvas, options) {
    let opts = options;
    if (typeof opts === 'undefined' && (!canvas || !canvas.getContext)) {
      opts = canvas;
      canvas = undefined;
    }
    if (!opts) opts = {};
    const canvasEl = exports.render(qrData, canvas, opts);
    const type = opts.type || 'image/png';
    const rendererOpts = opts.rendererOpts || {};
    return canvasEl.toDataURL(type, rendererOpts.quality);
  };
},1254,[1255]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  function hex2rgba(hex) {
    if (typeof hex === 'number') {
      hex = hex.toString();
    }
    if (typeof hex !== 'string') {
      throw new Error('Color should be defined as hex string');
    }
    let hexCode = hex.slice().replace('#', '').split('');
    if (hexCode.length < 3 || hexCode.length === 5 || hexCode.length > 8) {
      throw new Error('Invalid hex color: ' + hex);
    }

    // Convert from short to long form (fff -> ffffff)
    if (hexCode.length === 3 || hexCode.length === 4) {
      hexCode = Array.prototype.concat.apply([], hexCode.map(function (c) {
        return [c, c];
      }));
    }

    // Add default alpha value
    if (hexCode.length === 6) hexCode.push('F', 'F');
    const hexValue = parseInt(hexCode.join(''), 16);
    return {
      r: hexValue >> 24 & 255,
      g: hexValue >> 16 & 255,
      b: hexValue >> 8 & 255,
      a: hexValue & 255,
      hex: '#' + hexCode.slice(0, 6).join('')
    };
  }
  exports.getOptions = function getOptions(options) {
    if (!options) options = {};
    if (!options.color) options.color = {};
    const margin = typeof options.margin === 'undefined' || options.margin === null || options.margin < 0 ? 4 : options.margin;
    const width = options.width && options.width >= 21 ? options.width : undefined;
    const scale = options.scale || 4;
    return {
      width: width,
      scale: width ? 4 : scale,
      margin: margin,
      color: {
        dark: hex2rgba(options.color.dark || '#000000ff'),
        light: hex2rgba(options.color.light || '#ffffffff')
      },
      type: options.type,
      rendererOpts: options.rendererOpts || {}
    };
  };
  exports.getScale = function getScale(qrSize, opts) {
    return opts.width && opts.width >= qrSize + opts.margin * 2 ? opts.width / (qrSize + opts.margin * 2) : opts.scale;
  };
  exports.getImageWidth = function getImageWidth(qrSize, opts) {
    const scale = exports.getScale(qrSize, opts);
    return Math.floor((qrSize + opts.margin * 2) * scale);
  };
  exports.qrToImageData = function qrToImageData(imgData, qr, opts) {
    const size = qr.modules.size;
    const data = qr.modules.data;
    const scale = exports.getScale(size, opts);
    const symbolSize = Math.floor((size + opts.margin * 2) * scale);
    const scaledMargin = opts.margin * scale;
    const palette = [opts.color.light, opts.color.dark];
    for (let i = 0; i < symbolSize; i++) {
      for (let j = 0; j < symbolSize; j++) {
        let posDst = (i * symbolSize + j) * 4;
        let pxColor = opts.color.light;
        if (i >= scaledMargin && j >= scaledMargin && i < symbolSize - scaledMargin && j < symbolSize - scaledMargin) {
          const iSrc = Math.floor((i - scaledMargin) / scale);
          const jSrc = Math.floor((j - scaledMargin) / scale);
          pxColor = palette[data[iSrc * size + jSrc] ? 1 : 0];
        }
        imgData[posDst++] = pxColor.r;
        imgData[posDst++] = pxColor.g;
        imgData[posDst++] = pxColor.b;
        imgData[posDst] = pxColor.a;
      }
    }
  };
},1255,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  const Utils = require(_dependencyMap[0]);
  function getColorAttrib(color, attrib) {
    const alpha = color.a / 255;
    const str = attrib + '="' + color.hex + '"';
    return alpha < 1 ? str + ' ' + attrib + '-opacity="' + alpha.toFixed(2).slice(1) + '"' : str;
  }
  function svgCmd(cmd, x, y) {
    let str = cmd + x;
    if (typeof y !== 'undefined') str += ' ' + y;
    return str;
  }
  function qrToPath(data, size, margin) {
    let path = '';
    let moveBy = 0;
    let newRow = false;
    let lineLength = 0;
    for (let i = 0; i < data.length; i++) {
      const col = Math.floor(i % size);
      const row = Math.floor(i / size);
      if (!col && !newRow) newRow = true;
      if (data[i]) {
        lineLength++;
        if (!(i > 0 && col > 0 && data[i - 1])) {
          path += newRow ? svgCmd('M', col + margin, 0.5 + row + margin) : svgCmd('m', moveBy, 0);
          moveBy = 0;
          newRow = false;
        }
        if (!(col + 1 < size && data[i + 1])) {
          path += svgCmd('h', lineLength);
          lineLength = 0;
        }
      } else {
        moveBy++;
      }
    }
    return path;
  }
  exports.render = function render(qrData, options, cb) {
    const opts = Utils.getOptions(options);
    const size = qrData.modules.size;
    const data = qrData.modules.data;
    const qrcodesize = size + opts.margin * 2;
    const bg = !opts.color.light.a ? '' : '<path ' + getColorAttrib(opts.color.light, 'fill') + ' d="M0 0h' + qrcodesize + 'v' + qrcodesize + 'H0z"/>';
    const path = '<path ' + getColorAttrib(opts.color.dark, 'stroke') + ' d="' + qrToPath(data, size, opts.margin) + '"/>';
    const viewBox = "viewBox=\"0 0 " + qrcodesize + ' ' + qrcodesize + '"';
    const width = !opts.width ? '' : 'width="' + opts.width + '" height="' + opts.width + '" ';
    const svgTag = '<svg xmlns="http://www.w3.org/2000/svg" ' + width + viewBox + ' shape-rendering="crispEdges">' + bg + path + '</svg>\n';
    if (typeof cb === 'function') {
      cb(null, svgTag);
    }
    return svgTag;
  };
},1256,[1255]);