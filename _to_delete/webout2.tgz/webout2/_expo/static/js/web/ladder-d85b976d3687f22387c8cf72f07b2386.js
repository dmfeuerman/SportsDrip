__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return LadderScreen;
    }
  });
  Object.defineProperty(exports, "TIER_LABEL", {
    enumerable: true,
    get: function () {
      return TIER_LABEL;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _firebaseFirestore = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[3]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsUi = require(_dependencyMap[7]);
  var _constantsTheme = require(_dependencyMap[8]);
  var theme = _interopDefault(_constantsTheme);
  var _contextAppContext = require(_dependencyMap[9]);
  var _hooksUseColors = require(_dependencyMap[10]);
  var _hooksUsePublicProfiles = require(_dependencyMap[11]);
  var _libExperiments = require(_dependencyMap[12]);
  var _libFirebase = require(_dependencyMap[13]);
  var _reactJsxRuntime = require(_dependencyMap[14]);
  const TIER_LABEL = {
    bronze: "Bronze",
    silver: "Silver",
    gold: "Gold",
    platinum: "Platinum",
    diamond: "Diamond"
  };

  /** This week's ladder cohort, framed as "players like you". Experimental (ladder_v1). */
  function LadderScreen() {
    const $ = (0, _reactCompilerRuntime.c)(36);
    const c = (0, _hooksUseColors.useColors)();
    const bottom = (0, _componentsUi.useBottomPad)(false);
    const {
      profile
    } = (0, _contextAppContext.useApp)();
    const arm = (0, _libExperiments.useExperiment)(_libExperiments.EXPERIMENTS.ladder, profile?.uid);
    const cohortId = profile?.ladder?.cohortId ?? null;
    const [cohort, setCohort] = (0, _react.useState)(null);
    let t0;
    let t1;
    if ($[0] !== cohortId) {
      t0 = () => {
        const db = (0, _libFirebase.getDb)();
        if (!db || !cohortId) {
          return;
        }
        return (0, _firebaseFirestore.onSnapshot)((0, _firebaseFirestore.doc)(db, "ladderCohorts", cohortId), s => setCohort(s.exists() ? s.data() : null), _temp);
      };
      t1 = [cohortId];
      $[0] = cohortId;
      $[1] = t0;
      $[2] = t1;
    } else {
      t0 = $[1];
      t1 = $[2];
    }
    (0, _react.useEffect)(t0, t1);
    let t2;
    if ($[3] !== cohort?.members) {
      t2 = cohort?.members ?? [];
      $[3] = cohort?.members;
      $[4] = t2;
    } else {
      t2 = $[4];
    }
    const ids = t2;
    const profiles = (0, _hooksUsePublicProfiles.usePublicProfiles)(ids);
    const tier = TIER_LABEL[profile?.ladder?.tier ?? "bronze"] ?? "Bronze";
    if (arm === _libExperiments.CONTROL || !cohort) {
      let t3;
      if ($[5] !== c.background) {
        t3 = {
          flex: 1,
          backgroundColor: c.background
        };
        $[5] = c.background;
        $[6] = t3;
      } else {
        t3 = $[6];
      }
      let t4;
      let t5;
      if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
          title: "Ladder",
          back: true
        });
        t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
          icon: "stairs-up",
          title: "Ladder opens Monday",
          body: "Play this week to get placed with players like you."
        });
        $[7] = t4;
        $[8] = t5;
      } else {
        t4 = $[7];
        t5 = $[8];
      }
      let t6;
      if ($[9] !== t3) {
        t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: t3,
          children: [t4, t5]
        });
        $[9] = t3;
        $[10] = t6;
      } else {
        t6 = $[10];
      }
      return t6;
    }
    let t3;
    if ($[11] !== c.background) {
      t3 = {
        flex: 1,
        backgroundColor: c.background
      };
      $[11] = c.background;
      $[12] = t3;
    } else {
      t3 = $[12];
    }
    const t4 = `${tier} ladder`;
    let t5;
    if ($[13] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
        title: t4,
        subtitle: "Players like you, this week",
        back: true
      });
      $[13] = t4;
      $[14] = t5;
    } else {
      t5 = $[14];
    }
    let t6;
    if ($[15] !== bottom) {
      t6 = {
        padding: 16,
        gap: 8,
        paddingBottom: bottom
      };
      $[15] = bottom;
      $[16] = t6;
    } else {
      t6 = $[16];
    }
    let t7;
    if ($[17] !== c.mutedForeground) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.sub, {
          color: c.mutedForeground
        }],
        children: "Top 3 move up, bottom 3 move down on Sunday night. Score = correct picks."
      });
      $[17] = c.mutedForeground;
      $[18] = t7;
    } else {
      t7 = $[18];
    }
    let t8;
    if ($[19] !== c.foreground || $[20] !== ids || $[21] !== profile?.uid || $[22] !== profiles) {
      let t9;
      if ($[24] !== c.foreground || $[25] !== profile?.uid || $[26] !== profiles) {
        t9 = u => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsUi.Card, {
          style: styles.row,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.name, {
              color: c.foreground,
              flex: 1
            }],
            numberOfLines: 1,
            children: u === profile?.uid ? "You" : profiles[u]?.displayName ?? "Player"
          }), u === profile?.uid ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
            label: "You",
            tone: "league"
          }) : null]
        }, u);
        $[24] = c.foreground;
        $[25] = profile?.uid;
        $[26] = profiles;
        $[27] = t9;
      } else {
        t9 = $[27];
      }
      t8 = ids.map(t9);
      $[19] = c.foreground;
      $[20] = ids;
      $[21] = profile?.uid;
      $[22] = profiles;
      $[23] = t8;
    } else {
      t8 = $[23];
    }
    let t9;
    if ($[28] !== t6 || $[29] !== t7 || $[30] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        contentContainerStyle: t6,
        children: [t7, t8]
      });
      $[28] = t6;
      $[29] = t7;
      $[30] = t8;
      $[31] = t9;
    } else {
      t9 = $[31];
    }
    let t10;
    if ($[32] !== t3 || $[33] !== t5 || $[34] !== t9) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t3,
        children: [t5, t9]
      });
      $[32] = t3;
      $[33] = t5;
      $[34] = t9;
      $[35] = t10;
    } else {
      t10 = $[35];
    }
    return t10;
  }
  function _temp() {}
  const styles = StyleSheet.default.create({
    row: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    name: theme.default.type.bodyStrong,
    sub: theme.default.type.caption
  });
},765,[815,905,12,133,28,188,109,836,874,837,819,1222,898,906,6]);