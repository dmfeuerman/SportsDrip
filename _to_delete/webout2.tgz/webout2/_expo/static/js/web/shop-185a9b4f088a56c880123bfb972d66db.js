__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return ShopScreen;
    }
  });
  var _expoVectorIcons = require(_dependencyMap[0]);
  var _libMotion = require(_dependencyMap[1]);
  var _expoRouter = require(_dependencyMap[2]);
  var _expoRouterReactNavigation = require(_dependencyMap[3]);
  var _react = require(_dependencyMap[4]);
  var _reactNativeWebDistExportsActivityIndicator = require(_dependencyMap[5]);
  var ActivityIndicator = _interopDefault(_reactNativeWebDistExportsActivityIndicator);
  var _reactNativeWebDistExportsFlatList = require(_dependencyMap[6]);
  var FlatList = _interopDefault(_reactNativeWebDistExportsFlatList);
  var _reactNativeWebDistExportsModal = require(_dependencyMap[7]);
  var Modal = _interopDefault(_reactNativeWebDistExportsModal);
  require(_dependencyMap[8]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[9]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[10]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[11]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[12]);
  var _reactNativeSafeAreaContext = require(_dependencyMap[13]);
  var _componentsAvatarDisplay = require(_dependencyMap[14]);
  var AvatarDisplay = _interopDefault(_componentsAvatarDisplay);
  var _componentsCartButton = require(_dependencyMap[15]);
  var CartButton = _interopDefault(_componentsCartButton);
  var _libAvatar3dSpec = require(_dependencyMap[16]);
  var _componentsClothingCard = require(_dependencyMap[17]);
  var ClothingCard = _interopDefault(_componentsClothingCard);
  var _componentsMoveCard = require(_dependencyMap[18]);
  var MoveCard = _interopDefault(_componentsMoveCard);
  var _componentsBackgroundCard = require(_dependencyMap[19]);
  var BackgroundCard = _interopDefault(_componentsBackgroundCard);
  var _componentsAvatarAvatarBackdrop = require(_dependencyMap[20]);
  var AvatarBackdrop = _interopDefault(_componentsAvatarAvatarBackdrop);
  var _componentsTokenBalance = require(_dependencyMap[21]);
  var TokenBalance = _interopDefault(_componentsTokenBalance);
  var _constantsAvatarOptions = require(_dependencyMap[22]);
  var _constantsMoves = require(_dependencyMap[23]);
  var _contextAppContext = require(_dependencyMap[24]);
  var _hooksUseCatalog = require(_dependencyMap[25]);
  var _componentsCartExitDialog = require(_dependencyMap[26]);
  var CartExitDialog = _interopDefault(_componentsCartExitDialog);
  var _componentsUi = require(_dependencyMap[27]);
  var _hooksUseCartItems = require(_dependencyMap[28]);
  var _contextCartContext = require(_dependencyMap[29]);
  var _hooksUseColors = require(_dependencyMap[30]);
  var _hooksUseMoves = require(_dependencyMap[31]);
  var _hooksUseBackgrounds = require(_dependencyMap[32]);
  var _typesCatalog = require(_dependencyMap[33]);
  var _reactJsxRuntime = require(_dependencyMap[34]);
  const ALL = "ALL";
  /** Not a catalog slot: dance moves, sold here like clothes. `/shop?tab=moves` opens on it. */
  const MOVES = "MOVES";
  /** Not a catalog slot either: scenes behind the character. `/shop?tab=backgrounds`. */
  const BACKDROPS = "BACKDROPS";
  /**
   * Store rewritten against the database-driven catalog.
   *
   * Previously this imported a hardcoded 15-item array, so shipping a new hat
   * meant a code change and an app release (AUDIT A4, requirement §14). It now
   * subscribes to `catalog/*`.
   *
   * Preview (§18) shows the item on the user's actual character with their real
   * appearance and the rest of their current outfit, not a generic mannequin.
   */
  function ShopScreen() {
    const colors = (0, _hooksUseColors.useColors)();
    const insets = (0, _reactNativeSafeAreaContext.useSafeAreaInsets)();
    const focused = (0, _expoRouter.useIsFocused)();
    const params = (0, _expoRouter.useLocalSearchParams)();
    const {
      balance,
      profile,
      inventory,
      equip,
      error,
      clearError,
      ownedMoves,
      loadout,
      purchaseMove,
      setLoadout,
      progress,
      ownedBackgrounds,
      background,
      purchaseBackground,
      setBackground
    } = (0, _contextAppContext.useApp)();
    const {
      backgrounds
    } = (0, _hooksUseBackgrounds.useBackgrounds)();
    const {
      items,
      byId,
      loading,
      error: catalogError
    } = (0, _hooksUseCatalog.useCatalog)();
    const {
      moves
    } = (0, _hooksUseMoves.useMoves)();
    const cart = (0, _contextCartContext.useCart)();
    const navigation = (0, _expoRouter.useNavigation)();
    const [slot, setSlot] = (0, _react.useState)(params.tab === "moves" ? MOVES : params.tab === "backgrounds" ? BACKDROPS : ALL);
    const [bgPreview, setBgPreview] = (0, _react.useState)(null);
    const [preview, setPreview] = (0, _react.useState)(null);
    const [busyId, setBusyId] = (0, _react.useState)(null);
    const [movePreview, setMovePreview] = (0, _react.useState)(null);
    const [play, setPlay] = (0, _react.useState)(null);
    const [moveNote, setMoveNote] = (0, _react.useState)(null);
    const topPad = 24;
    const bottomPad = 32;
    const owned = (0, _react.useMemo)(() => new Set(inventory), [inventory]);
    const equipped = profile?.equipped ?? {};
    const avatar = profile?.avatar ?? _constantsAvatarOptions.DEFAULT_AVATAR;
    const filtered = (0, _react.useMemo)(() => slot === ALL ? items : slot === MOVES || slot === BACKDROPS ? [] : items.filter(i => i.slot === slot), [items, slot]);
    // Everything for sale plus what you already own (free moves included), cheapest first.
    const moveList = (0, _react.useMemo)(() => moves.filter(m => m.forSale || ownedMoves.has(m.id)).sort((a, b) => a.price - b.price), [moves, ownedMoves]);
    const previewMove = (0, _react.useCallback)(m_0 => {
      setMovePreview(m_0);
      setPlay(p => ({
        id: m_0.id,
        n: (p?.n ?? 0) + 1
      }));
    }, []);
    const handleBuyMove = (0, _react.useCallback)(async m_1 => {
      setBusyId(m_1.id);
      const ok = await purchaseMove(m_1.id);
      setBusyId(null);
      if (ok) _libMotion.haptic.success();
      return ok;
    }, [purchaseMove]);
    const handleToggleMove = (0, _react.useCallback)(async m_2 => {
      _libMotion.haptic.tick();
      if (loadout.includes(m_2.id)) {
        if (loadout.length === 1) return setMoveNote("Keep at least one move on your dance button.");
        setMoveNote(null);
        setBusyId(m_2.id);
        await setLoadout(loadout.filter(x => x !== m_2.id));
      } else {
        if (loadout.length >= _constantsMoves.MAX_LOADOUT) return setMoveNote(`Your dance button holds ${_constantsMoves.MAX_LOADOUT} moves — remove one first.`);
        setMoveNote(null);
        setBusyId(m_2.id);
        await setLoadout([...loadout, m_2.id]);
      }
      setBusyId(null);
    }, [loadout, setLoadout]);

    // Everything you could own, cheapest first. Level-reward scenes are buyable now or free at their level.
    const backgroundList = (0, _react.useMemo)(() => backgrounds.filter(b_0 => b_0.forSale || b_0.levelReward || ownedBackgrounds.has(b_0.id)).sort((a_0, b_1) => a_0.price - b_1.price), [backgrounds, ownedBackgrounds]);
    const bgLocked = (0, _react.useCallback)(b_2 => !ownedBackgrounds.has(b_2.id) && (!!b_2.levelRequired && b_2.levelRequired > progress.level || !(b_2.price > 0)), [ownedBackgrounds, progress.level]);
    const handleBuyBackground = (0, _react.useCallback)(async b_3 => {
      setBusyId(b_3.id);
      const ok_0 = await purchaseBackground(b_3.id);
      setBusyId(null);
      if (ok_0) _libMotion.haptic.success();
      return ok_0;
    }, [purchaseBackground]);
    const handleUseBackground = (0, _react.useCallback)(async b_4 => {
      _libMotion.haptic.light();
      setBusyId(b_4.id);
      await setBackground(b_4.id);
      setBusyId(null);
    }, [setBackground]);
    const itemLocked = (0, _react.useCallback)(item => !owned.has(item.id) && (!!item.levelReward || !!item.levelRequired && item.levelRequired > progress.level), [owned, progress.level]);
    const handleCart = (0, _react.useCallback)(item_0 => {
      if (itemLocked(item_0)) {
        _libMotion.haptic.warning();
        return;
      }
      if (cart.toggle(item_0.id)) _libMotion.haptic.medium();else _libMotion.haptic.tick();
    }, [cart, itemLocked]);

    // ── cart ─────────────────────────────────────────────────────────────────
    const {
      count: cartCount
    } = (0, _hooksUseCartItems.useCartItems)();
    const [leaveAsk, setLeaveAsk] = (0, _react.useState)(false);
    const [leaving, setLeaving] = (0, _react.useState)(false);
    const pendingNav = (0, _react.useRef)(null);
    // Back button, swipe-back and Android back all land here while the cart has something in it.
    const allowLeave = (0, _expoRouterReactNavigation.usePreventRemove)(cartCount > 0 && !leaving, ({
      data
    }) => {
      // Checkout just emptied the cart and is navigating away: don't stop it.
      if (!cart.peekCount() || cart.justCheckedOut()) {
        allowLeave();
        navigation.dispatch(data.action);
        return;
      }
      pendingNav.current = data.action;
      _libMotion.haptic.warning();
      setLeaveAsk(true);
    });
    const goCheckout = () => {
      pendingNav.current = null;
      setLeaveAsk(false);
      _expoRouter.router.push({
        pathname: "/checkout",
        params: {
          from: "shop"
        }
      });
    };
    const leaveAnyway = () => {
      setLeaveAsk(false);
      setLeaving(true);
      allowLeave();
      if (pendingNav.current) navigation.dispatch(pendingNav.current);else if (_expoRouter.router.canGoBack()) _expoRouter.router.back();
    };
    const handleToggleEquip = (0, _react.useCallback)(async item_1 => {
      _libMotion.haptic.light();
      setBusyId(item_1.id);
      await equip(item_1.slot, equipped[item_1.slot] === item_1.id ? null : item_1.id);
      setBusyId(null);
    }, [equip, equipped]);

    // What the avatar looks like with the previewed item on. Purely local — no
    // write happens until the user actually buys or equips.
    const previewEquipped = (0, _react.useMemo)(() => preview ? {
      ...equipped,
      [preview.slot]: preview.id
    } : equipped, [preview, equipped]);
    const slotTabs = [ALL, ..._typesCatalog.SLOT_ORDER, MOVES, BACKDROPS];
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
      style: [styles.container, {
        backgroundColor: colors.background
      }],
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.header, {
          backgroundColor: colors.background,
          borderBottomColor: colors.border,
          paddingTop: 36
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.headerRow,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.BackButton, {}), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: {
              flex: 1
            },
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.title, {
                color: colors.foreground
              }],
              children: "Drip Shop"
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.subtitle, {
                color: colors.mutedForeground
              }],
              children: slot === MOVES ? `${ownedMoves.size} moves owned · ${loadout.length} of ${_constantsMoves.MAX_LOADOUT} on your dance button` : slot === BACKDROPS ? `${ownedBackgrounds.size} scenes owned · Level ${progress.level}` : `${owned.size} ${owned.size === 1 ? "item" : "items"} owned`
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.headerActions,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(CartButton.default, {
              from: "shop"
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TokenBalance.default, {
              tokens: balance
            })]
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.FilterPills, {
          value: slot,
          onChange: t => {
            setSlot(t);
            setMoveNote(null);
          },
          options: slotTabs.map(t_0 => ({
            value: t_0,
            label: t_0 === ALL ? "All" : t_0 === MOVES ? "Moves" : t_0 === BACKDROPS ? "Scenes" : _typesCatalog.SLOT_LABELS[t_0],
            icon: t_0 === ALL ? "hanger" : t_0 === MOVES ? "human-handsup" : t_0 === BACKDROPS ? "image-filter-hdr" : _typesCatalog.SLOT_ICONS[t_0]
          }))
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: "Customize Character",
          icon: "account-edit-outline",
          variant: "secondary",
          size: "sm",
          onPress: () => _expoRouter.router.push("/customize"),
          style: {
            marginHorizontal: 16,
            marginTop: 10
          }
        })]
      }), (error || catalogError) && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        style: [styles.banner, {
          backgroundColor: colors.destructive + "22",
          borderColor: colors.destructive
        }],
        onPress: clearError,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "alert-circle-outline",
          size: 15,
          color: colors.destructive
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.bannerText, {
            color: colors.destructive
          }],
          children: error ?? catalogError
        })]
      }), slot === MOVES && moveNote ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        style: [styles.banner, {
          backgroundColor: colors.alpha(colors.warning, 0.13),
          borderColor: colors.warning
        }],
        onPress: () => setMoveNote(null),
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "information-outline",
          size: 15,
          color: colors.warning
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.bannerText, {
            color: colors.warning
          }],
          children: moveNote
        })]
      }) : null, slot === BACKDROPS ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FlatList.default, {
        data: backgroundList,
        keyExtractor: b_5 => b_5.id,
        numColumns: 2,
        columnWrapperStyle: {
          gap: 10
        },
        contentContainerStyle: [styles.list, {
          paddingBottom: bottomPad,
          gap: 10
        }],
        showsVerticalScrollIndicator: false,
        renderItem: ({
          item: b_6
        }) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BackgroundCard.default, {
          bg: b_6,
          owned: ownedBackgrounds.has(b_6.id),
          inUse: background === b_6.id,
          level: progress.level,
          canAfford: balance >= b_6.price,
          busy: busyId === b_6.id,
          onBuy: () => void handleBuyBackground(b_6),
          onUse: () => void handleUseBackground(b_6),
          onPreview: () => setBgPreview(b_6)
        })
      }, "backdrops") : slot === MOVES ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FlatList.default, {
        data: moveList,
        keyExtractor: m_3 => m_3.id,
        contentContainerStyle: [styles.list, {
          paddingBottom: bottomPad
        }],
        showsVerticalScrollIndicator: false,
        renderItem: ({
          item: m_4
        }) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(MoveCard.default, {
          move: m_4,
          owned: ownedMoves.has(m_4.id),
          equipped: loadout.includes(m_4.id),
          canAfford: balance >= m_4.price,
          busy: busyId === m_4.id,
          onBuy: () => void handleBuyMove(m_4),
          onToggleEquip: () => void handleToggleMove(m_4),
          onPreview: () => previewMove(m_4)
        })
      }, "moves") : loading ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.loading,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
          color: colors.primary
        })
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FlatList.default, {
        data: filtered,
        keyExtractor: i_0 => i_0.id,
        contentContainerStyle: [styles.list, {
          paddingBottom: bottomPad
        }],
        showsVerticalScrollIndicator: false,
        initialNumToRender: 8,
        windowSize: 7,
        removeClippedSubviews: true,
        renderItem: ({
          item: item_2
        }) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ClothingCard.default, {
          item: item_2,
          owned: owned.has(item_2.id),
          equipped: equipped[item_2.slot] === item_2.id,
          canAfford: balance >= item_2.price,
          inCart: cart.has(item_2.id),
          busy: busyId === item_2.id,
          level: progress.level,
          onCart: () => handleCart(item_2),
          onToggleEquip: () => handleToggleEquip(item_2),
          onPreview: () => setPreview(item_2)
        }),
        ListEmptyComponent: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.empty, {
            backgroundColor: colors.card,
            borderColor: colors.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "hanger",
            size: 32,
            color: colors.mutedForeground
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.emptyTitle, {
              color: colors.foreground
            }],
            children: "Nothing Here Yet"
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.emptyBody, {
              color: colors.mutedForeground
            }],
            children: "New drops land in this category soon."
          })]
        })
      }, "items"), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Modal.default, {
        visible: !!preview,
        transparent: true,
        animationType: "slide",
        onRequestClose: () => setPreview(null),
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
          style: styles.overlay,
          onPress: () => setPreview(null)
        }), preview && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.sheet, {
            backgroundColor: colors.card,
            borderColor: colors.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [styles.handle, {
              backgroundColor: colors.border
            }]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.previewStage, {
              backgroundColor: colors.secondary
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarBackdrop.default, {
              id: background
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarDisplay.default, {
              avatar: avatar,
              equipped: previewEquipped,
              catalog: byId,
              size: "lg",
              focus: _libAvatar3dSpec.SLOT_FOCUS[preview.slot]
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.previewHead,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.previewName, {
                color: colors.foreground
              }],
              children: preview.name
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.rarity, {
                backgroundColor: _typesCatalog.RARITY_COLORS[preview.rarity] + "22",
                borderColor: _typesCatalog.RARITY_COLORS[preview.rarity]
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.rarityText, {
                  color: _typesCatalog.RARITY_COLORS[preview.rarity]
                }],
                children: preview.rarity.toUpperCase()
              })
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.previewDesc, {
              color: colors.mutedForeground
            }],
            children: preview.description
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
            style: ({
              pressed
            }) => [styles.previewBtn, {
              backgroundColor: colors.primary,
              opacity: busyId === preview.id || itemLocked(preview) ? 0.45 : pressed ? 0.85 : 1
            }],
            disabled: busyId === preview.id || itemLocked(preview),
            onPress: async () => {
              if (owned.has(preview.id)) await handleToggleEquip(preview);else handleCart(preview);
              setPreview(null);
            },
            children: busyId === preview.id ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
              size: "small",
              color: colors.primaryForeground
            }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.previewBtnText, {
                color: colors.primaryForeground
              }],
              children: owned.has(preview.id) ? equipped[preview.slot] === preview.id ? "Take it off" : "Wear it" : preview.levelReward ? `Unlocks free at level ${preview.levelReward}` : itemLocked(preview) ? `Reach level ${preview.levelRequired} to buy` : cart.has(preview.id) ? "Remove from cart" : `Add to cart · ${preview.price.toLocaleString()}`
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.CloseButton, {
            onPress: () => setPreview(null),
            style: styles.previewClose
          })]
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(CartExitDialog.default, {
        visible: leaveAsk,
        onCheckout: goCheckout,
        onLeave: leaveAnyway,
        onCancel: () => {
          pendingNav.current = null;
          setLeaveAsk(false);
        }
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Modal.default, {
        visible: !!bgPreview,
        transparent: true,
        animationType: "slide",
        onRequestClose: () => setBgPreview(null),
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
          style: styles.overlay,
          onPress: () => setBgPreview(null)
        }), bgPreview && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.sheet, {
            backgroundColor: colors.card,
            borderColor: colors.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [styles.handle, {
              backgroundColor: colors.border
            }]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.previewStage, styles.bgStage, {
              backgroundColor: colors.secondary
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarBackdrop.default, {
              id: bgPreview.id
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarDisplay.default, {
              avatar: avatar,
              equipped: equipped,
              catalog: byId,
              size: "lg",
              focus: "hero",
              controls: false,
              active: focused && !!bgPreview
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.previewHead,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.previewName, {
                color: colors.foreground
              }],
              children: bgPreview.name
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.rarity, {
                backgroundColor: colors.alpha(colors.rarity(bgPreview.rarity), 0.14),
                borderColor: colors.rarity(bgPreview.rarity)
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.rarityText, {
                  color: colors.rarity(bgPreview.rarity)
                }],
                children: bgPreview.rarity.toUpperCase()
              })
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.previewDesc, {
              color: colors.mutedForeground
            }],
            children: bgPreview.description
          }), (() => {
            const mine = ownedBackgrounds.has(bgPreview.id);
            const on = background === bgPreview.id;
            const locked = bgLocked(bgPreview);
            const blocked = busyId === bgPreview.id || on || locked || !mine && balance < bgPreview.price;
            return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
              style: ({
                pressed: pressed_0
              }) => [styles.previewBtn, {
                backgroundColor: colors.primary,
                opacity: blocked ? 0.45 : pressed_0 ? 0.85 : 1
              }],
              disabled: blocked,
              onPress: async () => {
                if (mine) await handleUseBackground(bgPreview);else await handleBuyBackground(bgPreview);
                setBgPreview(null);
              },
              children: busyId === bgPreview.id ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
                size: "small",
                color: colors.primaryForeground
              }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.previewBtnText, {
                  color: colors.primaryForeground
                }],
                children: on ? "In Use" : mine ? "Use This Scene" : locked ? bgPreview.levelReward ? `Unlocks Free at Level ${bgPreview.levelReward}` : `Reach Level ${bgPreview.levelRequired} to Buy` : `Buy for ${bgPreview.price.toLocaleString()}${bgPreview.levelReward ? ` · or Free at Lv ${bgPreview.levelReward}` : ""}`
              })
            });
          })(), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.CloseButton, {
            onPress: () => setBgPreview(null),
            style: styles.previewClose
          })]
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Modal.default, {
        visible: !!movePreview,
        transparent: true,
        animationType: "slide",
        onRequestClose: () => setMovePreview(null),
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
          style: styles.overlay,
          onPress: () => setMovePreview(null)
        }), movePreview && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: [styles.sheet, {
            backgroundColor: colors.card,
            borderColor: colors.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [styles.handle, {
              backgroundColor: colors.border
            }]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.previewStage, {
              backgroundColor: colors.secondary
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarBackdrop.default, {
              id: background
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarDisplay.default, {
              avatar: avatar,
              equipped: equipped,
              catalog: byId,
              size: "lg",
              focus: "hero",
              controls: false,
              move: play,
              active: focused && !!movePreview
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: styles.previewHead,
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.previewName, {
                color: colors.foreground
              }],
              children: movePreview.name
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
              accessibilityRole: "button",
              accessibilityLabel: "Play again",
              hitSlop: 8,
              onPress: () => previewMove(movePreview),
              style: [styles.replay, {
                backgroundColor: colors.secondary,
                borderColor: colors.border
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "replay",
                size: 16,
                color: colors.foreground
              })
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.rarity, {
                backgroundColor: colors.alpha(colors.rarity(movePreview.rarity), 0.14),
                borderColor: colors.rarity(movePreview.rarity)
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.rarityText, {
                  color: colors.rarity(movePreview.rarity)
                }],
                children: movePreview.rarity.toUpperCase()
              })
            })]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.previewDesc, {
              color: colors.mutedForeground
            }],
            children: [movePreview.description, " \xB7 ", movePreview.seconds.toFixed(0), "s"]
          }), (() => {
            const mine_0 = ownedMoves.has(movePreview.id);
            const on_0 = loadout.includes(movePreview.id);
            const blocked_0 = busyId === movePreview.id || !mine_0 && balance < movePreview.price;
            return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
              style: ({
                pressed: pressed_1
              }) => [styles.previewBtn, {
                backgroundColor: colors.primary,
                opacity: blocked_0 ? 0.45 : pressed_1 ? 0.85 : 1
              }],
              disabled: blocked_0,
              onPress: async () => {
                if (mine_0) {
                  await handleToggleMove(movePreview);
                  setMovePreview(null);
                } else if (await handleBuyMove(movePreview)) {
                  previewMove(movePreview);
                }
              },
              children: busyId === movePreview.id ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
                size: "small",
                color: colors.primaryForeground
              }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.previewBtnText, {
                  color: colors.primaryForeground
                }],
                children: mine_0 ? on_0 ? "Take off dance button" : "Put on dance button" : `Buy for ${movePreview.price.toLocaleString()}`
              })
            });
          })(), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.CloseButton, {
            onPress: () => setMovePreview(null),
            style: styles.previewClose
          })]
        })]
      })]
    });
  }
  const styles = StyleSheet.default.create({
    charRow: {
      gap: 6,
      marginTop: 10
    },
    charLabel: {
      fontSize: 11,
      fontFamily: "Inter_800ExtraBold",
      letterSpacing: 1
    },
    charChips: {
      gap: 6,
      paddingRight: 16
    },
    charChip: {
      flexDirection: "row",
      alignItems: "center",
      gap: 5,
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 999,
      borderWidth: 1
    },
    charChipText: {
      fontSize: 13,
      fontFamily: "Inter_700Bold"
    },
    container: {
      flex: 1
    },
    header: {
      borderBottomWidth: 1,
      paddingBottom: 12,
      gap: 10
    },
    headerRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      paddingHorizontal: 16
    },
    headerActions: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10
    },
    title: {
      fontSize: 24,
      fontFamily: "Inter_900Black"
    },
    subtitle: {
      fontSize: 13,
      fontFamily: "Inter_500Medium",
      marginTop: 2
    },
    tabList: {
      paddingHorizontal: 16,
      gap: 8
    },
    tab: {
      paddingHorizontal: 14,
      paddingVertical: 7,
      borderRadius: 20,
      borderWidth: 1
    },
    movesTab: {
      flexDirection: "row",
      alignItems: "center",
      gap: 5
    },
    tabText: {
      fontSize: 13,
      fontFamily: "Inter_600SemiBold"
    },
    banner: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      marginHorizontal: 16,
      marginTop: 10,
      padding: 10,
      borderRadius: 10,
      borderWidth: 1
    },
    bannerText: {
      flex: 1,
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    },
    loading: {
      flex: 1,
      alignItems: "center",
      justifyContent: "center"
    },
    list: {
      padding: 16
    },
    empty: {
      alignItems: "center",
      gap: 8,
      padding: 32,
      borderRadius: 16,
      borderWidth: 1,
      marginTop: 24
    },
    emptyTitle: {
      fontSize: 16,
      fontFamily: "Inter_600SemiBold"
    },
    emptyBody: {
      fontSize: 13,
      fontFamily: "Inter_400Regular",
      textAlign: "center"
    },
    overlay: {
      flex: 1,
      backgroundColor: "rgba(0,0,0,0.5)"
    },
    sheet: {
      borderTopLeftRadius: 24,
      borderTopRightRadius: 24,
      borderWidth: 1,
      padding: 24,
      paddingTop: 14,
      gap: 12
    },
    handle: {
      width: 36,
      height: 4,
      borderRadius: 2,
      alignSelf: "center",
      marginBottom: 6
    },
    previewClose: {
      position: "absolute",
      top: 12,
      right: 14
    },
    previewStage: {
      borderRadius: 18,
      height: 300,
      overflow: "hidden"
    },
    bgStage: {
      height: 380
    },
    previewHead: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    previewName: {
      flex: 1,
      fontSize: 19,
      fontFamily: "Inter_700Bold"
    },
    replay: {
      width: 30,
      height: 30,
      borderRadius: 15,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center"
    },
    rarity: {
      paddingHorizontal: 8,
      paddingVertical: 3,
      borderRadius: 8,
      borderWidth: 1
    },
    rarityText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.5
    },
    previewDesc: {
      fontSize: 13,
      fontFamily: "Inter_400Regular",
      marginTop: -6
    },
    previewBtn: {
      paddingVertical: 15,
      borderRadius: 14,
      alignItems: "center",
      marginTop: 4
    },
    previewBtnText: {
      fontSize: 16,
      fontFamily: "Inter_700Bold"
    }
  });
},776,[818,820,817,1216,12,228,107,238,104,28,188,109,827,271,828,830,1212,1268,1269,1270,829,835,894,840,837,838,1218,836,1215,1191,819,1266,1271,839,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  var _reactNativeWebDistExportsActivityIndicator = require(_dependencyMap[3]);
  var ActivityIndicator = _interopDefault(_reactNativeWebDistExportsActivityIndicator);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[7]);
  var _componentsAvatarItemIcon = require(_dependencyMap[8]);
  var ItemIcon = _interopDefault(_componentsAvatarItemIcon);
  var _typesCatalog = require(_dependencyMap[9]);
  var _hooksUseColors = require(_dependencyMap[10]);
  var _reactJsxRuntime = require(_dependencyMap[11]);
  /**
   * Now renders a `CatalogItem` from Firestore rather than a hardcoded
   * `ClothingItem` (AUDIT A4), and surfaces rarity, which the old card had no
   * concept of (§13).
   *
   * `busy` disables the button while the purchase callable is in flight — the UI
   * half of the rapid-click protection from §17.
   */
  function ClothingCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(85);
    const {
      item,
      owned,
      equipped,
      canAfford,
      inCart,
      busy,
      level: t1,
      onCart,
      onToggleEquip,
      onPreview
    } = t0;
    const level = t1 === undefined ? 1 : t1;
    const colors = (0, _hooksUseColors.useColors)();
    const rarity = _typesCatalog.RARITY_COLORS[item.rarity];
    const lockLevel = owned ? null : item.levelReward ? item.levelReward : item.levelRequired && item.levelRequired > level ? item.levelRequired : null;
    const label = busy ? "" : equipped ? "Remove" : owned ? "Equip" : lockLevel ? `Lv ${lockLevel}` : inCart ? "In cart" : "Add to cart";
    const disabled = busy || !!lockLevel;
    const cartOn = !owned && inCart;
    const t2 = equipped ? colors.primary : colors.border;
    const t3 = equipped ? 1.5 : 1;
    let t4;
    if ($[0] !== colors.card || $[1] !== t2 || $[2] !== t3) {
      t4 = [styles.card, {
        backgroundColor: colors.card,
        borderColor: t2,
        borderWidth: t3
      }];
      $[0] = colors.card;
      $[1] = t2;
      $[2] = t3;
      $[3] = t4;
    } else {
      t4 = $[3];
    }
    let t5;
    if ($[4] !== colors.primary || $[5] !== colors.primaryForeground || $[6] !== equipped) {
      t5 = equipped && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [styles.badge, {
          backgroundColor: colors.primary
        }],
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.badgeText, {
            color: colors.primaryForeground
          }],
          children: "ON"
        })
      });
      $[4] = colors.primary;
      $[5] = colors.primaryForeground;
      $[6] = equipped;
      $[7] = t5;
    } else {
      t5 = $[7];
    }
    let t6;
    if ($[8] !== colors.secondary) {
      t6 = [styles.swatch, {
        backgroundColor: colors.secondary
      }];
      $[8] = colors.secondary;
      $[9] = t6;
    } else {
      t6 = $[9];
    }
    let t7;
    if ($[10] !== item) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ItemIcon.default, {
        item: item,
        size: 64
      });
      $[10] = item;
      $[11] = t7;
    } else {
      t7 = $[11];
    }
    let t8;
    if ($[12] !== t6 || $[13] !== t7) {
      t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t6,
        children: t7
      });
      $[12] = t6;
      $[13] = t7;
      $[14] = t8;
    } else {
      t8 = $[14];
    }
    let t9;
    if ($[15] !== colors.foreground) {
      t9 = [styles.name, {
        color: colors.foreground
      }];
      $[15] = colors.foreground;
      $[16] = t9;
    } else {
      t9 = $[16];
    }
    let t10;
    if ($[17] !== item.name || $[18] !== t9) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t9,
        numberOfLines: 1,
        children: item.name
      });
      $[17] = item.name;
      $[18] = t9;
      $[19] = t10;
    } else {
      t10 = $[19];
    }
    const t11 = rarity + "22";
    let t12;
    if ($[20] !== rarity || $[21] !== t11) {
      t12 = [styles.rarity, {
        backgroundColor: t11,
        borderColor: rarity
      }];
      $[20] = rarity;
      $[21] = t11;
      $[22] = t12;
    } else {
      t12 = $[22];
    }
    let t13;
    if ($[23] !== rarity) {
      t13 = [styles.rarityText, {
        color: rarity
      }];
      $[23] = rarity;
      $[24] = t13;
    } else {
      t13 = $[24];
    }
    let t14;
    if ($[25] !== item.rarity) {
      t14 = item.rarity.toUpperCase();
      $[25] = item.rarity;
      $[26] = t14;
    } else {
      t14 = $[26];
    }
    let t15;
    if ($[27] !== t13 || $[28] !== t14) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t13,
        children: t14
      });
      $[27] = t13;
      $[28] = t14;
      $[29] = t15;
    } else {
      t15 = $[29];
    }
    let t16;
    if ($[30] !== t12 || $[31] !== t15) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t12,
        children: t15
      });
      $[30] = t12;
      $[31] = t15;
      $[32] = t16;
    } else {
      t16 = $[32];
    }
    let t17;
    if ($[33] !== t10 || $[34] !== t16) {
      t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.nameRow,
        children: [t10, t16]
      });
      $[33] = t10;
      $[34] = t16;
      $[35] = t17;
    } else {
      t17 = $[35];
    }
    let t18;
    if ($[36] !== colors.mutedForeground) {
      t18 = [styles.desc, {
        color: colors.mutedForeground
      }];
      $[36] = colors.mutedForeground;
      $[37] = t18;
    } else {
      t18 = $[37];
    }
    let t19;
    if ($[38] !== item.description || $[39] !== t18) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t18,
        numberOfLines: 1,
        children: item.description
      });
      $[38] = item.description;
      $[39] = t18;
      $[40] = t19;
    } else {
      t19 = $[40];
    }
    let t20;
    if ($[41] !== canAfford || $[42] !== colors || $[43] !== item.levelReward || $[44] !== item.price || $[45] !== owned) {
      t20 = owned ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [styles.owned, {
          backgroundColor: colors.secondary
        }],
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.ownedText, {
            color: colors.mutedForeground
          }],
          children: "OWNED"
        })
      }) : item.levelReward ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.owned, styles.priceRow, {
          backgroundColor: colors.alpha(colors.warning, 0.14)
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "gift",
          size: 11,
          color: colors.warning
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.ownedText, {
            color: colors.warning
          }],
          children: ["LEVEL ", item.levelReward, " REWARD"]
        })]
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.priceRow,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "lightning-bolt",
          size: 13,
          color: colors.primary
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.price, {
            color: canAfford ? colors.primary : colors.mutedForeground
          }],
          children: item.price.toLocaleString()
        })]
      });
      $[41] = canAfford;
      $[42] = colors;
      $[43] = item.levelReward;
      $[44] = item.price;
      $[45] = owned;
      $[46] = t20;
    } else {
      t20 = $[46];
    }
    let t21;
    if ($[47] !== busy || $[48] !== cartOn || $[49] !== colors.border || $[50] !== colors.primary || $[51] !== colors.secondary || $[52] !== equipped || $[53] !== lockLevel || $[54] !== owned) {
      t21 = t22 => {
        const {
          pressed
        } = t22;
        return [styles.action, {
          backgroundColor: equipped || lockLevel ? colors.secondary : owned || cartOn ? colors.primary : colors.primary + "22",
          borderColor: equipped || lockLevel ? colors.border : owned || cartOn ? "transparent" : colors.primary,
          opacity: busy ? 0.5 : pressed ? 0.8 : 1
        }];
      };
      $[47] = busy;
      $[48] = cartOn;
      $[49] = colors.border;
      $[50] = colors.primary;
      $[51] = colors.secondary;
      $[52] = equipped;
      $[53] = lockLevel;
      $[54] = owned;
      $[55] = t21;
    } else {
      t21 = $[55];
    }
    const t22 = owned ? onToggleEquip : onCart;
    const t23 = owned ? label : lockLevel ? `${item.name}, unlocks at level ${lockLevel}` : inCart ? `Remove ${item.name} from cart` : `Add ${item.name} to cart`;
    let t24;
    if ($[56] !== busy || $[57] !== colors.mutedForeground || $[58] !== colors.primary || $[59] !== colors.primaryForeground || $[60] !== equipped || $[61] !== inCart || $[62] !== label || $[63] !== lockLevel || $[64] !== owned) {
      t24 = busy ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
        size: "small",
        color: colors.primary
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.actionRow,
        children: [lockLevel ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "lock",
          size: 13,
          color: colors.mutedForeground
        }) : !owned ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: inCart ? "cart-check" : "cart-plus",
          size: 14,
          color: inCart ? colors.primaryForeground : colors.primary
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.actionText, {
            color: equipped || lockLevel ? colors.mutedForeground : owned ? colors.primaryForeground : inCart ? colors.primaryForeground : colors.primary
          }],
          children: label
        })]
      });
      $[56] = busy;
      $[57] = colors.mutedForeground;
      $[58] = colors.primary;
      $[59] = colors.primaryForeground;
      $[60] = equipped;
      $[61] = inCart;
      $[62] = label;
      $[63] = lockLevel;
      $[64] = owned;
      $[65] = t24;
    } else {
      t24 = $[65];
    }
    let t25;
    if ($[66] !== disabled || $[67] !== t21 || $[68] !== t22 || $[69] !== t23 || $[70] !== t24) {
      t25 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
        style: t21,
        onPress: t22,
        disabled: disabled,
        accessibilityRole: "button",
        accessibilityLabel: t23,
        children: t24
      });
      $[66] = disabled;
      $[67] = t21;
      $[68] = t22;
      $[69] = t23;
      $[70] = t24;
      $[71] = t25;
    } else {
      t25 = $[71];
    }
    let t26;
    if ($[72] !== t20 || $[73] !== t25) {
      t26 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.bottom,
        children: [t20, t25]
      });
      $[72] = t20;
      $[73] = t25;
      $[74] = t26;
    } else {
      t26 = $[74];
    }
    let t27;
    if ($[75] !== t17 || $[76] !== t19 || $[77] !== t26) {
      t27 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.info,
        children: [t17, t19, t26]
      });
      $[75] = t17;
      $[76] = t19;
      $[77] = t26;
      $[78] = t27;
    } else {
      t27 = $[78];
    }
    let t28;
    if ($[79] !== onPreview || $[80] !== t27 || $[81] !== t4 || $[82] !== t5 || $[83] !== t8) {
      t28 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        style: t4,
        onPress: onPreview,
        children: [t5, t8, t27]
      });
      $[79] = onPreview;
      $[80] = t27;
      $[81] = t4;
      $[82] = t5;
      $[83] = t8;
      $[84] = t28;
    } else {
      t28 = $[84];
    }
    return t28;
  }
  var _default = /*#__PURE__*/(0, _react.memo)(ClothingCard);
  const styles = StyleSheet.default.create({
    card: {
      flexDirection: "row",
      borderRadius: 14,
      overflow: "hidden",
      marginBottom: 10
    },
    badge: {
      position: "absolute",
      top: 8,
      left: 8,
      paddingHorizontal: 6,
      paddingVertical: 2,
      borderRadius: 6,
      zIndex: 1
    },
    badgeText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.5
    },
    swatch: {
      width: 80,
      alignItems: "center",
      justifyContent: "center"
    },
    info: {
      flex: 1,
      padding: 12,
      gap: 4,
      justifyContent: "space-between"
    },
    nameRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6
    },
    name: {
      flex: 1,
      fontSize: 15,
      fontFamily: "Inter_600SemiBold"
    },
    rarity: {
      paddingHorizontal: 6,
      paddingVertical: 2,
      borderRadius: 6,
      borderWidth: 1
    },
    rarityText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.5
    },
    desc: {
      fontSize: 12,
      fontFamily: "Inter_400Regular"
    },
    bottom: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      marginTop: 4
    },
    priceRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 3
    },
    price: {
      fontSize: 15,
      fontFamily: "Inter_700Bold"
    },
    owned: {
      paddingHorizontal: 8,
      paddingVertical: 3,
      borderRadius: 8
    },
    ownedText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.5
    },
    actionRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 5
    },
    action: {
      minWidth: 78,
      paddingHorizontal: 14,
      paddingVertical: 7,
      borderRadius: 10,
      borderWidth: 1,
      alignItems: "center"
    },
    actionText: {
      fontSize: 13,
      fontFamily: "Inter_600SemiBold"
    }
  });
},1268,[815,818,12,228,28,188,109,827,834,839,819,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  var _reactNativeWebDistExportsActivityIndicator = require(_dependencyMap[3]);
  var ActivityIndicator = _interopDefault(_reactNativeWebDistExportsActivityIndicator);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[7]);
  var _hooksUseColors = require(_dependencyMap[8]);
  var _reactJsxRuntime = require(_dependencyMap[9]);
  /** A dance move in the Drip Shop, laid out like ClothingCard. */
  function MoveCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(123);
    const {
      move,
      owned,
      equipped,
      canAfford,
      busy,
      onBuy,
      onToggleEquip,
      onPreview
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    let T0;
    let T1;
    let T2;
    let disabled;
    let label;
    let rarity;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[0] !== busy || $[1] !== c || $[2] !== canAfford || $[3] !== equipped || $[4] !== move.description || $[5] !== move.name || $[6] !== move.rarity || $[7] !== onPreview || $[8] !== owned) {
      rarity = c.rarity(move.rarity);
      label = busy ? "" : equipped ? "Remove" : owned ? "Equip" : canAfford ? "Buy" : "Can't afford";
      disabled = busy || !owned && !canAfford;
      T2 = _componentsFxTap.Pressable;
      const t10 = equipped ? c.primary : c.border;
      const t11 = equipped ? 1.5 : 1;
      if ($[24] !== c.card || $[25] !== t10 || $[26] !== t11) {
        t5 = [styles.card, {
          backgroundColor: c.card,
          borderColor: t10,
          borderWidth: t11
        }];
        $[24] = c.card;
        $[25] = t10;
        $[26] = t11;
        $[27] = t5;
      } else {
        t5 = $[27];
      }
      t6 = onPreview;
      t7 = "button";
      t8 = `${move.name}. ${move.description}. Preview`;
      if ($[28] !== c.primary || $[29] !== c.primaryForeground || $[30] !== equipped) {
        t9 = equipped && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [styles.badge, {
            backgroundColor: c.primary
          }],
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.badgeText, {
              color: c.primaryForeground
            }],
            children: "ON"
          })
        });
        $[28] = c.primary;
        $[29] = c.primaryForeground;
        $[30] = equipped;
        $[31] = t9;
      } else {
        t9 = $[31];
      }
      T1 = View.default;
      if ($[32] !== c.secondary) {
        t4 = [styles.swatch, {
          backgroundColor: c.secondary
        }];
        $[32] = c.secondary;
        $[33] = t4;
      } else {
        t4 = $[33];
      }
      T0 = View.default;
      t3 = styles.icon;
      t1 = c.alpha(rarity, 0.16);
      t2 = c.alpha(rarity, 0.5);
      $[0] = busy;
      $[1] = c;
      $[2] = canAfford;
      $[3] = equipped;
      $[4] = move.description;
      $[5] = move.name;
      $[6] = move.rarity;
      $[7] = onPreview;
      $[8] = owned;
      $[9] = T0;
      $[10] = T1;
      $[11] = T2;
      $[12] = disabled;
      $[13] = label;
      $[14] = rarity;
      $[15] = t1;
      $[16] = t2;
      $[17] = t3;
      $[18] = t4;
      $[19] = t5;
      $[20] = t6;
      $[21] = t7;
      $[22] = t8;
      $[23] = t9;
    } else {
      T0 = $[9];
      T1 = $[10];
      T2 = $[11];
      disabled = $[12];
      label = $[13];
      rarity = $[14];
      t1 = $[15];
      t2 = $[16];
      t3 = $[17];
      t4 = $[18];
      t5 = $[19];
      t6 = $[20];
      t7 = $[21];
      t8 = $[22];
      t9 = $[23];
    }
    let t10;
    if ($[34] !== t1 || $[35] !== t2) {
      t10 = {
        backgroundColor: t1,
        borderColor: t2
      };
      $[34] = t1;
      $[35] = t2;
      $[36] = t10;
    } else {
      t10 = $[36];
    }
    let t11;
    if ($[37] !== t10 || $[38] !== t3) {
      t11 = [t3, t10];
      $[37] = t10;
      $[38] = t3;
      $[39] = t11;
    } else {
      t11 = $[39];
    }
    const t12 = move.icon;
    let t13;
    if ($[40] !== rarity || $[41] !== t12) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: t12,
        size: 26,
        color: rarity
      });
      $[40] = rarity;
      $[41] = t12;
      $[42] = t13;
    } else {
      t13 = $[42];
    }
    let t14;
    if ($[43] !== T0 || $[44] !== t11 || $[45] !== t13) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(T0, {
        style: t11,
        children: t13
      });
      $[43] = T0;
      $[44] = t11;
      $[45] = t13;
      $[46] = t14;
    } else {
      t14 = $[46];
    }
    let t15;
    if ($[47] !== T1 || $[48] !== t14 || $[49] !== t4) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(T1, {
        style: t4,
        children: t14
      });
      $[47] = T1;
      $[48] = t14;
      $[49] = t4;
      $[50] = t15;
    } else {
      t15 = $[50];
    }
    let t16;
    if ($[51] !== c.foreground) {
      t16 = [styles.name, {
        color: c.foreground
      }];
      $[51] = c.foreground;
      $[52] = t16;
    } else {
      t16 = $[52];
    }
    let t17;
    if ($[53] !== move.name || $[54] !== t16) {
      t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t16,
        numberOfLines: 1,
        children: move.name
      });
      $[53] = move.name;
      $[54] = t16;
      $[55] = t17;
    } else {
      t17 = $[55];
    }
    let t18;
    if ($[56] !== c || $[57] !== rarity) {
      t18 = c.alpha(rarity, 0.14);
      $[56] = c;
      $[57] = rarity;
      $[58] = t18;
    } else {
      t18 = $[58];
    }
    let t19;
    if ($[59] !== rarity || $[60] !== t18) {
      t19 = [styles.rarity, {
        backgroundColor: t18,
        borderColor: rarity
      }];
      $[59] = rarity;
      $[60] = t18;
      $[61] = t19;
    } else {
      t19 = $[61];
    }
    let t20;
    if ($[62] !== rarity) {
      t20 = [styles.rarityText, {
        color: rarity
      }];
      $[62] = rarity;
      $[63] = t20;
    } else {
      t20 = $[63];
    }
    let t21;
    if ($[64] !== move.rarity) {
      t21 = move.rarity.toUpperCase();
      $[64] = move.rarity;
      $[65] = t21;
    } else {
      t21 = $[65];
    }
    let t22;
    if ($[66] !== t20 || $[67] !== t21) {
      t22 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t20,
        children: t21
      });
      $[66] = t20;
      $[67] = t21;
      $[68] = t22;
    } else {
      t22 = $[68];
    }
    let t23;
    if ($[69] !== t19 || $[70] !== t22) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t19,
        children: t22
      });
      $[69] = t19;
      $[70] = t22;
      $[71] = t23;
    } else {
      t23 = $[71];
    }
    let t24;
    if ($[72] !== t17 || $[73] !== t23) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.nameRow,
        children: [t17, t23]
      });
      $[72] = t17;
      $[73] = t23;
      $[74] = t24;
    } else {
      t24 = $[74];
    }
    let t25;
    if ($[75] !== c.mutedForeground) {
      t25 = [styles.desc, {
        color: c.mutedForeground
      }];
      $[75] = c.mutedForeground;
      $[76] = t25;
    } else {
      t25 = $[76];
    }
    let t26;
    if ($[77] !== move.description || $[78] !== t25) {
      t26 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t25,
        numberOfLines: 1,
        children: move.description
      });
      $[77] = move.description;
      $[78] = t25;
      $[79] = t26;
    } else {
      t26 = $[79];
    }
    let t27;
    if ($[80] !== c.mutedForeground || $[81] !== c.primary || $[82] !== c.secondary || $[83] !== canAfford || $[84] !== move.free || $[85] !== move.price || $[86] !== owned) {
      t27 = owned ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [styles.owned, {
          backgroundColor: c.secondary
        }],
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.ownedText, {
            color: c.mutedForeground
          }],
          children: move.free ? "FREE" : "OWNED"
        })
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.priceRow,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "lightning-bolt",
          size: 13,
          color: c.primary
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.price, {
            color: canAfford ? c.primary : c.mutedForeground
          }],
          children: move.price.toLocaleString()
        })]
      });
      $[80] = c.mutedForeground;
      $[81] = c.primary;
      $[82] = c.secondary;
      $[83] = canAfford;
      $[84] = move.free;
      $[85] = move.price;
      $[86] = owned;
      $[87] = t27;
    } else {
      t27 = $[87];
    }
    let t28;
    if ($[88] !== c || $[89] !== disabled || $[90] !== equipped || $[91] !== owned) {
      t28 = t29 => {
        const {
          pressed
        } = t29;
        return [styles.action, {
          backgroundColor: equipped ? c.secondary : owned ? c.primary : c.alpha(c.primary, 0.13),
          borderColor: equipped ? c.border : owned ? "transparent" : c.primary,
          opacity: disabled ? 0.5 : pressed ? 0.8 : 1
        }];
      };
      $[88] = c;
      $[89] = disabled;
      $[90] = equipped;
      $[91] = owned;
      $[92] = t28;
    } else {
      t28 = $[92];
    }
    const t29 = owned ? onToggleEquip : onBuy;
    const t30 = equipped ? `Take ${move.name} off your dance button` : owned ? `Put ${move.name} on your dance button` : `Buy ${move.name}`;
    let t31;
    if ($[93] !== busy || $[94] !== c.mutedForeground || $[95] !== c.primary || $[96] !== c.primaryForeground || $[97] !== equipped || $[98] !== label || $[99] !== owned) {
      t31 = busy ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
        size: "small",
        color: c.primary
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.actionText, {
          color: equipped ? c.mutedForeground : owned ? c.primaryForeground : c.primary
        }],
        children: label
      });
      $[93] = busy;
      $[94] = c.mutedForeground;
      $[95] = c.primary;
      $[96] = c.primaryForeground;
      $[97] = equipped;
      $[98] = label;
      $[99] = owned;
      $[100] = t31;
    } else {
      t31 = $[100];
    }
    let t32;
    if ($[101] !== disabled || $[102] !== t28 || $[103] !== t29 || $[104] !== t30 || $[105] !== t31) {
      t32 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
        style: t28,
        onPress: t29,
        disabled: disabled,
        accessibilityRole: "button",
        accessibilityLabel: t30,
        children: t31
      });
      $[101] = disabled;
      $[102] = t28;
      $[103] = t29;
      $[104] = t30;
      $[105] = t31;
      $[106] = t32;
    } else {
      t32 = $[106];
    }
    let t33;
    if ($[107] !== t27 || $[108] !== t32) {
      t33 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.bottom,
        children: [t27, t32]
      });
      $[107] = t27;
      $[108] = t32;
      $[109] = t33;
    } else {
      t33 = $[109];
    }
    let t34;
    if ($[110] !== t24 || $[111] !== t26 || $[112] !== t33) {
      t34 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.info,
        children: [t24, t26, t33]
      });
      $[110] = t24;
      $[111] = t26;
      $[112] = t33;
      $[113] = t34;
    } else {
      t34 = $[113];
    }
    let t35;
    if ($[114] !== T2 || $[115] !== t15 || $[116] !== t34 || $[117] !== t5 || $[118] !== t6 || $[119] !== t7 || $[120] !== t8 || $[121] !== t9) {
      t35 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T2, {
        style: t5,
        onPress: t6,
        accessibilityRole: t7,
        accessibilityLabel: t8,
        children: [t9, t15, t34]
      });
      $[114] = T2;
      $[115] = t15;
      $[116] = t34;
      $[117] = t5;
      $[118] = t6;
      $[119] = t7;
      $[120] = t8;
      $[121] = t9;
      $[122] = t35;
    } else {
      t35 = $[122];
    }
    return t35;
  }
  var _default = /*#__PURE__*/(0, _react.memo)(MoveCard);
  const styles = StyleSheet.default.create({
    card: {
      flexDirection: "row",
      borderRadius: 14,
      overflow: "hidden",
      marginBottom: 10
    },
    badge: {
      position: "absolute",
      top: 8,
      left: 8,
      paddingHorizontal: 6,
      paddingVertical: 2,
      borderRadius: 6,
      zIndex: 1
    },
    badgeText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.5
    },
    swatch: {
      width: 80,
      alignItems: "center",
      justifyContent: "center"
    },
    icon: {
      width: 52,
      height: 52,
      borderRadius: 16,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center"
    },
    info: {
      flex: 1,
      padding: 12,
      gap: 4,
      justifyContent: "space-between"
    },
    nameRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6
    },
    name: {
      flex: 1,
      fontSize: 15,
      fontFamily: "Inter_600SemiBold"
    },
    rarity: {
      paddingHorizontal: 6,
      paddingVertical: 2,
      borderRadius: 6,
      borderWidth: 1
    },
    rarityText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.5
    },
    desc: {
      fontSize: 12,
      fontFamily: "Inter_400Regular"
    },
    bottom: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      marginTop: 4
    },
    priceRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 3
    },
    price: {
      fontSize: 15,
      fontFamily: "Inter_700Bold"
    },
    owned: {
      paddingHorizontal: 8,
      paddingVertical: 3,
      borderRadius: 8
    },
    ownedText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.5
    },
    action: {
      minWidth: 78,
      paddingHorizontal: 14,
      paddingVertical: 7,
      borderRadius: 10,
      borderWidth: 1,
      alignItems: "center"
    },
    actionText: {
      fontSize: 13,
      fontFamily: "Inter_600SemiBold"
    }
  });
},1269,[815,818,12,228,28,188,109,827,819,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  var _reactNativeWebDistExportsActivityIndicator = require(_dependencyMap[3]);
  var ActivityIndicator = _interopDefault(_reactNativeWebDistExportsActivityIndicator);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsAvatarAvatarBackdrop = require(_dependencyMap[7]);
  var AvatarBackdrop = _interopDefault(_componentsAvatarAvatarBackdrop);
  var _componentsFxTap = require(_dependencyMap[8]);
  var _hooksUseColors = require(_dependencyMap[9]);
  var _reactJsxRuntime = require(_dependencyMap[10]);
  /**
   * A background in the Drip Shop: the scene itself as the thumbnail, then
   * price / level lock / owned, and one action (buy, use, in use).
   */
  function BackgroundCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(78);
    const {
      bg,
      owned,
      inUse,
      level,
      canAfford,
      busy,
      onBuy,
      onUse,
      onPreview
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    let t1;
    if ($[0] !== bg.rarity || $[1] !== c) {
      t1 = c.rarity(bg.rarity);
      $[0] = bg.rarity;
      $[1] = c;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    const col = t1;
    const lock = owned ? null : bg.levelRequired && bg.levelRequired > level ? bg.levelRequired : null;
    const reward = owned || !bg.levelReward ? null : bg.levelReward;
    const buyable = !owned && !lock && bg.price > 0;
    let t2;
    if ($[3] !== bg.price || $[4] !== buyable || $[5] !== inUse || $[6] !== lock || $[7] !== owned || $[8] !== reward) {
      t2 = inUse ? "In Use" : owned ? "Use" : lock ? `Lv ${lock}` : buyable ? `Buy ${bg.price.toLocaleString()}` : reward ? `Lv ${reward}` : "Locked";
      $[3] = bg.price;
      $[4] = buyable;
      $[5] = inUse;
      $[6] = lock;
      $[7] = owned;
      $[8] = reward;
      $[9] = t2;
    } else {
      t2 = $[9];
    }
    const label = t2;
    const t3 = `${bg.name}, ${bg.rarity}${inUse ? ", in use" : owned ? ", owned" : lock ? `, unlocks at level ${lock}` : `, ${bg.price} credits${reward ? `, or free at level ${reward}` : ""}`}`;
    let t4;
    if ($[10] !== c.border || $[11] !== c.card || $[12] !== c.primary || $[13] !== inUse) {
      t4 = t5 => {
        const {
          pressed
        } = t5;
        return [styles.card, {
          backgroundColor: c.card,
          borderColor: inUse ? c.primary : c.border,
          borderWidth: inUse ? 1.5 : 1,
          opacity: pressed ? 0.9 : 1
        }];
      };
      $[10] = c.border;
      $[11] = c.card;
      $[12] = c.primary;
      $[13] = inUse;
      $[14] = t4;
    } else {
      t4 = $[14];
    }
    let t5;
    if ($[15] !== bg.id) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarBackdrop.default, {
        id: bg.id
      });
      $[15] = bg.id;
      $[16] = t5;
    } else {
      t5 = $[16];
    }
    let t6;
    if ($[17] !== lock || $[18] !== reward) {
      t6 = lock ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.lockVeil,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "lock",
          size: 22,
          color: "#FFFFFF"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: styles.lockText,
          children: `LEVEL ${lock}`
        })]
      }) : reward ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.rewardTag, {
          backgroundColor: "rgba(0,0,0,0.6)"
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "star-four-points",
          size: 11,
          color: "#FFFFFF"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: styles.rewardText,
          children: `FREE AT LV ${reward}`
        })]
      }) : null;
      $[17] = lock;
      $[18] = reward;
      $[19] = t6;
    } else {
      t6 = $[19];
    }
    let t7;
    if ($[20] !== col) {
      t7 = [styles.rarity, {
        backgroundColor: "rgba(0,0,0,0.55)",
        borderColor: col
      }];
      $[20] = col;
      $[21] = t7;
    } else {
      t7 = $[21];
    }
    let t8;
    if ($[22] !== col) {
      t8 = [styles.rarityText, {
        color: col
      }];
      $[22] = col;
      $[23] = t8;
    } else {
      t8 = $[23];
    }
    let t9;
    if ($[24] !== bg.rarity) {
      t9 = bg.rarity.toUpperCase();
      $[24] = bg.rarity;
      $[25] = t9;
    } else {
      t9 = $[25];
    }
    let t10;
    if ($[26] !== t8 || $[27] !== t9) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t8,
        children: t9
      });
      $[26] = t8;
      $[27] = t9;
      $[28] = t10;
    } else {
      t10 = $[28];
    }
    let t11;
    if ($[29] !== t10 || $[30] !== t7) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t7,
        children: t10
      });
      $[29] = t10;
      $[30] = t7;
      $[31] = t11;
    } else {
      t11 = $[31];
    }
    let t12;
    if ($[32] !== c.primary || $[33] !== c.primaryForeground || $[34] !== inUse) {
      t12 = inUse ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [styles.on, {
          backgroundColor: c.primary
        }],
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.onText, {
            color: c.primaryForeground
          }],
          children: "ON"
        })
      }) : null;
      $[32] = c.primary;
      $[33] = c.primaryForeground;
      $[34] = inUse;
      $[35] = t12;
    } else {
      t12 = $[35];
    }
    let t13;
    if ($[36] !== t11 || $[37] !== t12 || $[38] !== t5 || $[39] !== t6) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.thumb,
        children: [t5, t6, t11, t12]
      });
      $[36] = t11;
      $[37] = t12;
      $[38] = t5;
      $[39] = t6;
      $[40] = t13;
    } else {
      t13 = $[40];
    }
    let t14;
    if ($[41] !== c.foreground) {
      t14 = [styles.name, {
        color: c.foreground
      }];
      $[41] = c.foreground;
      $[42] = t14;
    } else {
      t14 = $[42];
    }
    let t15;
    if ($[43] !== bg.name || $[44] !== t14) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t14,
        numberOfLines: 1,
        children: bg.name
      });
      $[43] = bg.name;
      $[44] = t14;
      $[45] = t15;
    } else {
      t15 = $[45];
    }
    const t16 = inUse ? "In use" : owned ? `Use ${bg.name}` : lock ? `Locked until level ${lock}` : `Buy ${bg.name} for ${bg.price} credits`;
    const t17 = busy || inUse || !!lock || !owned && (!buyable || !canAfford);
    const t18 = owned ? onUse : onBuy;
    let t19;
    if ($[46] !== busy || $[47] !== c || $[48] !== canAfford || $[49] !== inUse || $[50] !== lock || $[51] !== owned) {
      t19 = t20 => {
        const {
          pressed: pressed_0
        } = t20;
        return [styles.action, owned && !inUse ? {
          backgroundColor: c.primary,
          borderColor: c.primary
        } : inUse || lock ? {
          backgroundColor: c.secondary,
          borderColor: c.border
        } : {
          backgroundColor: c.alpha(c.primary, 0.13),
          borderColor: c.primary
        }, {
          opacity: busy ? 0.5 : !owned && !lock && !canAfford ? 0.55 : pressed_0 ? 0.8 : 1
        }];
      };
      $[46] = busy;
      $[47] = c;
      $[48] = canAfford;
      $[49] = inUse;
      $[50] = lock;
      $[51] = owned;
      $[52] = t19;
    } else {
      t19 = $[52];
    }
    let t20;
    if ($[53] !== busy || $[54] !== buyable || $[55] !== c.mutedForeground || $[56] !== c.primary || $[57] !== c.primaryForeground || $[58] !== inUse || $[59] !== label || $[60] !== lock || $[61] !== owned) {
      t20 = busy ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
        size: "small",
        color: c.primary
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.actionRow,
        children: [buyable ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "lightning-bolt",
          size: 13,
          color: c.primary
        }) : null, lock ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "lock",
          size: 12,
          color: c.mutedForeground
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.actionText, {
            color: owned && !inUse ? c.primaryForeground : inUse || lock ? c.mutedForeground : c.primary
          }],
          children: label
        })]
      });
      $[53] = busy;
      $[54] = buyable;
      $[55] = c.mutedForeground;
      $[56] = c.primary;
      $[57] = c.primaryForeground;
      $[58] = inUse;
      $[59] = label;
      $[60] = lock;
      $[61] = owned;
      $[62] = t20;
    } else {
      t20 = $[62];
    }
    let t21;
    if ($[63] !== t16 || $[64] !== t17 || $[65] !== t18 || $[66] !== t19 || $[67] !== t20) {
      t21 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
        accessibilityRole: "button",
        accessibilityLabel: t16,
        disabled: t17,
        onPress: t18,
        hitSlop: 4,
        style: t19,
        children: t20
      });
      $[63] = t16;
      $[64] = t17;
      $[65] = t18;
      $[66] = t19;
      $[67] = t20;
      $[68] = t21;
    } else {
      t21 = $[68];
    }
    let t22;
    if ($[69] !== t15 || $[70] !== t21) {
      t22 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.info,
        children: [t15, t21]
      });
      $[69] = t15;
      $[70] = t21;
      $[71] = t22;
    } else {
      t22 = $[71];
    }
    let t23;
    if ($[72] !== onPreview || $[73] !== t13 || $[74] !== t22 || $[75] !== t3 || $[76] !== t4) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        accessibilityRole: "button",
        accessibilityLabel: t3,
        onPress: onPreview,
        style: t4,
        children: [t13, t22]
      });
      $[72] = onPreview;
      $[73] = t13;
      $[74] = t22;
      $[75] = t3;
      $[76] = t4;
      $[77] = t23;
    } else {
      t23 = $[77];
    }
    return t23;
  }
  var _default = /*#__PURE__*/(0, _react.memo)(BackgroundCard);
  const styles = StyleSheet.default.create({
    card: {
      flex: 1,
      borderRadius: 16,
      overflow: "hidden"
    },
    thumb: {
      height: 150,
      overflow: "hidden"
    },
    lockVeil: {
      position: "absolute",
      left: 0,
      right: 0,
      top: 0,
      bottom: 0,
      backgroundColor: "rgba(0,0,0,0.5)",
      alignItems: "center",
      justifyContent: "center",
      gap: 4
    },
    rewardTag: {
      position: "absolute",
      left: 8,
      bottom: 8,
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
      paddingHorizontal: 7,
      paddingVertical: 3,
      borderRadius: 6
    },
    rewardText: {
      color: "#FFFFFF",
      fontSize: 11,
      fontFamily: "Inter_900Black",
      letterSpacing: 0.6
    },
    lockText: {
      color: "#FFFFFF",
      fontSize: 11,
      fontFamily: "Inter_900Black",
      letterSpacing: 1
    },
    rarity: {
      position: "absolute",
      left: 8,
      top: 8,
      paddingHorizontal: 6,
      paddingVertical: 2,
      borderRadius: 6,
      borderWidth: 1
    },
    rarityText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.5
    },
    on: {
      position: "absolute",
      right: 8,
      top: 8,
      paddingHorizontal: 6,
      paddingVertical: 2,
      borderRadius: 6
    },
    onText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.5
    },
    info: {
      padding: 10,
      gap: 8
    },
    name: {
      fontSize: 14,
      fontFamily: "Inter_700Bold"
    },
    action: {
      borderRadius: 10,
      borderWidth: 1,
      paddingVertical: 7,
      alignItems: "center"
    },
    actionRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4
    },
    actionText: {
      fontSize: 13,
      fontFamily: "Inter_700Bold"
    }
  });
},1270,[815,818,12,228,28,188,109,829,827,819,6]);