__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  exports.getRandomBytes = getRandomBytes;
  exports.getRandomBytesAsync = getRandomBytesAsync;
  exports.digestStringAsync = digestStringAsync;
  exports.getRandomValues = getRandomValues;
  exports.randomUUID = randomUUID;
  exports.digest = digest;
  var _expo = require(_dependencyMap[0]);
  var _CryptoTypes = require(_dependencyMap[1]);
  Object.keys(_CryptoTypes).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _CryptoTypes[k];
        }
      });
    }
  });
  var _ExpoCrypto = require(_dependencyMap[2]);
  var ExpoCrypto = _interopDefault(_ExpoCrypto);
  var _aes = require(_dependencyMap[3]);
  Object.keys(_aes).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _aes[k];
        }
      });
    }
  });
  class CryptoError extends TypeError {
    code = 'ERR_CRYPTO';
    constructor(message) {
      super(`expo-crypto: ${message}`);
    }
  }
  // @needsAudit
  /**
   * Generates completely random bytes using native implementations. The `byteCount` property
   * is a `number` indicating the number of bytes to generate in the form of a `Uint8Array`.
   * Falls back to `Math.random` during development to prevent issues with React Native Debugger.
   * @param byteCount - A number within the range from `0` to `1024`. Anything else will throw a `TypeError`.
   * @return An array of random bytes with the same length as the `byteCount`.
   */
  function getRandomBytes(byteCount) {
    assertByteCount(byteCount, 'getRandomBytes');
    const validByteCount = Math.floor(byteCount);
    if (ExpoCrypto.default.getRandomValues) {
      const byteArray = new Uint8Array(validByteCount);
      ExpoCrypto.default.getRandomValues(byteArray);
      return byteArray;
    } else {
      throw new _expo.UnavailabilityError('expo-crypto', 'getRandomBytes');
    }
  }
  // @needsAudit
  /**
   * Generates completely random bytes using native implementations. The `byteCount` property
   * is a `number` indicating the number of bytes to generate in the form of a `Uint8Array`.
   * @param byteCount - A number within the range from `0` to `1024`. Anything else will throw a `TypeError`.
   * @return A promise that fulfills with an array of random bytes with the same length as the `byteCount`.
   */
  async function getRandomBytesAsync(byteCount) {
    assertByteCount(byteCount, 'getRandomBytesAsync');
    const validByteCount = Math.floor(byteCount);
    if (ExpoCrypto.default.getRandomValues) {
      const byteArray = new Uint8Array(validByteCount);
      ExpoCrypto.default.getRandomValues(byteArray);
      return byteArray;
    } else {
      throw new _expo.UnavailabilityError('expo-crypto', 'getRandomBytesAsync');
    }
  }
  function assertByteCount(value, methodName) {
    if (typeof value !== 'number' || isNaN(value) || Math.floor(value) < 0 || Math.floor(value) > 1024) {
      throw new TypeError(`expo-crypto: ${methodName}(${value}) expected a valid number from range 0...1024`);
    }
  }
  function assertAlgorithm(algorithm) {
    if (!Object.values(_CryptoTypes.CryptoDigestAlgorithm).includes(algorithm)) {
      throw new CryptoError(`Invalid algorithm provided. Expected one of: CryptoDigestAlgorithm.${Object.keys(_CryptoTypes.CryptoDigestAlgorithm).join(', AlgCryptoDigestAlgorithmorithm.')}`);
    }
  }
  function assertData(data) {
    if (typeof data !== 'string') {
      throw new CryptoError(`Invalid data provided. Expected a string.`);
    }
  }
  function assertEncoding(encoding) {
    if (!Object.values(_CryptoTypes.CryptoEncoding).includes(encoding)) {
      throw new CryptoError(`Invalid encoding provided. Expected one of: CryptoEncoding.${Object.keys(_CryptoTypes.CryptoEncoding).join(', CryptoEncoding.')}`);
    }
  }
  // @needsAudit
  /**
   * The `digestStringAsync()` method of `Crypto` generates a digest of the supplied `data` string with the provided digest `algorithm`.
   * A digest is a short fixed-length value derived from some variable-length input. **Cryptographic digests** should exhibit _collision-resistance_,
   * meaning that it's very difficult to generate multiple inputs that have equal digest values.
   * You can specify the returned string format as one of `CryptoEncoding`. By default, the resolved value will be formatted as a `HEX` string.
   * On web, this method can only be called from a secure origin (HTTPS) otherwise, an error will be thrown.
   *
   * @param algorithm The cryptographic hash function to use to transform a block of data into a fixed-size output.
   * @param data The value that will be used to generate a digest.
   * @param options Format of the digest string. Defaults to: `CryptoDigestOptions.HEX`.
   * @return Return a Promise which fulfills with a value representing the hashed input.
   *
   * @example
   * ```ts
   * const digest = await Crypto.digestStringAsync(
   *   Crypto.CryptoDigestAlgorithm.SHA512,
   *   '🥓 Easy to Digest! 💙'
   * );
   * ```
   */
  async function digestStringAsync(algorithm, data, options = {
    encoding: _CryptoTypes.CryptoEncoding.HEX
  }) {
    if (!ExpoCrypto.default.digestStringAsync) {
      throw new _expo.UnavailabilityError('expo-crypto', 'digestStringAsync');
    }
    assertAlgorithm(algorithm);
    assertData(data);
    assertEncoding(options.encoding);
    return await ExpoCrypto.default.digestStringAsync(algorithm, data, options);
  }
  /**
   * The `getRandomValues()` method of `Crypto` fills a provided `TypedArray` with cryptographically secure random values.
   *
   * @param typedArray An integer based [`TypedArray`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypedArray) to fill with cryptographically secure random values. It modifies the input array in place.
   * @return The input array filled with cryptographically secure random values.
   *
   * @example
   * ```ts
   * const byteArray = new Uint8Array(16);
   * Crypto.getRandomValues(byteArray);
   * console.log('Your lucky bytes: ' + byteArray);
   * ```
   */
  function getRandomValues(typedArray) {
    ExpoCrypto.default.getRandomValues(typedArray);
    return typedArray;
  }
  /**
   * The `randomUUID()` method returns a unique identifier based on the V4 UUID spec (RFC4122).
   * It uses cryptographically secure random values to generate the UUID.
   *
   * @return A string containing a newly generated UUIDv4 identifier
   * @example
   * ```ts
   * const UUID = Crypto.randomUUID();
   * console.log('Your UUID: ' + UUID);
   * ```
   */
  function randomUUID() {
    return ExpoCrypto.default.randomUUID();
  }
  const digestLengths = {
    [_CryptoTypes.CryptoDigestAlgorithm.SHA1]: 20,
    [_CryptoTypes.CryptoDigestAlgorithm.SHA256]: 32,
    [_CryptoTypes.CryptoDigestAlgorithm.SHA384]: 48,
    [_CryptoTypes.CryptoDigestAlgorithm.SHA512]: 64,
    [_CryptoTypes.CryptoDigestAlgorithm.MD2]: 16,
    [_CryptoTypes.CryptoDigestAlgorithm.MD4]: 16,
    [_CryptoTypes.CryptoDigestAlgorithm.MD5]: 16
  };
  // The native `digest` functions accept only typed arrays, while `BufferSource` also allows
  // `ArrayBuffer` and `DataView`. Wrap those in a `Uint8Array` view over the same bytes.
  function toTypedArray(data) {
    if (ArrayBuffer.isView(data)) {
      return data instanceof DataView ? new Uint8Array(data.buffer, data.byteOffset, data.byteLength) : data;
    }
    return new Uint8Array(data);
  }
  /**
   * The `digest()` method of `Crypto` generates a digest of the supplied `TypedArray` of bytes `data` with the provided digest `algorithm`.
   * A digest is a short fixed-length value derived from some variable-length input. **Cryptographic digests** should exhibit _collision-resistance_,
   * meaning that it's very difficult to generate multiple inputs that have equal digest values.
   * On web, this method can only be called from a secure origin (HTTPS) otherwise, an error will be thrown.
   *
   * @param algorithm The cryptographic hash function to use to transform a block of data into a fixed-size output.
   * @param data The value that will be used to generate a digest.
   * @return A Promise which fulfills with an ArrayBuffer representing the hashed input.
   * @example
   * ```ts
   * const array = new Uint8Array([1, 2, 3, 4, 5]);
   * const digest = await Crypto.digest(Crypto.CryptoDigestAlgorithm.SHA512, array);
   * console.log('Your digest: ' + digest);
   * ```
   */
  function digest(algorithm, data) {
    return new Promise((resolve, reject) => {
      try {
        if (typeof ExpoCrypto.default.digestAsync === 'function') {
          resolve(ExpoCrypto.default.digestAsync(algorithm, data));
        } else {
          const output = new Uint8Array(digestLengths[algorithm]);
          ExpoCrypto.default.digest(algorithm, output, toTypedArray(data));
          resolve(output.buffer);
        }
      } catch (error) {
        reject(error);
      }
    });
  }
},1279,[620,1280,1281,1282]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "CryptoDigestAlgorithm", {
    enumerable: true,
    get: function () {
      return CryptoDigestAlgorithm;
    }
  });
  Object.defineProperty(exports, "CryptoEncoding", {
    enumerable: true,
    get: function () {
      return CryptoEncoding;
    }
  });
  // @needsAudit
  /**
   * [`Cryptographic hash function`](https://developer.mozilla.org/en-US/docs/Glossary/Cryptographic_hash_function)
   */
  var CryptoDigestAlgorithm = /*#__PURE__*/function (CryptoDigestAlgorithm) {
    /**
    * `160` bits.
    */
    CryptoDigestAlgorithm["SHA1"] = "SHA-1";
    /**
    * `256` bits. Collision Resistant.
    */
    CryptoDigestAlgorithm["SHA256"] = "SHA-256";
    /**
    * `384` bits. Collision Resistant.
    */
    CryptoDigestAlgorithm["SHA384"] = "SHA-384";
    /**
    * `512` bits. Collision Resistant.
    */
    CryptoDigestAlgorithm["SHA512"] = "SHA-512";
    /**
    * `128` bits.
    * @platform ios
    */
    CryptoDigestAlgorithm["MD2"] = "MD2";
    /**
    * `128` bits.
    * @platform ios
    */
    CryptoDigestAlgorithm["MD4"] = "MD4";
    /**
    * `128` bits.
    * @platform android
    * @platform ios
    */
    CryptoDigestAlgorithm["MD5"] = "MD5";
    return CryptoDigestAlgorithm;
  }({});
  // @needsAudit
  var CryptoEncoding = /*#__PURE__*/function (CryptoEncoding) {
    CryptoEncoding["HEX"] = "hex";
    /**
    * Has trailing padding. Does not wrap lines. Does not have a trailing newline.
    */
    CryptoEncoding["BASE64"] = "base64";
    return CryptoEncoding;
  }({});
},1280,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _expo = require(_dependencyMap[0]);
  var _CryptoTypes = require(_dependencyMap[1]);
  const getCrypto = () => {
    if (typeof globalThis.crypto !== 'undefined') {
      return globalThis.crypto;
    } else if (typeof window !== 'undefined') {
      return window.crypto ?? window.msCrypto;
    } else {
      return crypto;
    }
  };
  var _default = {
    async digestStringAsync(algorithm, data, options) {
      const crypto1 = getCrypto();
      if (!crypto1.subtle) {
        throw new _expo.CodedError('ERR_CRYPTO_UNAVAILABLE', 'Access to the WebCrypto API is restricted to secure origins (localhost/https).');
      }
      const encoder = new TextEncoder();
      const buffer = encoder.encode(data);
      const hashedData = await crypto1.subtle.digest(algorithm, buffer);
      if (options.encoding === _CryptoTypes.CryptoEncoding.HEX) {
        return hexString(hashedData);
      } else if (options.encoding === _CryptoTypes.CryptoEncoding.BASE64) {
        return btoa(String.fromCharCode(...new Uint8Array(hashedData)));
      }
      throw new _expo.CodedError('ERR_CRYPTO_DIGEST', 'Invalid encoding type provided.');
    },
    getRandomBytes(length) {
      const array = new Uint8Array(length);
      return getCrypto().getRandomValues(array);
    },
    async getRandomBytesAsync(length) {
      const array = new Uint8Array(length);
      return getCrypto().getRandomValues(array);
    },
    getRandomValues(typedArray) {
      return getCrypto().getRandomValues(typedArray);
    },
    randomUUID() {
      return getCrypto().randomUUID();
    },
    digestAsync(algorithm, data) {
      return getCrypto().subtle.digest(algorithm, data);
    }
  };
  function hexString(buffer) {
    const byteArray = new Uint8Array(buffer);
    const hexCodes = [...byteArray].map(value => {
      const hexCode = value.toString(16);
      const paddedHexCode = hexCode.padStart(2, '0');
      return paddedHexCode;
    });
    return hexCodes.join('');
  }
},1281,[620,1280]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "AESEncryptionKey", {
    enumerable: true,
    get: function () {
      return AESEncryptionKey;
    }
  });
  Object.defineProperty(exports, "AESSealedData", {
    enumerable: true,
    get: function () {
      return AESSealedData;
    }
  });
  exports.aesEncryptAsync = aesEncryptAsync;
  exports.aesDecryptAsync = aesDecryptAsync;
  var _ExpoCryptoAES = require(_dependencyMap[0]);
  var AesCryptoModule = _interopDefault(_ExpoCryptoAES);
  var _webUtils = require(_dependencyMap[1]);
  var _aesTypes = require(_dependencyMap[2]);
  Object.keys(_aesTypes).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _aesTypes[k];
        }
      });
    }
  });
  /**
   * Represents an AES encryption key that can be used for encryption and decryption operations.
   * This class provides methods to generate, import, and export encryption keys.
   */
  class AESEncryptionKey extends AesCryptoModule.default.EncryptionKey {}
  /**
   * Represents encrypted data including the ciphertext, initialization vector, and authentication tag.
   * This class provides methods to create sealed data from various formats and extract its components.
   */
  class AESSealedData extends AesCryptoModule.default.SealedData {
    static fromParts(iv, ciphertext, tag) {
      const processedIV = convertBinaryInput(iv);
      const processedCiphertext = convertBinaryInput(ciphertext);
      if (!tag || typeof tag === 'number') {
        return AesCryptoModule.default.SealedData.fromParts(processedIV, processedCiphertext, tag);
      } else {
        const processedTag = convertBinaryInput(tag);
        return AesCryptoModule.default.SealedData.fromParts(processedIV, processedCiphertext, processedTag);
      }
    }
    /**
    * Static method. Creates a SealedData instance from a combined byte array, including the IV, ciphertext, and tag.
    * @param combined The combined data array. When providing a string, it must be base64-encoded.
    * @param config Configuration specifying IV and tag lengths.
    * @returns A SealedData object.
    */
    static fromCombined(combined, config) {
      const processedInput = convertBinaryInput(combined);
      return AesCryptoModule.default.SealedData.fromCombined(processedInput, config);
    }
  }
  /**
   * Encrypts the given plaintext using AES-GCM with the specified key.
   * @param plaintext The data to encrypt. When providing a string, it must be base64-encoded.
   * @param key The encryption key to use.
   * @param options Optional encryption parameters including nonce, tag length, and additional data.
   * @returns A promise that resolves to a SealedData instance containing the encrypted data.
   */
  function aesEncryptAsync(plaintext, key, options = {}) {
    const {
      nonce: iv,
      additionalData: aad,
      ...rest
    } = options;
    let nativeOptions = {
      ...rest
    };
    if (iv) {
      const nonce = 'bytes' in iv ? convertBinaryInput(iv.bytes, true) : iv?.length;
      nativeOptions = {
        ...nativeOptions,
        nonce
      };
    }
    if (aad) {
      const additionalData = convertBinaryInput(aad, true);
      nativeOptions = {
        ...nativeOptions,
        additionalData
      };
    }
    return AesCryptoModule.default.encryptAsync(convertBinaryInput(plaintext), key, nativeOptions);
  }
  function aesDecryptAsync(sealedData, key, options = {}) {
    const {
      additionalData,
      ...rest
    } = options;
    const nativeOptions = {
      ...rest,
      additionalData: additionalData ? convertBinaryInput(additionalData, true) : undefined
    };
    return AesCryptoModule.default.decryptAsync(sealedData, key, nativeOptions);
  }
  function convertBinaryInput(input, useBase64 = false) {
    // Native implementations don't support ArrayBuffers directly yet
    const bytes = input instanceof ArrayBuffer ? new Uint8Array(input) : input;
    if (typeof bytes !== 'string' && useBase64) {
      return (0, _webUtils.uint8ArrayToBase64)(bytes);
    }
    return bytes;
  }
},1282,[1283,1285,1284]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _expo = require(_dependencyMap[0]);
  var _aesTypes = require(_dependencyMap[1]);
  var _webUtils = require(_dependencyMap[2]);
  const DEFAULT_IV_LENGTH = 12;
  const DEFAULT_TAG_LENGTH = 16;
  const defaultConfig = {
    ivLength: DEFAULT_IV_LENGTH,
    tagLength: DEFAULT_TAG_LENGTH
  };
  class EncryptionKey {
    constructor(key, size) {
      this.key = key;
      this.keySize = size;
    }
    static async generate(size) {
      const keySize = size ?? _aesTypes.AESKeySize.AES256;
      const algorithm = {
        name: 'AES-GCM',
        length: keySize
      };
      const key = await crypto.subtle.generateKey(algorithm, true, ['encrypt', 'decrypt']);
      return new EncryptionKey(key, keySize);
    }
    static async import(input, encoding) {
      let bytes;
      if (typeof input === 'string') {
        bytes = encoding === 'base64' ? (0, _webUtils.base64ToUintArray)(input) : (0, _webUtils.hexToUintArray)(input);
      } else {
        bytes = input;
      }
      const key = await crypto.subtle.importKey('raw', bytes, 'AES-GCM', true, ['encrypt', 'decrypt']);
      return new EncryptionKey(key, bytes.byteLength * 8);
    }
    async bytes() {
      const buffer = await crypto.subtle.exportKey('raw', this.key);
      return new Uint8Array(buffer);
    }
    async encoded(encoding) {
      const bytes = await this.bytes();
      const encoded = encoding === 'base64' ? (0, _webUtils.uint8ArrayToBase64)(bytes) : (0, _webUtils.bytesToHex)(bytes);
      return encoded;
    }
    get size() {
      return this.keySize;
    }
  }
  class SealedData {
    constructor(bytes, config) {
      this.bytes = bytes;
      this.config = config;
    }
    static fromCombined(combined, config) {
      const bytes = (0, _webUtils.binaryInputBytes)(combined);
      const sealedConfig = config ?? defaultConfig;
      const minimumLength = sealedConfig.ivLength + sealedConfig.tagLength;
      if (bytes.byteLength < minimumLength) {
        throw new _expo.CodedError('ERR_INVALID_SEALED_DATA_CONFIG', `Sealed data is ${bytes.byteLength} bytes, which is too short to hold a ${sealedConfig.ivLength}-byte IV and a ${sealedConfig.tagLength}-byte authentication tag. Pass the whole combined output of encryptAsync, or set ivLength and tagLength in the config to match how the data was sealed.`);
      }
      return new SealedData(bytes, sealedConfig);
    }
    static fromParts(iv, ciphertext, tag) {
      const ciphertextBytes = (0, _webUtils.binaryInputBytes)(ciphertext);
      const ivBytes = (0, _webUtils.binaryInputBytes)(iv);
      const ivLength = ivBytes.byteLength;
      if (!tag) {
        tag = DEFAULT_TAG_LENGTH;
      }
      if (typeof tag === 'number') {
        const totalLength = ivLength + ciphertextBytes.byteLength;
        const combined = new Uint8Array(totalLength);
        combined.set(ivBytes);
        combined.set(ciphertextBytes, ivLength);
        const config = {
          ivLength,
          tagLength: tag
        };
        return new SealedData(combined, config);
      }
      const tagBytes = (0, _webUtils.binaryInputBytes)(tag);
      const tagLength = tagBytes.byteLength;
      const totalLength = ivLength + ciphertextBytes.byteLength + tagLength;
      const combined = new Uint8Array(totalLength);
      combined.set(ivBytes);
      combined.set(ciphertextBytes, ivLength);
      combined.set(tagBytes, totalLength - tagLength);
      return new SealedData(combined, {
        ivLength,
        tagLength
      });
    }
    get ivSize() {
      return this.config.ivLength;
    }
    get tagSize() {
      return this.config.tagLength;
    }
    get combinedSize() {
      return this.bytes.byteLength;
    }
    async iv(encoding) {
      const useBase64 = encoding === 'base64';
      const bytes = this.bytes.subarray(0, this.ivSize);
      return useBase64 ? (0, _webUtils.uint8ArrayToBase64)(bytes) : bytes;
    }
    async tag(encoding) {
      const useBase64 = encoding === 'base64';
      const offset = this.combinedSize - this.tagSize;
      const bytes = this.bytes.subarray(offset, offset + this.tagSize);
      return useBase64 ? (0, _webUtils.uint8ArrayToBase64)(bytes) : bytes;
    }
    async combined(encoding) {
      const useBase64 = encoding === 'base64';
      const bytes = this.bytes.subarray();
      return useBase64 ? (0, _webUtils.uint8ArrayToBase64)(bytes) : bytes;
    }
    async ciphertext(options) {
      const includeTag = options?.includeTag ?? false;
      const useBase64 = options?.encoding === 'base64';
      const taggedCiphertextLength = this.combinedSize - this.ivSize;
      const ciphertextLength = includeTag ? taggedCiphertextLength : taggedCiphertextLength - this.tagSize;
      const bytes = this.bytes.subarray(this.ivSize, this.ivSize + ciphertextLength);
      return useBase64 ? (0, _webUtils.uint8ArrayToBase64)(bytes) : bytes;
    }
  }
  class AesCryptoModule extends _expo.NativeModule {
    EncryptionKey = EncryptionKey;
    SealedData = SealedData;
    async encryptAsync(plaintext, key, options = {}) {
      const {
        nonce = DEFAULT_IV_LENGTH,
        tagLength = DEFAULT_TAG_LENGTH,
        additionalData: aad
      } = options;
      const iv = typeof nonce === 'number' ? crypto.getRandomValues(new Uint8Array(nonce)) : (0, _webUtils.binaryInputBytes)(nonce);
      const baseParams = {
        name: 'AES-GCM',
        iv,
        tagLength: tagLength * 8
      };
      // workaround for invalid AAD format error when it's present but undefined
      const gcmParams = aad ? {
        ...baseParams,
        additionalData: (0, _webUtils.binaryInputBytes)(aad)
      } : baseParams;
      const ciphertextWithTag = await crypto.subtle.encrypt(gcmParams, key.key, (0, _webUtils.binaryInputBytes)(plaintext));
      return SealedData.fromParts(iv, ciphertextWithTag, tagLength);
    }
    async decryptAsync(sealedData, key, options = {}) {
      const {
        additionalData: aad,
        output
      } = options;
      // workaround for invalid AAD format error when it's present but undefined
      const iv = await sealedData.iv();
      const baseParams = {
        name: 'AES-GCM',
        iv: iv,
        tagLength: sealedData.tagSize * 8
      };
      const gcmParams = aad ? {
        ...baseParams,
        additionalData: (0, _webUtils.binaryInputBytes)(aad)
      } : baseParams;
      const taggedCiphertext = await sealedData.ciphertext({
        includeTag: true
      });
      const plaintextBuffer = await crypto.subtle.decrypt(gcmParams, key.key, taggedCiphertext);
      const useBase64 = output === 'base64';
      const bytes = new Uint8Array(plaintextBuffer);
      return useBase64 ? (0, _webUtils.uint8ArrayToBase64)(bytes) : bytes;
    }
  }
  var _default = (0, _expo.registerWebModule)(AesCryptoModule, 'ExpoCryptoAES');
},1283,[620,1284,1285]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "AESKeySize", {
    enumerable: true,
    get: function () {
      return AESKeySize;
    }
  });
  /**
   * Represents binary input data that can be processed by AES APIs.
   * When providing a string, it must be base64-encoded.
   */ /**
      * AES key sizes in bits.
      */
  var AESKeySize = /*#__PURE__*/function (AESKeySize) {
    /** 128-bit AES key */AESKeySize[AESKeySize["AES128"] = 128] = "AES128";
    /** 192-bit AES key. It is unsupported on Web.
    * @platform apple
    * @platform android
    */
    AESKeySize[AESKeySize["AES192"] = 192] = "AES192";
    /** 256-bit AES key */
    AESKeySize[AESKeySize["AES256"] = 256] = "AES256";
    return AESKeySize;
  }({});
},1284,[]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  exports.hexToUintArray = hexToUintArray;
  exports.bytesToHex = bytesToHex;
  exports.base64ToUintArray = base64ToUintArray;
  exports.uint8ArrayToBase64 = uint8ArrayToBase64;
  exports.binaryInputBytes = binaryInputBytes;
  function hexToUintArray(hexString) {
    const byteLength = hexString.length / 2;
    const bytes = new Uint8Array(byteLength);
    for (let i = 0; i < hexString.length; i += 2) {
      bytes[i >>> 1] = parseInt(hexString.substring(i, i + 2), 16);
    }
    return bytes;
  }
  function bytesToHex(bytes) {
    const hex = [];
    for (const byte of bytes) {
      const current = byte < 0 ? byte + 256 : byte;
      hex.push((current >>> 4).toString(16));
      hex.push((current & 0xf).toString(16));
    }
    return hex.join('');
  }
  function base64ToUintArray(base64String) {
    const binaryString = atob(base64String);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }
  function uint8ArrayToBase64(uint8Array) {
    let binaryString = '';
    for (const byte of uint8Array) {
      binaryString += String.fromCharCode(byte);
    }
    return btoa(binaryString);
  }
  function binaryInputBytes(input) {
    if (input instanceof Uint8Array) {
      return input;
    }
    if (input instanceof ArrayBuffer) {
      return new Uint8Array(input);
    }
    if (ArrayBuffer.isView(input)) {
      return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
    }
    if (typeof input === 'string') {
      return base64ToUintArray(input);
    }
    throw new Error('Cannot parse serializable input as ArrayBuffer');
  }
},1285,[]);