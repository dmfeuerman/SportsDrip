__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return ActivityScreen;
    }
  });
  var _expoVectorIcons = require(_dependencyMap[0]);
  var _expoRouter = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  var _reactNativeWebDistExportsFlatList = require(_dependencyMap[3]);
  var FlatList = _interopDefault(_reactNativeWebDistExportsFlatList);
  var _reactNativeWebDistExportsRefreshControl = require(_dependencyMap[4]);
  var RefreshControl = _interopDefault(_reactNativeWebDistExportsRefreshControl);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[5]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[6]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[7]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[8]);
  var _componentsBetBreakdownModal = require(_dependencyMap[9]);
  var BetBreakdownModal = _interopDefault(_componentsBetBreakdownModal);
  var _componentsGameQuickView = require(_dependencyMap[10]);
  var GameQuickView = _interopDefault(_componentsGameQuickView);
  var _componentsInviteToastHost = require(_dependencyMap[11]);
  var _componentsUi = require(_dependencyMap[12]);
  var _contextNotificationContext = require(_dependencyMap[13]);
  var _hooksUseColors = require(_dependencyMap[14]);
  var _hooksUseNow = require(_dependencyMap[15]);
  var _reactJsxRuntime = require(_dependencyMap[16]);
  const ICON = {
    bet_won: "arrow-up-bold-circle",
    level_up: "star-circle",
    team_reminder: "bell-ring-outline",
    reaction: "emoticon-happy-outline",
    sweat_alert: "fire",
    achievement: "trophy-award",
    referral_bonus: "account-heart",
    bet_lost: "arrow-down-bold-circle",
    bet_push: "minus-circle",
    bet_refunded: "undo-variant",
    league_payout: "trophy",
    league_ended: "flag-checkered",
    league_invite: "email-outline",
    loan_funded: "handshake-outline",
    loan_repaid: "cash-refund",
    loan_countered: "swap-horizontal",
    loan_request: "hand-coin-outline",
    friend_request: "account-plus",
    friend_accepted: "account-check",
    challenge_received: "sword-cross",
    challenge_accepted: "lock",
    challenge_declined: "close-circle-outline",
    challenge_cancelled: "close-circle-outline",
    challenge_expired: "timer-sand",
    challenge_won: "trophy",
    challenge_lost: "arrow-down-bold-circle",
    challenge_push: "minus-circle",
    challenge_refunded: "undo-variant",
    bet_tailed: "account-multiple-plus",
    bet_faded: "account-switch",
    stimulus_request: "cash-plus",
    stimulus_approved: "cash-plus"
  };
  function ago(at, now) {
    const m = Math.max(0, Math.round((now - at) / 60_000));
    if (m < 1) return "now";
    if (m < 60) return `${m}m`;
    const h = Math.round(m / 60);
    if (h < 24) return `${h}h`;
    return `${Math.round(h / 24)}d`;
  }

  /** Every result, payout, loan event and invite — the history behind the popups. */
  function ActivityScreen() {
    const c = (0, _hooksUseColors.useColors)();
    const bottom = (0, _componentsUi.useBottomPad)(false);
    const now = (0, _hooksUseNow.useNow)(60_000);
    const {
      notifications,
      unreadCount,
      markAllRead,
      markRead,
      refresh
    } = (0, _contextNotificationContext.useNotifications)();
    const [refreshing, setRefreshing] = (0, _react.useState)(false);
    const [breakdown, setBreakdown] = (0, _react.useState)(null);
    const [quickGame, setQuickGame] = (0, _react.useState)(null);
    const onRefresh = (0, _react.useCallback)(async () => {
      setRefreshing(true);
      try {
        await refresh();
      } finally {
        setRefreshing(false);
      }
    }, [refresh]);

    // Opening Activity clears its badge at once; what was new stays highlighted
    // here until you leave.
    const [fresh, setFresh] = (0, _react.useState)(() => new Set());
    (0, _react.useEffect)(() => {
      if (!unreadCount) return;
      const ids = notifications.filter(n => !n.read).map(n_0 => n_0.id);
      setFresh(prev => new Set([...prev, ...ids]));
      markAllRead();
    }, [unreadCount, notifications, markAllRead]);
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
      style: [styles.container, {
        backgroundColor: c.background
      }],
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
        back: true,
        title: "Activity",
        subtitle: fresh.size ? `${fresh.size} new` : "Results, payouts, loans and invites"
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FlatList.default, {
        data: notifications,
        keyExtractor: n_1 => n_1.id,
        contentContainerStyle: [styles.list, {
          paddingBottom: bottom
        }],
        refreshControl: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(RefreshControl.default, {
          refreshing: refreshing,
          onRefresh: onRefresh,
          tintColor: c.mutedForeground
        }),
        renderItem: ({
          item: n_2
        }) => {
          const tone = (0, _contextNotificationContext.isWin)(n_2) || n_2.type === "league_payout" || n_2.type === "loan_repaid" || n_2.type === "level_up" || n_2.type === "referral_bonus" ? c.positive : (0, _contextNotificationContext.isLoss)(n_2) ? c.negative : n_2.leagueId ? c.league : (0, _contextNotificationContext.isChallenge)(n_2) ? c.accent : c.mutedForeground;
          const go = () => {
            markRead([n_2.id]);
            if (n_2.bet) {
              setBreakdown({
                id: n_2.bet.betId,
                gameId: n_2.bet.gameId,
                sport: n_2.bet.sport,
                teamName: n_2.bet.teamName,
                teamAbbr: n_2.bet.teamAbbr,
                teamColor: n_2.bet.teamColor,
                opponentAbbr: n_2.bet.opponentAbbr,
                side: n_2.bet.side,
                market: n_2.type.startsWith("challenge_") ? "challenge" : "ml",
                odds: n_2.bet.odds,
                stake: n_2.bet.stake,
                payout: n_2.bet.payout,
                status: (0, _contextNotificationContext.isWin)(n_2) ? "won" : (0, _contextNotificationContext.isLoss)(n_2) ? "lost" : n_2.type.includes("push") ? "push" : "cancelled",
                finalHomeScore: n_2.bet.finalHomeScore,
                finalAwayScore: n_2.bet.finalAwayScore,
                wallet: n_2.wallet,
                leagueId: n_2.leagueId,
                leagueName: n_2.leagueName,
                friendName: n_2.data?.friendName ?? null,
                settledAtMs: n_2.createdAtMs
              });
              return;
            }
            // Every row goes somewhere: the most specific screen for its type, else its league, else the closest list.
            const gameId = n_2.data?.gameId;
            if (n_2.type === "league_invite" && n_2.data?.code || n_2.type === "friend_request" || n_2.type === "friend_accepted" || n_2.type === "referral_bonus" || n_2.type === "level_up" || (0, _contextNotificationContext.isChallenge)(n_2)) (0, _componentsInviteToastHost.openSocialNotification)(n_2);else if (n_2.type === "achievement") _expoRouter.router.push("/trophies");else if ((n_2.type === "team_reminder" || n_2.type === "sweat_alert") && gameId) setQuickGame(gameId);else if (n_2.leagueId && (n_2.type.startsWith("loan") || n_2.type.startsWith("stimulus"))) _expoRouter.router.push({
              pathname: "/league/[id]",
              params: {
                id: n_2.leagueId,
                tab: "bank"
              }
            });else if (n_2.leagueId && (n_2.type === "bet_tailed" || n_2.type === "bet_faded" || n_2.type === "bet_refunded")) _expoRouter.router.push({
              pathname: "/league/[id]",
              params: {
                id: n_2.leagueId,
                tab: "bets"
              }
            });else if (n_2.leagueId && n_2.type === "reaction") _expoRouter.router.push({
              pathname: "/league/[id]",
              params: {
                id: n_2.leagueId,
                tab: "feed"
              }
            });else if (n_2.leagueId) _expoRouter.router.push({
              pathname: "/league/[id]",
              params: {
                id: n_2.leagueId,
                tab: "standings"
              }
            });else if (n_2.type === "team_reminder" || n_2.type === "sweat_alert") _expoRouter.router.push("/(tabs)/games");else if (n_2.type === "reaction") _expoRouter.router.push("/feed");else if (n_2.type.startsWith("loan") || n_2.type.startsWith("stimulus") || n_2.type === "league_ended" || n_2.type === "league_payout" || n_2.type === "league_invite") _expoRouter.router.push("/(tabs)/leagues");else _expoRouter.router.push("/bets");
          };
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
            accessibilityRole: "button",
            accessibilityLabel: `${n_2.title}. ${n_2.body}`,
            onPress: go,
            style: ({
              pressed
            }) => [styles.row, {
              backgroundColor: !fresh.has(n_2.id) ? c.card : c.elevated,
              borderColor: !fresh.has(n_2.id) ? c.border : c.alpha(tone, 0.4),
              opacity: pressed ? 0.85 : 1
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.icon, {
                backgroundColor: c.alpha(tone, 0.14)
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: ICON[n_2.type] ?? "bell-outline",
                size: 20,
                color: tone
              })
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1,
                gap: 2
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.title, {
                  color: c.foreground
                }],
                numberOfLines: 1,
                children: n_2.title
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.body, {
                  color: c.mutedForeground
                }],
                numberOfLines: 2,
                children: n_2.body
              }), n_2.bet && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.cta, {
                  color: c.primary
                }],
                children: "Tap for Full Bet Breakdown"
              }), n_2.type === "league_invite" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.cta, {
                  color: c.accent
                }],
                children: "Tap to Join"
              }), n_2.type === "friend_request" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.cta, {
                  color: c.accent
                }],
                children: "Tap to Respond"
              }), n_2.type === "challenge_received" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.cta, {
                  color: c.accent
                }],
                children: "Tap to Accept or Decline"
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                alignItems: "flex-end",
                gap: 4
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.time, {
                  color: c.subtleForeground
                }],
                children: ago(n_2.createdAtMs, now)
              }), n_2.delta !== 0 && (n_2.bet || n_2.type === "league_payout" || n_2.type === "loan_repaid" || n_2.type === "level_up" || n_2.type === "referral_bonus") ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Amount, {
                value: (0, _contextNotificationContext.isWin)(n_2) && n_2.bet ? n_2.bet.payout - n_2.bet.stake : n_2.delta,
                currency: n_2.wallet === "league" ? "league" : "credits",
                size: "sm",
                signed: true,
                tone: n_2.delta > 0 ? "positive" : "negative"
              }) : null, !n_2.read && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
                style: [styles.dot, {
                  backgroundColor: c.accent
                }]
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "chevron-right",
              size: 18,
              color: c.subtleForeground
            })]
          });
        },
        ListEmptyComponent: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
          icon: "bell-sleep-outline",
          title: "All Quiet",
          body: "Bet results, league payouts, loan updates and invites will show up here."
        })
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BetBreakdownModal.default, {
        item: breakdown,
        onClose: () => setBreakdown(null),
        onOpenGame: gId => setQuickGame(gId)
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(GameQuickView.default, {
        gameId: quickGame,
        onClose: () => setQuickGame(null)
      })]
    });
  }
  const styles = StyleSheet.default.create({
    container: {
      flex: 1
    },
    list: {
      padding: 16,
      gap: 8
    },
    row: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      padding: 12,
      borderRadius: 14,
      borderWidth: 1
    },
    icon: {
      width: 40,
      height: 40,
      borderRadius: 20,
      alignItems: "center",
      justifyContent: "center"
    },
    title: {
      fontSize: 14,
      fontFamily: "Inter_700Bold"
    },
    body: {
      fontSize: 12,
      lineHeight: 17,
      fontFamily: "Inter_400Regular"
    },
    cta: {
      fontSize: 12,
      fontFamily: "Inter_600SemiBold",
      marginTop: 2
    },
    time: {
      fontSize: 11,
      fontFamily: "Inter_500Medium"
    },
    dot: {
      width: 8,
      height: 8,
      borderRadius: 4
    }
  });
},757,[818,817,12,107,132,28,188,109,827,890,851,1196,836,823,819,844,6]);