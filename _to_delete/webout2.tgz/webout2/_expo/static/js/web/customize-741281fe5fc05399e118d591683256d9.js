__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return CustomizeScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _libMotion = require(_dependencyMap[2]);
  var _expoRouter = require(_dependencyMap[3]);
  var _expoRouterReactNavigation = require(_dependencyMap[4]);
  var _react = require(_dependencyMap[5]);
  var _reactNativeWebDistExportsActivityIndicator = require(_dependencyMap[6]);
  var ActivityIndicator = _interopDefault(_reactNativeWebDistExportsActivityIndicator);
  var _reactNativeWebDistExportsAnimated = require(_dependencyMap[7]);
  var Animated = _interopDefault(_reactNativeWebDistExportsAnimated);
  require(_dependencyMap[8]);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[9]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[10]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[11]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsUseWindowDimensions = require(_dependencyMap[12]);
  var useWindowDimensions = _interopDefault(_reactNativeWebDistExportsUseWindowDimensions);
  var _reactNativeWebDistExportsView = require(_dependencyMap[13]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[14]);
  var _reactNativeSafeAreaContext = require(_dependencyMap[15]);
  var _componentsAvatarDisplay = require(_dependencyMap[16]);
  var AvatarDisplay = _interopDefault(_componentsAvatarDisplay);
  var _componentsAvatarEditorControls = require(_dependencyMap[17]);
  var _componentsAvatarItemIcon = require(_dependencyMap[18]);
  var ItemIcon = _interopDefault(_componentsAvatarItemIcon);
  var _componentsCartButton = require(_dependencyMap[19]);
  var CartButton = _interopDefault(_componentsCartButton);
  var _componentsCartExitDialog = require(_dependencyMap[20]);
  var CartExitDialog = _interopDefault(_componentsCartExitDialog);
  var _componentsUi = require(_dependencyMap[21]);
  var _constantsAvatarOptions = require(_dependencyMap[22]);
  var _contextAppContext = require(_dependencyMap[23]);
  var _contextCartContext = require(_dependencyMap[24]);
  var _hooksUseCartItems = require(_dependencyMap[25]);
  var _hooksUseCatalog = require(_dependencyMap[26]);
  var _hooksUseColors = require(_dependencyMap[27]);
  var _libAvatar3dAvatarRules = require(_dependencyMap[28]);
  var _typesCatalog = require(_dependencyMap[29]);
  var _reactJsxRuntime = require(_dependencyMap[30]);
  const CATS = [{
    id: "body",
    label: "Body",
    icon: "human",
    focus: "full"
  }, {
    id: "face",
    label: "Face",
    icon: "emoticon-outline",
    focus: "head"
  }, {
    id: "hair",
    label: "Hair",
    icon: "content-cut",
    focus: "head"
  }, {
    id: "hat",
    label: "Hats",
    icon: "hat-fedora",
    focus: "head"
  }, {
    id: "eyewear",
    label: "Glasses",
    icon: "sunglasses",
    focus: "head"
  }, {
    id: "top",
    label: "Tops",
    icon: "tshirt-crew",
    focus: "torso"
  }, {
    id: "outerwear",
    label: "Jackets",
    icon: "coat-rack",
    focus: "torso"
  }, {
    id: "bottom",
    label: "Bottoms",
    icon: "human-male",
    focus: "legs"
  }, {
    id: "shoes",
    label: "Shoes",
    icon: "shoe-sneaker",
    focus: "feet"
  }, {
    id: "accessory",
    label: "Extras",
    icon: "watch-variant",
    focus: "torso"
  }];
  const isSlot = c => !["body", "face", "hair"].includes(c);
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const canon = e => Object.fromEntries(Object.entries(e).filter(([, v]) => !!v).sort(([a], [b]) => a.localeCompare(b)));

  /**
   * The character creator. A live, rotatable character on top; categories and
   * a visual item grid below. Nothing is written until Save, which commits
   * appearance and outfit together; Cancel and Reset never touch the server.
   */
  function CustomizeScreen() {
    const c = (0, _hooksUseColors.useColors)();
    const insets = (0, _reactNativeSafeAreaContext.useSafeAreaInsets)();
    const {
      height: winH,
      width: winW
    } = (0, useWindowDimensions.default)();
    const params = (0, _expoRouter.useLocalSearchParams)();
    const navigation = (0, _expoRouter.useNavigation)();
    const {
      profile,
      inventory,
      balance,
      saveLook,
      error,
      clearError
    } = (0, _contextAppContext.useApp)();
    const {
      items,
      byId
    } = (0, _hooksUseCatalog.useCatalog)();
    const cart = (0, _contextCartContext.useCart)();
    const saved = (0, _react.useMemo)(() => ({
      avatar: (0, _constantsAvatarOptions.normalizeAvatar)(profile?.avatar),
      equipped: canon(profile?.equipped ?? {})
    }), [profile?.avatar, profile?.equipped]);
    // Back with a look still in the cart: pick up where you left off (minus anything removed at checkout since).
    const [resume] = (0, _react.useState)(() => {
      const d = cart.draft;
      if (!d) return null;
      const own = new Set(inventory);
      const equipped = Object.fromEntries(Object.entries(d.equipped).filter(([, id]) => !!id && (own.has(id) || cart.has(id))));
      return {
        avatar: d.avatar,
        equipped
      };
    });
    const [avatar, setAvatar] = (0, _react.useState)(resume?.avatar ?? saved.avatar);
    const [equipped, setEquipped] = (0, _react.useState)(resume?.equipped ?? saved.equipped);
    const [cat, setCat] = (0, _react.useState)(() => CATS.some(x => x.id === params.category) ? params.category : "body");
    const [saving, setSaving] = (0, _react.useState)(false);
    const [confirm, setConfirm] = (0, _react.useState)(false);
    const [cheer, setCheer] = (0, _react.useState)(0);
    const [leaving, setLeaving] = (0, _react.useState)(false);
    const catScroll = (0, _react.useRef)(null);
    const pendingNav = (0, _react.useRef)(null);

    // Follow the server copy until the user starts editing (first load, or a
    // save from another device).
    const touched = (0, _react.useRef)(!!resume);
    (0, _react.useEffect)(() => {
      if (touched.current) return;
      setAvatar(saved.avatar);
      setEquipped(saved.equipped);
    }, [saved]);
    const dirty = !same(avatar, saved.avatar) || !same(canon(equipped), saved.equipped);
    const owned = (0, _react.useMemo)(() => new Set(inventory), [inventory]);
    const unowned = Object.values(equipped).filter(id => !!id && !owned.has(id));
    const unownedKey = unowned.join(",");
    const cartView = (0, _hooksUseCartItems.useCartItems)();

    // ── cart ─────────────────────────────────────────────────────────────────
    // Trying on a store item puts it in the cart. Swapping it for another in the
    // same session swaps it in the cart too; everything else (shop picks, earlier
    // sessions) stays until it's bought or cleared at checkout.
    const wasInCart = (0, _react.useRef)(new Set(cart.ids));
    const triedOn = (0, _react.useRef)(new Set(resume ? Object.values(resume.equipped).filter(id => !!id && !owned.has(id)) : []));
    (0, _react.useEffect)(() => {
      const now = new Set(unowned);
      for (const id of unowned) {
        if (!cart.has(id)) {
          cart.add(id);
          triedOn.current.add(id);
        }
      }
      for (const id of [...triedOn.current]) {
        if (!now.has(id)) {
          cart.remove(id);
          triedOn.current.delete(id);
        }
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [unownedKey]);
    // Checkout gets the whole draft look, to save it once everything in it is bought.
    (0, _react.useEffect)(() => {
      if (!touched.current) return;
      cart.setDraft(unowned.length ? {
        avatar,
        equipped: canon(equipped)
      } : null);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [avatar, equipped, unownedKey]);
    // Removed (or cleared) at checkout → take it off here too (back to what's saved for that slot, if owned).
    const cartKey = cart.ids.join(",");
    (0, _react.useEffect)(() => {
      for (const id of cart.ids) wasInCart.current.add(id);
      const gone = unowned.filter(id => !cart.has(id) && wasInCart.current.has(id));
      if (!gone.length) return;
      for (const id of gone) {
        wasInCart.current.delete(id);
        triedOn.current.delete(id);
      }
      setEquipped(e => {
        const next = {
          ...e
        };
        for (const id of gone) {
          const slot = byId.get(id)?.slot;
          if (!slot || next[slot] !== id) continue;
          const back = saved.equipped[slot];
          next[slot] = back && owned.has(back) ? back : undefined;
        }
        return next;
      });
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [cartKey]);

    // ── edits ────────────────────────────────────────────────────────────────
    const edit = patch => {
      touched.current = true;
      setAvatar(a => ({
        ...a,
        ...patch
      }));
    };
    const [toast, setToast] = (0, _react.useState)(null);
    const toastOpacity = (0, _react.useRef)(new Animated.default.Value(0)).current;
    const showToast = (0, _react.useCallback)(msg => {
      setToast(msg);
      toastOpacity.stopAnimation();
      Animated.default.sequence([Animated.default.timing(toastOpacity, {
        toValue: 1,
        duration: 160,
        useNativeDriver: false
      }), Animated.default.delay(2600), Animated.default.timing(toastOpacity, {
        toValue: 0,
        duration: 260,
        useNativeDriver: false
      })]).start();
    }, [toastOpacity]);
    const wear = (slot, itemId) => {
      touched.current = true;
      _libMotion.haptic.tick();
      const r = (0, _libAvatar3dAvatarRules.applyEquip)(equipped, slot, itemId, id => byId.get(id));
      setEquipped(r.equipped);
      if (r.removed.length && itemId) {
        const name = byId.get(itemId)?.name ?? "That";
        showToast(`Took off ${r.removed.map(s => _typesCatalog.SLOT_LABELS[s].toLowerCase()).join(" and ")} — ${name} can't be worn with ${r.removed.length > 1 ? "them" : "it"}.`);
      }
    };
    const reset = () => {
      _libMotion.haptic.tick();
      setAvatar(saved.avatar);
      setEquipped(saved.equipped);
      touched.current = false;
    };

    // Save with unbought items on: ask whether to buy them (saving everything
    // after checkout) or save just the character and the owned pieces.
    const [saveAsk, setSaveAsk] = (0, _react.useState)(false);
    const ownedOnly = () => {
      const out = {};
      for (const [slot, id] of Object.entries(equipped)) {
        if (!id) continue;
        if (owned.has(id)) out[slot] = id;else {
          const back = saved.equipped[slot];
          if (back && owned.has(back)) out[slot] = back;
        }
      }
      return canon(out);
    };
    const buyAndSave = () => {
      setSaveAsk(false);
      // Checkout saves this whole look (character changes included) once the items are bought.
      cart.setDraft({
        avatar,
        equipped: canon(equipped)
      });
      checkout();
    };
    const saveCharacterOnly = () => {
      setSaveAsk(false);
      void save(ownedOnly());
    };
    const save = async look => {
      if (!dirty) return;
      if (!look && unowned.length) {
        _libMotion.haptic.tick();
        setSaveAsk(true);
        return;
      }
      setSaving(true);
      const ok = await saveLook(avatar, look ?? canon(equipped));
      setSaving(false);
      if (!ok) return;
      _libMotion.haptic.success();
      touched.current = false;
      setLeaving(true);
      allowLeave();
      setCheer(n => n + 1);
      setTimeout(() => _expoRouter.router.canGoBack() ? _expoRouter.router.back() : _expoRouter.router.replace("/(tabs)/avatar"), 1300);
    };

    // ── leaving with unsaved changes ─────────────────────────────────────────
    const allowLeave = (0, _expoRouterReactNavigation.usePreventRemove)((dirty || cartView.count > 0) && !leaving, ({
      data
    }) => {
      // Checkout just bought everything and is navigating away: don't stop it.
      if (cart.justCheckedOut()) {
        allowLeave();
        navigation.dispatch(data.action);
        return;
      }
      if (!dirty && !cart.peekCount()) {
        allowLeave();
        navigation.dispatch(data.action);
        return;
      }
      pendingNav.current = data.action;
      setConfirm(true);
    });
    const close = () => _expoRouter.router.canGoBack() ? _expoRouter.router.back() : _expoRouter.router.replace("/(tabs)/avatar");
    const checkout = () => {
      pendingNav.current = null;
      setConfirm(false);
      _expoRouter.router.push({
        pathname: "/checkout",
        params: {
          from: "customize"
        }
      });
    };
    /** Leave with the cart (and the look it was tried on for) kept for later. */
    const leaveForNow = () => {
      setConfirm(false);
      setLeaving(true);
      allowLeave();
      if (pendingNav.current) navigation.dispatch(pendingNav.current);else close();
    };
    const discard = () => {
      setConfirm(false);
      cart.setDraft(null);
      setLeaving(true);
      allowLeave();
      if (pendingNav.current) navigation.dispatch(pendingNav.current);else close();
    };
    const focus = CATS.find(x => x.id === cat).focus;
    const stageH = Math.max(280, Math.min(winH * 0.46, 520));
    const cols = winW >= 700 ? 5 : winW >= 420 ? 4 : 3;
    if (!profile) {
      return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: [styles.fill, styles.centre, {
          backgroundColor: c.background
        }],
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
          color: c.primary
        })
      });
    }
    return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
      style: [styles.fill, {
        backgroundColor: c.background
      }],
      children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.header, {
          paddingTop: 18,
          borderBottomColor: c.border
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
          accessibilityRole: "button",
          accessibilityLabel: "Cancel",
          onPress: close,
          hitSlop: 10,
          style: [styles.round, {
            backgroundColor: c.secondary,
            borderColor: c.border
          }],
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "close",
            size: 18,
            color: c.foreground
          })
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          accessibilityRole: "header",
          style: [styles.title, {
            color: c.foreground
          }],
          children: "Customize"
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
          accessibilityRole: "button",
          accessibilityLabel: "Reset unsaved changes",
          disabled: !dirty,
          onPress: reset,
          hitSlop: 10,
          style: [styles.round, {
            backgroundColor: c.secondary,
            borderColor: c.border,
            opacity: dirty ? 1 : 0.4
          }],
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "undo-variant",
            size: 18,
            color: c.foreground
          })
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: saving ? "Saving" : dirty ? "Save" : "Saved",
          size: "sm",
          onPress: () => void save(),
          loading: saving,
          disabled: !dirty || saving,
          accessibilityHint: unowned.length ? "Asks whether to buy the new items or save just your character" : undefined
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(CartButton.default, {
          from: "customize"
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.stage, {
          height: stageH,
          backgroundColor: c.card,
          borderBottomColor: c.border
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [styles.floor, {
            backgroundColor: c.secondary
          }]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(AvatarDisplay.default, {
          avatar: avatar,
          equipped: equipped,
          catalog: byId,
          size: "lg",
          focus: focus,
          cheerSignal: cheer
        }), toast ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Animated.default.View, {
          pointerEvents: "none",
          style: [styles.toast, {
            opacity: toastOpacity,
            backgroundColor: c.elevated,
            borderColor: c.border
          }],
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "information-outline",
            size: 15,
            color: c.accent
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.toastText, {
              color: c.foreground
            }],
            children: toast
          })]
        }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.hint, {
            color: c.subtleForeground
          }],
          pointerEvents: "none",
          children: "Drag to turn"
        })]
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ScrollView.default, {
        ref: catScroll,
        horizontal: true,
        showsHorizontalScrollIndicator: false,
        style: [styles.catBar, {
          borderBottomColor: c.border
        }],
        contentContainerStyle: styles.catRow,
        accessibilityRole: "tablist",
        children: CATS.map(x => {
          const on = x.id === cat;
          const worn = isSlot(x.id) && !!equipped[x.id];
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
            onLayout: e => {
              // Deep-linked into a category off to the right: bring it into view.
              if (x.id === cat && e.nativeEvent.layout.x > winW * 0.6) {
                catScroll.current?.scrollTo({
                  x: e.nativeEvent.layout.x - 16,
                  animated: false
                });
              }
            },
            accessibilityRole: "tab",
            accessibilityState: {
              selected: on
            },
            accessibilityLabel: x.label,
            onPress: () => {
              _libMotion.haptic.tick();
              setCat(x.id);
            },
            style: [styles.cat, {
              backgroundColor: on ? c.primarySoft : "transparent",
              borderColor: on ? c.primary : "transparent"
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: x.icon,
              size: 20,
              color: on ? c.primary : c.mutedForeground
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.catText, {
                color: on ? c.foreground : c.mutedForeground
              }],
              children: x.label
            }), worn ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.wornDot, {
                backgroundColor: c.positive
              }]
            }) : null]
          }, x.id);
        })
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ErrorBanner, {
        message: error,
        onDismiss: clearError
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        style: styles.fill,
        contentContainerStyle: [styles.panel, {
          paddingBottom: insets.bottom + (unowned.length ? 96 : 28)
        }],
        showsVerticalScrollIndicator: false,
        children: [cat === "body" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Swatches, {
            label: "Skin Tone",
            options: _constantsAvatarOptions.SKIN_TONES,
            value: avatar.skinTone,
            onChange: skinTone => edit({
              skinTone
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Stops, {
            label: "Height",
            value: avatar.height,
            onChange: height => edit({
              height
            }),
            ends: ["Shorter", "Taller"]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Stops, {
            label: "Build",
            value: avatar.bodyType,
            onChange: bodyType => edit({
              bodyType
            }),
            ends: ["Slim", "Broad"]
          })]
        }), cat === "face" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Face Shape",
            options: _constantsAvatarOptions.FACE_SHAPES,
            value: avatar.faceShape ?? "oval",
            onChange: faceShape => edit({
              faceShape
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Eye Shape",
            options: _constantsAvatarOptions.EYE_SHAPES,
            value: avatar.eyeShape ?? "round",
            onChange: eyeShape => edit({
              eyeShape
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Swatches, {
            label: "Eyes",
            options: _constantsAvatarOptions.EYE_COLORS,
            value: avatar.eyeColor ?? _constantsAvatarOptions.EYE_COLORS[0],
            onChange: eyeColor => edit({
              eyeColor
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Brows",
            options: _constantsAvatarOptions.EYEBROWS,
            value: avatar.eyebrows ?? "soft",
            onChange: eyebrows => edit({
              eyebrows
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Nose",
            options: _constantsAvatarOptions.NOSE_SHAPES,
            value: avatar.noseShape ?? "button",
            onChange: noseShape => edit({
              noseShape
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Mouth",
            options: _constantsAvatarOptions.MOUTH_SHAPES,
            value: avatar.mouthShape ?? "neutral",
            onChange: mouthShape => edit({
              mouthShape
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Facial Hair",
            options: _constantsAvatarOptions.FACIAL_HAIR,
            value: avatar.facialHair ?? "none",
            onChange: facialHair => edit({
              facialHair
            })
          })]
        }), cat === "hair" && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_reactJsxRuntime.Fragment, {
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Chips, {
            label: "Style",
            options: _constantsAvatarOptions.HAIR_STYLES,
            value: avatar.hairStyle,
            onChange: hairStyle => edit({
              hairStyle
            })
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Swatches, {
            label: "Colour",
            options: _constantsAvatarOptions.HAIR_COLORS,
            value: avatar.hairColor,
            onChange: hairColor => edit({
              hairColor
            })
          }), equipped.hat ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.note, {
              color: c.mutedForeground
            }],
            children: "Your hat trims the hair to fit. Take it off to see the full style."
          }) : null]
        }), isSlot(cat) && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(SlotGrid, {
          slot: cat,
          items: items,
          byId: byId,
          equipped: equipped,
          owned: owned,
          cols: cols,
          onWear: wear
        })]
      }), cartView.count > 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.cartBar, {
          backgroundColor: c.elevated,
          borderColor: c.alpha(c.primary, 0.5),
          bottom: insets.bottom + 12
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "cart",
          size: 18,
          color: c.primary
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: {
            flex: 1
          },
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
            style: [styles.buyName, {
              color: c.foreground
            }],
            numberOfLines: 1,
            children: [cartView.count, " ", cartView.count === 1 ? "item" : "items", " in your cart \xB7 ", cartView.total.toLocaleString()]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: [styles.buySub, {
              color: balance < cartView.total ? c.negative : c.mutedForeground
            }],
            numberOfLines: 1,
            children: balance < cartView.total ? `You have ${balance.toLocaleString()} credits` : unowned.length ? "Buy them to save this look" : "Ready when you are"
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
          label: "Checkout",
          size: "sm",
          onPress: checkout
        })]
      }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsx)(CartExitDialog.default, {
        visible: confirm && cartView.count > 0,
        onCheckout: checkout,
        onLeave: leaveForNow,
        onCancel: () => {
          pendingNav.current = null;
          setConfirm(false);
        }
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ChoiceDialog, {
        visible: saveAsk,
        title: "Save your look?",
        body: `You're wearing ${unowned.length} item${unowned.length === 1 ? "" : "s"} you don't own yet. Buy ${unowned.length === 1 ? "it" : "them"} and save everything, or save just your character changes (the new ${unowned.length === 1 ? "item stays" : "items stay"} in your cart).`,
        actions: [{
          label: `Buy ${unowned.length === 1 ? "Item" : `${unowned.length} Items`} & Save`,
          icon: "cart-check",
          onPress: buyAndSave
        }, {
          label: "Save Character Changes",
          icon: "account-check-outline",
          variant: "secondary",
          onPress: saveCharacterOnly
        }],
        onCancel: () => setSaveAsk(false)
      }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ConfirmDialog, {
        visible: confirm && cartView.count === 0,
        title: "Discard changes?",
        body: "Your character goes back to how it was last saved.",
        confirmLabel: "Discard",
        destructive: true,
        onConfirm: discard,
        onCancel: () => {
          pendingNav.current = null;
          setConfirm(false);
        }
      })]
    });
  }
  function SlotGrid(t0) {
    const $ = (0, _reactCompilerRuntime.c)(58);
    const {
      slot,
      items,
      byId,
      equipped,
      owned,
      cols,
      onWear
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    let t1;
    if ($[0] !== byId || $[1] !== items || $[2] !== owned || $[3] !== slot) {
      const ownedHere = [...owned].map(id => byId.get(id)).filter(i => !!i && i.slot === slot);
      let t2;
      if ($[5] !== owned || $[6] !== slot) {
        t2 = i_0 => i_0.slot === slot && !owned.has(i_0.id);
        $[5] = owned;
        $[6] = slot;
        $[7] = t2;
      } else {
        t2 = $[7];
      }
      const store = items.filter(t2);
      t1 = [...ownedHere.sort(_temp), ...store];
      $[0] = byId;
      $[1] = items;
      $[2] = owned;
      $[3] = slot;
      $[4] = t1;
    } else {
      t1 = $[4];
    }
    const list = t1;
    const current = equipped[slot] ?? null;
    const w = `${100 / cols}%`;
    let t2;
    if ($[8] !== list || $[9] !== owned) {
      t2 = list.filter(i_1 => owned.has(i_1.id));
      $[8] = list;
      $[9] = owned;
      $[10] = t2;
    } else {
      t2 = $[10];
    }
    const t3 = `${_typesCatalog.SLOT_LABELS[slot]} · ${t2.length} owned`;
    let t4;
    if ($[11] !== w) {
      t4 = {
        width: w,
        padding: 4
      };
      $[11] = w;
      $[12] = t4;
    } else {
      t4 = $[12];
    }
    const t5 = current === null;
    let t6;
    if ($[13] !== t5) {
      t6 = {
        selected: t5
      };
      $[13] = t5;
      $[14] = t6;
    } else {
      t6 = $[14];
    }
    const t7 = _typesCatalog.SLOT_LABELS[slot];
    let t8;
    if ($[15] !== t7) {
      t8 = t7.toLowerCase();
      $[15] = t7;
      $[16] = t8;
    } else {
      t8 = $[16];
    }
    const t9 = `No ${t8}`;
    let t10;
    if ($[17] !== onWear || $[18] !== slot) {
      t10 = () => onWear(slot, null);
      $[17] = onWear;
      $[18] = slot;
      $[19] = t10;
    } else {
      t10 = $[19];
    }
    const t11 = current === null ? c.primary : c.border;
    const t12 = current === null ? 2 : 1;
    let t13;
    if ($[20] !== c.card || $[21] !== t11 || $[22] !== t12) {
      t13 = [styles.tile, {
        backgroundColor: c.card,
        borderColor: t11,
        borderWidth: t12
      }];
      $[20] = c.card;
      $[21] = t11;
      $[22] = t12;
      $[23] = t13;
    } else {
      t13 = $[23];
    }
    let t14;
    if ($[24] !== c.subtleForeground) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.tileArt,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "cancel",
          size: 26,
          color: c.subtleForeground
        })
      });
      $[24] = c.subtleForeground;
      $[25] = t14;
    } else {
      t14 = $[25];
    }
    let t15;
    if ($[26] !== c.mutedForeground) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.tileName, {
          color: c.mutedForeground
        }],
        numberOfLines: 1,
        children: "None"
      });
      $[26] = c.mutedForeground;
      $[27] = t15;
    } else {
      t15 = $[27];
    }
    let t16;
    if ($[28] !== t10 || $[29] !== t13 || $[30] !== t14 || $[31] !== t15 || $[32] !== t6 || $[33] !== t9) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        accessibilityRole: "radio",
        accessibilityState: t6,
        accessibilityLabel: t9,
        onPress: t10,
        style: t13,
        children: [t14, t15]
      });
      $[28] = t10;
      $[29] = t13;
      $[30] = t14;
      $[31] = t15;
      $[32] = t6;
      $[33] = t9;
      $[34] = t16;
    } else {
      t16 = $[34];
    }
    let t17;
    if ($[35] !== t16 || $[36] !== t4) {
      t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t4,
        children: t16
      });
      $[35] = t16;
      $[36] = t4;
      $[37] = t17;
    } else {
      t17 = $[37];
    }
    let t18;
    if ($[38] !== c.border || $[39] !== c.card || $[40] !== c.foreground || $[41] !== c.mutedForeground || $[42] !== c.primary || $[43] !== c.primaryForeground || $[44] !== c.secondary || $[45] !== current || $[46] !== list || $[47] !== onWear || $[48] !== owned || $[49] !== slot || $[50] !== w) {
      t18 = list.map(item => {
        const on = current === item.id;
        const mine = owned.has(item.id);
        return /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: {
            width: w,
            padding: 4
          },
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
            accessibilityRole: "radio",
            accessibilityState: {
              selected: on
            },
            accessibilityLabel: `${item.name}${mine ? "" : `, not owned, ${item.price} credits`}`,
            onPress: () => onWear(slot, on ? null : item.id),
            style: t19 => {
              const {
                pressed
              } = t19;
              return [styles.tile, {
                backgroundColor: c.card,
                borderColor: on ? c.primary : c.border,
                borderWidth: on ? 2 : 1,
                opacity: pressed ? 0.85 : 1
              }];
            },
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.rarity, {
                backgroundColor: _typesCatalog.RARITY_COLORS[item.rarity]
              }]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.tileArt, !mine && {
                opacity: 0.75
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ItemIcon.default, {
                item: item,
                size: 64
              })
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.tileName, {
                color: c.foreground
              }],
              numberOfLines: 1,
              children: item.name
            }), mine ? on ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.badge, {
                backgroundColor: c.primary
              }],
              children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "check",
                size: 12,
                color: c.primaryForeground
              })
            }) : null : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: [styles.price, {
                backgroundColor: c.secondary
              }],
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "lock",
                size: 10,
                color: c.mutedForeground
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.priceText, {
                  color: c.mutedForeground
                }],
                children: item.price.toLocaleString()
              })]
            })]
          })
        }, item.id);
      });
      $[38] = c.border;
      $[39] = c.card;
      $[40] = c.foreground;
      $[41] = c.mutedForeground;
      $[42] = c.primary;
      $[43] = c.primaryForeground;
      $[44] = c.secondary;
      $[45] = current;
      $[46] = list;
      $[47] = onWear;
      $[48] = owned;
      $[49] = slot;
      $[50] = w;
      $[51] = t18;
    } else {
      t18 = $[51];
    }
    let t19;
    if ($[52] !== t17 || $[53] !== t18) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.grid,
        children: [t17, t18]
      });
      $[52] = t17;
      $[53] = t18;
      $[54] = t19;
    } else {
      t19 = $[54];
    }
    let t20;
    if ($[55] !== t19 || $[56] !== t3) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsAvatarEditorControls.Field, {
        label: t3,
        children: t19
      });
      $[55] = t19;
      $[56] = t3;
      $[57] = t20;
    } else {
      t20 = $[57];
    }
    return t20;
  }
  function _temp(a, b) {
    return a.price - b.price;
  }
  const styles = StyleSheet.default.create({
    fill: {
      flex: 1
    },
    centre: {
      alignItems: "center",
      justifyContent: "center"
    },
    header: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      paddingHorizontal: 14,
      paddingBottom: 10,
      borderBottomWidth: StyleSheet.default.hairlineWidth
    },
    title: {
      flex: 1,
      fontSize: 18,
      fontFamily: "Inter_700Bold"
    },
    round: {
      width: 36,
      height: 36,
      borderRadius: 18,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center"
    },
    stage: {
      borderBottomWidth: StyleSheet.default.hairlineWidth,
      overflow: "hidden"
    },
    floor: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: 0,
      height: "22%"
    },
    toast: {
      position: "absolute",
      top: 10,
      left: 12,
      right: 12,
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      paddingHorizontal: 12,
      paddingVertical: 9,
      borderRadius: 12,
      borderWidth: 1
    },
    toastText: {
      flex: 1,
      fontSize: 13,
      fontFamily: "Inter_500Medium"
    },
    hint: {
      position: "absolute",
      left: 14,
      bottom: 12,
      fontSize: 11,
      fontFamily: "Inter_500Medium"
    },
    // Never squeezed: when the panel below fills up, it scrolls; the category row keeps its height.
    catBar: {
      flexGrow: 0,
      flexShrink: 0,
      borderBottomWidth: StyleSheet.default.hairlineWidth
    },
    catRow: {
      paddingHorizontal: 10,
      paddingVertical: 8,
      gap: 4
    },
    cat: {
      alignItems: "center",
      gap: 3,
      paddingHorizontal: 10,
      paddingVertical: 7,
      borderRadius: 12,
      borderWidth: 1,
      minWidth: 62
    },
    catText: {
      fontSize: 11,
      fontFamily: "Inter_600SemiBold"
    },
    wornDot: {
      position: "absolute",
      top: 6,
      right: 12,
      width: 6,
      height: 6,
      borderRadius: 3
    },
    panel: {
      padding: 16,
      gap: 18
    },
    note: {
      fontSize: 13,
      fontFamily: "Inter_400Regular",
      lineHeight: 18
    },
    grid: {
      flexDirection: "row",
      flexWrap: "wrap",
      marginHorizontal: -4
    },
    tile: {
      borderRadius: 14,
      padding: 8,
      alignItems: "center",
      gap: 4,
      overflow: "hidden"
    },
    tileArt: {
      width: 64,
      height: 64,
      alignItems: "center",
      justifyContent: "center"
    },
    tileName: {
      fontSize: 11,
      fontFamily: "Inter_600SemiBold",
      alignSelf: "stretch",
      textAlign: "center"
    },
    rarity: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      height: 3
    },
    badge: {
      position: "absolute",
      top: 7,
      right: 7,
      width: 18,
      height: 18,
      borderRadius: 9,
      alignItems: "center",
      justifyContent: "center"
    },
    price: {
      position: "absolute",
      top: 7,
      right: 6,
      flexDirection: "row",
      alignItems: "center",
      gap: 3,
      paddingHorizontal: 6,
      paddingVertical: 2,
      borderRadius: 8
    },
    priceText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold"
    },
    cartBar: {
      position: "absolute",
      left: 12,
      right: 12,
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      borderRadius: 16,
      borderWidth: 1,
      paddingVertical: 10,
      paddingHorizontal: 14,
      shadowColor: "#000",
      shadowOpacity: 0.25,
      shadowRadius: 12,
      shadowOffset: {
        width: 0,
        height: 4
      },
      elevation: 6
    },
    buyName: {
      fontSize: 14,
      fontFamily: "Inter_700Bold"
    },
    buySub: {
      fontSize: 12,
      fontFamily: "Inter_400Regular"
    }
  });
},761,[815,818,820,817,1216,12,228,102,104,133,28,188,269,109,827,271,828,1217,834,830,1218,836,894,837,1191,1215,838,819,1219,839,6]);