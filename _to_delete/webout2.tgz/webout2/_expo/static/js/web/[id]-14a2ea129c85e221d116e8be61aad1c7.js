__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return GameCenterScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _libPresence = require(_dependencyMap[2]);
  var _hooksUseFriends = require(_dependencyMap[3]);
  var _libMotion = require(_dependencyMap[4]);
  var _expoRouter = require(_dependencyMap[5]);
  var _react = require(_dependencyMap[6]);
  var _reactNativeWebDistExportsRefreshControl = require(_dependencyMap[7]);
  var RefreshControl = _interopDefault(_reactNativeWebDistExportsRefreshControl);
  var _reactNativeWebDistExportsScrollView = require(_dependencyMap[8]);
  var ScrollView = _interopDefault(_reactNativeWebDistExportsScrollView);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[9]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[10]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[11]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[12]);
  var _reactNativeReanimated = require(_dependencyMap[13]);
  var Animated = _interopDefault(_reactNativeReanimated);
  var _componentsScrollHint = require(_dependencyMap[14]);
  var ScrollHint = _interopDefault(_componentsScrollHint);
  var _componentsInsights = require(_dependencyMap[15]);
  var _componentsUi = require(_dependencyMap[16]);
  var _contextAppContext = require(_dependencyMap[17]);
  var _contextChallengeContext = require(_dependencyMap[18]);
  var _contextLeagueContext = require(_dependencyMap[19]);
  var _hooksUseColors = require(_dependencyMap[20]);
  var _hooksUseGame = require(_dependencyMap[21]);
  var _hooksUseGameInsights = require(_dependencyMap[22]);
  var _hooksUseNow = require(_dependencyMap[23]);
  var _libOdds = require(_dependencyMap[24]);
  var _libSettings = require(_dependencyMap[25]);
  var _reactJsxRuntime = require(_dependencyMap[26]);
  function GameCenterScreen() {
    const $ = (0, _reactCompilerRuntime.c)(124);
    const c = (0, _hooksUseColors.useColors)();
    const fmt = (0, _libSettings.useOddsFormat)();
    const bottom = (0, _componentsUi.useBottomPad)(false);
    const params = (0, _expoRouter.useLocalSearchParams)();
    const gameId = typeof params.id === "string" && params.id ? params.id : null;
    const {
      game,
      loading,
      missing
    } = (0, _hooksUseGame.useGame)(gameId);
    const insights = (0, _hooksUseGameInsights.useGameInsights)(gameId, game?.status);
    const {
      bets
    } = (0, _contextAppContext.useApp)();
    const {
      leagues,
      myLeagueBets,
      uid
    } = (0, _contextLeagueContext.useLeague)();
    const {
      byLeague: leagueSweats
    } = (0, _contextLeagueContext.useGameLeagueSweat)(gameId ?? undefined);
    const live = game?.status === "live";
    const now = (0, _hooksUseNow.useNow)(live ? 5000 : 60000);
    const [tab, setTab] = (0, _react.useState)(params.tab === "matchup" ? "matchup" : "live");
    const {
      profile
    } = (0, _contextAppContext.useApp)();
    const {
      friends
    } = (0, _hooksUseFriends.useFriends)(profile?.uid ?? null);
    let t0;
    if ($[0] !== friends) {
      t0 = friends.map(_temp);
      $[0] = friends;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    const presence = (0, _libPresence.usePresence)(t0);
    let t1;
    if ($[2] !== gameId || $[3] !== now || $[4] !== presence) {
      t1 = f_0 => presence[f_0.uid]?.gameId === gameId && (presence[f_0.uid]?.at ?? 0) > now - _libPresence.ONLINE_MS;
      $[2] = gameId;
      $[3] = now;
      $[4] = presence;
      $[5] = t1;
    } else {
      t1 = $[5];
    }
    const watching = friends.filter(t1);
    let t2;
    let t3;
    if ($[6] !== gameId) {
      t2 = () => {
        if (!gameId) {
          return;
        }
        (0, _libPresence.setWatchingGame)(gameId);
        return _temp2;
      };
      t3 = [gameId];
      $[6] = gameId;
      $[7] = t2;
      $[8] = t3;
    } else {
      t2 = $[7];
      t3 = $[8];
    }
    (0, _react.useEffect)(t2, t3);
    const challenges = (0, _contextChallengeContext.useChallenges)();
    let t4;
    bb0: {
      const me = challenges.uid;
      if (!me || !gameId) {
        let t5;
        if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
          t5 = [];
          $[9] = t5;
        } else {
          t5 = $[9];
        }
        t4 = t5;
        break bb0;
      }
      let t5;
      if ($[10] !== challenges.challenges || $[11] !== gameId || $[12] !== me) {
        let t6;
        if ($[14] !== gameId) {
          t6 = ch => ch.gameId === gameId && (ch.status === "pending" || ch.status === "accepted" || ch.status === "settled");
          $[14] = gameId;
          $[15] = t6;
        } else {
          t6 = $[15];
        }
        let t7;
        if ($[16] !== me) {
          t7 = ch_0 => (0, _contextChallengeContext.viewOf)(ch_0, me);
          $[16] = me;
          $[17] = t7;
        } else {
          t7 = $[17];
        }
        t5 = challenges.challenges.filter(t6).map(t7);
        $[10] = challenges.challenges;
        $[11] = gameId;
        $[12] = me;
        $[13] = t5;
      } else {
        t5 = $[13];
      }
      t4 = t5;
    }
    const duels = t4;
    const [refreshing, setRefreshing] = (0, _react.useState)(false);
    const hint = (0, _componentsScrollHint.useScrollHint)();
    let out;
    if ($[18] !== bets || $[19] !== gameId || $[20] !== leagues || $[21] !== myLeagueBets) {
      out = [];
      for (const b of bets) {
        if (b.gameId === gameId && b.status !== "cancelled") {
          out.push({
            key: b.id,
            bet: b,
            wallet: null
          });
        }
      }
      for (const lg of leagues) {
        for (const b_0 of myLeagueBets[lg.id] ?? []) {
          if (b_0.gameId === gameId && b_0.status !== "cancelled") {
            out.push({
              key: `${lg.id}:${b_0.id}`,
              bet: b_0,
              wallet: lg.name
            });
          }
        }
      }
      $[18] = bets;
      $[19] = gameId;
      $[20] = leagues;
      $[21] = myLeagueBets;
      $[22] = out;
    } else {
      out = $[22];
    }
    const positions = out;
    const scoreKey = game ? `${game.awayScore}-${game.homeScore}` : "";
    const lastScore = (0, _react.useRef)(scoreKey);
    let t5;
    let t6;
    if ($[23] !== live || $[24] !== positions.length || $[25] !== scoreKey) {
      t5 = () => {
        if (lastScore.current && scoreKey && lastScore.current !== scoreKey && live && positions.length) {
          _libMotion.haptic.light();
        }
        lastScore.current = scoreKey;
      };
      t6 = [scoreKey, live, positions.length];
      $[23] = live;
      $[24] = positions.length;
      $[25] = scoreKey;
      $[26] = t5;
      $[27] = t6;
    } else {
      t5 = $[26];
      t6 = $[27];
    }
    (0, _react.useEffect)(t5, t6);
    const started = !!game && game.status !== "upcoming";
    const shown = started ? tab : "matchup";
    let t7;
    if ($[28] !== insights) {
      t7 = async () => {
        setRefreshing(true);
        await insights.reload();
        setRefreshing(false);
      };
      $[28] = insights;
      $[29] = t7;
    } else {
      t7 = $[29];
    }
    const onRefresh = t7;
    const title = game ? `${game.awayTeam.abbreviation} @ ${game.homeTeam.abbreviation}` : "Game";
    const watchingText = watching.length ? `👀 ${watching.slice(0, 2).map(_temp3).join(", ")}${watching.length > 2 ? ` +${watching.length - 2}` : ""} watching` : null;
    let t8;
    if ($[30] !== game || $[31] !== watchingText) {
      t8 = game ? [game.sport, game.seasonLabel, watchingText].filter(Boolean).join(" \xB7 ") : undefined;
      $[30] = game;
      $[31] = watchingText;
      $[32] = t8;
    } else {
      t8 = $[32];
    }
    const subtitle = t8;
    if (!game) {
      let t9;
      if ($[33] !== positions) {
        t9 = positions.find(_temp4);
        $[33] = positions;
        $[34] = t9;
      } else {
        t9 = $[34];
      }
      const settled = t9;
      let t10;
      if ($[35] !== c.background) {
        t10 = [styles.container, {
          backgroundColor: c.background
        }];
        $[35] = c.background;
        $[36] = t10;
      } else {
        t10 = $[36];
      }
      let t11;
      if ($[37] !== title) {
        t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
          back: true,
          title: title
        });
        $[37] = title;
        $[38] = t11;
      } else {
        t11 = $[38];
      }
      let t12;
      if ($[39] !== loading || $[40] !== missing || $[41] !== settled) {
        t12 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: styles.body,
          children: loading ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsInsights.InsightsSkeleton, {
            rows: 2
          }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.EmptyState, {
            icon: "calendar-remove",
            title: missing ? "This game has been archived" : "Can't load this game",
            body: settled ? `Final: ${settled.bet.teamAbbr} ${settled.bet.side === "home" ? settled.bet.finalHomeScore : settled.bet.finalAwayScore}, ${settled.bet.opponentAbbr} ${settled.bet.side === "home" ? settled.bet.finalAwayScore : settled.bet.finalHomeScore}. Your bet history keeps the result.` : "Finished games drop off the board after two days. Your bet history keeps the result.",
            action: "My Bets",
            onAction: _temp5
          })
        });
        $[39] = loading;
        $[40] = missing;
        $[41] = settled;
        $[42] = t12;
      } else {
        t12 = $[42];
      }
      let t13;
      if ($[43] !== t10 || $[44] !== t11 || $[45] !== t12) {
        t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: t10,
          children: [t11, t12]
        });
        $[43] = t10;
        $[44] = t11;
        $[45] = t12;
        $[46] = t13;
      } else {
        t13 = $[46];
      }
      return t13;
    }
    let t9;
    if ($[47] !== insights.data || $[48] !== now) {
      t9 = insights.data ? Math.max(0, Math.round((now - insights.data.fetchedAt) / 1000)) : null;
      $[47] = insights.data;
      $[48] = now;
      $[49] = t9;
    } else {
      t9 = $[49];
    }
    const updated = t9;
    let t10;
    if ($[50] !== c.background) {
      t10 = [styles.container, {
        backgroundColor: c.background
      }];
      $[50] = c.background;
      $[51] = t10;
    } else {
      t10 = $[51];
    }
    let t11;
    if ($[52] !== onRefresh) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.IconButton, {
        icon: "refresh",
        label: "Refresh Stats",
        onPress: () => void onRefresh()
      });
      $[52] = onRefresh;
      $[53] = t11;
    } else {
      t11 = $[53];
    }
    let t12;
    if ($[54] !== live || $[55] !== started || $[56] !== tab) {
      t12 = started ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.TabStrip, {
        value: tab,
        onChange: setTab,
        options: [{
          value: "live",
          label: live ? "Live" : "Recap"
        }, {
          value: "matchup",
          label: "Matchup"
        }]
      }) : null;
      $[54] = live;
      $[55] = started;
      $[56] = tab;
      $[57] = t12;
    } else {
      t12 = $[57];
    }
    let t13;
    if ($[58] !== subtitle || $[59] !== t11 || $[60] !== t12 || $[61] !== title) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ScreenHeader, {
        back: true,
        title: title,
        subtitle: subtitle,
        right: t11,
        children: t12
      });
      $[58] = subtitle;
      $[59] = t11;
      $[60] = t12;
      $[61] = title;
      $[62] = t13;
    } else {
      t13 = $[62];
    }
    let t14;
    if ($[63] === Symbol.for("react.memo_cache_sentinel")) {
      t14 = {
        flex: 1
      };
      $[63] = t14;
    } else {
      t14 = $[63];
    }
    const t15 = hint.scrollProps;
    let t16;
    if ($[64] !== bottom) {
      t16 = [styles.body, {
        paddingBottom: bottom
      }];
      $[64] = bottom;
      $[65] = t16;
    } else {
      t16 = $[65];
    }
    let t17;
    if ($[66] !== c.primary || $[67] !== onRefresh || $[68] !== refreshing) {
      t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(RefreshControl.default, {
        refreshing: refreshing,
        onRefresh: onRefresh,
        tintColor: c.primary
      });
      $[66] = c.primary;
      $[67] = onRefresh;
      $[68] = refreshing;
      $[69] = t17;
    } else {
      t17 = $[69];
    }
    let t18;
    if ($[70] !== c || $[71] !== fmt || $[72] !== game || $[73] !== now) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Scoreboard, {
        game: game,
        now: now,
        c: c,
        fmt: fmt
      });
      $[70] = c;
      $[71] = fmt;
      $[72] = game;
      $[73] = now;
      $[74] = t18;
    } else {
      t18 = $[74];
    }
    let t19;
    if ($[75] !== c || $[76] !== fmt || $[77] !== game || $[78] !== positions) {
      t19 = positions.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Positions, {
        game: game,
        positions: positions,
        c: c,
        fmt: fmt
      });
      $[75] = c;
      $[76] = fmt;
      $[77] = game;
      $[78] = positions;
      $[79] = t19;
    } else {
      t19 = $[79];
    }
    let t20;
    if ($[80] !== c || $[81] !== duels || $[82] !== fmt || $[83] !== game) {
      t20 = duels.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Duels, {
        game: game,
        duels: duels,
        c: c,
        fmt: fmt
      });
      $[80] = c;
      $[81] = duels;
      $[82] = fmt;
      $[83] = game;
      $[84] = t20;
    } else {
      t20 = $[84];
    }
    let t21;
    if ($[85] !== c || $[86] !== fmt || $[87] !== game || $[88] !== leagueSweats || $[89] !== uid) {
      t21 = leagueSweats.length > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(LeagueSweat, {
        game: game,
        sweats: leagueSweats,
        uid: uid,
        c: c,
        fmt: fmt
      });
      $[85] = c;
      $[86] = fmt;
      $[87] = game;
      $[88] = leagueSweats;
      $[89] = uid;
      $[90] = t21;
    } else {
      t21 = $[90];
    }
    let t22;
    if ($[91] !== game || $[92] !== insights || $[93] !== shown) {
      t22 = shown === "live" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Animated.default.View, {
        entering: _reactNativeReanimated.FadeIn.duration(200),
        style: styles.stack,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsInsights.SituationCard, {
          game: game
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsInsights.WinProbability, {
          game: game,
          insights: insights.data
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsInsights.Linescore, {
          game: game,
          insights: insights.data
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsInsights.ScoringTimeline, {
          game: game,
          insights: insights.data
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsInsights.KeyPlayersBlock, {
          game: game,
          insights: insights.data
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsInsights.TeamStatsBlock, {
          game: game,
          insights: insights.data,
          limit: 14
        }), !insights.data && insights.loading ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsInsights.InsightsSkeleton, {}) : null, !insights.data && insights.error ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsInsights.Note, {
          icon: "wifi-off",
          text: `Live details aren't loading. ${insights.error}`,
          action: "Retry",
          onAction: () => void insights.reload()
        }) : null]
      }, "live") : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Animated.default.View, {
        entering: _reactNativeReanimated.FadeIn.duration(200),
        style: styles.stack,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsInsights.MatchupInsights, {
          game: game,
          insights: insights.data,
          loading: insights.loading,
          error: insights.error,
          onRetry: () => void insights.reload()
        })
      }, "matchup");
      $[91] = game;
      $[92] = insights;
      $[93] = shown;
      $[94] = t22;
    } else {
      t22 = $[94];
    }
    let t23;
    if ($[95] !== c.subtleForeground) {
      t23 = [styles.footer, {
        color: c.subtleForeground
      }];
      $[95] = c.subtleForeground;
      $[96] = t23;
    } else {
      t23 = $[96];
    }
    const t24 = game.venue ? `${game.venue}${game.city ? `, ${game.city}` : ""}` : null;
    const t25 = game.broadcast ? `Watch on ${game.broadcast}` : null;
    const t26 = updated !== null && live ? `${updated < 5 ? "Stats just updated" : `Stats updated ${updated}s ago`} · refreshes every 30s` : null;
    let t27;
    if ($[97] !== t24 || $[98] !== t25 || $[99] !== t26) {
      t27 = [t24, t25, t26].filter(Boolean);
      $[97] = t24;
      $[98] = t25;
      $[99] = t26;
      $[100] = t27;
    } else {
      t27 = $[100];
    }
    const t28 = t27.join("\n");
    let t29;
    if ($[101] !== t23 || $[102] !== t28) {
      t29 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t23,
        children: t28
      });
      $[101] = t23;
      $[102] = t28;
      $[103] = t29;
    } else {
      t29 = $[103];
    }
    let t30;
    if ($[104] !== hint.scrollProps || $[105] !== t16 || $[106] !== t17 || $[107] !== t18 || $[108] !== t19 || $[109] !== t20 || $[110] !== t21 || $[111] !== t22 || $[112] !== t29) {
      t30 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(ScrollView.default, {
        ...t15,
        contentContainerStyle: t16,
        showsVerticalScrollIndicator: true,
        refreshControl: t17,
        children: [t18, t19, t20, t21, t22, t29]
      });
      $[104] = hint.scrollProps;
      $[105] = t16;
      $[106] = t17;
      $[107] = t18;
      $[108] = t19;
      $[109] = t20;
      $[110] = t21;
      $[111] = t22;
      $[112] = t29;
      $[113] = t30;
    } else {
      t30 = $[113];
    }
    let t31;
    if ($[114] !== c.background || $[115] !== hint.visible) {
      t31 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ScrollHint.default, {
        visible: hint.visible,
        bg: c.background,
        label: "Scroll For Full Matchup"
      });
      $[114] = c.background;
      $[115] = hint.visible;
      $[116] = t31;
    } else {
      t31 = $[116];
    }
    let t32;
    if ($[117] !== t30 || $[118] !== t31) {
      t32 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t14,
        children: [t30, t31]
      });
      $[117] = t30;
      $[118] = t31;
      $[119] = t32;
    } else {
      t32 = $[119];
    }
    let t33;
    if ($[120] !== t10 || $[121] !== t13 || $[122] !== t32) {
      t33 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t10,
        children: [t13, t32]
      });
      $[120] = t10;
      $[121] = t13;
      $[122] = t32;
      $[123] = t33;
    } else {
      t33 = $[123];
    }
    return t33;
  }
  function _temp5() {
    return _expoRouter.router.replace("/bets");
  }
  function _temp4(p) {
    return p.bet.finalHomeScore !== undefined && p.bet.finalAwayScore !== undefined;
  }
  function _temp3(f_1) {
    return f_1.displayName;
  }
  function _temp2() {
    return (0, _libPresence.setWatchingGame)(null);
  }
  function _temp(f) {
    return f.uid;
  }
  function Scoreboard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(46);
    const {
      game,
      now,
      c,
      fmt
    } = t0;
    const live = game.status === "live";
    const final = game.status === "final";
    const leader = game.homeScore !== null && game.awayScore !== null && game.homeScore !== game.awayScore ? game.homeScore > game.awayScore ? "home" : "away" : null;
    let t1;
    if ($[0] !== c || $[1] !== live) {
      t1 = live ? c.alpha(c.live, 0.45) : c.border;
      $[0] = c;
      $[1] = live;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    let t2;
    if ($[3] !== c.card || $[4] !== t1) {
      t2 = [styles.hero, {
        backgroundColor: c.card,
        borderColor: t1
      }];
      $[3] = c.card;
      $[4] = t1;
      $[5] = t2;
    } else {
      t2 = $[5];
    }
    const t3 = final && leader === "home";
    let t4;
    if ($[6] !== c || $[7] !== fmt || $[8] !== game.awayScore || $[9] !== game.awayTeam || $[10] !== t3) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(HeroTeam, {
        team: game.awayTeam,
        score: game.awayScore,
        dim: t3,
        c: c,
        fmt: fmt
      });
      $[6] = c;
      $[7] = fmt;
      $[8] = game.awayScore;
      $[9] = game.awayTeam;
      $[10] = t3;
      $[11] = t4;
    } else {
      t4 = $[11];
    }
    let t5;
    if ($[12] !== c || $[13] !== live) {
      t5 = live ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.livePill, {
          backgroundColor: c.alpha(c.live, 0.14)
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsInsights.LiveDot, {
          size: 7
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.livePillText, {
            color: c.live
          }],
          children: "LIVE"
        })]
      }) : null;
      $[12] = c;
      $[13] = live;
      $[14] = t5;
    } else {
      t5 = $[14];
    }
    const t6 = live ? c.foreground : c.mutedForeground;
    let t7;
    if ($[15] !== t6) {
      t7 = [styles.heroClock, {
        color: t6
      }];
      $[15] = t6;
      $[16] = t7;
    } else {
      t7 = $[16];
    }
    let t8;
    if ($[17] !== final || $[18] !== game.clock || $[19] !== game.startsAt || $[20] !== live || $[21] !== now) {
      t8 = live ? game.clock ?? "In progress" : final ? "Final" : (0, _libOdds.kickoffLabel)(game.startsAt, now);
      $[17] = final;
      $[18] = game.clock;
      $[19] = game.startsAt;
      $[20] = live;
      $[21] = now;
      $[22] = t8;
    } else {
      t8 = $[22];
    }
    let t9;
    if ($[23] !== t7 || $[24] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t7,
        numberOfLines: 2,
        children: t8
      });
      $[23] = t7;
      $[24] = t8;
      $[25] = t9;
    } else {
      t9 = $[25];
    }
    let t10;
    if ($[26] !== c.subtleForeground || $[27] !== game.startsAt || $[28] !== game.status || $[29] !== now) {
      t10 = game.status === "upcoming" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.heroSub, {
          color: c.subtleForeground
        }],
        children: (0, _libOdds.untilKickoff)(game.startsAt, now)
      }) : null;
      $[26] = c.subtleForeground;
      $[27] = game.startsAt;
      $[28] = game.status;
      $[29] = now;
      $[30] = t10;
    } else {
      t10 = $[30];
    }
    let t11;
    if ($[31] !== t10 || $[32] !== t5 || $[33] !== t9) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.heroMid,
        children: [t5, t9, t10]
      });
      $[31] = t10;
      $[32] = t5;
      $[33] = t9;
      $[34] = t11;
    } else {
      t11 = $[34];
    }
    const t12 = final && leader === "away";
    let t13;
    if ($[35] !== c || $[36] !== fmt || $[37] !== game.homeScore || $[38] !== game.homeTeam || $[39] !== t12) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(HeroTeam, {
        team: game.homeTeam,
        score: game.homeScore,
        dim: t12,
        c: c,
        fmt: fmt
      });
      $[35] = c;
      $[36] = fmt;
      $[37] = game.homeScore;
      $[38] = game.homeTeam;
      $[39] = t12;
      $[40] = t13;
    } else {
      t13 = $[40];
    }
    let t14;
    if ($[41] !== t11 || $[42] !== t13 || $[43] !== t2 || $[44] !== t4) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t2,
        children: [t4, t11, t13]
      });
      $[41] = t11;
      $[42] = t13;
      $[43] = t2;
      $[44] = t4;
      $[45] = t14;
    } else {
      t14 = $[45];
    }
    return t14;
  }
  function HeroTeam(t0) {
    const $ = (0, _reactCompilerRuntime.c)(37);
    const {
      team,
      score,
      dim,
      c,
      fmt
    } = t0;
    let t1;
    if ($[0] !== c || $[1] !== team.color) {
      t1 = c.alpha(team.color, 0.2);
      $[0] = c;
      $[1] = team.color;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    let t2;
    if ($[3] !== t1 || $[4] !== team.color) {
      t2 = [styles.heroLogo, styles.heroFallback, {
        backgroundColor: t1,
        borderColor: team.color
      }];
      $[3] = t1;
      $[4] = team.color;
      $[5] = t2;
    } else {
      t2 = $[5];
    }
    let t3;
    if ($[6] !== c.foreground) {
      t3 = [styles.heroAbbr, {
        color: c.foreground
      }];
      $[6] = c.foreground;
      $[7] = t3;
    } else {
      t3 = $[7];
    }
    let t4;
    if ($[8] !== t3 || $[9] !== team.abbreviation) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t3,
        children: team.abbreviation
      });
      $[8] = t3;
      $[9] = team.abbreviation;
      $[10] = t4;
    } else {
      t4 = $[10];
    }
    let t5;
    if ($[11] !== t2 || $[12] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: t2,
        children: t4
      });
      $[11] = t2;
      $[12] = t4;
      $[13] = t5;
    } else {
      t5 = $[13];
    }
    let t6;
    if ($[14] !== c.foreground) {
      t6 = [styles.heroName, {
        color: c.foreground
      }];
      $[14] = c.foreground;
      $[15] = t6;
    } else {
      t6 = $[15];
    }
    let t7;
    if ($[16] !== team.location || $[17] !== team.name) {
      t7 = team.location && team.name.startsWith(team.location) ? team.name.slice(team.location.length).trim() || team.name : team.name;
      $[16] = team.location;
      $[17] = team.name;
      $[18] = t7;
    } else {
      t7 = $[18];
    }
    let t8;
    if ($[19] !== t6 || $[20] !== t7) {
      t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t6,
        numberOfLines: 1,
        children: t7
      });
      $[19] = t6;
      $[20] = t7;
      $[21] = t8;
    } else {
      t8 = $[21];
    }
    let t9;
    if ($[22] !== c.subtleForeground || $[23] !== team.record) {
      t9 = team.record ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.heroSub, {
          color: c.subtleForeground
        }],
        children: team.record
      }) : null;
      $[22] = c.subtleForeground;
      $[23] = team.record;
      $[24] = t9;
    } else {
      t9 = $[24];
    }
    let t10;
    if ($[25] !== c.foreground || $[26] !== c.mutedForeground || $[27] !== dim || $[28] !== fmt || $[29] !== score || $[30] !== team.odds) {
      t10 = score !== null ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Animated.default.Text, {
        entering: _reactNativeReanimated.ZoomIn.duration(260),
        style: [styles.heroScore, {
          color: dim ? c.mutedForeground : c.foreground
        }],
        children: score
      }, score) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.heroOdds, {
          color: c.mutedForeground
        }],
        children: team.odds != null && team.odds > 1 ? `${(0, _libOdds.formatOdds)(team.odds, fmt)} · ${(0, _libOdds.formatPercent)((0, _libOdds.impliedProbability)(team.odds))}` : _libOdds.NO_LINE
      });
      $[25] = c.foreground;
      $[26] = c.mutedForeground;
      $[27] = dim;
      $[28] = fmt;
      $[29] = score;
      $[30] = team.odds;
      $[31] = t10;
    } else {
      t10 = $[31];
    }
    let t11;
    if ($[32] !== t10 || $[33] !== t5 || $[34] !== t8 || $[35] !== t9) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.heroTeam,
        children: [t5, t8, t9, t10]
      });
      $[32] = t10;
      $[33] = t5;
      $[34] = t8;
      $[35] = t9;
      $[36] = t11;
    } else {
      t11 = $[36];
    }
    return t11;
  }
  const STATUS_TONE = {
    won: {
      label: "Won",
      tone: "positive"
    },
    lost: {
      label: "Lost",
      tone: "negative"
    },
    push: {
      label: "Push",
      tone: "neutral"
    }
  };
  function Positions(t0) {
    const $ = (0, _reactCompilerRuntime.c)(29);
    const {
      game,
      positions,
      c,
      fmt
    } = t0;
    let t1;
    if ($[0] !== c.foreground) {
      t1 = [styles.sectionTitle, {
        color: c.foreground
      }];
      $[0] = c.foreground;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    const t2 = positions.length === 1 ? "bet" : `bets (${positions.length})`;
    let t3;
    if ($[2] !== t1 || $[3] !== t2) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        accessibilityRole: "header",
        style: t1,
        children: ["Your ", t2]
      });
      $[2] = t1;
      $[3] = t2;
      $[4] = t3;
    } else {
      t3 = $[4];
    }
    let t4;
    if ($[5] !== c.border || $[6] !== c.card || $[7] !== c.foreground || $[8] !== c.league || $[9] !== c.mutedForeground || $[10] !== c.negative || $[11] !== c.positive || $[12] !== fmt || $[13] !== game || $[14] !== positions) {
      let t5;
      if ($[16] !== c.border || $[17] !== c.card || $[18] !== c.foreground || $[19] !== c.league || $[20] !== c.mutedForeground || $[21] !== c.negative || $[22] !== c.positive || $[23] !== fmt || $[24] !== game) {
        t5 = t6 => {
          const {
            key,
            bet,
            wallet
          } = t6;
          const pos = bet.status === "pending" ? (0, _libOdds.livePosition)(game, bet) : null;
          const settled = STATUS_TONE[bet.status];
          const nowValue = pos === "ahead" ? bet.potentialPayout : pos === "level" ? bet.stake : pos === "behind" ? 0 : null;
          const tone = settled ? settled.tone : pos === "ahead" ? "positive" : pos === "behind" ? "negative" : pos === "level" ? "warning" : "accent";
          const label = settled ? settled.label : pos ? pos[0].toUpperCase() + pos.slice(1) : "Open";
          const currency = wallet ? "tokens" : "credits";
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.position, {
              backgroundColor: c.card,
              borderColor: c.border,
              borderLeftColor: bet.teamColor
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1,
                gap: 2
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: {
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 6
                },
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.posTitle, {
                    color: c.foreground,
                    flexShrink: 1
                  }],
                  numberOfLines: 1,
                  children: bet.label ?? `${bet.teamName} to win`
                }), bet.lockWeek ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
                  label: "LOCK 1.5x",
                  tone: "accent",
                  icon: "lock"
                }) : null]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.posMeta, {
                  color: c.mutedForeground
                }],
                numberOfLines: 1,
                children: [bet.stake.toLocaleString(), " at ", (0, _libOdds.formatOdds)(bet.odds, fmt), " \u2192 ", bet.potentialPayout.toLocaleString(), " ", currency]
              }), wallet ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: styles.wallet,
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                  name: "shield-star",
                  size: 11,
                  color: c.league
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.walletText, {
                    color: c.league
                  }],
                  numberOfLines: 1,
                  children: wallet
                })]
              }) : null]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                alignItems: "flex-end",
                gap: 4
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
                label: label,
                tone: tone
              }), nowValue !== null ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.posNow, {
                  color: nowValue > bet.stake ? c.positive : nowValue === 0 ? c.negative : c.mutedForeground
                }],
                children: nowValue > 0 ? `Pays ${nowValue.toLocaleString()} if it ends now` : "Loses if it ends now"
              }) : null]
            })]
          }, key);
        };
        $[16] = c.border;
        $[17] = c.card;
        $[18] = c.foreground;
        $[19] = c.league;
        $[20] = c.mutedForeground;
        $[21] = c.negative;
        $[22] = c.positive;
        $[23] = fmt;
        $[24] = game;
        $[25] = t5;
      } else {
        t5 = $[25];
      }
      t4 = positions.map(t5);
      $[5] = c.border;
      $[6] = c.card;
      $[7] = c.foreground;
      $[8] = c.league;
      $[9] = c.mutedForeground;
      $[10] = c.negative;
      $[11] = c.positive;
      $[12] = fmt;
      $[13] = game;
      $[14] = positions;
      $[15] = t4;
    } else {
      t4 = $[15];
    }
    let t5;
    if ($[26] !== t3 || $[27] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.stack,
        children: [t3, t4]
      });
      $[26] = t3;
      $[27] = t4;
      $[28] = t5;
    } else {
      t5 = $[28];
    }
    return t5;
  }
  function LeagueSweat(t0) {
    const $ = (0, _reactCompilerRuntime.c)(21);
    const {
      game,
      sweats,
      uid,
      c,
      fmt
    } = t0;
    let t1;
    if ($[0] !== sweats) {
      t1 = sweats.reduce(_temp6, 0);
      $[0] = sweats;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    const totalCount = t1;
    let t2;
    if ($[2] !== c.foreground) {
      t2 = [styles.sectionTitle, {
        color: c.foreground
      }];
      $[2] = c.foreground;
      $[3] = t2;
    } else {
      t2 = $[3];
    }
    let t3;
    if ($[4] !== t2 || $[5] !== totalCount) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        accessibilityRole: "header",
        style: t2,
        children: ["League sweat (", totalCount, ")"]
      });
      $[4] = t2;
      $[5] = totalCount;
      $[6] = t3;
    } else {
      t3 = $[6];
    }
    let t4;
    if ($[7] !== c || $[8] !== fmt || $[9] !== game || $[10] !== sweats || $[11] !== uid) {
      let t5;
      if ($[13] !== c || $[14] !== fmt || $[15] !== game || $[16] !== uid) {
        t5 = t6 => {
          const {
            league,
            sides,
            rivalries
          } = t6;
          const entries = sides.entries ?? [];
          const awayBets = sides.away?.length ? sides.away : entries.filter(_temp7);
          const homeBets = sides.home?.length ? sides.home : entries.filter(_temp8);
          const totalStake = entries.reduce(_temp9, 0);
          const myRivalry = uid ? rivalries.find(r => (r.aUid === uid || r.bUid === uid) && r.aWins + r.bWins + r.pushes > 0) : undefined;
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.sweatCard, {
              backgroundColor: c.card,
              borderColor: c.alpha(c.league, 0.45)
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
              accessibilityRole: "button",
              onPress: () => _expoRouter.router.push({
                pathname: "/league/[id]",
                params: {
                  id: league.id,
                  tab: "bets"
                }
              }),
              style: styles.sweatHead,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "shield-star",
                size: 15,
                color: c.league
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.posTitle, {
                  color: c.foreground,
                  flex: 1
                }],
                numberOfLines: 1,
                children: league.name
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.posMeta, {
                  color: c.mutedForeground
                }],
                children: [totalStake.toLocaleString(), " tokens in play"]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                name: "chevron-right",
                size: 16,
                color: c.subtleForeground
              })]
            }), myRivalry && uid ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
              style: [styles.posMeta, {
                color: c.accent
              }],
              children: ["\u2694\uFE0F H2H vs ", myRivalry.aUid === uid ? myRivalry.bName : myRivalry.aName, ":", " ", myRivalry.aUid === uid ? `${myRivalry.aWins}–${myRivalry.bWins}` : `${myRivalry.bWins}–${myRivalry.aWins}`]
            }) : null, /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.sweatSplit,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: [styles.sweatCol, {
                  backgroundColor: c.secondary,
                  borderColor: c.border
                }],
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                  style: [styles.sweatColHeader, {
                    color: game.awayTeam.color
                  }],
                  children: [game.awayTeam.abbreviation, " / OVER (", awayBets.length, ")"]
                }), awayBets.length === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.posMeta, {
                    color: c.subtleForeground
                  }],
                  children: "No Action"
                }) : awayBets.map(b_2 => {
                  const pos = (0, _libOdds.livePosition)(game, {
                    side: b_2.side ?? "away",
                    market: b_2.market,
                    selection: b_2.selection,
                    line: b_2.line
                  });
                  return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                    style: styles.sweatBetRow,
                    children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                      style: [styles.sweatMember, {
                        color: b_2.uid === uid ? c.league : c.foreground
                      }],
                      numberOfLines: 1,
                      children: [b_2.uid === uid ? "You" : b_2.displayName || b_2.name, b_2.lock ? " \uD83D\uDD12" : ""]
                    }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                      style: [styles.sweatBetMeta, {
                        color: pos === "ahead" ? c.positive : pos === "behind" ? c.negative : c.mutedForeground
                      }],
                      numberOfLines: 1,
                      children: [b_2.label || b_2.teamAbbr, " \xB7 ", b_2.stake.toLocaleString(), " (", (0, _libOdds.formatOdds)(b_2.odds, fmt), ")"]
                    })]
                  }, b_2.betId);
                })]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: [styles.sweatCol, {
                  backgroundColor: c.secondary,
                  borderColor: c.border
                }],
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                  style: [styles.sweatColHeader, {
                    color: game.homeTeam.color
                  }],
                  children: [game.homeTeam.abbreviation, " / UNDER (", homeBets.length, ")"]
                }), homeBets.length === 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.posMeta, {
                    color: c.subtleForeground
                  }],
                  children: "No Action"
                }) : homeBets.map(b_3 => {
                  const pos_0 = (0, _libOdds.livePosition)(game, {
                    side: b_3.side ?? "home",
                    market: b_3.market,
                    selection: b_3.selection,
                    line: b_3.line
                  });
                  return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                    style: styles.sweatBetRow,
                    children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                      style: [styles.sweatMember, {
                        color: b_3.uid === uid ? c.league : c.foreground
                      }],
                      numberOfLines: 1,
                      children: [b_3.uid === uid ? "You" : b_3.displayName || b_3.name, b_3.lock ? " \uD83D\uDD12" : ""]
                    }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                      style: [styles.sweatBetMeta, {
                        color: pos_0 === "ahead" ? c.positive : pos_0 === "behind" ? c.negative : c.mutedForeground
                      }],
                      numberOfLines: 1,
                      children: [b_3.label || b_3.teamAbbr, " \xB7 ", b_3.stake.toLocaleString(), " (", (0, _libOdds.formatOdds)(b_3.odds, fmt), ")"]
                    })]
                  }, b_3.betId);
                })]
              })]
            })]
          }, league.id);
        };
        $[13] = c;
        $[14] = fmt;
        $[15] = game;
        $[16] = uid;
        $[17] = t5;
      } else {
        t5 = $[17];
      }
      t4 = sweats.map(t5);
      $[7] = c;
      $[8] = fmt;
      $[9] = game;
      $[10] = sweats;
      $[11] = uid;
      $[12] = t4;
    } else {
      t4 = $[12];
    }
    let t5;
    if ($[18] !== t3 || $[19] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.stack,
        children: [t3, t4]
      });
      $[18] = t3;
      $[19] = t4;
      $[20] = t5;
    } else {
      t5 = $[20];
    }
    return t5;
  }
  function _temp9(s_0, b_1) {
    return s_0 + b_1.stake;
  }
  function _temp8(b_0) {
    return (b_0.selection ?? b_0.side) === "home" || b_0.selection === "under";
  }
  function _temp7(b) {
    return (b.selection ?? b.side) === "away" || b.selection === "over";
  }
  function _temp6(n, s) {
    return n + (s.sides.entries?.length ?? 0);
  }
  function Duels(t0) {
    const $ = (0, _reactCompilerRuntime.c)(29);
    const {
      game,
      duels,
      c,
      fmt
    } = t0;
    let t1;
    if ($[0] !== c.foreground) {
      t1 = [styles.sectionTitle, {
        color: c.foreground
      }];
      $[0] = c.foreground;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    const t2 = duels.length > 1 ? `(${duels.length})` : "";
    let t3;
    if ($[2] !== t1 || $[3] !== t2) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        accessibilityRole: "header",
        style: t1,
        children: ["Vs friends ", t2]
      });
      $[2] = t1;
      $[3] = t2;
      $[4] = t3;
    } else {
      t3 = $[4];
    }
    let t4;
    if ($[5] !== c.accent || $[6] !== c.border || $[7] !== c.card || $[8] !== c.foreground || $[9] !== c.mutedForeground || $[10] !== c.negative || $[11] !== c.positive || $[12] !== duels || $[13] !== fmt || $[14] !== game) {
      let t5;
      if ($[16] !== c.accent || $[17] !== c.border || $[18] !== c.card || $[19] !== c.foreground || $[20] !== c.mutedForeground || $[21] !== c.negative || $[22] !== c.positive || $[23] !== fmt || $[24] !== game) {
        t5 = v => {
          const {
            ch
          } = v;
          const pos = ch.status === "accepted" ? (0, _libOdds.livePosition)(game, v.mySide) : null;
          const settled = v.result ? STATUS_TONE[v.result] : null;
          const tone = settled ? settled.tone : ch.status === "pending" ? "neutral" : pos === "ahead" ? "positive" : pos === "behind" ? "negative" : pos === "level" ? "warning" : "accent";
          const label = settled ? settled.label : ch.status === "pending" ? v.isCreator ? "Sent" : "Your call" : pos ? pos[0].toUpperCase() + pos.slice(1) : "Locked";
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
            accessibilityRole: "button",
            onPress: () => _expoRouter.router.push({
              pathname: "/challenges",
              params: {
                tab: ch.status === "pending" ? "inbox" : ch.status === "accepted" ? "live" : "history"
              }
            }),
            style: [styles.position, {
              backgroundColor: c.card,
              borderColor: c.border,
              borderLeftColor: v.myTeam.color
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1,
                gap: 2
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.posTitle, {
                  color: c.foreground
                }],
                numberOfLines: 1,
                children: [v.myTeam.abbreviation, " vs ", v.friendName, " on ", v.theirTeam.abbreviation]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
                style: [styles.posMeta, {
                  color: c.mutedForeground
                }],
                numberOfLines: 1,
                children: [v.myStake.toLocaleString(), " in \xB7 ", ch.pot.toLocaleString(), " pot \xB7 ", ch.mode === "pot" ? "winner takes all" : (0, _libOdds.formatOdds)(v.myOdds, fmt)]
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
                style: styles.wallet,
                children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
                  name: "sword-cross",
                  size: 11,
                  color: c.accent
                }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                  style: [styles.walletText, {
                    color: c.accent
                  }],
                  children: "Head to Head"
                })]
              })]
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                alignItems: "flex-end",
                gap: 4
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
                label: label,
                tone: tone
              }), pos ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.posNow, {
                  color: pos === "ahead" ? c.positive : pos === "behind" ? c.negative : c.mutedForeground
                }],
                children: pos === "ahead" ? `Takes ${ch.pot.toLocaleString()} if it ends now` : pos === "behind" ? `${v.friendName} takes it now` : "Stakes back if level"
              }) : null]
            })]
          }, ch.id);
        };
        $[16] = c.accent;
        $[17] = c.border;
        $[18] = c.card;
        $[19] = c.foreground;
        $[20] = c.mutedForeground;
        $[21] = c.negative;
        $[22] = c.positive;
        $[23] = fmt;
        $[24] = game;
        $[25] = t5;
      } else {
        t5 = $[25];
      }
      t4 = duels.map(t5);
      $[5] = c.accent;
      $[6] = c.border;
      $[7] = c.card;
      $[8] = c.foreground;
      $[9] = c.mutedForeground;
      $[10] = c.negative;
      $[11] = c.positive;
      $[12] = duels;
      $[13] = fmt;
      $[14] = game;
      $[15] = t4;
    } else {
      t4 = $[15];
    }
    let t5;
    if ($[26] !== t3 || $[27] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.stack,
        children: [t3, t4]
      });
      $[26] = t3;
      $[27] = t4;
      $[28] = t5;
    } else {
      t5 = $[28];
    }
    return t5;
  }
  const styles = StyleSheet.default.create({
    container: {
      flex: 1
    },
    body: {
      padding: 16,
      gap: 18
    },
    stack: {
      gap: 18
    },
    sectionTitle: {
      fontSize: 15,
      fontFamily: "Inter_700Bold",
      marginBottom: -8
    },
    hero: {
      flexDirection: "row",
      alignItems: "flex-start",
      borderWidth: 1,
      borderRadius: 20,
      paddingVertical: 18,
      paddingHorizontal: 10
    },
    heroTeam: {
      flex: 1,
      alignItems: "center",
      gap: 4
    },
    heroLogo: {
      width: 56,
      height: 56,
      borderRadius: 14
    },
    heroFallback: {
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1
    },
    heroAbbr: {
      fontSize: 14,
      fontFamily: "Inter_800ExtraBold"
    },
    heroName: {
      fontSize: 14,
      fontFamily: "Inter_700Bold",
      marginTop: 4
    },
    heroSub: {
      fontSize: 11,
      fontFamily: "Inter_500Medium"
    },
    heroScore: {
      fontSize: 40,
      fontFamily: "Inter_900Black",
      fontVariant: ["tabular-nums"],
      letterSpacing: -1,
      marginTop: 4
    },
    heroOdds: {
      fontSize: 12,
      fontFamily: "Inter_600SemiBold",
      fontVariant: ["tabular-nums"],
      marginTop: 6
    },
    heroMid: {
      width: 96,
      alignItems: "center",
      gap: 6,
      paddingTop: 16
    },
    heroClock: {
      fontSize: 14,
      fontFamily: "Inter_700Bold",
      textAlign: "center"
    },
    livePill: {
      flexDirection: "row",
      alignItems: "center",
      gap: 5,
      paddingHorizontal: 8,
      paddingVertical: 3,
      borderRadius: 999
    },
    livePillText: {
      fontSize: 11,
      fontFamily: "Inter_800ExtraBold",
      letterSpacing: 0.6
    },
    position: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      padding: 12,
      borderRadius: 14,
      borderWidth: 1,
      borderLeftWidth: 4
    },
    posTitle: {
      fontSize: 14,
      fontFamily: "Inter_600SemiBold"
    },
    posMeta: {
      fontSize: 12,
      fontFamily: "Inter_500Medium",
      fontVariant: ["tabular-nums"]
    },
    posNow: {
      fontSize: 11,
      fontFamily: "Inter_600SemiBold"
    },
    wallet: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
      marginTop: 1
    },
    walletText: {
      fontSize: 11,
      fontFamily: "Inter_600SemiBold"
    },
    sweatCard: {
      borderRadius: 16,
      borderWidth: 1,
      padding: 12,
      gap: 10
    },
    sweatHead: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6
    },
    sweatSplit: {
      flexDirection: "row",
      gap: 8
    },
    sweatCol: {
      flex: 1,
      borderRadius: 12,
      borderWidth: 1,
      padding: 10,
      gap: 6
    },
    sweatColHeader: {
      fontSize: 11,
      fontFamily: "Inter_800ExtraBold",
      letterSpacing: 0.5
    },
    sweatBetRow: {
      gap: 1,
      paddingVertical: 2
    },
    sweatMember: {
      fontSize: 12,
      fontFamily: "Inter_700Bold"
    },
    sweatBetMeta: {
      fontSize: 11,
      fontFamily: "Inter_500Medium",
      fontVariant: ["tabular-nums"]
    },
    footer: {
      fontSize: 11,
      fontFamily: "Inter_500Medium",
      textAlign: "center",
      lineHeight: 17
    }
  });
},763,[815,818,843,846,820,817,12,132,133,28,188,109,827,867,1220,1214,836,837,821,858,819,1221,861,844,870,816,6]);