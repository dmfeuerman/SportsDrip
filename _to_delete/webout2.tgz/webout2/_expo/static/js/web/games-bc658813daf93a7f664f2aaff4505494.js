__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return GamesScreen;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _componentsBackToLevels = require(_dependencyMap[1]);
  var BackToLevels = _interopDefault(_componentsBackToLevels);
  var _expoVectorIcons = require(_dependencyMap[2]);
  var _libMotion = require(_dependencyMap[3]);
  var _react = require(_dependencyMap[4]);
  var _reactNativeWebDistExportsActivityIndicator = require(_dependencyMap[5]);
  var ActivityIndicator = _interopDefault(_reactNativeWebDistExportsActivityIndicator);
  var _reactNativeWebDistExportsFlatList = require(_dependencyMap[6]);
  var FlatList = _interopDefault(_reactNativeWebDistExportsFlatList);
  require(_dependencyMap[7]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[8]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[9]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[10]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[11]);
  var _reactNativeSafeAreaContext = require(_dependencyMap[12]);
  var _expoRouter = require(_dependencyMap[13]);
  var _componentsBetModal = require(_dependencyMap[14]);
  var BetModal = _interopDefault(_componentsBetModal);
  var _componentsGameCard = require(_dependencyMap[15]);
  var GameCard = _interopDefault(_componentsGameCard);
  var _componentsFeaturedGameCard = require(_dependencyMap[16]);
  var FeaturedGameCard = _interopDefault(_componentsFeaturedGameCard);
  var _componentsGameQuickView = require(_dependencyMap[17]);
  var GameQuickView = _interopDefault(_componentsGameQuickView);
  var _componentsTailSheet = require(_dependencyMap[18]);
  var TailSheet = _interopDefault(_componentsTailSheet);
  var _componentsGameDetailSheet = require(_dependencyMap[19]);
  var GameDetailSheet = _interopDefault(_componentsGameDetailSheet);
  var _componentsAdsSponsoredCard = require(_dependencyMap[20]);
  var SponsoredCard = _interopDefault(_componentsAdsSponsoredCard);
  var _componentsTokenBalance = require(_dependencyMap[21]);
  var TokenBalance = _interopDefault(_componentsTokenBalance);
  var _componentsUi = require(_dependencyMap[22]);
  var _constantsColors = require(_dependencyMap[23]);
  var _constantsLeagueTypes = require(_dependencyMap[24]);
  var _constantsAds = require(_dependencyMap[25]);
  var _contextAdsContext = require(_dependencyMap[26]);
  var _contextAppContext = require(_dependencyMap[27]);
  var _contextChallengeContext = require(_dependencyMap[28]);
  var _contextLeagueContext = require(_dependencyMap[29]);
  var _hooksUseNow = require(_dependencyMap[30]);
  var _contextToastContext = require(_dependencyMap[31]);
  var _contextNotificationContext = require(_dependencyMap[32]);
  var _hooksUseColors = require(_dependencyMap[33]);
  var _hooksUseGames = require(_dependencyMap[34]);
  var _hooksUseGameInsights = require(_dependencyMap[35]);
  var _libGameCenter = require(_dependencyMap[36]);
  var _libApi = require(_dependencyMap[37]);
  var _libMarkets = require(_dependencyMap[38]);
  var _typesGame = require(_dependencyMap[39]);
  var _reactJsxRuntime = require(_dependencyMap[40]);
  const ALL = "ALL";
  function GamesScreen() {
    const $ = (0, _reactCompilerRuntime.c)(161);
    const colors = (0, _hooksUseColors.useColors)();
    const insets = (0, _reactNativeSafeAreaContext.useSafeAreaInsets)();
    const {
      balance,
      bets,
      error,
      clearError,
      profile,
      placeBet
    } = (0, _contextAppContext.useApp)();
    const {
      leagues,
      activeLeagues,
      uid,
      placeLeagueBet,
      myLeagueBets
    } = (0, _contextLeagueContext.useLeague)();
    const {
      betLocked
    } = (0, _contextToastContext.useToast)();
    const {
      unreadCount
    } = (0, _contextNotificationContext.useNotifications)();
    const {
      live,
      upcoming,
      loading,
      error: gamesError,
      syncedAt
    } = (0, _hooksUseGames.useGames)();
    const boardSides = (0, _contextLeagueContext.useBoardLeagueSides)(uid);
    const clock = (0, _hooksUseNow.useNow)(15000);
    const {
      enabled: adsOn
    } = (0, _contextAdsContext.useAds)();
    const params = (0, _expoRouter.useLocalSearchParams)();
    const challenges = (0, _contextChallengeContext.useChallenges)();
    const {
      show
    } = (0, _contextToastContext.useToast)();
    const [target, setTarget] = (0, _react.useState)(null);
    let t0;
    let t1;
    if ($[0] !== params.challenge || $[1] !== params.challengeName) {
      t0 = () => {
        if (params.challenge) {
          setTarget({
            uid: params.challenge,
            name: params.challengeName || "your friend"
          });
          _expoRouter.router.setParams({
            challenge: undefined,
            challengeName: undefined
          });
        }
      };
      t1 = [params.challenge, params.challengeName];
      $[0] = params.challenge;
      $[1] = params.challengeName;
      $[2] = t0;
      $[3] = t1;
    } else {
      t0 = $[2];
      t1 = $[3];
    }
    (0, _react.useEffect)(t0, t1);
    const [slipError, setSlipError] = (0, _react.useState)(null);
    const [sport, setSport] = (0, _react.useState)(ALL);
    const [pending, setPending] = (0, _react.useState)(null);
    const [detail, setDetail] = (0, _react.useState)(null);
    const [tailGame, setTailGame] = (0, _react.useState)(null);
    const [quickGame, setQuickGame] = (0, _react.useState)(null);
    const [follow, setFollow] = (0, _react.useState)(null);
    const [submitting] = (0, _react.useState)(false);
    const topPad = 24;
    const bottomPad = 100;
    let t2;
    if ($[4] !== bets) {
      t2 = bets.filter(_temp);
      $[4] = bets;
      $[5] = t2;
    } else {
      t2 = $[5];
    }
    const t3 = t2.length;
    let t4;
    if ($[6] !== myLeagueBets) {
      t4 = Object.values(myLeagueBets).reduce(_temp3, 0);
      $[6] = myLeagueBets;
      $[7] = t4;
    } else {
      t4 = $[7];
    }
    const openBets = t3 + t4;
    let map;
    if ($[8] !== bets || $[9] !== challenges.byGame || $[10] !== challenges.uid || $[11] !== leagues || $[12] !== myLeagueBets) {
      map = new Map();
      for (const b_1 of bets) {
        if (b_1.status !== "pending" || map.has(b_1.gameId)) {
          continue;
        }
        map.set(b_1.gameId, {
          side: b_1.side,
          label: b_1.label,
          stake: b_1.stake,
          potentialPayout: b_1.potentialPayout
        });
      }
      for (const lg of leagues) {
        for (const b_2 of myLeagueBets[lg.id] ?? []) {
          if (b_2.status !== "pending" || map.has(b_2.gameId)) {
            continue;
          }
          map.set(b_2.gameId, {
            side: b_2.side,
            label: b_2.label,
            stake: b_2.stake,
            potentialPayout: b_2.potentialPayout
          });
        }
      }
      const me = challenges.uid;
      if (me) {
        for (const [gameId, list_0] of challenges.byGame) {
          if (map.has(gameId)) {
            continue;
          }
          const ch = list_0.find(x => (0, _contextChallengeContext.holdsMyStake)(x, me));
          if (!ch) {
            continue;
          }
          const v = (0, _contextChallengeContext.viewOf)(ch, me);
          map.set(gameId, {
            side: v.mySide,
            stake: v.myStake,
            potentialPayout: ch.pot
          });
        }
      }
      $[8] = bets;
      $[9] = challenges.byGame;
      $[10] = challenges.uid;
      $[11] = leagues;
      $[12] = myLeagueBets;
      $[13] = map;
    } else {
      map = $[13];
    }
    const positions = map;
    let t5;
    if ($[14] !== sport) {
      t5 = g => sport === ALL || g.sport === sport;
      $[14] = sport;
      $[15] = t5;
    } else {
      t5 = $[15];
    }
    const match = t5;
    let out;
    if ($[16] !== adsOn || $[17] !== live || $[18] !== match || $[19] !== upcoming) {
      const l = live.filter(match);
      const u = upcoming.filter(match);
      out = [];
      let seen = 0;
      let ads = 0;
      const pushGame = g_0 => {
        out.push({
          kind: "game",
          id: g_0.id,
          game: g_0
        });
        seen = seen + 1;
        seen;
        const slot = seen - _constantsAds.AD_POLICY.boardFirstAfter;
        if (adsOn && ads < _constantsAds.AD_POLICY.boardMax && slot >= 0 && slot % _constantsAds.AD_POLICY.boardEvery === 0) {
          out.push({
            kind: "ad",
            id: `ad-${ads}`
          });
          ads = ads + 1;
          ads;
        }
      };
      if (l.length) {
        out.push({
          kind: "section",
          id: "sec-live",
          title: "Live Now",
          live: true
        });
        l.forEach(pushGame);
      }
      let lastDay = "";
      for (const g_1 of u) {
        const day = dayKey(g_1.startsAt);
        if (day !== lastDay) {
          lastDay = day;
          out.push({
            kind: "section",
            id: `sec-${day}`,
            title: dayTitle(g_1.startsAt)
          });
        }
        pushGame(g_1);
      }
      $[16] = adsOn;
      $[17] = live;
      $[18] = match;
      $[19] = upcoming;
      $[20] = out;
    } else {
      out = $[20];
    }
    const rows = out;
    let t6;
    if ($[21] !== boardSides || $[22] !== profile?.favoriteTeams || $[23] !== sport || $[24] !== upcoming) {
      t6 = () => {
        const favs = new Set((profile?.favoriteTeams ?? []).map(_temp4));
        const pool = upcoming.filter(g_2 => sport === ALL || g_2.sport === sport);
        return (0, _componentsFeaturedGameCard.pickFeatured)(pool, boardSides, favs, Date.now());
      };
      $[21] = boardSides;
      $[22] = profile?.favoriteTeams;
      $[23] = sport;
      $[24] = upcoming;
      $[25] = t6;
    } else {
      t6 = $[25];
    }
    profile?.favoriteTeams;
    let t7;
    if ($[26] !== t6) {
      t7 = t6();
      $[26] = t6;
      $[27] = t7;
    } else {
      t7 = $[27];
    }
    const featured = t7;
    let t8;
    if ($[28] !== target) {
      t8 = (game, side, friend, market, selection) => {
        (0, _hooksUseGameInsights.prefetchGameInsights)(game.id);
        setSlipError(null);
        setPending({
          game,
          side,
          market,
          selection,
          key: (0, _libApi.newIdempotencyKey)(),
          friend: friend || !!target
        });
      };
      $[28] = target;
      $[29] = t8;
    } else {
      t8 = $[29];
    }
    const openBetSheet = t8;
    let t9;
    if ($[30] !== show) {
      t9 = sent => {
        setPending(null);
        setTarget(null);
        show({
          id: `chsent_${Date.now()}`,
          kind: "social",
          icon: "sword-cross",
          color: sent.teamColor,
          title: `Challenge sent to ${sent.friendName}`,
          body: `${sent.stake.toLocaleString()} on ${sent.teamAbbr} is in the pot. Winner takes ${sent.pot.toLocaleString()} once they accept.`,
          cta: "View",
          href: "/challenges"
        });
      };
      $[30] = show;
      $[31] = t9;
    } else {
      t9 = $[31];
    }
    const onChallengeSent = t9;
    let t10;
    if ($[32] !== activeLeagues || $[33] !== balance || $[34] !== pending || $[35] !== uid) {
      bb0: {
        let t11;
        if ($[37] !== balance) {
          t11 = {
            id: "credits",
            label: "Credits",
            balance,
            kind: "credits"
          };
          $[37] = balance;
          $[38] = t11;
        } else {
          t11 = $[38];
        }
        const out_0 = [t11];
        if (!pending || !uid) {
          t10 = out_0;
          break bb0;
        }
        for (const lg_0 of activeLeagues) {
          if (!lg_0.allowedSports.includes(pending.game.sport)) {
            continue;
          }
          if (pending.game.startsAt >= lg_0.endsAt) {
            continue;
          }
          const me_0 = lg_0.members[uid];
          if (!me_0) {
            continue;
          }
          out_0.push({
            id: lg_0.id,
            label: lg_0.name,
            balance: me_0.leagueTokens,
            kind: "league"
          });
        }
        t10 = out_0;
      }
      $[32] = activeLeagues;
      $[33] = balance;
      $[34] = pending;
      $[35] = uid;
      $[36] = t10;
    } else {
      t10 = $[36];
    }
    const wallets = t10;
    let t11;
    if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
      t11 = (0, _libMarkets.weekKey)();
      $[39] = t11;
    } else {
      t11 = $[39];
    }
    const wk = t11;
    let out_1;
    if ($[40] !== activeLeagues || $[41] !== myLeagueBets || $[42] !== uid) {
      out_1 = {};
      for (const lg_1 of activeLeagues) {
        const me_1 = uid ? lg_1.members[uid] : undefined;
        out_1[lg_1.id] = me_1?.lastLockWeek === wk || (myLeagueBets[lg_1.id] ?? []).some(b_3 => b_3.lockWeek === wk && b_3.status !== "cancelled");
      }
      $[40] = activeLeagues;
      $[41] = myLeagueBets;
      $[42] = uid;
      $[43] = out_1;
    } else {
      out_1 = $[43];
    }
    const lockUsedMap = out_1;
    let t12;
    if ($[44] !== betLocked || $[45] !== pending || $[46] !== placeBet || $[47] !== placeLeagueBet || $[48] !== show || $[49] !== wallets) {
      t12 = async (stake, walletId, extras) => {
        if (!pending) {
          return;
        }
        const m = pending.market ?? "ml";
        const sel = pending.selection ?? pending.side;
        const q = (0, _libMarkets.quoteMarket)(pending.game, m, sel);
        if (!q || !q.odds) {
          setSlipError("No line yet for this game. Check back closer to kickoff.");
          return;
        }
        const oddsVal = q.odds;
        const Q = q;
        setSlipError(null);
        if (walletId === "credits") {
          const t_0 = (q.side ?? pending.side) === "home" ? pending.game.homeTeam : pending.game.awayTeam;
          const o = (q.side ?? pending.side) === "home" ? pending.game.awayTeam : pending.game.homeTeam;
          const ok = await placeBet({
            gameId: pending.game.id,
            side: q.side ?? undefined,
            market: m,
            selection: sel,
            expectedLine: q.line ?? undefined,
            stake,
            idempotencyKey: pending.key,
            expectedOdds: oddsVal,
            preview: {
              gameId: pending.game.id,
              sport: pending.game.sport,
              side: q.side ?? pending.side,
              market: Q.market,
              selection: Q.selection,
              line: Q.line ?? null,
              label: q.label,
              startsAt: pending.game.startsAt,
              voidReason: null,
              teamName: Q.teamName || t_0.name,
              teamAbbr: Q.teamAbbr || t_0.abbreviation,
              teamColor: Q.teamColor || t_0.color,
              opponentAbbr: Q.opponentAbbr || o.abbreviation,
              odds: Q.odds,
              potentialPayout: Math.round(stake * Q.odds),
              opponentUid: null
            }
          });
          if (!ok) {
            _libMotion.haptic.error();
            setSlipError("Not enough credits.");
            return;
          }
        } else {
          const key = pending.key;
          placeLeagueBet({
            leagueId: walletId,
            gameId: pending.game.id,
            side: q.side ?? undefined,
            market: m,
            selection: sel,
            expectedLine: q.line ?? undefined,
            lock: extras?.lock,
            hidden: extras?.hidden,
            stake,
            idempotencyKey: `${pending.key}${walletId.slice(-4)}`,
            expectedOdds: oddsVal
          }).then(why => {
            if (why) {
              show({
                id: `lbet_fail_${key}`,
                kind: "warning",
                title: "Bet didn't go through",
                body: `${why} Your league balance wasn't charged.`
              });
            }
          });
        }
        _libMotion.haptic.success();
        const t_1 = (q.side ?? pending.side) === "home" ? pending.game.homeTeam : pending.game.awayTeam;
        const w = wallets.find(x_0 => x_0.id === walletId);
        betLocked({
          teamName: q.label || t_1.name,
          teamAbbr: t_1.abbreviation,
          teamColor: t_1.color,
          odds: oddsVal,
          stake,
          payout: Math.round(stake * oddsVal),
          currency: walletId === "credits" ? "credits" : "league",
          walletLabel: w?.label,
          leagueId: walletId === "credits" ? undefined : walletId,
          gameId: pending.game.id,
          hidden: !!extras?.hidden
        });
        setPending(null);
      };
      $[44] = betLocked;
      $[45] = pending;
      $[46] = placeBet;
      $[47] = placeLeagueBet;
      $[48] = show;
      $[49] = wallets;
      $[50] = t12;
    } else {
      t12 = $[50];
    }
    const confirmBet = t12;
    let t13;
    bb1: {
      if (!detail) {
        let t14;
        if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
          t14 = [];
          $[51] = t14;
        } else {
          t14 = $[51];
        }
        t13 = t14;
        break bb1;
      }
      let out_2;
      if ($[52] !== bets || $[53] !== detail || $[54] !== leagues || $[55] !== myLeagueBets) {
        let t14;
        if ($[57] !== detail) {
          t14 = b_4 => b_4.gameId === detail.id;
          $[57] = detail;
          $[58] = t14;
        } else {
          t14 = $[58];
        }
        out_2 = bets.filter(t14);
        for (const lg_2 of leagues) {
          for (const b_5 of myLeagueBets[lg_2.id] ?? []) {
            if (b_5.gameId === detail.id) {
              out_2.push({
                ...b_5,
                id: `${lg_2.id}:${b_5.id}`,
                wallet: lg_2.name
              });
            }
          }
        }
        $[52] = bets;
        $[53] = detail;
        $[54] = leagues;
        $[55] = myLeagueBets;
        $[56] = out_2;
      } else {
        out_2 = $[56];
      }
      t13 = out_2;
    }
    const detailBets = t13;
    let t14;
    if ($[59] !== openBetSheet) {
      t14 = (game_0, side_0, friend_0, market_0, selection_0) => {
        setDetail(null);
        {
          openBetSheet(game_0, side_0, friend_0, market_0, selection_0);
        }
      };
      $[59] = openBetSheet;
      $[60] = t14;
    } else {
      t14 = $[60];
    }
    const betFromDetail = t14;
    const team = pending ? pending.side === "home" ? pending.game.homeTeam : pending.game.awayTeam : null;
    let t15;
    if ($[61] !== pending) {
      t15 = pending ? (0, _libMarkets.quoteMarket)(pending.game, pending.market ?? "ml", pending.selection ?? pending.side) : null;
      $[61] = pending;
      $[62] = t15;
    } else {
      t15 = $[62];
    }
    const pendingQuote = t15;
    let t16;
    if ($[63] !== colors.background) {
      t16 = [styles.container, {
        backgroundColor: colors.background
      }];
      $[63] = colors.background;
      $[64] = t16;
    } else {
      t16 = $[64];
    }
    const t17 = 36;
    let t18;
    if ($[65] !== colors.background || $[66] !== colors.border || $[67] !== t17) {
      t18 = [styles.header, {
        backgroundColor: colors.background,
        borderBottomColor: colors.border,
        paddingTop: t17
      }];
      $[65] = colors.background;
      $[66] = colors.border;
      $[67] = t17;
      $[68] = t18;
    } else {
      t18 = $[68];
    }
    let t19;
    if ($[69] === Symbol.for("react.memo_cache_sentinel")) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BackToLevels.default, {});
      $[69] = t19;
    } else {
      t19 = $[69];
    }
    let t20;
    if ($[70] !== colors.foreground) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        accessibilityRole: "header",
        style: [styles.title, {
          color: colors.foreground
        }],
        children: "Games"
      });
      $[70] = colors.foreground;
      $[71] = t20;
    } else {
      t20 = $[71];
    }
    let t21;
    if ($[72] !== colors || $[73] !== openBets) {
      t21 = openBets > 0 && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
        accessibilityRole: "button",
        accessibilityLabel: `${openBets} open bets. Open My bets`,
        onPress: _temp5,
        style: [styles.pendingBadge, {
          backgroundColor: colors.alpha(colors.accent, 0.16),
          borderColor: colors.alpha(colors.accent, 0.5)
        }],
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.pendingText, {
            color: colors.accent
          }],
          children: [openBets, " open"]
        })
      });
      $[72] = colors;
      $[73] = openBets;
      $[74] = t21;
    } else {
      t21 = $[74];
    }
    let t22;
    if ($[75] !== balance) {
      t22 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TokenBalance.default, {
        tokens: balance
      });
      $[75] = balance;
      $[76] = t22;
    } else {
      t22 = $[76];
    }
    let t23;
    if ($[77] !== unreadCount) {
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.IconButton, {
        icon: "bell-outline",
        label: "Activity",
        badge: unreadCount,
        onPress: _temp6
      });
      $[77] = unreadCount;
      $[78] = t23;
    } else {
      t23 = $[78];
    }
    let t24;
    if ($[79] !== t21 || $[80] !== t22 || $[81] !== t23) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.headerRight,
        children: [t21, t22, t23]
      });
      $[79] = t21;
      $[80] = t22;
      $[81] = t23;
      $[82] = t24;
    } else {
      t24 = $[82];
    }
    let t25;
    if ($[83] !== t20 || $[84] !== t24) {
      t25 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.headerRow,
        children: [t19, t20, t24]
      });
      $[83] = t20;
      $[84] = t24;
      $[85] = t25;
    } else {
      t25 = $[85];
    }
    let t26;
    if ($[86] === Symbol.for("react.memo_cache_sentinel")) {
      t26 = [{
        value: ALL,
        label: "All",
        icon: "trophy-outline"
      }, ..._typesGame.SPORTS.map(_temp7)];
      $[86] = t26;
    } else {
      t26 = $[86];
    }
    let t27;
    if ($[87] !== sport) {
      t27 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.FilterPills, {
        value: sport,
        onChange: setSport,
        options: t26
      });
      $[87] = sport;
      $[88] = t27;
    } else {
      t27 = $[88];
    }
    let t28;
    if ($[89] !== clock || $[90] !== colors.subtleForeground || $[91] !== syncedAt) {
      t28 = syncedAt ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: {
          color: colors.subtleForeground,
          fontSize: 12,
          fontFamily: "Inter_500Medium",
          textAlign: "center",
          marginTop: 8,
          marginBottom: -4
        },
        children: ["Scores live \xB7 updated ", ago(syncedAt, clock)]
      }) : null;
      $[89] = clock;
      $[90] = colors.subtleForeground;
      $[91] = syncedAt;
      $[92] = t28;
    } else {
      t28 = $[92];
    }
    let t29;
    if ($[93] !== t18 || $[94] !== t25 || $[95] !== t27 || $[96] !== t28) {
      t29 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t18,
        children: [t25, t27, t28]
      });
      $[93] = t18;
      $[94] = t25;
      $[95] = t27;
      $[96] = t28;
      $[97] = t29;
    } else {
      t29 = $[97];
    }
    let t30;
    if ($[98] !== colors || $[99] !== target) {
      t30 = target && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.banner, {
          backgroundColor: colors.alpha(colors.accent, 0.12),
          borderColor: colors.alpha(colors.accent, 0.6)
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "sword-cross",
          size: 16,
          color: colors.accent
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.bannerText, {
            color: colors.foreground
          }],
          numberOfLines: 2,
          children: ["Tap a team on any upcoming game to challenge ", target.name, "."]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
          accessibilityRole: "button",
          accessibilityLabel: "Cancel challenge",
          hitSlop: 10,
          onPress: () => setTarget(null),
          children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
            name: "close",
            size: 16,
            color: colors.mutedForeground
          })
        })]
      });
      $[98] = colors;
      $[99] = target;
      $[100] = t30;
    } else {
      t30 = $[100];
    }
    let t31;
    if ($[101] !== clearError || $[102] !== colors.destructive || $[103] !== error) {
      t31 = error && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        style: [styles.banner, {
          backgroundColor: colors.destructive + "22",
          borderColor: colors.destructive
        }],
        onPress: clearError,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "alert-circle-outline",
          size: 15,
          color: colors.destructive
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.bannerText, {
            color: colors.destructive
          }],
          children: error
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "close",
          size: 15,
          color: colors.destructive
        })]
      });
      $[101] = clearError;
      $[102] = colors.destructive;
      $[103] = error;
      $[104] = t31;
    } else {
      t31 = $[104];
    }
    let t32;
    if ($[105] !== boardSides || $[106] !== bottomPad || $[107] !== colors || $[108] !== featured || $[109] !== gamesError || $[110] !== loading || $[111] !== openBetSheet || $[112] !== positions || $[113] !== rows || $[114] !== sport) {
      t32 = loading ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(SkeletonList, {
        colors: colors
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FlatList.default, {
        data: rows,
        keyExtractor: _temp8,
        stickyHeaderIndices: rows.map((r_0, i) => r_0.kind === "section" ? i + (featured ? 1 : 0) : -1).filter(_temp9),
        ListHeaderComponent: featured ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(FeaturedGameCard.default, {
          game: featured,
          sides: boardSides.get(featured.id) ?? [],
          onOpen: setDetail
        }) : undefined,
        renderItem: t33 => {
          const {
            item
          } = t33;
          return item.kind === "ad" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(SponsoredCard.default, {
            compact: true,
            style: styles.adRow
          }) : item.kind === "section" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.sectionHeader, {
              backgroundColor: colors.background
            }],
            children: [item.live ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
              style: [styles.liveDot, {
                backgroundColor: colors.live
              }]
            }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
              name: "calendar-clock",
              size: 15,
              color: colors.mutedForeground
            }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: [styles.sectionTitle, {
                color: colors.foreground
              }],
              children: item.title
            })]
          }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(GameCard.default, {
            game: item.game,
            onBet: (g_3, s, m_0, sel_0) => openBetSheet(g_3, s, false, m_0, sel_0),
            onChallenge: (g_4, s_0) => openBetSheet(g_4, s_0, true),
            onOpenDetail: setDetail,
            position: positions.get(item.game.id) ?? null,
            leagueMembers: boardSides.get(item.game.id),
            onLeaguePress: setTailGame
          });
        },
        contentContainerStyle: [styles.listContent, {
          paddingBottom: bottomPad
        }],
        showsVerticalScrollIndicator: false,
        initialNumToRender: 8,
        maxToRenderPerBatch: 8,
        windowSize: 7,
        ListEmptyComponent: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(EmptyState, {
          colors: colors,
          error: gamesError,
          sport: sport,
          onClearFilter: () => setSport(ALL)
        })
      });
      $[105] = boardSides;
      $[106] = bottomPad;
      $[107] = colors;
      $[108] = featured;
      $[109] = gamesError;
      $[110] = loading;
      $[111] = openBetSheet;
      $[112] = positions;
      $[113] = rows;
      $[114] = sport;
      $[115] = t32;
    } else {
      t32 = $[115];
    }
    let t33;
    if ($[116] === Symbol.for("react.memo_cache_sentinel")) {
      t33 = () => setDetail(null);
      $[116] = t33;
    } else {
      t33 = $[116];
    }
    let t34;
    let t35;
    if ($[117] !== betFromDetail) {
      t34 = (g_5, side_1, market_1, selection_1) => betFromDetail(g_5, side_1, false, market_1, selection_1);
      t35 = (g_6, side_2) => betFromDetail(g_6, side_2, true);
      $[117] = betFromDetail;
      $[118] = t34;
      $[119] = t35;
    } else {
      t34 = $[118];
      t35 = $[119];
    }
    let t36;
    if ($[120] === Symbol.for("react.memo_cache_sentinel")) {
      t36 = game_1 => {
        setDetail(null);
        (0, _libGameCenter.openGameCenter)(game_1.id, game_1.status === "upcoming" ? "matchup" : "live");
      };
      $[120] = t36;
    } else {
      t36 = $[120];
    }
    let t37;
    if ($[121] !== detail || $[122] !== detailBets || $[123] !== t34 || $[124] !== t35) {
      t37 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(GameDetailSheet.default, {
        game: detail,
        onClose: t33,
        onBet: t34,
        onChallenge: t35,
        bets: detailBets,
        onOpenCenter: t36
      });
      $[121] = detail;
      $[122] = detailBets;
      $[123] = t34;
      $[124] = t35;
      $[125] = t37;
    } else {
      t37 = $[125];
    }
    let t38;
    if ($[126] !== confirmBet || $[127] !== lockUsedMap || $[128] !== onChallengeSent || $[129] !== params || $[130] !== pending || $[131] !== pendingQuote || $[132] !== slipError || $[133] !== submitting || $[134] !== target?.uid || $[135] !== team || $[136] !== wallets) {
      t38 = pending && team && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(BetModal.default, {
        visible: true,
        onClose: () => setPending(null),
        onConfirm: confirmBet,
        teamName: team.name,
        teamAbbr: team.abbreviation,
        teamColor: team.color,
        pickTitle: pendingQuote?.label,
        lockUsed: lockUsedMap,
        odds: pendingQuote ? pendingQuote.odds : (0, _typesGame.sideOdds)(pending.game, pending.side),
        game: pending.game,
        side: pending.side,
        wallets: wallets,
        defaultWallet: params.wallet,
        error: slipError,
        submitting: submitting,
        challenge: {
          initial: pending.friend,
          friendUid: target?.uid,
          onSent: onChallengeSent,
          onFindFriends: () => {
            setPending(null);
            _expoRouter.router.navigate("/(tabs)/friends");
          }
        },
        gameSummary: `${pending.game.awayTeam.abbreviation} @ ${pending.game.homeTeam.abbreviation} · ${pending.game.sport}`
      });
      $[126] = confirmBet;
      $[127] = lockUsedMap;
      $[128] = onChallengeSent;
      $[129] = params;
      $[130] = pending;
      $[131] = pendingQuote;
      $[132] = slipError;
      $[133] = submitting;
      $[134] = target?.uid;
      $[135] = team;
      $[136] = wallets;
      $[137] = t38;
    } else {
      t38 = $[137];
    }
    let t39;
    if ($[138] !== boardSides || $[139] !== tailGame) {
      t39 = tailGame ? boardSides.get(tailGame.id) ?? [] : [];
      $[138] = boardSides;
      $[139] = tailGame;
      $[140] = t39;
    } else {
      t39 = $[140];
    }
    let t40;
    let t41;
    if ($[141] === Symbol.for("react.memo_cache_sentinel")) {
      t40 = () => setTailGame(null);
      t41 = (gameId_0, intent) => {
        setTailGame(null);
        setFollow(intent);
        setQuickGame(gameId_0);
      };
      $[141] = t40;
      $[142] = t41;
    } else {
      t40 = $[141];
      t41 = $[142];
    }
    let t42;
    if ($[143] !== t39 || $[144] !== tailGame) {
      t42 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TailSheet.default, {
        game: tailGame,
        members: t39,
        onClose: t40,
        onFollow: t41
      });
      $[143] = t39;
      $[144] = tailGame;
      $[145] = t42;
    } else {
      t42 = $[145];
    }
    let t43;
    if ($[146] === Symbol.for("react.memo_cache_sentinel")) {
      t43 = () => {
        setQuickGame(null);
        setFollow(null);
      };
      $[146] = t43;
    } else {
      t43 = $[146];
    }
    const t44 = follow?.leagueId;
    let t45;
    if ($[147] !== follow || $[148] !== quickGame || $[149] !== t44) {
      t45 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(GameQuickView.default, {
        gameId: quickGame,
        onClose: t43,
        defaultWallet: t44,
        follow: follow
      });
      $[147] = follow;
      $[148] = quickGame;
      $[149] = t44;
      $[150] = t45;
    } else {
      t45 = $[150];
    }
    let t46;
    if ($[151] !== t16 || $[152] !== t29 || $[153] !== t30 || $[154] !== t31 || $[155] !== t32 || $[156] !== t37 || $[157] !== t38 || $[158] !== t42 || $[159] !== t45) {
      t46 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t16,
        children: [t29, t30, t31, t32, t37, t38, t42, t45]
      });
      $[151] = t16;
      $[152] = t29;
      $[153] = t30;
      $[154] = t31;
      $[155] = t32;
      $[156] = t37;
      $[157] = t38;
      $[158] = t42;
      $[159] = t45;
      $[160] = t46;
    } else {
      t46 = $[160];
    }
    return t46;
  }
  function _temp9(i_0) {
    return i_0 >= 0;
  }
  function _temp8(r) {
    return r.id;
  }
  function _temp7(sp) {
    return {
      value: sp,
      label: sp,
      icon: _constantsLeagueTypes.SPORT_ICONS[sp],
      color: _constantsColors.SPORT_COLORS[sp]
    };
  }
  function _temp6() {
    return _expoRouter.router.push("/activity");
  }
  function _temp5() {
    return _expoRouter.router.push("/bets");
  }
  function _temp4(t) {
    return `${t.sport}:${t.abbr}`;
  }
  function _temp3(n, list) {
    return n + list.filter(_temp2).length;
  }
  function _temp2(b_0) {
    return b_0.status === "pending";
  }
  function _temp(b) {
    return b.status === "pending";
  }
  function dayKey(ms) {
    const d = new Date(ms);
    return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
  }
  function dayTitle(ms) {
    const d = new Date(ms);
    const start = x => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
    const diff = Math.round((start(d) - start(new Date())) / 86_400_000);
    if (diff <= 0) return "Today";
    if (diff === 1) return "Tomorrow";
    return d.toLocaleDateString([], {
      weekday: "long",
      month: "short",
      day: "numeric"
    });
  }
  function SkeletonList(t0) {
    const $ = (0, _reactCompilerRuntime.c)(11);
    const {
      colors
    } = t0;
    let t1;
    if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
      t1 = [0, 1, 2, 3];
      $[0] = t1;
    } else {
      t1 = $[0];
    }
    let t2;
    if ($[1] !== colors.border || $[2] !== colors.card || $[3] !== colors.secondary) {
      t2 = t1.map(i => /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.skeleton, {
          backgroundColor: colors.card,
          borderColor: colors.border
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [styles.skelBar, {
            backgroundColor: colors.secondary,
            width: "35%"
          }]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.skelRow,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [styles.skelBar, {
              backgroundColor: colors.secondary,
              flex: 1,
              height: 46
            }]
          }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [styles.skelBar, {
              backgroundColor: colors.secondary,
              flex: 1,
              height: 46
            }]
          })]
        })]
      }, i));
      $[1] = colors.border;
      $[2] = colors.card;
      $[3] = colors.secondary;
      $[4] = t2;
    } else {
      t2 = $[4];
    }
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
      t3 = {
        marginTop: 12
      };
      $[5] = t3;
    } else {
      t3 = $[5];
    }
    let t4;
    if ($[6] !== colors.mutedForeground) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ActivityIndicator.default, {
        color: colors.mutedForeground,
        style: t3
      });
      $[6] = colors.mutedForeground;
      $[7] = t4;
    } else {
      t4 = $[7];
    }
    let t5;
    if ($[8] !== t2 || $[9] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.listContent,
        children: [t2, t4]
      });
      $[8] = t2;
      $[9] = t4;
      $[10] = t5;
    } else {
      t5 = $[10];
    }
    return t5;
  }
  function EmptyState(t0) {
    const $ = (0, _reactCompilerRuntime.c)(27);
    const {
      colors,
      error,
      sport,
      onClearFilter
    } = t0;
    const filtered = sport !== ALL;
    let t1;
    if ($[0] !== colors.border || $[1] !== colors.card) {
      t1 = [styles.empty, {
        borderColor: colors.border,
        backgroundColor: colors.card
      }];
      $[0] = colors.border;
      $[1] = colors.card;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    const t2 = error ? "wifi-off" : "calendar-blank-outline";
    let t3;
    if ($[3] !== colors.mutedForeground || $[4] !== t2) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: t2,
        size: 34,
        color: colors.mutedForeground
      });
      $[3] = colors.mutedForeground;
      $[4] = t2;
      $[5] = t3;
    } else {
      t3 = $[5];
    }
    let t4;
    if ($[6] !== colors.foreground) {
      t4 = [styles.emptyTitle, {
        color: colors.foreground
      }];
      $[6] = colors.foreground;
      $[7] = t4;
    } else {
      t4 = $[7];
    }
    const t5 = error ? "Can't reach the board" : filtered ? `No ${sport} games right now` : "No games on the board";
    let t6;
    if ($[8] !== t4 || $[9] !== t5) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t4,
        children: t5
      });
      $[8] = t4;
      $[9] = t5;
      $[10] = t6;
    } else {
      t6 = $[10];
    }
    let t7;
    if ($[11] !== colors.mutedForeground) {
      t7 = [styles.emptyBody, {
        color: colors.mutedForeground
      }];
      $[11] = colors.mutedForeground;
      $[12] = t7;
    } else {
      t7 = $[12];
    }
    const t8 = error ? "You're offline, or the scores service is down. The board will fill in on its own once you're back." : "Fixtures land here as soon as they're scheduled. Check back closer to game day.";
    let t9;
    if ($[13] !== t7 || $[14] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t7,
        children: t8
      });
      $[13] = t7;
      $[14] = t8;
      $[15] = t9;
    } else {
      t9 = $[15];
    }
    let t10;
    if ($[16] !== colors || $[17] !== error || $[18] !== filtered || $[19] !== onClearFilter) {
      t10 = filtered && !error && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsFxTap.Pressable, {
        style: [styles.emptyBtn, {
          borderColor: colors.alpha(colors.primary, 0.6),
          backgroundColor: colors.alpha(colors.primary, 0.12)
        }],
        onPress: onClearFilter,
        children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.emptyBtnText, {
            color: colors.primary
          }],
          children: "Show All Sports"
        })
      });
      $[16] = colors;
      $[17] = error;
      $[18] = filtered;
      $[19] = onClearFilter;
      $[20] = t10;
    } else {
      t10 = $[20];
    }
    let t11;
    if ($[21] !== t1 || $[22] !== t10 || $[23] !== t3 || $[24] !== t6 || $[25] !== t9) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t1,
        children: [t3, t6, t9, t10]
      });
      $[21] = t1;
      $[22] = t10;
      $[23] = t3;
      $[24] = t6;
      $[25] = t9;
      $[26] = t11;
    } else {
      t11 = $[26];
    }
    return t11;
  }
  const styles = StyleSheet.default.create({
    container: {
      flex: 1
    },
    header: {
      borderBottomWidth: 1,
      paddingBottom: 12
    },
    headerRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      paddingHorizontal: 16,
      paddingBottom: 12
    },
    title: {
      fontSize: 24,
      fontFamily: "Inter_900Black"
    },
    headerRight: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    pendingBadge: {
      paddingHorizontal: 10,
      paddingVertical: 5,
      borderRadius: 20,
      borderWidth: 1
    },
    pendingText: {
      fontSize: 12,
      fontFamily: "Inter_700Bold"
    },
    filterList: {
      paddingHorizontal: 16,
      gap: 8
    },
    chip: {
      paddingHorizontal: 14,
      paddingVertical: 7,
      borderRadius: 20,
      borderWidth: 1
    },
    chipText: {
      fontSize: 13,
      fontFamily: "Inter_600SemiBold"
    },
    banner: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      marginHorizontal: 16,
      marginTop: 10,
      padding: 10,
      borderRadius: 10,
      borderWidth: 1
    },
    bannerText: {
      flex: 1,
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    },
    listContent: {
      padding: 16
    },
    sectionHeader: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6,
      paddingVertical: 10
    },
    liveDot: {
      width: 8,
      height: 8,
      borderRadius: 4
    },
    adRow: {
      marginBottom: 10
    },
    sectionTitle: {
      fontSize: 16,
      fontFamily: "Inter_700Bold"
    },
    skeleton: {
      borderRadius: 16,
      borderWidth: 1,
      padding: 14,
      marginBottom: 10,
      gap: 12
    },
    skelBar: {
      height: 12,
      borderRadius: 6
    },
    skelRow: {
      flexDirection: "row",
      gap: 10
    },
    empty: {
      alignItems: "center",
      gap: 10,
      padding: 32,
      borderRadius: 16,
      borderWidth: 1,
      marginTop: 24
    },
    emptyTitle: {
      fontSize: 16,
      fontFamily: "Inter_600SemiBold",
      textAlign: "center"
    },
    emptyBody: {
      fontSize: 13,
      fontFamily: "Inter_400Regular",
      textAlign: "center",
      lineHeight: 19
    },
    emptyBtn: {
      borderWidth: 1.5,
      borderRadius: 999,
      paddingHorizontal: 16,
      paddingVertical: 9,
      minHeight: 38,
      justifyContent: "center",
      marginTop: 4
    },
    emptyBtnText: {
      fontSize: 14,
      fontFamily: "Inter_800ExtraBold"
    }
  });
  function ago(t, now) {
    const s = Math.max(0, Math.round((now - t) / 1000));
    if (s < 60) return s < 10 ? "just now" : `${s}s ago`;
    const m = Math.round(s / 60);
    return m < 60 ? `${m}m ago` : `${Math.round(m / 60)}h ago`;
  }
},752,[815,842,818,820,12,228,107,104,28,188,109,827,271,817,850,847,848,851,849,852,853,835,836,854,855,856,857,837,821,858,844,859,823,819,860,861,862,863,864,865,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _componentsTeamCrest = require(_dependencyMap[2]);
  var TeamCrest = _interopDefault(_componentsTeamCrest);
  var _libMotion = require(_dependencyMap[3]);
  var _react = require(_dependencyMap[4]);
  require(_dependencyMap[5]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[6]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[7]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[8]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxTap = require(_dependencyMap[9]);
  var _reactNativeReanimated = require(_dependencyMap[10]);
  var Reanimated = _interopDefault(_reactNativeReanimated);
  var _componentsFxPressableScale = require(_dependencyMap[11]);
  var PressableScale = _interopDefault(_componentsFxPressableScale);
  var _componentsUi = require(_dependencyMap[12]);
  var _hooksUseColors = require(_dependencyMap[13]);
  var _hooksUseMotion = require(_dependencyMap[14]);
  var _libMarkets = require(_dependencyMap[15]);
  var _libOdds = require(_dependencyMap[16]);
  var _libSettings = require(_dependencyMap[17]);
  var _typesGame = require(_dependencyMap[18]);
  var _reactJsxRuntime = require(_dependencyMap[19]);
  function GameCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(129);
    const {
      game,
      onBet,
      onOpenDetail,
      position,
      leagueMembers,
      locked,
      onLeaguePress,
      onChallenge
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const oddsFormat = (0, _libSettings.useOddsFormat)();
    const isLocked = locked ?? (game.status !== "upcoming" || !!game.disrupted);
    let t1;
    if ($[0] !== game) {
      t1 = (0, _typesGame.isPriced)(game);
      $[0] = game;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    const priced = t1;
    let t2;
    if ($[2] !== game.awayTeam.odds || $[3] !== game.homeTeam.odds) {
      t2 = (0, _libOdds.fairProbabilities)(game.homeTeam.odds, game.awayTeam.odds);
      $[2] = game.awayTeam.odds;
      $[3] = game.homeTeam.odds;
      $[4] = t2;
    } else {
      t2 = $[4];
    }
    const prob = t2;
    let t3;
    if ($[5] !== game || $[6] !== isLocked) {
      t3 = !isLocked && (0, _libMarkets.hasSpreadLine)(game);
      $[5] = game;
      $[6] = isLocked;
      $[7] = t3;
    } else {
      t3 = $[7];
    }
    const canSpread = t3;
    let t4;
    if ($[8] !== game || $[9] !== isLocked) {
      t4 = !isLocked && (0, _libMarkets.hasTotalLine)(game);
      $[8] = game;
      $[9] = isLocked;
      $[10] = t4;
    } else {
      t4 = $[10];
    }
    const canTotal = t4;
    const leader = game.homeScore === null || game.awayScore === null || game.homeScore === game.awayScore ? null : game.homeScore > game.awayScore ? "home" : "away";
    const [pick, setPick] = (0, _react.useState)(null);
    let t5;
    let t6;
    if ($[11] !== isLocked) {
      t5 = () => {
        if (isLocked) {
          setPick(null);
        }
      };
      t6 = [isLocked];
      $[11] = isLocked;
      $[12] = t5;
      $[13] = t6;
    } else {
      t5 = $[12];
      t6 = $[13];
    }
    (0, _react.useEffect)(t5, t6);
    let t7;
    if ($[14] !== pick) {
      t7 = (market, selection) => pick?.market === market && pick.selection === selection;
      $[14] = pick;
      $[15] = t7;
    } else {
      t7 = $[15];
    }
    const isPicked = t7;
    let t8;
    if ($[16] !== game || $[17] !== isLocked || $[18] !== onOpenDetail || $[19] !== priced) {
      t8 = function handleBet(side, t9, selection_0, label) {
        const market_0 = t9 === undefined ? "ml" : t9;
        if (isLocked) {
          return;
        }
        if (market_0 === "ml" && !priced) {
          onOpenDetail?.(game);
          return;
        }
        const sel = selection_0 ?? side;
        _libMotion.haptic.tick();
        setPick(p => p && p.market === market_0 && p.selection === sel ? null : {
          side,
          market: market_0,
          selection: sel,
          label: label ?? (side === "home" ? game.homeTeam.abbreviation : game.awayTeam.abbreviation)
        });
      };
      $[16] = game;
      $[17] = isLocked;
      $[18] = onOpenDetail;
      $[19] = priced;
      $[20] = t8;
    } else {
      t8 = $[20];
    }
    const handleBet = t8;
    let t9;
    if ($[21] !== c || $[22] !== onOpenDetail || $[23] !== position) {
      t9 = t10 => {
        const {
          pressed
        } = t10;
        return [styles.card, {
          backgroundColor: c.card,
          borderColor: position ? c.alpha(c.primary, 0.45) : c.border,
          opacity: pressed && onOpenDetail ? 0.92 : 1
        }];
      };
      $[21] = c;
      $[22] = onOpenDetail;
      $[23] = position;
      $[24] = t9;
    } else {
      t9 = $[24];
    }
    let t10;
    if ($[25] !== game || $[26] !== onOpenDetail) {
      t10 = onOpenDetail ? () => onOpenDetail(game) : undefined;
      $[25] = game;
      $[26] = onOpenDetail;
      $[27] = t10;
    } else {
      t10 = $[27];
    }
    const t11 = onOpenDetail && false ? "button" : undefined;
    const t12 = `${game.awayTeam.name} at ${game.homeTeam.name}`;
    let t13;
    if ($[28] !== c || $[29] !== game) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Header, {
        game: game,
        c: c
      });
      $[28] = c;
      $[29] = game;
      $[30] = t13;
    } else {
      t13 = $[30];
    }
    let t14;
    if ($[31] !== c.subtleForeground) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.colLabel, {
          color: c.subtleForeground
        }],
        children: "MONEYLINE \xB7 WHO WINS"
      });
      $[31] = c.subtleForeground;
      $[32] = t14;
    } else {
      t14 = $[32];
    }
    let t15;
    if ($[33] !== c.subtleForeground) {
      t15 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.colLabel, styles.colOdds, {
          color: c.subtleForeground
        }],
        children: "TAP TO PICK"
      });
      $[33] = c.subtleForeground;
      $[34] = t15;
    } else {
      t15 = $[34];
    }
    let t16;
    if ($[35] !== t14 || $[36] !== t15) {
      t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.colHead,
        accessibilityElementsHidden: true,
        importantForAccessibility: "no-hide-descendants",
        children: [t14, t15]
      });
      $[35] = t14;
      $[36] = t15;
      $[37] = t16;
    } else {
      t16 = $[37];
    }
    const t17 = game.sport;
    const t18 = game.awayTeam;
    const t19 = game.awayScore;
    const t20 = prob.away;
    const t21 = leader === "away";
    const t22 = position?.side === "away";
    const t23 = isPicked("ml", "away");
    let t24;
    if ($[38] !== game.awayTeam.abbreviation || $[39] !== handleBet) {
      t24 = () => handleBet("away", "ml", "away", `${game.awayTeam.abbreviation} to win`);
      $[38] = game.awayTeam.abbreviation;
      $[39] = handleBet;
      $[40] = t24;
    } else {
      t24 = $[40];
    }
    let t25;
    if ($[41] !== c || $[42] !== game.awayScore || $[43] !== game.awayTeam || $[44] !== game.sport || $[45] !== isLocked || $[46] !== oddsFormat || $[47] !== priced || $[48] !== prob.away || $[49] !== t21 || $[50] !== t22 || $[51] !== t23 || $[52] !== t24) {
      t25 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TeamRow, {
        sport: t17,
        team: t18,
        score: t19,
        probability: t20,
        priced: priced,
        leading: t21,
        locked: isLocked,
        backed: t22,
        selected: t23,
        oddsFormat: oddsFormat,
        onPress: t24,
        c: c
      });
      $[41] = c;
      $[42] = game.awayScore;
      $[43] = game.awayTeam;
      $[44] = game.sport;
      $[45] = isLocked;
      $[46] = oddsFormat;
      $[47] = priced;
      $[48] = prob.away;
      $[49] = t21;
      $[50] = t22;
      $[51] = t23;
      $[52] = t24;
      $[53] = t25;
    } else {
      t25 = $[53];
    }
    const t26 = game.sport;
    const t27 = game.homeTeam;
    const t28 = game.homeScore;
    const t29 = prob.home;
    const t30 = leader === "home";
    const t31 = position?.side === "home";
    const t32 = isPicked("ml", "home");
    let t33;
    if ($[54] !== game.homeTeam.abbreviation || $[55] !== handleBet) {
      t33 = () => handleBet("home", "ml", "home", `${game.homeTeam.abbreviation} to win`);
      $[54] = game.homeTeam.abbreviation;
      $[55] = handleBet;
      $[56] = t33;
    } else {
      t33 = $[56];
    }
    let t34;
    if ($[57] !== c || $[58] !== game.homeScore || $[59] !== game.homeTeam || $[60] !== game.sport || $[61] !== isLocked || $[62] !== oddsFormat || $[63] !== priced || $[64] !== prob.home || $[65] !== t30 || $[66] !== t31 || $[67] !== t32 || $[68] !== t33) {
      t34 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TeamRow, {
        sport: t26,
        team: t27,
        score: t28,
        probability: t29,
        priced: priced,
        leading: t30,
        locked: isLocked,
        backed: t31,
        selected: t32,
        oddsFormat: oddsFormat,
        onPress: t33,
        c: c
      });
      $[57] = c;
      $[58] = game.homeScore;
      $[59] = game.homeTeam;
      $[60] = game.sport;
      $[61] = isLocked;
      $[62] = oddsFormat;
      $[63] = priced;
      $[64] = prob.home;
      $[65] = t30;
      $[66] = t31;
      $[67] = t32;
      $[68] = t33;
      $[69] = t34;
    } else {
      t34 = $[69];
    }
    let t35;
    if ($[70] !== t16 || $[71] !== t25 || $[72] !== t34) {
      t35 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.teams,
        children: [t16, t25, t34]
      });
      $[70] = t16;
      $[71] = t25;
      $[72] = t34;
      $[73] = t35;
    } else {
      t35 = $[73];
    }
    let t36;
    if ($[74] !== c || $[75] !== game || $[76] !== priced || $[77] !== prob) {
      t36 = priced ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(ProbabilityBar, {
        game: game,
        prob: prob,
        c: c
      }) : null;
      $[74] = c;
      $[75] = game;
      $[76] = priced;
      $[77] = prob;
      $[78] = t36;
    } else {
      t36 = $[78];
    }
    let t37;
    if ($[79] !== c || $[80] !== canSpread || $[81] !== game.awayTeam.abbreviation || $[82] !== game.homeTeam.abbreviation || $[83] !== game.line || $[84] !== handleBet || $[85] !== isPicked || $[86] !== oddsFormat) {
      t37 = canSpread && typeof game.line?.spreadHome === "number" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(MarketGroup, {
        title: "SPREAD \xB7 WIN OR LOSE BY",
        c: c,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(MarketChip, {
          label: `${game.awayTeam.abbreviation} ${(0, _libMarkets.formatSpread)(-game.line.spreadHome)}`,
          odds: (0, _libOdds.formatOdds)(_libMarkets.SPREAD_TOTAL_ODDS, oddsFormat),
          selected: isPicked("spread", "away"),
          onPress: () => handleBet("away", "spread", "away", `${game.awayTeam.abbreviation} ${(0, _libMarkets.formatSpread)(-game.line.spreadHome)}`),
          c: c
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(MarketChip, {
          label: `${game.homeTeam.abbreviation} ${(0, _libMarkets.formatSpread)(game.line.spreadHome)}`,
          odds: (0, _libOdds.formatOdds)(_libMarkets.SPREAD_TOTAL_ODDS, oddsFormat),
          selected: isPicked("spread", "home"),
          onPress: () => handleBet("home", "spread", "home", `${game.homeTeam.abbreviation} ${(0, _libMarkets.formatSpread)(game.line.spreadHome)}`),
          c: c
        })]
      }) : null;
      $[79] = c;
      $[80] = canSpread;
      $[81] = game.awayTeam.abbreviation;
      $[82] = game.homeTeam.abbreviation;
      $[83] = game.line;
      $[84] = handleBet;
      $[85] = isPicked;
      $[86] = oddsFormat;
      $[87] = t37;
    } else {
      t37 = $[87];
    }
    let t38;
    if ($[88] !== c || $[89] !== canTotal || $[90] !== game.line || $[91] !== handleBet || $[92] !== isPicked || $[93] !== oddsFormat) {
      t38 = canTotal && typeof game.line?.overUnder === "number" ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(MarketGroup, {
        title: "TOTAL POINTS \xB7 OVER / UNDER",
        c: c,
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(MarketChip, {
          label: `Over ${game.line.overUnder}`,
          odds: (0, _libOdds.formatOdds)(_libMarkets.SPREAD_TOTAL_ODDS, oddsFormat),
          selected: isPicked("total", "over"),
          onPress: () => handleBet("home", "total", "over", `Over ${game.line.overUnder}`),
          c: c
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(MarketChip, {
          label: `Under ${game.line.overUnder}`,
          odds: (0, _libOdds.formatOdds)(_libMarkets.SPREAD_TOTAL_ODDS, oddsFormat),
          selected: isPicked("total", "under"),
          onPress: () => handleBet("away", "total", "under", `Under ${game.line.overUnder}`),
          c: c
        })]
      }) : null;
      $[88] = c;
      $[89] = canTotal;
      $[90] = game.line;
      $[91] = handleBet;
      $[92] = isPicked;
      $[93] = oddsFormat;
      $[94] = t38;
    } else {
      t38 = $[94];
    }
    let t39;
    if ($[95] !== c || $[96] !== game || $[97] !== isLocked || $[98] !== onBet || $[99] !== onChallenge || $[100] !== pick) {
      t39 = pick && !isLocked ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.cta, {
          borderColor: c.alpha(c.primary, 0.4),
          backgroundColor: c.primarySoft
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.ctaText, {
            color: c.foreground
          }],
          numberOfLines: 1,
          children: ["Your Pick: ", /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: {
              color: c.primary
            },
            children: pick.label
          })]
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.ctaRow,
          children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: "Choose Bet Amount",
            icon: "cash-multiple",
            size: "sm",
            style: {
              flex: 1.3
            },
            accessibilityHint: "Opens the bet slip to choose how much to stake",
            onPress: () => {
              _libMotion.haptic.medium();
              onBet(game, pick.side, pick.market, pick.selection);
              setPick(null);
            }
          }), onChallenge && pick.market === "ml" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Button, {
            label: "Select Friend",
            icon: "sword-cross",
            size: "sm",
            variant: "secondary",
            style: {
              flex: 1
            },
            accessibilityHint: "Pick a friend to challenge, then choose the amount",
            onPress: () => {
              onChallenge(game, pick.side);
              setPick(null);
            }
          }) : null]
        })]
      }) : null;
      $[95] = c;
      $[96] = game;
      $[97] = isLocked;
      $[98] = onBet;
      $[99] = onChallenge;
      $[100] = pick;
      $[101] = t39;
    } else {
      t39 = $[101];
    }
    let t40;
    if ($[102] !== game || $[103] !== onLeaguePress) {
      t40 = onLeaguePress ? () => onLeaguePress(game) : undefined;
      $[102] = game;
      $[103] = onLeaguePress;
      $[104] = t40;
    } else {
      t40 = $[104];
    }
    let t41;
    if ($[105] !== c || $[106] !== game || $[107] !== isLocked || $[108] !== leagueMembers || $[109] !== priced || $[110] !== t40) {
      t41 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Footer, {
        game: game,
        c: c,
        isLocked: isLocked,
        priced: priced,
        leagueMembers: leagueMembers,
        onLeaguePress: t40
      });
      $[105] = c;
      $[106] = game;
      $[107] = isLocked;
      $[108] = leagueMembers;
      $[109] = priced;
      $[110] = t40;
      $[111] = t41;
    } else {
      t41 = $[111];
    }
    let t42;
    if ($[112] !== c || $[113] !== game || $[114] !== position) {
      t42 = position && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(PositionStrip, {
        game: game,
        position: position,
        c: c
      });
      $[112] = c;
      $[113] = game;
      $[114] = position;
      $[115] = t42;
    } else {
      t42 = $[115];
    }
    let t43;
    if ($[116] !== t10 || $[117] !== t11 || $[118] !== t12 || $[119] !== t13 || $[120] !== t35 || $[121] !== t36 || $[122] !== t37 || $[123] !== t38 || $[124] !== t39 || $[125] !== t41 || $[126] !== t42 || $[127] !== t9) {
      t43 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        style: t9,
        onPress: t10,
        accessibilityRole: t11,
        accessibilityLabel: t12,
        children: [t13, t35, t36, t37, t38, t39, t41, t42]
      });
      $[116] = t10;
      $[117] = t11;
      $[118] = t12;
      $[119] = t13;
      $[120] = t35;
      $[121] = t36;
      $[122] = t37;
      $[123] = t38;
      $[124] = t39;
      $[125] = t41;
      $[126] = t42;
      $[127] = t9;
      $[128] = t43;
    } else {
      t43 = $[128];
    }
    return t43;
  }
  var _default = /*#__PURE__*/(0, _react.memo)(GameCard);
  function MarketGroup(t0) {
    const $ = (0, _reactCompilerRuntime.c)(13);
    const {
      title,
      c,
      children
    } = t0;
    let t1;
    if ($[0] !== c.border) {
      t1 = [styles.group, {
        borderTopColor: c.border
      }];
      $[0] = c.border;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    let t2;
    if ($[2] !== c.subtleForeground) {
      t2 = [styles.colLabel, {
        color: c.subtleForeground
      }];
      $[2] = c.subtleForeground;
      $[3] = t2;
    } else {
      t2 = $[3];
    }
    let t3;
    if ($[4] !== t2 || $[5] !== title) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t2,
        children: title
      });
      $[4] = t2;
      $[5] = title;
      $[6] = t3;
    } else {
      t3 = $[6];
    }
    let t4;
    if ($[7] !== children) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.marketStrip,
        children: children
      });
      $[7] = children;
      $[8] = t4;
    } else {
      t4 = $[8];
    }
    let t5;
    if ($[9] !== t1 || $[10] !== t3 || $[11] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t1,
        children: [t3, t4]
      });
      $[9] = t1;
      $[10] = t3;
      $[11] = t4;
      $[12] = t5;
    } else {
      t5 = $[12];
    }
    return t5;
  }
  function MarketChip(t0) {
    const $ = (0, _reactCompilerRuntime.c)(22);
    const {
      label,
      odds,
      selected,
      onPress,
      c
    } = t0;
    let t1;
    if ($[0] !== c || $[1] !== selected) {
      t1 = [styles.marketChip, selected ? {
        backgroundColor: c.alpha(c.primary, 0.18),
        borderColor: c.primary,
        borderWidth: 2
      } : {
        backgroundColor: c.secondary,
        borderColor: c.alpha(c.foreground, 0.22)
      }];
      $[0] = c;
      $[1] = selected;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    let t2;
    if ($[3] !== selected) {
      t2 = {
        selected
      };
      $[3] = selected;
      $[4] = t2;
    } else {
      t2 = $[4];
    }
    const t3 = `${label} at ${odds}${selected ? ", selected" : ""}`;
    let t4;
    if ($[5] !== c.foreground) {
      t4 = [styles.marketChipLabel, {
        color: c.foreground
      }];
      $[5] = c.foreground;
      $[6] = t4;
    } else {
      t4 = $[6];
    }
    let t5;
    if ($[7] !== label || $[8] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t4,
        children: label
      });
      $[7] = label;
      $[8] = t4;
      $[9] = t5;
    } else {
      t5 = $[9];
    }
    const t6 = selected ? c.primary : c.mutedForeground;
    let t7;
    if ($[10] !== t6) {
      t7 = [styles.marketChipOdds, {
        color: t6
      }];
      $[10] = t6;
      $[11] = t7;
    } else {
      t7 = $[11];
    }
    let t8;
    if ($[12] !== odds || $[13] !== t7) {
      t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t7,
        children: odds
      });
      $[12] = odds;
      $[13] = t7;
      $[14] = t8;
    } else {
      t8 = $[14];
    }
    let t9;
    if ($[15] !== onPress || $[16] !== t1 || $[17] !== t2 || $[18] !== t3 || $[19] !== t5 || $[20] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(PressableScale.default, {
        style: t1,
        scaleTo: 0.95,
        onPress: onPress,
        accessibilityRole: "button",
        accessibilityState: t2,
        accessibilityLabel: t3,
        children: [t5, t8]
      });
      $[15] = onPress;
      $[16] = t1;
      $[17] = t2;
      $[18] = t3;
      $[19] = t5;
      $[20] = t8;
      $[21] = t9;
    } else {
      t9 = $[21];
    }
    return t9;
  }
  function Header(t0) {
    const $ = (0, _reactCompilerRuntime.c)(43);
    const {
      game,
      c
    } = t0;
    let T0;
    let T1;
    let sportColor;
    let t1;
    let t2;
    let t3;
    let underHour;
    if ($[0] !== c || $[1] !== game.disrupted || $[2] !== game.sport || $[3] !== game.startsAt || $[4] !== game.status) {
      sportColor = c.sport(game.sport);
      const now = Date.now();
      const msLeft = game.startsAt - now;
      underHour = game.status === "upcoming" && !game.disrupted && msLeft > 0 && msLeft <= 3600000;
      T1 = View.default;
      t3 = styles.header;
      T0 = View.default;
      t2 = styles.sportChip;
      t1 = c.alpha(sportColor, 0.16);
      $[0] = c;
      $[1] = game.disrupted;
      $[2] = game.sport;
      $[3] = game.startsAt;
      $[4] = game.status;
      $[5] = T0;
      $[6] = T1;
      $[7] = sportColor;
      $[8] = t1;
      $[9] = t2;
      $[10] = t3;
      $[11] = underHour;
    } else {
      T0 = $[5];
      T1 = $[6];
      sportColor = $[7];
      t1 = $[8];
      t2 = $[9];
      t3 = $[10];
      underHour = $[11];
    }
    let t4;
    if ($[12] !== t1) {
      t4 = {
        backgroundColor: t1
      };
      $[12] = t1;
      $[13] = t4;
    } else {
      t4 = $[13];
    }
    let t5;
    if ($[14] !== t2 || $[15] !== t4) {
      t5 = [t2, t4];
      $[14] = t2;
      $[15] = t4;
      $[16] = t5;
    } else {
      t5 = $[16];
    }
    const t6 = game.sportIcon;
    let t7;
    if ($[17] !== sportColor || $[18] !== t6) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: t6,
        size: 12,
        color: sportColor
      });
      $[17] = sportColor;
      $[18] = t6;
      $[19] = t7;
    } else {
      t7 = $[19];
    }
    let t8;
    if ($[20] !== sportColor) {
      t8 = [styles.sportText, {
        color: sportColor
      }];
      $[20] = sportColor;
      $[21] = t8;
    } else {
      t8 = $[21];
    }
    let t9;
    if ($[22] !== game.sport || $[23] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t8,
        children: game.sport
      });
      $[22] = game.sport;
      $[23] = t8;
      $[24] = t9;
    } else {
      t9 = $[24];
    }
    let t10;
    if ($[25] !== T0 || $[26] !== t5 || $[27] !== t7 || $[28] !== t9) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T0, {
        style: t5,
        children: [t7, t9]
      });
      $[25] = T0;
      $[26] = t5;
      $[27] = t7;
      $[28] = t9;
      $[29] = t10;
    } else {
      t10 = $[29];
    }
    let t11;
    if ($[30] !== c.subtleForeground || $[31] !== game.seasonLabel) {
      t11 = game.seasonLabel ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.meta, {
          color: c.subtleForeground
        }],
        numberOfLines: 1,
        children: game.seasonLabel
      }) : null;
      $[30] = c.subtleForeground;
      $[31] = game.seasonLabel;
      $[32] = t11;
    } else {
      t11 = $[32];
    }
    let t12;
    if ($[33] !== c || $[34] !== game || $[35] !== underHour) {
      t12 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.headerRight,
        children: game.disrupted ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.statusText, {
            color: c.warning
          }],
          children: game.disrupted === "canceled" ? "Cancelled" : "Postponed"
        }) : game.status === "live" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(LiveClock, {
          game: game,
          c: c
        }) : game.status === "final" ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.statusText, {
            color: c.mutedForeground
          }],
          children: "Final"
        }) : /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: [styles.statusText, {
            color: c.foreground
          }],
          children: [(0, _libOdds.kickoffLabel)(game.startsAt), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
            style: {
              color: underHour ? c.live : c.subtleForeground
            },
            children: `  ${underHour ? `Locks ${(0, _libOdds.untilKickoff)(game.startsAt)}` : (0, _libOdds.untilKickoff)(game.startsAt)}`
          })]
        })
      });
      $[33] = c;
      $[34] = game;
      $[35] = underHour;
      $[36] = t12;
    } else {
      t12 = $[36];
    }
    let t13;
    if ($[37] !== T1 || $[38] !== t10 || $[39] !== t11 || $[40] !== t12 || $[41] !== t3) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T1, {
        style: t3,
        children: [t10, t11, t12]
      });
      $[37] = T1;
      $[38] = t10;
      $[39] = t11;
      $[40] = t12;
      $[41] = t3;
      $[42] = t13;
    } else {
      t13 = $[42];
    }
    return t13;
  }
  const _worklet_8319462634842_init_data = {
    code: "(function GameCardTsx1(){const[pulse]=this.__closure;return{opacity:pulse.value};})"
  };
  function LiveClock(t0) {
    const $ = (0, _reactCompilerRuntime.c)(25);
    const {
      game,
      c
    } = t0;
    const reduced = (0, _reactNativeReanimated.useReducedMotion)();
    const pulse = (0, _reactNativeReanimated.useSharedValue)(1);
    let t1;
    let t2;
    if ($[0] !== pulse || $[1] !== reduced) {
      t1 = () => {
        if (reduced) {
          pulse.value = 1;
          return;
        }
        pulse.value = (0, _reactNativeReanimated.withRepeat)((0, _reactNativeReanimated.withSequence)((0, _reactNativeReanimated.withTiming)(0.25, {
          duration: 700,
          easing: _reactNativeReanimated.Easing.inOut(_reactNativeReanimated.Easing.quad)
        }), (0, _reactNativeReanimated.withTiming)(1, {
          duration: 700,
          easing: _reactNativeReanimated.Easing.inOut(_reactNativeReanimated.Easing.quad)
        })), -1);
        return () => (0, _reactNativeReanimated.cancelAnimation)(pulse);
      };
      t2 = [pulse, reduced];
      $[0] = pulse;
      $[1] = reduced;
      $[2] = t1;
      $[3] = t2;
    } else {
      t1 = $[2];
      t2 = $[3];
    }
    (0, _react.useEffect)(t1, t2);
    const dotStyle = (0, _reactNativeReanimated.useAnimatedStyle)(function GameCardTsx1Factory([_worklet_8319462634842_init_data, pulse]) {
      const GameCardTsx1 = function () {
        "use no memo";

        return {
          opacity: pulse.value
        };
      };
      GameCardTsx1.__closure = [pulse];
      GameCardTsx1.__workletHash = 8319462634842;
      GameCardTsx1.__initData = _worklet_8319462634842_init_data;
      return GameCardTsx1;
    }([_worklet_8319462634842_init_data, pulse]));
    let t3;
    if ($[4] !== game.clock || $[5] !== game.situation || $[6] !== game.startsAt) {
      t3 = game.clock ?? game.situation ?? (0, _libOdds.kickoffLabel)(game.startsAt);
      $[4] = game.clock;
      $[5] = game.situation;
      $[6] = game.startsAt;
      $[7] = t3;
    } else {
      t3 = $[7];
    }
    const detail = t3;
    let t4;
    if ($[8] !== c.live) {
      t4 = [styles.liveBadge, {
        backgroundColor: c.live
      }];
      $[8] = c.live;
      $[9] = t4;
    } else {
      t4 = $[9];
    }
    let t5;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
      t5 = {
        backgroundColor: "#fff"
      };
      $[10] = t5;
    } else {
      t5 = $[10];
    }
    let t6;
    if ($[11] !== dotStyle) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Reanimated.default.View, {
        style: [styles.liveDot, t5, dotStyle]
      });
      $[11] = dotStyle;
      $[12] = t6;
    } else {
      t6 = $[12];
    }
    let t7;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: styles.liveText,
        children: "LIVE"
      });
      $[13] = t7;
    } else {
      t7 = $[13];
    }
    let t8;
    if ($[14] !== t4 || $[15] !== t6) {
      t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t4,
        children: [t6, t7]
      });
      $[14] = t4;
      $[15] = t6;
      $[16] = t8;
    } else {
      t8 = $[16];
    }
    let t9;
    if ($[17] !== c.foreground) {
      t9 = [styles.statusText, {
        color: c.foreground,
        flexShrink: 1
      }];
      $[17] = c.foreground;
      $[18] = t9;
    } else {
      t9 = $[18];
    }
    let t10;
    if ($[19] !== detail || $[20] !== t9) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t9,
        numberOfLines: 1,
        children: detail
      });
      $[19] = detail;
      $[20] = t9;
      $[21] = t10;
    } else {
      t10 = $[21];
    }
    let t11;
    if ($[22] !== t10 || $[23] !== t8) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.headerRight,
        children: [t8, t10]
      });
      $[22] = t10;
      $[23] = t8;
      $[24] = t11;
    } else {
      t11 = $[24];
    }
    return t11;
  }
  function TeamRow(t0) {
    const $ = (0, _reactCompilerRuntime.c)(47);
    const {
      sport,
      team,
      score,
      probability,
      priced,
      leading,
      locked,
      backed,
      selected,
      oddsFormat,
      onPress,
      c
    } = t0;
    let t1;
    if ($[0] !== c || $[1] !== sport || $[2] !== team) {
      t1 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TeamMark, {
        team: team,
        sport: sport,
        c: c
      });
      $[0] = c;
      $[1] = sport;
      $[2] = team;
      $[3] = t1;
    } else {
      t1 = $[3];
    }
    let t2;
    if ($[4] !== c.mutedForeground || $[5] !== team.rank) {
      t2 = team.rank ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.rank, {
          color: c.mutedForeground
        }],
        children: team.rank
      }) : null;
      $[4] = c.mutedForeground;
      $[5] = team.rank;
      $[6] = t2;
    } else {
      t2 = $[6];
    }
    const t3 = leading ? c.foreground : c.cardForeground;
    let t4;
    if ($[7] !== t3) {
      t4 = [styles.teamName, {
        color: t3
      }];
      $[7] = t3;
      $[8] = t4;
    } else {
      t4 = $[8];
    }
    let t5;
    if ($[9] !== t4 || $[10] !== team.name) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t4,
        numberOfLines: 1,
        children: team.name
      });
      $[9] = t4;
      $[10] = team.name;
      $[11] = t5;
    } else {
      t5 = $[11];
    }
    let t6;
    if ($[12] !== t2 || $[13] !== t5) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.nameLine,
        children: [t2, t5]
      });
      $[12] = t2;
      $[13] = t5;
      $[14] = t6;
    } else {
      t6 = $[14];
    }
    let t7;
    if ($[15] !== c.mutedForeground || $[16] !== team.record) {
      t7 = team.record ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.record, {
          color: c.mutedForeground
        }],
        children: team.record
      }) : null;
      $[15] = c.mutedForeground;
      $[16] = team.record;
      $[17] = t7;
    } else {
      t7 = $[17];
    }
    let t8;
    if ($[18] !== c || $[19] !== team.form) {
      t8 = team.form?.length ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Form, {
        form: team.form,
        c: c
      }) : null;
      $[18] = c;
      $[19] = team.form;
      $[20] = t8;
    } else {
      t8 = $[20];
    }
    let t9;
    if ($[21] !== t7 || $[22] !== t8) {
      t9 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.nameLine,
        children: [t7, t8]
      });
      $[21] = t7;
      $[22] = t8;
      $[23] = t9;
    } else {
      t9 = $[23];
    }
    let t10;
    if ($[24] !== t6 || $[25] !== t9) {
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.teamText,
        children: [t6, t9]
      });
      $[24] = t6;
      $[25] = t9;
      $[26] = t10;
    } else {
      t10 = $[26];
    }
    let t11;
    if ($[27] !== c.foreground || $[28] !== c.mutedForeground || $[29] !== leading || $[30] !== score) {
      t11 = score !== null && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.score, {
          color: leading ? c.foreground : c.mutedForeground,
          fontVariant: ["tabular-nums"]
        }],
        children: score
      });
      $[27] = c.foreground;
      $[28] = c.mutedForeground;
      $[29] = leading;
      $[30] = score;
      $[31] = t11;
    } else {
      t11 = $[31];
    }
    let t12;
    if ($[32] !== backed || $[33] !== c || $[34] !== locked || $[35] !== oddsFormat || $[36] !== onPress || $[37] !== priced || $[38] !== probability || $[39] !== selected || $[40] !== team) {
      t12 = priced || backed ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(OddsButton, {
        team: team,
        probability: probability,
        locked: locked,
        backed: backed,
        selected: selected,
        oddsFormat: oddsFormat,
        onPress: onPress,
        c: c
      }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(NoLineTile, {
        locked: locked,
        onPress: onPress,
        c: c
      });
      $[32] = backed;
      $[33] = c;
      $[34] = locked;
      $[35] = oddsFormat;
      $[36] = onPress;
      $[37] = priced;
      $[38] = probability;
      $[39] = selected;
      $[40] = team;
      $[41] = t12;
    } else {
      t12 = $[41];
    }
    let t13;
    if ($[42] !== t1 || $[43] !== t10 || $[44] !== t11 || $[45] !== t12) {
      t13 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.teamRow,
        children: [t1, t10, t11, t12]
      });
      $[42] = t1;
      $[43] = t10;
      $[44] = t11;
      $[45] = t12;
      $[46] = t13;
    } else {
      t13 = $[46];
    }
    return t13;
  }
  function NoLineTile(t0) {
    const $ = (0, _reactCompilerRuntime.c)(14);
    const {
      locked,
      onPress,
      c
    } = t0;
    const t1 = locked ? 0.55 : 1;
    let t2;
    if ($[0] !== c.border || $[1] !== c.secondary || $[2] !== t1) {
      t2 = [styles.oddsBtn, {
        backgroundColor: c.secondary,
        borderColor: c.border,
        borderStyle: "dashed",
        opacity: t1
      }];
      $[0] = c.border;
      $[1] = c.secondary;
      $[2] = t1;
      $[3] = t2;
    } else {
      t2 = $[3];
    }
    let t3;
    if ($[4] !== c.mutedForeground) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.noLine, {
          color: c.mutedForeground
        }],
        children: "No Line"
      });
      $[4] = c.mutedForeground;
      $[5] = t3;
    } else {
      t3 = $[5];
    }
    let t4;
    if ($[6] !== c.subtleForeground) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.oddsProb, {
          color: c.subtleForeground
        }],
        children: "yet"
      });
      $[6] = c.subtleForeground;
      $[7] = t4;
    } else {
      t4 = $[7];
    }
    let t5;
    if ($[8] !== locked || $[9] !== onPress || $[10] !== t2 || $[11] !== t3 || $[12] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(PressableScale.default, {
        style: t2,
        scaleTo: 0.96,
        onPress: onPress,
        disabled: locked,
        accessibilityRole: "button",
        accessibilityLabel: `${_libOdds.NO_LINE}. Opens the game`,
        children: [t3, t4]
      });
      $[8] = locked;
      $[9] = onPress;
      $[10] = t2;
      $[11] = t3;
      $[12] = t4;
      $[13] = t5;
    } else {
      t5 = $[13];
    }
    return t5;
  }
  const _worklet_15231037191662_init_data = {
    code: "(function GameCardTsx2(){const[pop]=this.__closure;return{transform:[{scale:pop.value}]};})"
  };
  function OddsButton(t0) {
    const $ = (0, _reactCompilerRuntime.c)(70);
    const {
      team,
      probability,
      locked,
      backed,
      selected,
      oddsFormat,
      onPress,
      c
    } = t0;
    const odds = team.odds ?? 0;
    const t1 = c.positive;
    const t2 = c.negative;
    let t3;
    if ($[0] !== c) {
      t3 = c.alpha(c.border, 0);
      $[0] = c;
      $[1] = t3;
    } else {
      t3 = $[1];
    }
    let t4;
    if ($[2] !== c.negative || $[3] !== c.positive || $[4] !== t3) {
      t4 = {
        up: t1,
        down: t2,
        rest: t3
      };
      $[2] = c.negative;
      $[3] = c.positive;
      $[4] = t3;
      $[5] = t4;
    } else {
      t4 = $[5];
    }
    const flash = (0, _hooksUseMotion.useValueFlash)(odds, t4);
    const pop = (0, _reactNativeReanimated.useSharedValue)(1);
    const wasBacked = (0, _react.useRef)(backed);
    let t5;
    let t6;
    if ($[6] !== backed || $[7] !== pop) {
      t5 = () => {
        if (backed && !wasBacked.current) {
          pop.value = (0, _reactNativeReanimated.withSequence)((0, _reactNativeReanimated.withTiming)(1.12, {
            duration: 110
          }), (0, _reactNativeReanimated.withSpring)(1, _libMotion.SPRING.bouncy));
        }
        wasBacked.current = backed;
      };
      t6 = [backed, pop];
      $[6] = backed;
      $[7] = pop;
      $[8] = t5;
      $[9] = t6;
    } else {
      t5 = $[8];
      t6 = $[9];
    }
    (0, _react.useEffect)(t5, t6);
    const popStyle = (0, _reactNativeReanimated.useAnimatedStyle)(function GameCardTsx2Factory([_worklet_15231037191662_init_data, pop]) {
      const GameCardTsx2 = function () {
        "use no memo";

        return {
          transform: [{
            scale: pop.value
          }]
        };
      };
      GameCardTsx2.__closure = [pop];
      GameCardTsx2.__workletHash = 15231037191662;
      GameCardTsx2.__initData = _worklet_15231037191662_init_data;
      return GameCardTsx2;
    }([_worklet_15231037191662_init_data, pop]));
    let t7;
    if ($[10] !== backed || $[11] !== c || $[12] !== selected) {
      t7 = backed ? c.primary : selected ? c.alpha(c.primary, 0.18) : c.secondary;
      $[10] = backed;
      $[11] = c;
      $[12] = selected;
      $[13] = t7;
    } else {
      t7 = $[13];
    }
    let t8;
    if ($[14] !== backed || $[15] !== c || $[16] !== selected) {
      t8 = backed || selected ? c.primary : c.alpha(c.foreground, 0.22);
      $[14] = backed;
      $[15] = c;
      $[16] = selected;
      $[17] = t8;
    } else {
      t8 = $[17];
    }
    const t9 = selected ? 2 : 1;
    const t10 = locked && !backed ? 0.55 : 1;
    let t11;
    if ($[18] !== t10 || $[19] !== t7 || $[20] !== t8 || $[21] !== t9) {
      t11 = [styles.oddsBtn, {
        backgroundColor: t7,
        borderColor: t8,
        borderWidth: t9,
        opacity: t10
      }];
      $[18] = t10;
      $[19] = t7;
      $[20] = t8;
      $[21] = t9;
      $[22] = t11;
    } else {
      t11 = $[22];
    }
    let t12;
    if ($[23] !== selected) {
      t12 = {
        selected
      };
      $[23] = selected;
      $[24] = t12;
    } else {
      t12 = $[24];
    }
    let t13;
    if ($[25] !== odds || $[26] !== oddsFormat || $[27] !== probability || $[28] !== team.name) {
      t13 = odds > 1 ? `Pick ${team.name} at ${(0, _libOdds.formatOdds)(odds, oddsFormat)}, ${(0, _libOdds.formatPercent)(probability)} chance` : `Your pick: ${team.name}`;
      $[25] = odds;
      $[26] = oddsFormat;
      $[27] = probability;
      $[28] = team.name;
      $[29] = t13;
    } else {
      t13 = $[29];
    }
    let t14;
    if ($[30] !== flash.style) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Reanimated.default.View, {
        pointerEvents: "none",
        style: [styles.oddsFlash, flash.style]
      });
      $[30] = flash.style;
      $[31] = t14;
    } else {
      t14 = $[31];
    }
    let t15;
    if ($[32] !== c.negative || $[33] !== c.positive || $[34] !== flash.dir) {
      t15 = flash.dir !== 0 ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: flash.dir > 0 ? "menu-up" : "menu-down",
        size: 16,
        color: flash.dir > 0 ? c.positive : c.negative,
        style: {
          marginHorizontal: -4
        }
      }) : null;
      $[32] = c.negative;
      $[33] = c.positive;
      $[34] = flash.dir;
      $[35] = t15;
    } else {
      t15 = $[35];
    }
    const t16 = backed ? c.primaryForeground : c.foreground;
    let t17;
    if ($[36] !== t16) {
      t17 = [styles.oddsValue, {
        color: t16
      }];
      $[36] = t16;
      $[37] = t17;
    } else {
      t17 = $[37];
    }
    let t18;
    if ($[38] !== odds || $[39] !== oddsFormat) {
      t18 = odds > 1 ? (0, _libOdds.formatOdds)(odds, oddsFormat) : "\u2014";
      $[38] = odds;
      $[39] = oddsFormat;
      $[40] = t18;
    } else {
      t18 = $[40];
    }
    let t19;
    if ($[41] !== t17 || $[42] !== t18) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t17,
        children: t18
      });
      $[41] = t17;
      $[42] = t18;
      $[43] = t19;
    } else {
      t19 = $[43];
    }
    let t20;
    if ($[44] !== t15 || $[45] !== t19) {
      t20 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.oddsLine,
        children: [t15, t19]
      });
      $[44] = t15;
      $[45] = t19;
      $[46] = t20;
    } else {
      t20 = $[46];
    }
    let t21;
    if ($[47] !== backed || $[48] !== c) {
      t21 = backed ? c.alpha(c.primaryForeground, 0.75) : c.mutedForeground;
      $[47] = backed;
      $[48] = c;
      $[49] = t21;
    } else {
      t21 = $[49];
    }
    let t22;
    if ($[50] !== t21) {
      t22 = [styles.oddsProb, {
        color: t21
      }];
      $[50] = t21;
      $[51] = t22;
    } else {
      t22 = $[51];
    }
    let t23;
    if ($[52] !== odds || $[53] !== probability) {
      t23 = odds > 1 ? (0, _libOdds.formatPercent)(probability) : "your pick";
      $[52] = odds;
      $[53] = probability;
      $[54] = t23;
    } else {
      t23 = $[54];
    }
    let t24;
    if ($[55] !== t22 || $[56] !== t23) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t22,
        children: t23
      });
      $[55] = t22;
      $[56] = t23;
      $[57] = t24;
    } else {
      t24 = $[57];
    }
    let t25;
    if ($[58] !== locked || $[59] !== onPress || $[60] !== t11 || $[61] !== t12 || $[62] !== t13 || $[63] !== t14 || $[64] !== t20 || $[65] !== t24) {
      t25 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(PressableScale.default, {
        style: t11,
        scaleTo: 0.93,
        onPress: onPress,
        disabled: locked,
        accessibilityRole: "button",
        accessibilityState: t12,
        accessibilityLabel: t13,
        children: [t14, t20, t24]
      });
      $[58] = locked;
      $[59] = onPress;
      $[60] = t11;
      $[61] = t12;
      $[62] = t13;
      $[63] = t14;
      $[64] = t20;
      $[65] = t24;
      $[66] = t25;
    } else {
      t25 = $[66];
    }
    let t26;
    if ($[67] !== popStyle || $[68] !== t25) {
      t26 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Reanimated.default.View, {
        style: popStyle,
        children: t25
      });
      $[67] = popStyle;
      $[68] = t25;
      $[69] = t26;
    } else {
      t26 = $[69];
    }
    return t26;
  }

  /** Team colour + abbreviation. Official logos aren't shown (trademarked). */
  function TeamMark(t0) {
    const $ = (0, _reactCompilerRuntime.c)(5);
    const {
      team,
      sport
    } = t0;
    let t1;
    if ($[0] !== sport || $[1] !== team.abbreviation || $[2] !== team.altColor || $[3] !== team.color) {
      t1 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TeamCrest.default, {
        abbr: team.abbreviation,
        color: team.color,
        altColor: team.altColor,
        size: 28,
        sport: sport
      });
      $[0] = sport;
      $[1] = team.abbreviation;
      $[2] = team.altColor;
      $[3] = team.color;
      $[4] = t1;
    } else {
      t1 = $[4];
    }
    return t1;
  }
  function Form(t0) {
    const $ = (0, _reactCompilerRuntime.c)(7);
    const {
      form,
      c
    } = t0;
    let t1;
    if ($[0] !== c || $[1] !== form) {
      let t2;
      if ($[3] !== c) {
        t2 = (r, i) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: [styles.formPip, {
            backgroundColor: r === "W" ? c.positive : r === "L" ? c.alpha(c.negative, 0.75) : c.push,
            opacity: 1 - i * 0.13
          }]
        }, i);
        $[3] = c;
        $[4] = t2;
      } else {
        t2 = $[4];
      }
      t1 = form.slice(0, 5).map(t2);
      $[0] = c;
      $[1] = form;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    let t2;
    if ($[5] !== t1) {
      t2 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: styles.form,
        children: t1
      });
      $[5] = t1;
      $[6] = t2;
    } else {
      t2 = $[6];
    }
    return t2;
  }
  function ProbabilityBar(t0) {
    const $ = (0, _reactCompilerRuntime.c)(15);
    const {
      game,
      prob,
      c
    } = t0;
    let t1;
    if ($[0] !== c.secondary) {
      t1 = [styles.bar, {
        backgroundColor: c.secondary
      }];
      $[0] = c.secondary;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    const t2 = Math.max(0.02, prob.away);
    let t3;
    if ($[2] !== game.awayTeam.color || $[3] !== t2) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: {
          flex: t2,
          backgroundColor: game.awayTeam.color
        }
      });
      $[2] = game.awayTeam.color;
      $[3] = t2;
      $[4] = t3;
    } else {
      t3 = $[4];
    }
    let t4;
    if ($[5] !== c.card) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: {
          width: 2,
          backgroundColor: c.card
        }
      });
      $[5] = c.card;
      $[6] = t4;
    } else {
      t4 = $[6];
    }
    const t5 = Math.max(0.02, prob.home);
    let t6;
    if ($[7] !== game.homeTeam.color || $[8] !== t5) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
        style: {
          flex: t5,
          backgroundColor: game.homeTeam.color
        }
      });
      $[7] = game.homeTeam.color;
      $[8] = t5;
      $[9] = t6;
    } else {
      t6 = $[9];
    }
    let t7;
    if ($[10] !== t1 || $[11] !== t3 || $[12] !== t4 || $[13] !== t6) {
      t7 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t1,
        accessibilityElementsHidden: true,
        children: [t3, t4, t6]
      });
      $[10] = t1;
      $[11] = t3;
      $[12] = t4;
      $[13] = t6;
      $[14] = t7;
    } else {
      t7 = $[14];
    }
    return t7;
  }
  function Footer(t0) {
    const $ = (0, _reactCompilerRuntime.c)(31);
    const {
      game,
      c,
      isLocked,
      priced,
      leagueMembers,
      onLeaguePress
    } = t0;
    const noLine = !priced && game.status === "upcoming" && !game.disrupted;
    const modelLine = priced && game.oddsSource === "model" && game.status === "upcoming";
    let bits;
    if ($[0] !== game.broadcast || $[1] !== game.line || $[2] !== game.status || $[3] !== game.venue) {
      bits = [];
      if (game.line?.spread) {
        bits.push(game.line.spread);
      }
      if (game.line?.overUnder) {
        bits.push(`O/U ${game.line.overUnder}`);
      }
      if (game.broadcast) {
        bits.push(game.broadcast);
      }
      if (game.venue && game.status === "upcoming") {
        bits.push(game.venue);
      }
      $[0] = game.broadcast;
      $[1] = game.line;
      $[2] = game.status;
      $[3] = game.venue;
      $[4] = bits;
    } else {
      bits = $[4];
    }
    const hasLeagueAction = !!leagueMembers && leagueMembers.length > 0;
    if (bits.length === 0 && !isLocked && !noLine && !modelLine && !hasLeagueAction) {
      return null;
    }
    let t1;
    if ($[5] !== c || $[6] !== hasLeagueAction || $[7] !== leagueMembers || $[8] !== onLeaguePress) {
      t1 = hasLeagueAction && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(_componentsFxTap.Pressable, {
        onPress: onLeaguePress,
        disabled: !onLeaguePress,
        hitSlop: 6,
        accessibilityRole: onLeaguePress ? "button" : undefined,
        accessibilityLabel: "See who in your league is on this game",
        style: [styles.leagueOnChip, {
          backgroundColor: c.leagueSoft,
          borderColor: c.alpha(c.league, 0.45)
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
          style: styles.avatarStack,
          children: leagueMembers.slice(0, 3).map((m, idx) => /*#__PURE__*/(0, _reactJsxRuntime.jsx)(View.default, {
            style: [styles.avatarPip, {
              backgroundColor: m.avatarColor || c.league,
              borderColor: c.card,
              marginLeft: idx === 0 ? 0 : -6
            }],
            children: /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
              style: styles.avatarPipText,
              children: (m.displayName || "P")[0].toUpperCase()
            })
          }, m.uid))
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.leagueOnText, {
            color: c.league
          }],
          children: leagueMembers.length === 1 ? `${leagueMembers[0].displayName} on this` : `${leagueMembers.length} in league on this`
        })]
      });
      $[5] = c;
      $[6] = hasLeagueAction;
      $[7] = leagueMembers;
      $[8] = onLeaguePress;
      $[9] = t1;
    } else {
      t1 = $[9];
    }
    let t2;
    if ($[10] !== c.subtleForeground) {
      t2 = [styles.meta, {
        color: c.subtleForeground,
        flex: 1
      }];
      $[10] = c.subtleForeground;
      $[11] = t2;
    } else {
      t2 = $[11];
    }
    const t3 = bits.join("   ");
    let t4;
    if ($[12] !== t2 || $[13] !== t3) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t2,
        numberOfLines: 1,
        children: t3
      });
      $[12] = t2;
      $[13] = t3;
      $[14] = t4;
    } else {
      t4 = $[14];
    }
    let t5;
    if ($[15] !== c.mutedForeground || $[16] !== game.status || $[17] !== isLocked) {
      t5 = isLocked && game.status === "live" && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.meta, {
          color: c.mutedForeground
        }],
        children: "Betting Closed"
      });
      $[15] = c.mutedForeground;
      $[16] = game.status;
      $[17] = isLocked;
      $[18] = t5;
    } else {
      t5 = $[18];
    }
    let t6;
    if ($[19] !== c || $[20] !== modelLine) {
      t6 = modelLine && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        accessible: true,
        accessibilityLabel: "SportDrip model line. No sportsbook line yet.",
        style: [styles.noLinePill, {
          backgroundColor: c.alpha(c.accent, 0.14)
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "chart-bell-curve-cumulative",
          size: 11,
          color: c.accent
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.noLinePillText, {
            color: c.accent
          }],
          children: "Model Line"
        })]
      });
      $[19] = c;
      $[20] = modelLine;
      $[21] = t6;
    } else {
      t6 = $[21];
    }
    let t7;
    if ($[22] !== c || $[23] !== noLine) {
      t7 = noLine && /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.noLinePill, {
          backgroundColor: c.alpha(c.warning, 0.14)
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "clock-outline",
          size: 11,
          color: c.warning
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.noLinePillText, {
            color: c.warning
          }],
          children: _libOdds.NO_LINE
        })]
      });
      $[22] = c;
      $[23] = noLine;
      $[24] = t7;
    } else {
      t7 = $[24];
    }
    let t8;
    if ($[25] !== t1 || $[26] !== t4 || $[27] !== t5 || $[28] !== t6 || $[29] !== t7) {
      t8 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.footer,
        children: [t1, t4, t5, t6, t7]
      });
      $[25] = t1;
      $[26] = t4;
      $[27] = t5;
      $[28] = t6;
      $[29] = t7;
      $[30] = t8;
    } else {
      t8 = $[30];
    }
    return t8;
  }
  function PositionStrip(t0) {
    const $ = (0, _reactCompilerRuntime.c)(37);
    const {
      game,
      position,
      c
    } = t0;
    const backed = position.side === "home" ? game.homeTeam : game.awayTeam;
    const mine = position.side === "home" ? game.homeScore : game.awayScore;
    const theirs = position.side === "home" ? game.awayScore : game.homeScore;
    let t1;
    if ($[0] !== c.negative || $[1] !== c.positive || $[2] !== c.push || $[3] !== game.status || $[4] !== mine || $[5] !== theirs) {
      t1 = mine === null || theirs === null ? null : mine === theirs ? {
        label: "Level",
        color: c.push
      } : mine > theirs ? {
        label: game.status === "final" ? "Won" : "Ahead",
        color: c.positive
      } : {
        label: game.status === "final" ? "Lost" : "Behind",
        color: c.negative
      };
      $[0] = c.negative;
      $[1] = c.positive;
      $[2] = c.push;
      $[3] = game.status;
      $[4] = mine;
      $[5] = theirs;
      $[6] = t1;
    } else {
      t1 = $[6];
    }
    const state = t1;
    const t2 = c.primarySoft;
    let t3;
    if ($[7] !== c) {
      t3 = c.alpha(c.primary, 0.3);
      $[7] = c;
      $[8] = t3;
    } else {
      t3 = $[8];
    }
    let t4;
    if ($[9] !== c.primarySoft || $[10] !== t3) {
      t4 = [styles.position, {
        backgroundColor: t2,
        borderColor: t3
      }];
      $[9] = c.primarySoft;
      $[10] = t3;
      $[11] = t4;
    } else {
      t4 = $[11];
    }
    let t5;
    if ($[12] !== c.primary) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "ticket-confirmation-outline",
        size: 14,
        color: c.primary
      });
      $[12] = c.primary;
      $[13] = t5;
    } else {
      t5 = $[13];
    }
    let t6;
    if ($[14] !== c.foreground) {
      t6 = [styles.positionText, {
        color: c.foreground
      }];
      $[14] = c.foreground;
      $[15] = t6;
    } else {
      t6 = $[15];
    }
    let t7;
    if ($[16] !== position.stake) {
      t7 = position.stake.toLocaleString();
      $[16] = position.stake;
      $[17] = t7;
    } else {
      t7 = $[17];
    }
    const t8 = position.label ?? backed.abbreviation;
    let t9;
    if ($[18] !== c.primary) {
      t9 = {
        color: c.primary
      };
      $[18] = c.primary;
      $[19] = t9;
    } else {
      t9 = $[19];
    }
    let t10;
    if ($[20] !== position.potentialPayout) {
      t10 = position.potentialPayout.toLocaleString();
      $[20] = position.potentialPayout;
      $[21] = t10;
    } else {
      t10 = $[21];
    }
    let t11;
    if ($[22] !== t10 || $[23] !== t9) {
      t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t9,
        children: t10
      });
      $[22] = t10;
      $[23] = t9;
      $[24] = t11;
    } else {
      t11 = $[24];
    }
    let t12;
    if ($[25] !== t11 || $[26] !== t6 || $[27] !== t7 || $[28] !== t8) {
      t12 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: t6,
        numberOfLines: 1,
        children: [t7, " on ", t8, " to return", " ", t11]
      });
      $[25] = t11;
      $[26] = t6;
      $[27] = t7;
      $[28] = t8;
      $[29] = t12;
    } else {
      t12 = $[29];
    }
    let t13;
    if ($[30] !== state) {
      t13 = state && /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.positionState, {
          color: state.color
        }],
        children: state.label
      });
      $[30] = state;
      $[31] = t13;
    } else {
      t13 = $[31];
    }
    let t14;
    if ($[32] !== t12 || $[33] !== t13 || $[34] !== t4 || $[35] !== t5) {
      t14 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t4,
        children: [t5, t12, t13]
      });
      $[32] = t12;
      $[33] = t13;
      $[34] = t4;
      $[35] = t5;
      $[36] = t14;
    } else {
      t14 = $[36];
    }
    return t14;
  }
  const styles = StyleSheet.default.create({
    card: {
      borderRadius: 16,
      borderWidth: 1,
      padding: 14,
      marginBottom: 10,
      gap: 10
    },
    header: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8
    },
    headerRight: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6,
      marginLeft: "auto",
      flexShrink: 0,
      maxWidth: "62%"
    },
    sportChip: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
      paddingHorizontal: 7,
      paddingVertical: 3,
      borderRadius: 999,
      flexShrink: 0
    },
    sportText: {
      fontSize: 11,
      fontFamily: "Inter_800ExtraBold",
      letterSpacing: 0.8
    },
    // Long season labels ("Premier League · Regular Season") truncate instead of pushing the status off-screen.
    meta: {
      flex: 1,
      flexShrink: 1,
      minWidth: 0,
      fontSize: 11,
      fontFamily: "Inter_400Regular"
    },
    statusText: {
      fontSize: 12,
      fontFamily: "Inter_600SemiBold"
    },
    liveDot: {
      width: 6,
      height: 6,
      borderRadius: 3
    },
    liveBadge: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
      paddingHorizontal: 6,
      paddingVertical: 2,
      borderRadius: 5
    },
    liveText: {
      color: "#fff",
      fontSize: 11,
      fontFamily: "Inter_900Black",
      letterSpacing: 0.8
    },
    colHead: {
      flexDirection: "row",
      alignItems: "center",
      marginBottom: -4
    },
    colLabel: {
      flex: 1,
      fontSize: 11,
      fontFamily: "Inter_800ExtraBold",
      letterSpacing: 1
    },
    colOdds: {
      flex: 0,
      width: 80,
      textAlign: "center"
    },
    teams: {
      gap: 10
    },
    teamRow: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10
    },
    logo: {
      width: 30,
      height: 30,
      borderRadius: 8
    },
    logoFallback: {
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1
    },
    logoText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold"
    },
    teamText: {
      flex: 1,
      gap: 2
    },
    nameLine: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6
    },
    rank: {
      fontSize: 11,
      fontFamily: "Inter_700Bold"
    },
    teamName: {
      fontSize: 15,
      fontFamily: "Inter_700Bold",
      flexShrink: 1,
      letterSpacing: -0.2
    },
    record: {
      fontSize: 11,
      fontFamily: "Inter_500Medium"
    },
    form: {
      flexDirection: "row",
      gap: 3
    },
    formPip: {
      width: 12,
      height: 3,
      borderRadius: 2
    },
    score: {
      fontSize: 22,
      fontFamily: "Inter_900Black",
      minWidth: 32,
      textAlign: "right",
      letterSpacing: -0.5
    },
    oddsBtn: {
      width: 80,
      borderWidth: 1,
      borderRadius: 10,
      paddingVertical: 8,
      alignItems: "center",
      gap: 1
    },
    oddsFlash: {
      position: "absolute",
      top: -1,
      left: -1,
      right: -1,
      bottom: -1,
      borderRadius: 10,
      borderWidth: 2
    },
    oddsLine: {
      flexDirection: "row",
      alignItems: "center"
    },
    oddsValue: {
      fontSize: 15,
      fontFamily: "Inter_900Black",
      fontVariant: ["tabular-nums"],
      letterSpacing: -0.3
    },
    oddsProb: {
      fontSize: 11,
      fontFamily: "Inter_500Medium",
      fontVariant: ["tabular-nums"]
    },
    noLine: {
      fontSize: 12,
      fontFamily: "Inter_700Bold"
    },
    noLinePill: {
      flexDirection: "row",
      alignItems: "center",
      gap: 4,
      paddingHorizontal: 7,
      paddingVertical: 2,
      borderRadius: 999
    },
    noLinePillText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold",
      letterSpacing: 0.2
    },
    marketStrip: {
      flexDirection: "row",
      flexWrap: "wrap",
      gap: 6
    },
    group: {
      gap: 6,
      borderTopWidth: StyleSheet.default.hairlineWidth,
      paddingTop: 10
    },
    cta: {
      gap: 8,
      borderWidth: 1,
      borderRadius: 12,
      padding: 10
    },
    ctaText: {
      fontSize: 13,
      fontFamily: "Inter_700Bold"
    },
    ctaRow: {
      flexDirection: "row",
      gap: 8
    },
    marketChip: {
      flex: 1,
      minWidth: 74,
      borderWidth: 1,
      borderRadius: 10,
      paddingVertical: 8,
      paddingHorizontal: 8,
      alignItems: "center",
      gap: 1
    },
    marketChipLabel: {
      fontSize: 13,
      fontFamily: "Inter_700Bold",
      fontVariant: ["tabular-nums"]
    },
    marketChipOdds: {
      fontSize: 11,
      fontFamily: "Inter_500Medium",
      fontVariant: ["tabular-nums"]
    },
    bar: {
      flexDirection: "row",
      height: 4,
      borderRadius: 2,
      overflow: "hidden"
    },
    footer: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      flexWrap: "wrap"
    },
    leagueOnChip: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6,
      borderWidth: 1,
      borderRadius: 999,
      paddingHorizontal: 8,
      paddingVertical: 3
    },
    avatarStack: {
      flexDirection: "row",
      alignItems: "center"
    },
    avatarPip: {
      width: 16,
      height: 16,
      borderRadius: 8,
      borderWidth: 1.5,
      alignItems: "center",
      justifyContent: "center"
    },
    avatarPipText: {
      color: "#fff",
      fontSize: 11,
      fontFamily: "Inter_800ExtraBold"
    },
    leagueOnText: {
      fontSize: 11,
      fontFamily: "Inter_700Bold"
    },
    position: {
      flexDirection: "row",
      alignItems: "center",
      gap: 7,
      borderWidth: 1,
      borderRadius: 10,
      paddingHorizontal: 10,
      paddingVertical: 7
    },
    positionText: {
      flex: 1,
      fontSize: 12,
      fontFamily: "Inter_500Medium"
    },
    positionState: {
      fontSize: 11,
      fontFamily: "Inter_700Bold"
    }
  });
},847,[815,818,866,820,12,104,28,188,109,827,867,868,836,819,869,864,870,816,865,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return FeaturedGameCard;
    }
  });
  exports.pickFeatured = pickFeatured;
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoVectorIcons = require(_dependencyMap[1]);
  var _expoLinearGradient = require(_dependencyMap[2]);
  require(_dependencyMap[3]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[4]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[5]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[6]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsFxPressableScale = require(_dependencyMap[7]);
  var PressableScale = _interopDefault(_componentsFxPressableScale);
  var _componentsFxShimmer = require(_dependencyMap[8]);
  var Shimmer = _interopDefault(_componentsFxShimmer);
  var _componentsTeamCrest = require(_dependencyMap[9]);
  var TeamCrest = _interopDefault(_componentsTeamCrest);
  var _hooksUseColors = require(_dependencyMap[10]);
  var _libMotion = require(_dependencyMap[11]);
  var _libOdds = require(_dependencyMap[12]);
  var _libSettings = require(_dependencyMap[13]);
  var _typesGame = require(_dependencyMap[14]);
  var _reactJsxRuntime = require(_dependencyMap[15]);
  const SPORT_WEIGHT = {
    NFL: 5,
    NBA: 3,
    NCAAF: 3,
    MLB: 2,
    NHL: 2,
    NCAAB: 2,
    Soccer: 2
  };

  /**
   * Game of the Night: the upcoming game (next 24h) with the most of your
   * league-mates on it; else one with your favorite team; else the biggest
   * matchup on the board, preferring prime time and a close line.
   */
  function pickFeatured(games, sides, favorites, now) {
    const pool = games.filter(g => g.status === "upcoming" && !g.disrupted && g.startsAt > now && g.startsAt - now < 86400000);
    if (!pool.length) return null;
    const score = g => {
      const crowd = (sides.get(g.id) ?? []).length * 10;
      const fav = favorites.has(`${g.sport}:${g.homeTeam.abbreviation}`) || favorites.has(`${g.sport}:${g.awayTeam.abbreviation}`) ? 8 : 0;
      const hour = new Date(g.startsAt).getHours();
      const prime = hour >= 19 && hour <= 21 ? 2 : 0;
      const p = (0, _typesGame.isPriced)(g) ? (0, _libOdds.fairProbabilities)(g.homeTeam.odds, g.awayTeam.odds) : null;
      const close = p ? 2 - Math.abs(p.home - p.away) * 2 : 0;
      return crowd + fav + prime + close + (SPORT_WEIGHT[g.sport] ?? 1);
    };
    return pool.slice().sort((a, b) => score(b) - score(a) || a.startsAt - b.startsAt)[0] ?? null;
  }
  function FeaturedGameCard(t0) {
    const $ = (0, _reactCompilerRuntime.c)(120);
    const {
      game,
      sides,
      onOpen
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const fmt = (0, _libSettings.useOddsFormat)();
    let t1;
    if ($[0] !== game) {
      t1 = (0, _typesGame.isPriced)(game);
      $[0] = game;
      $[1] = t1;
    } else {
      t1 = $[1];
    }
    const priced = t1;
    let T0;
    let T1;
    let T2;
    let crowd;
    let t10;
    let t11;
    let t12;
    let t13;
    let t14;
    let t15;
    let t16;
    let t17;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[2] !== c || $[3] !== fmt || $[4] !== game || $[5] !== onOpen || $[6] !== priced || $[7] !== sides) {
      const p = priced ? (0, _libOdds.fairProbabilities)(game.homeTeam.odds, game.awayTeam.odds) : null;
      let t18;
      if ($[28] !== sides) {
        t18 = sides.filter(_temp);
        $[28] = sides;
        $[29] = t18;
      } else {
        t18 = $[29];
      }
      const onHome = t18.length;
      let t19;
      if ($[30] !== sides) {
        t19 = sides.filter(_temp2);
        $[30] = sides;
        $[31] = t19;
      } else {
        t19 = $[31];
      }
      const onAway = t19.length;
      let t20;
      if ($[32] !== sides) {
        t20 = sides.filter(_temp3);
        $[32] = sides;
        $[33] = t20;
      } else {
        t20 = $[33];
      }
      const hidden = t20.length;
      crowd = sides.length ? `${sides.length} league-mate${sides.length > 1 ? "s" : ""} on this · ${game.awayTeam.abbreviation} ${onAway} – ${onHome} ${game.homeTeam.abbreviation}${hidden ? ` · ${hidden} hidden` : ""}` : null;
      T2 = PressableScale.default;
      t12 = "button";
      const t21 = game.awayTeam.name;
      const t22 = game.homeTeam.name;
      let t23;
      if ($[34] !== game.startsAt) {
        t23 = (0, _libOdds.kickoffLabel)(game.startsAt);
        $[34] = game.startsAt;
        $[35] = t23;
      } else {
        t23 = $[35];
      }
      t13 = `Game of the Night: ${t21} at ${t22}, ${t23}`;
      if ($[36] !== game || $[37] !== onOpen) {
        t14 = () => {
          _libMotion.haptic.light();
          onOpen(game);
        };
        $[36] = game;
        $[37] = onOpen;
        $[38] = t14;
      } else {
        t14 = $[38];
      }
      if ($[39] !== c.primary) {
        t15 = [styles.card, {
          borderColor: c.primary
        }];
        $[39] = c.primary;
        $[40] = t15;
      } else {
        t15 = $[40];
      }
      let t24;
      if ($[41] !== c || $[42] !== game.awayTeam.color) {
        t24 = c.alpha(game.awayTeam.color, 0.4);
        $[41] = c;
        $[42] = game.awayTeam.color;
        $[43] = t24;
      } else {
        t24 = $[43];
      }
      const t25 = c.elevated;
      let t26;
      if ($[44] !== c || $[45] !== game.homeTeam.color) {
        t26 = c.alpha(game.homeTeam.color, 0.4);
        $[44] = c;
        $[45] = game.homeTeam.color;
        $[46] = t26;
      } else {
        t26 = $[46];
      }
      let t27;
      if ($[47] !== c.elevated || $[48] !== t24 || $[49] !== t26) {
        t27 = [t24, t25, t26];
        $[47] = c.elevated;
        $[48] = t24;
        $[49] = t26;
        $[50] = t27;
      } else {
        t27 = $[50];
      }
      let t28;
      let t29;
      if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = {
          x: 0,
          y: 0.5
        };
        t29 = {
          x: 1,
          y: 0.5
        };
        $[51] = t28;
        $[52] = t29;
      } else {
        t28 = $[51];
        t29 = $[52];
      }
      if ($[53] !== t27) {
        t16 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoLinearGradient.LinearGradient, {
          colors: t27,
          start: t28,
          end: t29,
          style: StyleSheet.default.absoluteFill
        });
        $[53] = t27;
        $[54] = t16;
      } else {
        t16 = $[54];
      }
      let t30;
      if ($[55] !== c.primary) {
        t30 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "star-four-points",
          size: 14,
          color: c.primary
        });
        $[55] = c.primary;
        $[56] = t30;
      } else {
        t30 = $[56];
      }
      let t31;
      if ($[57] !== c.primary) {
        t31 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.kicker, {
            color: c.primary
          }],
          children: "GAME OF THE NIGHT"
        });
        $[57] = c.primary;
        $[58] = t31;
      } else {
        t31 = $[58];
      }
      let t32;
      if ($[59] !== c.mutedForeground) {
        t32 = [styles.when, {
          color: c.mutedForeground
        }];
        $[59] = c.mutedForeground;
        $[60] = t32;
      } else {
        t32 = $[60];
      }
      const t33 = game.sport;
      let t34;
      if ($[61] !== game.startsAt) {
        t34 = (0, _libOdds.untilKickoff)(game.startsAt);
        $[61] = game.startsAt;
        $[62] = t34;
      } else {
        t34 = $[62];
      }
      let t35;
      if ($[63] !== game.sport || $[64] !== t32 || $[65] !== t34) {
        t35 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
          style: t32,
          children: [t33, " \xB7 ", t34]
        });
        $[63] = game.sport;
        $[64] = t32;
        $[65] = t34;
        $[66] = t35;
      } else {
        t35 = $[66];
      }
      if ($[67] !== t30 || $[68] !== t31 || $[69] !== t35) {
        t17 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
          style: styles.head,
          children: [t30, t31, t35]
        });
        $[67] = t30;
        $[68] = t31;
        $[69] = t35;
        $[70] = t17;
      } else {
        t17 = $[70];
      }
      T1 = View.default;
      t9 = styles.row;
      let t36;
      if ($[71] !== fmt || $[72] !== game.awayTeam.odds || $[73] !== priced) {
        t36 = priced ? (0, _libOdds.formatOdds)(game.awayTeam.odds, fmt) : null;
        $[71] = fmt;
        $[72] = game.awayTeam.odds;
        $[73] = priced;
        $[74] = t36;
      } else {
        t36 = $[74];
      }
      t10 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Side, {
        sport: game.sport,
        abbr: game.awayTeam.abbreviation,
        name: game.awayTeam.name,
        color: game.awayTeam.color,
        alt: game.awayTeam.altColor,
        odds: t36,
        pct: p ? (0, _libOdds.formatPercent)(p.away) : null
      });
      if ($[75] !== c.mutedForeground) {
        t11 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.at, {
            color: c.mutedForeground
          }],
          children: "@"
        });
        $[75] = c.mutedForeground;
        $[76] = t11;
      } else {
        t11 = $[76];
      }
      T0 = Side;
      t2 = game.sport;
      t3 = game.homeTeam.abbreviation;
      t4 = game.homeTeam.name;
      t5 = game.homeTeam.color;
      t6 = game.homeTeam.altColor;
      if ($[77] !== fmt || $[78] !== game.homeTeam.odds || $[79] !== priced) {
        t7 = priced ? (0, _libOdds.formatOdds)(game.homeTeam.odds, fmt) : null;
        $[77] = fmt;
        $[78] = game.homeTeam.odds;
        $[79] = priced;
        $[80] = t7;
      } else {
        t7 = $[80];
      }
      t8 = p ? (0, _libOdds.formatPercent)(p.home) : null;
      $[2] = c;
      $[3] = fmt;
      $[4] = game;
      $[5] = onOpen;
      $[6] = priced;
      $[7] = sides;
      $[8] = T0;
      $[9] = T1;
      $[10] = T2;
      $[11] = crowd;
      $[12] = t10;
      $[13] = t11;
      $[14] = t12;
      $[15] = t13;
      $[16] = t14;
      $[17] = t15;
      $[18] = t16;
      $[19] = t17;
      $[20] = t2;
      $[21] = t3;
      $[22] = t4;
      $[23] = t5;
      $[24] = t6;
      $[25] = t7;
      $[26] = t8;
      $[27] = t9;
    } else {
      T0 = $[8];
      T1 = $[9];
      T2 = $[10];
      crowd = $[11];
      t10 = $[12];
      t11 = $[13];
      t12 = $[14];
      t13 = $[15];
      t14 = $[16];
      t15 = $[17];
      t16 = $[18];
      t17 = $[19];
      t2 = $[20];
      t3 = $[21];
      t4 = $[22];
      t5 = $[23];
      t6 = $[24];
      t7 = $[25];
      t8 = $[26];
      t9 = $[27];
    }
    let t18;
    if ($[81] !== T0 || $[82] !== t2 || $[83] !== t3 || $[84] !== t4 || $[85] !== t5 || $[86] !== t6 || $[87] !== t7 || $[88] !== t8) {
      t18 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(T0, {
        sport: t2,
        abbr: t3,
        name: t4,
        color: t5,
        alt: t6,
        odds: t7,
        pct: t8
      });
      $[81] = T0;
      $[82] = t2;
      $[83] = t3;
      $[84] = t4;
      $[85] = t5;
      $[86] = t6;
      $[87] = t7;
      $[88] = t8;
      $[89] = t18;
    } else {
      t18 = $[89];
    }
    let t19;
    if ($[90] !== T1 || $[91] !== t10 || $[92] !== t11 || $[93] !== t18 || $[94] !== t9) {
      t19 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T1, {
        style: t9,
        children: [t10, t11, t18]
      });
      $[90] = T1;
      $[91] = t10;
      $[92] = t11;
      $[93] = t18;
      $[94] = t9;
      $[95] = t19;
    } else {
      t19 = $[95];
    }
    let t20;
    if ($[96] !== c || $[97] !== crowd) {
      t20 = crowd ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: [styles.crowd, {
          backgroundColor: c.alpha(c.league, 0.16)
        }],
        children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
          name: "account-group",
          size: 14,
          color: c.league
        }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
          style: [styles.crowdText, {
            color: c.foreground
          }],
          numberOfLines: 1,
          children: crowd
        })]
      }) : null;
      $[96] = c;
      $[97] = crowd;
      $[98] = t20;
    } else {
      t20 = $[98];
    }
    let t21;
    if ($[99] !== c.primary) {
      t21 = [styles.cta, {
        backgroundColor: c.primary
      }];
      $[99] = c.primary;
      $[100] = t21;
    } else {
      t21 = $[100];
    }
    let t22;
    let t23;
    if ($[101] !== c.primaryForeground) {
      t22 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: [styles.ctaText, {
          color: c.primaryForeground
        }],
        children: "Make Your Pick"
      });
      t23 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoVectorIcons.MaterialCommunityIcons, {
        name: "chevron-right",
        size: 18,
        color: c.primaryForeground
      });
      $[101] = c.primaryForeground;
      $[102] = t22;
      $[103] = t23;
    } else {
      t22 = $[102];
      t23 = $[103];
    }
    let t24;
    if ($[104] === Symbol.for("react.memo_cache_sentinel")) {
      t24 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Shimmer.default, {
        every: 3000
      });
      $[104] = t24;
    } else {
      t24 = $[104];
    }
    let t25;
    if ($[105] !== t21 || $[106] !== t22 || $[107] !== t23) {
      t25 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: t21,
        children: [t22, t23, t24]
      });
      $[105] = t21;
      $[106] = t22;
      $[107] = t23;
      $[108] = t25;
    } else {
      t25 = $[108];
    }
    let t26;
    if ($[109] !== T2 || $[110] !== t12 || $[111] !== t13 || $[112] !== t14 || $[113] !== t15 || $[114] !== t16 || $[115] !== t17 || $[116] !== t19 || $[117] !== t20 || $[118] !== t25) {
      t26 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(T2, {
        accessibilityRole: t12,
        accessibilityLabel: t13,
        onPress: t14,
        style: t15,
        children: [t16, t17, t19, t20, t25]
      });
      $[109] = T2;
      $[110] = t12;
      $[111] = t13;
      $[112] = t14;
      $[113] = t15;
      $[114] = t16;
      $[115] = t17;
      $[116] = t19;
      $[117] = t20;
      $[118] = t25;
      $[119] = t26;
    } else {
      t26 = $[119];
    }
    return t26;
  }
  function _temp3(s_1) {
    return s_1.side === null;
  }
  function _temp2(s_0) {
    return s_0.side === "away";
  }
  function _temp(s) {
    return s.side === "home";
  }
  function Side(t0) {
    const $ = (0, _reactCompilerRuntime.c)(18);
    const {
      sport,
      abbr,
      name,
      color,
      alt,
      odds,
      pct
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    let t1;
    if ($[0] !== abbr || $[1] !== alt || $[2] !== color || $[3] !== sport) {
      t1 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(TeamCrest.default, {
        abbr: abbr,
        color: color,
        altColor: alt,
        size: 44,
        sport: sport
      });
      $[0] = abbr;
      $[1] = alt;
      $[2] = color;
      $[3] = sport;
      $[4] = t1;
    } else {
      t1 = $[4];
    }
    let t2;
    if ($[5] !== c.foreground) {
      t2 = [styles.name, {
        color: c.foreground
      }];
      $[5] = c.foreground;
      $[6] = t2;
    } else {
      t2 = $[6];
    }
    let t3;
    if ($[7] !== name || $[8] !== t2) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        style: t2,
        numberOfLines: 1,
        children: name
      });
      $[7] = name;
      $[8] = t2;
      $[9] = t3;
    } else {
      t3 = $[9];
    }
    let t4;
    if ($[10] !== c.mutedForeground || $[11] !== odds || $[12] !== pct) {
      t4 = odds ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.odds, {
          color: c.mutedForeground
        }],
        children: [odds, " \xB7 ", pct]
      }) : null;
      $[10] = c.mutedForeground;
      $[11] = odds;
      $[12] = pct;
      $[13] = t4;
    } else {
      t4 = $[13];
    }
    let t5;
    if ($[14] !== t1 || $[15] !== t3 || $[16] !== t4) {
      t5 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
        style: styles.side,
        children: [t1, t3, t4]
      });
      $[14] = t1;
      $[15] = t3;
      $[16] = t4;
      $[17] = t5;
    } else {
      t5 = $[17];
    }
    return t5;
  }
  const styles = StyleSheet.default.create({
    card: {
      borderRadius: 20,
      borderWidth: 1.5,
      padding: 14,
      gap: 12,
      overflow: "hidden",
      marginBottom: 6
    },
    head: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6
    },
    kicker: {
      flex: 1,
      fontSize: 11,
      letterSpacing: 1.4,
      fontFamily: "Inter_900Black"
    },
    when: {
      fontSize: 12,
      fontFamily: "Inter_700Bold"
    },
    row: {
      flexDirection: "row",
      alignItems: "center"
    },
    side: {
      flex: 1,
      alignItems: "center",
      gap: 4
    },
    name: {
      fontSize: 14,
      fontFamily: "Inter_800ExtraBold",
      textAlign: "center"
    },
    odds: {
      fontSize: 12,
      fontFamily: "Inter_600SemiBold",
      fontVariant: ["tabular-nums"]
    },
    at: {
      fontSize: 16,
      fontFamily: "Inter_700Bold",
      paddingHorizontal: 6
    },
    crowd: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6,
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 10
    },
    crowdText: {
      flex: 1,
      fontSize: 12,
      fontFamily: "Inter_600SemiBold"
    },
    cta: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 4,
      paddingVertical: 11,
      borderRadius: 999,
      overflow: "hidden"
    },
    ctaText: {
      fontSize: 15,
      fontFamily: "Inter_800ExtraBold"
    }
  });
},848,[815,818,871,12,28,188,109,868,872,866,819,820,870,816,865,6]);
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return TailSheet;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  require(_dependencyMap[1]);
  var _reactNativeWebDistExportsStyleSheet = require(_dependencyMap[2]);
  var StyleSheet = _interopDefault(_reactNativeWebDistExportsStyleSheet);
  var _reactNativeWebDistExportsText = require(_dependencyMap[3]);
  var Text = _interopDefault(_reactNativeWebDistExportsText);
  var _reactNativeWebDistExportsView = require(_dependencyMap[4]);
  var View = _interopDefault(_reactNativeWebDistExportsView);
  var _componentsKeyboardSheet = require(_dependencyMap[5]);
  var KeyboardSheet = _interopDefault(_componentsKeyboardSheet);
  var _componentsUi = require(_dependencyMap[6]);
  var _constantsTheme = require(_dependencyMap[7]);
  var theme = _interopDefault(_constantsTheme);
  var _contextLeagueContext = require(_dependencyMap[8]);
  var _hooksUseColors = require(_dependencyMap[9]);
  var _libMotion = require(_dependencyMap[10]);
  var _reactJsxRuntime = require(_dependencyMap[11]);
  /**
   * "League is on this" → who's on which side. Names and sides only, never stake;
   * hidden picks (side === null) stay hidden. Tail / Fade hand off to the slip with
   * that member's league wallet preselected.
   */
  function TailSheet(t0) {
    const $ = (0, _reactCompilerRuntime.c)(31);
    const {
      game,
      members,
      onClose,
      onFollow
    } = t0;
    const c = (0, _hooksUseColors.useColors)();
    const {
      leagues
    } = (0, _contextLeagueContext.useLeague)();
    const open = !!game && game.status === "upcoming" && !game.disrupted;
    let t1;
    if ($[0] !== game || $[1] !== onFollow) {
      t1 = (m, kind) => {
        if (!game || !m.side) {
          return;
        }
        _libMotion.haptic.tick();
        const theirs = m.side === "home" ? game.homeTeam : game.awayTeam;
        onFollow(game.id, {
          betId: m.betId,
          kind,
          leagueId: m.leagueId,
          name: m.displayName,
          side: kind === "tail" ? m.side : m.side === "home" ? "away" : "home",
          stake: 0,
          sourceTeamAbbr: theirs.abbreviation
        });
      };
      $[0] = game;
      $[1] = onFollow;
      $[2] = t1;
    } else {
      t1 = $[2];
    }
    const follow = t1;
    const t2 = !!game;
    let t3;
    if ($[3] !== c.foreground) {
      t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
        accessibilityRole: "header",
        style: [styles.title, {
          color: c.foreground
        }],
        children: "League is on this"
      });
      $[3] = c.foreground;
      $[4] = t3;
    } else {
      t3 = $[4];
    }
    let t4;
    if ($[5] !== c.mutedForeground || $[6] !== game) {
      t4 = game ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(Text.default, {
        style: [styles.sub, {
          color: c.mutedForeground
        }],
        children: [game.awayTeam.abbreviation, " @ ", game.homeTeam.abbreviation]
      }) : null;
      $[5] = c.mutedForeground;
      $[6] = game;
      $[7] = t4;
    } else {
      t4 = $[7];
    }
    let t5;
    if ($[8] !== c.border || $[9] !== c.foreground || $[10] !== c.mutedForeground || $[11] !== follow || $[12] !== game || $[13] !== leagues || $[14] !== members || $[15] !== open) {
      let t6;
      if ($[17] !== c.border || $[18] !== c.foreground || $[19] !== c.mutedForeground || $[20] !== follow || $[21] !== game || $[22] !== leagues || $[23] !== open) {
        t6 = m_0 => {
          const team = !game || !m_0.side ? null : m_0.side === "home" ? game.homeTeam : game.awayTeam;
          const league = leagues.find(l => l.id === m_0.leagueId);
          return /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
            style: [styles.row, {
              borderColor: c.border
            }],
            children: [/*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: {
                flex: 1,
                gap: 2
              },
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.name, {
                  color: c.foreground
                }],
                numberOfLines: 1,
                children: m_0.displayName
              }), league ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(Text.default, {
                style: [styles.sub, {
                  color: c.mutedForeground
                }],
                numberOfLines: 1,
                children: league.name
              }) : null]
            }), team ? /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
              label: team.abbreviation,
              tone: "league"
            }) : /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.Pill, {
              label: "hidden",
              icon: "lock"
            }), open && m_0.side ? /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(View.default, {
              style: styles.actions,
              children: [/*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
                label: "Tail",
                chevron: false,
                tone: "league",
                accessibilityLabel: `Tail ${m_0.displayName}`,
                onPress: () => follow(m_0, "tail")
              }), /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_componentsUi.ActionChip, {
                label: "Fade",
                chevron: false,
                tone: "neutral",
                accessibilityLabel: `Fade ${m_0.displayName}`,
                onPress: () => follow(m_0, "fade")
              })]
            }) : null]
          }, `${m_0.leagueId}_${m_0.uid}`);
        };
        $[17] = c.border;
        $[18] = c.foreground;
        $[19] = c.mutedForeground;
        $[20] = follow;
        $[21] = game;
        $[22] = leagues;
        $[23] = open;
        $[24] = t6;
      } else {
        t6 = $[24];
      }
      t5 = members.map(t6);
      $[8] = c.border;
      $[9] = c.foreground;
      $[10] = c.mutedForeground;
      $[11] = follow;
      $[12] = game;
      $[13] = leagues;
      $[14] = members;
      $[15] = open;
      $[16] = t5;
    } else {
      t5 = $[16];
    }
    let t6;
    if ($[25] !== onClose || $[26] !== t2 || $[27] !== t3 || $[28] !== t4 || $[29] !== t5) {
      t6 = /*#__PURE__*/(0, _reactJsxRuntime.jsxs)(KeyboardSheet.default, {
        visible: t2,
        onClose: onClose,
        children: [t3, t4, t5]
      });
      $[25] = onClose;
      $[26] = t2;
      $[27] = t3;
      $[28] = t4;
      $[29] = t5;
      $[30] = t6;
    } else {
      t6 = $[30];
    }
    return t6;
  }
  const styles = StyleSheet.default.create({
    title: theme.default.type.heading,
    sub: theme.default.type.caption,
    name: theme.default.type.bodyStrong,
    row: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      paddingVertical: 10,
      borderBottomWidth: StyleSheet.default.hairlineWidth
    },
    actions: {
      flexDirection: "row",
      gap: 6
    }
  });
},849,[815,12,28,188,109,873,836,874,858,819,820,6]);