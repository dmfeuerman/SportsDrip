__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return JoinByLink;
    }
  });
  var _reactCompilerRuntime = require(_dependencyMap[0]);
  var _expoRouter = require(_dependencyMap[1]);
  var _react = require(_dependencyMap[2]);
  var _libAnalytics = require(_dependencyMap[3]);
  var _libInvites = require(_dependencyMap[4]);
  var _reactJsxRuntime = require(_dependencyMap[5]);
  /**
   * sportdrip://join/{CODE}
   *
   * Only reached by a signed-in, onboarded user: the root layout parks the code
   * and sends everyone else to login / onboarding first (lib/invites.ts). Here
   * the code goes straight to the Leagues tab's join sheet, which previews the
   * league and its buy-in before anything is charged.
   */
  function JoinByLink() {
    const $ = (0, _reactCompilerRuntime.c)(9);
    const params = (0, _expoRouter.useLocalSearchParams)();
    let t0;
    if ($[0] !== params.code) {
      t0 = (0, _libInvites.normalizeInviteCode)(params.code);
      $[0] = params.code;
      $[1] = t0;
    } else {
      t0 = $[1];
    }
    const code = t0;
    let t1;
    let t2;
    if ($[2] !== code) {
      t1 = () => {
        (0, _libInvites.clearPendingInvite)();
        if (code) {
          (0, _libAnalytics.trackEvent)("invite_code_captured", {
            code,
            signed_in: true,
            deferred: false
          });
        }
      };
      t2 = [code];
      $[2] = code;
      $[3] = t1;
      $[4] = t2;
    } else {
      t1 = $[3];
      t2 = $[4];
    }
    (0, _react.useEffect)(t1, t2);
    if (!code) {
      let t3;
      if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoRouter.Redirect, {
          href: "/(tabs)/leagues"
        });
        $[5] = t3;
      } else {
        t3 = $[5];
      }
      return t3;
    }
    let t3;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
      t3 = Date.now();
      $[6] = t3;
    } else {
      t3 = $[6];
    }
    let t4;
    if ($[7] !== code) {
      t4 = /*#__PURE__*/(0, _reactJsxRuntime.jsx)(_expoRouter.Redirect, {
        href: {
          pathname: "/(tabs)/leagues",
          params: {
            join: "1",
            code,
            via: "link",
            t: String(t3)
          }
        }
      });
      $[7] = code;
      $[8] = t4;
    } else {
      t4 = $[8];
    }
    return t4;
  }
},764,[815,817,12,897,1193,6]);